---
name: unity-animation-delivery
description: 用于设计师需要查找、新建、调整或交付 Unity Animation/.anim，包括入场、退场、按钮反馈、强调、呼吸和循环动画，配置 Animation、Animator 或项目实际的播放挂点，或用 Timeline 预演。适用于用途规范、动画目录、播放名、循环末帧、重播、程序接收和 harness 检查；Spine 动画制作、粒子转换和程序业务开发使用各自流程。
---

# 设计师 Animation 制作与交付

先从当前工程实际资产、导入设置、运行组件及已安装工具发现约定。用户指定范围与当前工程的实际行为优先。

把设计师的动效需求变成可编辑、可预演、程序能接收的 Unity 资源。下文 `Assets/...` 均相对 Unity 项目。设计师用自然语言提供需求，harness 整理参数并执行，不要求设计师写 JSON 或 C#。面向设计师的说明和交付单沿用用户语言；JSON 字段名与状态值保留合同中的英文。

## 请求路由

| 请求 | mode | 本次结果 |
|---|---|---|
| 查规范、找动画、检查现有设置 | `inspect` | 相关约定、实测设置、待核对项；不改资源 |
| 没有就新建、调整节奏、补挂载 | `prepare` | 保存 Clip/Prefab、验证并记录变更；已有资源原位更新 |
| 看整段方案、编排或修复预演 | `preview` | 保存 Timeline 与场景绑定，核对预演和独立播放 |
| 给程序、验交付、生成接收说明 | `handoff` | 交付单 + JSON 报告，区分资源就绪和程序接入 |

一个请求可以包含多个模式；`mode` 记录本次主要目标，`request.modes` 记录实际范围。仅查询时不强制制作、Timeline、录屏或设计验收。

读取 [工程约定](references/project-conventions.md) 中与目标有关的部分；查询用途规范或制作、修改、交付具体动效前，读取 [按用途制作规则](references/animation-purposes.md) 和 [用途配置](assets/purpose-profiles.json) 的相关用途，分别确定 purpose、phase、repeat_mode。需要修改或预演时读取 [Unity 执行方法](references/unity-operations.md)；执行自动化检查或输出交付结果时读取 [harness 合同](references/harness.md)。

## 执行

1. **定位**：从用户给出的页面、Prefab、Clip、选中对象或功能名找真实目标。确认播放组件节点、已有播放入口、视觉要求和本次范围。已知信息直接采用；目标歧义影响写入时只询问该项，其余检查继续。新制作缺少关键姿态/节奏时记录 `needs_design`，已有资源和基准仍可先检查。
2. **检查并形成变更计划**：读保存资产和相关播放器，记录 GUID、节点、注册名、时长、Wrap Mode、自动播放、曲线和受影响属性。按用途明确每段的初终态、完成/后继条件、停止者、复位与重播；在 `motion_contracts` 中区分拟定设置和实测设置。确认目录、复用还是专用 Clip、需要改的字段及程序配合项。明确需求范围内直接执行；不把常规设置再交回设计师批准。
3. **制作与保存**：用可用 Unity 工具/API 创建或原位调整。保留既有曲线、切线、事件、引用和 GUID；只改需求涉及部分。共享 Clip 的专用变体另建到功能目录。重复执行先查询并复用目标，拒绝同名不同 Clip 的静默替换。空 Clip 只算骨架，不能称动效已制作。
4. **回读与验证**：保存后从磁盘重载；检查挂点、曲线、组件/属性、Clip 注册与实际播放名。按本次变化验证首次播放、打断/停止、重播、初终态。需要 Timeline 时额外核对保存绑定及脱离 Timeline 的播放。视觉效果和程序接入分别记录证据。
5. **交付**：输出资源路径和简明程序接收单，并把报告保存到 `.local/reports/unity-animation-delivery/<任务名>/`，不要把报告写入 Skill 包或 `Assets/`。程序未接入可以交付就绪资源，不能称真实页面已验收。没有视觉确认可先交付标注缺项的草稿。

## 关键边界

- 查询当前 Timeline 轨道的注册、采样和混合行为，并独立核验正式播放器。
- ClampForever 保持末帧且仍在播放；Loop 要有停止者；再次 Play 同一正在播放的动画不会自动回到开头。
- PlayQueued(CompleteOthers) 的前段必须能自然结束；Press/Show 不为“保持末帧”无限占住队列。零跨度但有姿态键的 Hold/Loop 不能直接判坏；动态循环另查周期变化和接缝。用途规范不规定统一秒数、缩放比或全局自动播放开关。
- 本 Skill 不自动修改程序业务、生成 UI 类或资源加载逻辑。需要接收函数、专用播放入口、时间源或打断策略时标为 `needs_programmer` 并写清合同。

## 可运行检查

只读磁盘预检，不需 Unity 或额外 Python 库：

```sh
python3 "$SKILL_DIR/scripts/audit.py" --project-root "$PROJECT_ROOT" --clip "$CLIP" --prefab "$PREFAB"
```

参数可重复。输出符合 [报告 Schema](assets/report.schema.json)。脚本只读取序列化设置、GUID 和 Animation 块内引用，嵌套/变体、挂点、注册别名、曲线正确性和播放结果留待 Unity 检查。退出码 0 表示静态检查未发现 `failed`，不代表整体交付通过；1 为发现失败，2 为调用错误。

设计师示例：`$unity-animation-delivery 给这个奖励弹窗做 0.65 秒入场，结束保持落位，生成预演和程序交付单。`
