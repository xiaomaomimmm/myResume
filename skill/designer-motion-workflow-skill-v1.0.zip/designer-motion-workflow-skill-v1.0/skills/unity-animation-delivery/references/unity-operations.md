# Unity 自动化执行方法

按任务选择操作；这些是 harness 使用的 Unity API 配方，不是设计师要手写的程序。不要把此处方法名直接当作 MCP action；先读取当前工具 schema，再映射调用。

## 能力发现与环境

1. 有 Unity MCP 时读取 `mcpforunity://custom-tools`、`mcpforunity://instances`、`mcpforunity://editor/state` 和 `mcpforunity://project/info`，确认项目根和版本。多实例时锁定真实目标实例；不使用本资料的旧实例 ID。
2. 按当前 schema 使用 `manage_asset`、`manage_animation`、`manage_components`、`manage_prefabs`、`manage_scene` 等。`manage_animation` 可能主要支持 Animator，不能默认它产出 Legacy 对象。工具动作覆盖不足时，可用工程 `script-execute` 桥调用 Unity API。
3. 桥来源 `Assets/Editor/MCP/ScriptExecuteTool.cs`：通过 `execute_custom_tool`，`tool_name="script-execute"`，parameters 含 `code`、`class_name`、`method_name`。代码定义 public class 和 public static 无参方法。先确认自定义工具存在；涉及 API 用当前反射/源码核对。临时桥代码在内存编译，不必写临时 Editor 文件进工程。
4. 桥返回明确 success/data envelope，或写出指定报告后回读。裸集合曾出现 success=true/data=null；空数据不能算检查通过。检查 Console、编译与导入状态，再读取具体结果。
5. 无 Unity 时执行静态预检、整理参数/变更计划/交付草稿。Unity 才能验证的项标 pending，说明缺能力；不手改 .anim、Prefab、Timeline YAML 来伪造已制作结果。

维护用户的未保存场景和修改。Prefab 修改优先隔离 `LoadPrefabContents`；预演使用专用场景/临时实例。不要默认保存当前打开的全部场景，或退出 Play Mode 丢弃用户工作；确需切换而影响工作时再确认。

## 创建或更新 Clip

- 先完成本次 [用途合同](animation-purposes.md)：入退场、按下/按住/释放、确认点击、强调或持续周期分别处理。推荐 WrapMode 取决于实际完成/后继条件；不能统一按文件名设 Loop，也不能把所有入场设 ClampForever 后仍用 CompleteOthers 等它结束。
- 用 `AssetDatabase.LoadAssetAtPath<AnimationClip>(path)` / 查 GUID 找已有 Clip。已有资源原位修改；移动用 `AssetDatabase.MoveAsset` 保留 GUID，避免删除重建。
- 新建功能目录用 `AssetDatabase.IsValidFolder` / `CreateFolder`；新 Clip 使用 `new AnimationClip`，设置 name、与播放器匹配的 legacy、按需求及同类资源设置 frameRate、wrapMode，再 `AssetDatabase.CreateAsset`。仅在路径无既有资源时 CreateAsset。
- 复用通用曲线制作页面专用变体：先查目标相对路径，复制到专用功能目录（CopyAsset 或 Instantiate 后 CreateAsset）；新变体有新 GUID，原共享资源保持原样。用户确要全局修改时再检查消费者范围。
- 浮点曲线用 `AnimationUtility.GetCurveBindings/GetEditorCurve/SetEditorCurve`；对象引用曲线用 `GetObjectReferenceCurveBindings/GetObjectReferenceCurve/SetObjectReferenceCurve`；事件用 `GetAnimationEvents/SetAnimationEvents`。调整既有数据只改涉及的曲线、时间和字段，保留其它切线、权重、事件和引用。
- 时间改动要同时核对各条曲线、事件和 Clip 设置。通过 `AnimationUtility.GetAnimationClipSettings/SetAnimationClipSettings` 调整所需 loopTime 等。最终 `clip.length` 与首尾帧由 Unity 回读，不能只写 stopTime 或拉长 Timeline 段就宣称正式动画为指定时长。
- 新曲线以实际组件序列化属性为依据，确认 binding.path、binding.type、propertyName。对需要的属性显式设置初终帧；有已确认参考则按参考制作，缺关键视觉值保留草稿并说明。不要用默认缩放淡入替换已有设计方案。
- 段间衔接比较共同负责属性的前段终帧/后段首帧；动态循环检查周期变化、首尾值/切线和离散切换。静态 Hold 可有零时刻姿态键，不为通过“时长检查”给既有资源补任意1秒尾帧。快速 Release 和退场中途打断要用实际触发时姿态验证，不能假定都从前段末帧开始。
- `EditorUtility.SetDirty` 后保存相关资产。`AssetDatabase.SaveAssets` 可能保存其它脏资产，优先使用当前版本支持的定向保存方法；确需全局保存时先检查脏资产范围。

## 正式 Prefab 挂载与回读

- `PrefabUtility.LoadPrefabContents(path)`，按目标相对节点路径定位 GameObject，定位实际播放器组件；`finally` 中 `UnloadPrefabContents`。变体和嵌套 Prefab 保持层级与连接，只应用到需求指定层，不能通过展开 YAML 猜引用。
- 对 Animator 核对当前 Controller 层、状态、Clip 或 Override、过渡及重播入口。只在目标使用 Legacy Animation 时检查 `animation.GetClip(playName)`。无注册时 `AddClip(clip, playName)`；已有同名同 Clip 则复用；同名不同 Clip 时先查消费者和请求，不静默覆盖。保留其它注册及默认 Clip；只有任务明确要求才改默认 Clip、autoplay 和更新模式。
- 解析所有 float/object-reference bindings，确认节点、组件和属性存在；检查 missing script、丢失对象引用、动态布局/文本/换图冲突。运行时程序注册可作为接收合同，但必须定位真实代码和名称，不能拿 Timeline AddClip 作证明。
- `SaveAsPrefabAsset` 保存目标，卸载后再次加载，记录 Animation 节点、实际状态名、各 Clip GUID、默认 Clip、autoplay、设置和曲线；读到已保存数据才算 `unity_load`。在重新加载前不运行 Timeline。
- 真正播放验证使用新实例、实际播放器或明确的临时验证入口。Sample 只能证明采样；实际 Play/事件/页面回调需要对应播放证据。检查首次、播放中重触发、停止/隐藏后重开、完整结束后重播；结束时记录视觉姿态和 state。

## Timeline 预演

使用当前工程可用的 Animation Track 或经确认的定制轨道，将 Director 绑定到实际对象及组件。核对片段、起止帧、速度、重叠混合和停止后的状态。若现有播放器需要 Legacy，查询项目当前扩展是否支持其预演。正式播放在脱离预演驱动后单独核验。

## 失败与重入

能定位的错误只修本次目标。相同操作失败且没有新依据时停止重复写入，保留可回读草稿、错误和 next_action。清理仅限本次临时实例/文件，不删除共享资源。恢复本次改动也需先核对用户是否期间修改，不能用整个目录回滚覆盖用户工作。
