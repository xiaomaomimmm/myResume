# 项目约定发现

查目标 Prefab 的 Animation、Animator、Timeline 或自定义播放器。核对实际动画目录、播放名、曲线绑定、循环、完成信号和时长来源。新 Clip 沿用同用途设置。Legacy 由消费者决定。Animator 的状态、过渡和事件按实际控制器验证。
