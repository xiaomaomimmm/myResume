# harness 输入、报告与交付合同

这是 Skill 的任务/结果合同，不是某个 harness 平台的 API schema。实际执行由当前已发现的工具或 Unity 桥承担；未知 action 不虚构为“已经执行”。

## 自然语言整理为请求

harness 记录以下信息；尚未知用 null/缺项，并写 checks，不替设计师补批准记录。

| 字段 | 内容 |
|---|---|
| mode / modes | inspect、prepare、preview、handoff，本次范围 |
| module / targets | 功能名；真实 Prefab/Clip 路径；Animation 相对挂点；页面基类/播放器。根挂点为 `""`，未知为 null |
| motion | purpose、phase、repeat_mode 分别记录；阶段、首尾姿态、时长、参考素材/效果、可修改属性。命名不替代用途判断 |
| playback | 实际注册名、速度、单次/循环/末帧、自动播放、时间源、重播/打断/停止后的状态 |
| preview | 是否请求；既有场景/Timeline/Director/轨道、画幅和倍率 |
| delivery | 是否要程序接收单、视觉确认记录、需要程序配合的合同 |

只读盘预检：`scripts/audit.py --help`。源文件 SHA-256 与 GUID 放在 observations。它不解析完整 Unity 序列化模型，注册 check 永远保留 pending，避免把其它对象的 GUID、嵌套/变体或 Timeline 的临时状态当正式挂载成功。目标若存在未保存修改，磁盘观察与 live Unity 数据分别注明来源。

## 执行结果

使用 [report.schema.json](../assets/report.schema.json)。Schema 保证结构，证据判断仍按下文执行。每次重新检查受变更影响的结果；以前的 passed 不自动延用，保存源哈希、Unity 回读、画面文件或明确人工记录，使结果能对应当前版本。

制作、修改或交付具体动效时，按 [用途规则](animation-purposes.md) 输出 `motion_contracts`。每段有独立 id/target/purpose/phase、settings_origin、Clip/挂点、初终态、duration_seconds、repeat_mode、有效 WrapMode、completion/next_id、停止/复位/重播及负责属性/冲突；periodic 附 cadence。查看 Schema 的 `motion_contract` 定义取得精确字段和值。旧报告和仅查设置的静态预检可不含此字段。

`settings_origin=proposed` 是待执行方案，`observed` 需指向当前资源/播放器证据，`unresolved` 保留缺项；不能将建议 WrapMode 或序列化 StopTime 写成实测状态/length。后继 id 必须能在本次合同中定位（外部回调用 completion_owner 说明），每段 id 唯一；只对共享属性检查段间衔接，重复提醒的周期与一次 Clip 时长分开。用途配置中的检查清单按条件取用，不把 cadence、短按或循环事件检查强加到无关用途。

purpose/phase 不明确时用 unresolved 并留下分类待办，不因文件名填成某种用途；有明确用途后再选对应配置。首终态、挂点、时长和其它尚缺值按 Schema 用 null，不编造可执行曲线参数。

Schema 可拒绝矛盾的新建方案，例如 proposed 的自然完成段使用 ClampForever、动态连续周期 length=0。观察到旧资产有这些设置时仍可完整报告，用相应 check 记录不符/待核对，不能为了通过 Schema 改写事实。结构与方案校验仍不代替 Unity 队列/姿态/输入/观感验证。

| check.status | 含义 |
|---|---|
| passed | 本项实际执行且符合要求，附真实证据 |
| failed | 已观察到确定不符合要求的结果 |
| pending | 工具不可用、缺材料、未执行或尚无法判断 |
| needs_design | 缺关键设计决定或观感确认 |
| needs_programmer | 缺接收函数、播放入口、等待/生命周期/资源加载接入 |
| not_applicable | 本次范围不涉及，写原因；不能用于掩盖缺证据 |

验证 level：none（未执行）、static（磁盘/源码）、data_load（结构化数据成功读取）、unity_load（Unity 正式保存资产回读）、visual（实际画面核对）、device（目标设备）。这些标签描述证据来源，不按等级替代检查：unity_load 不证明 Play 成功，visual 不证明事件收到。

每项有 id、target、scope、required、status、level、detail、evidence、next_action。scope 为 `resource_delivery`（设计资源交付）或 `programmer_integration`（接收方接入）。passed 的 evidence 不能空；其它待处理状态给具体下一步。required 根据本次 mode/需求确定。查询不要求设计确认；设备测试仅在需求或问题需要时列必需。

建议按目标覆盖以下检查组：

| 组 | 实际检查内容 |
|---|---|
| asset | 目录性质、存在、GUID、Legacy、settings、当前实际时长 |
| binding | 正确挂点、节点/组件/属性、注册名和引用、依赖、默认 Clip、autoplay |
| timing | 程序选名和等待方式、速度/时间源、交互/其它演出衔接 |
| playback | 首次、结束、循环停止、打断、复用/重播和姿态；事件接收分项 |
| purpose | 分类、完成/后继、共同属性的初终态衔接、竞争写入、短按/重启/禁用复位、重复提醒 cadence 与循环事件（按用途选择） |
| preview | 保存场景绑定、段裁切/倍率、关键画面与独立播放一致性 |
| visual / integration | 设计师确认；程序接入和真实页面验证分别记录 |

## 三种不同完成状态

`handoff_status`：

- `not_requested`：本次只是查询/制作/预演，未要求正式交付。
- `draft`：已整理可给程序参考的资源/方案，但交付必需技术检查或设计观感确认尚缺。
- `ready_for_programmer`：正式资源、必需技术/播放检查、接收合同及设计师对当前效果的确认完成；程序尚未接入的项可为 needs_programmer。**不要求程序先完成接入才允许设计师交资源。**
- `integrated`：上述已完成，程序接入与本次必需的真实页面验证也完成。

判定 ready 时，所有 required 的**资源交付项**须 passed（不适用项写明原因），且需要观感确认的任务有当前版本的设计记录。观感确认写入 `designer_approval`，含 reviewer、time 和对应当前资源版本的 evidence。把程序接入依赖设独立 check，注明它属于接收方工作，不能降低它为已通过。集成状态再要求这些接收方必需项通过。不要只因 JSON/脚本退出码正确、Timeline 能播或有人说“看起来可以”而提升状态。

## 程序接收单

每个目标生成 `handoff.md` 的一张表，JSON `programmer_handoff` 保持对应字段：

- 正式 Prefab / Clip / .meta 与必要依赖；Animation 挂点、每段实际播放名与 GUID。
- 顺序、实际时长、速度、最终 Wrap Mode、自动播放、时间源；首尾姿态和恢复方式。
- 触发和交互时机、循环停止者、播放中重复请求、隐藏/打断/重开策略。
- Animation Events 的时间/函数/参数/接收脚本；没有事件就明确无。
- 程序入口：目标项目实际使用的播放组件或专用入口；时长字段是否同步、需要程序新增/改动的具体合同。建议明确，不直接代写未授权业务。
- Timeline/场景/Director 绑定与裁切/倍率；录屏的画幅、版本、时间源；没有制作/验证的内容标明未做。
- 已验证项、视觉确认、程序待接入项和 next_action。

报告通常为 `report.json`、`handoff.md`，静态预检可以独立存为 `static-audit.json`。只查规范可简短答复，仅实际跑自动检查时保存报告；不要为简单查询制造额外交付工作。
