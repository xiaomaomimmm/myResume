# 官方依据与工程版本

核对日期：2026-11-09。方法来源与查证入口不等于当前资源播放验收。

## 官方文档

| 内容 | 页面 |
|---|---|
| 二进制、导入、SkeletonDataAsset、Mix、Preview | [Assets](https://esotericsoftware.com/spine-unity-assets) |
| Game/UI 组件、皮肤、UI 材质、多贴图 | [Main Components](https://esotericsoftware.com/spine-unity-main-components) |
| 材质、混合、透明 | [Rendering](https://esotericsoftware.com/spine-unity-rendering) |
| Handle、轨道、默认融合、编辑态近似与结束 | [Timeline Extension](https://esotericsoftware.com/spine-unity-timeline) |
| RectTransform 边界、可见性、Match 与布局模式 | [Bounds and Correct Visibility](https://esotericsoftware.com/spine-unity-main-components#Bounds-and-Correct-Visibility)，落实为 [UI 边界流程](game-ui.md#bounds) |
| 实例材质覆盖与全角色透明合成 | [Changing Materials Per Instance](https://esotericsoftware.com/spine-unity-rendering#Changing-Materials-Per-Instance)、[Fading a Skeleton In or Out](https://esotericsoftware.com/spine-unity-rendering#Fading-a-Skeleton-In-or-Out)，落实为 [材质与颜色流程](rendering.md#materials) |
| Gamma/Linear、PMA/Straight、sRGB | [Atlas Texture Workflows](https://esotericsoftware.com/spine-unity-assets#Atlas-Texture-Workflows) |
| Timeline 有效参数与翻转 | [Spine Animation State Clip](https://esotericsoftware.com/spine-unity-timeline#Spine-Animation-State-Clip)、[Skeleton Flip Track](https://esotericsoftware.com/spine-unity-timeline#Skeleton-Flip-Track)，落实为 [预演流程](timeline.md) |
| 骨骼挂点与外部对象穿插 | [Manually Accessing Bone Transforms](https://esotericsoftware.com/spine-unity-main-components#Manually-Accessing-Bone-Transforms)、[Objects Between Skeleton Parts](https://esotericsoftware.com/spine-unity-rendering#Objects-Between-Skeleton-Parts)，落实为 [挂点与分层流程](game-ui.md#attachments) |

按任务读取对应部分。官方页面持续更新，含 4.3 内容；用当前 Inspector 与实现核对名称和支持项，不自行迁移。

## 工程入口

从当前项目的包锁、内置插件目录和资源导出信息确认 Spine Editor、spine-unity 与 Spine Timeline 版本。用当前安装源码核对 SkeletonDataAsset、AnimationReferenceAsset、SkeletonGraphic、Timeline 绑定和材质支持。颜色空间、渲染管线和 Shader 变体以当前工程及构建实测为准。

## 版本适用与验收范围

以目标工程当前版本的 Inspector 和源码确定入口。整体合成组件只有在当前运行库或项目已提供时使用。

2026-11-09 初次蒸馏据官方页面和工程资源/实现完成，后续查证日期按上述记录保留。2026-11-11 文档组织调整仅合并流程与更新链接，未增加 Unity 生成、播放或构建验证证据。

## UI Add 实现核对细节

- [官方 SkeletonGraphic 组件与材质说明](https://esotericsoftware.com/spine-unity-main-components#SkeletonGraphic-Component)：CanvasGroup/PMA、UI 材质、关闭顶点 PMA 后的 Additive 材质要求。新版 Tint Black 支持项按工程 4.1 实现核对。
- `SkeletonGraphic.cs` 的 UpdateMaterialsMultipleCanvasRenderers：选择 Additive 材质需独立混合信息、顶点 PMA 关闭及有效 additiveMaterial。
- `SkeletonGraphicInspector.cs`：上述 UI 开关、Additive Material 槽及提示。
- `BlendModeMaterials.cs`：Apply Additive Material 决定 Additive 附件是否参与专用混合材质分配。
- `Spine-SkeletonGraphic-Additive.shader`：Blend One One、CanvasGroup 与 Straight Alpha 关键字；`Spine-SkeletonGraphic-NormalPass.cginc` 处理 CanvasGroup 修改后的顶点 Alpha。
