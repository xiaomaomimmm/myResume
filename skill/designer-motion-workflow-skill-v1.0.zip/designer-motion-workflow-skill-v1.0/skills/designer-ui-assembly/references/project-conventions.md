# 项目约定发现

定位目标模块 Prefab、Canvas/Scaler、组件模板和字体。已有 Prefab 先查 GUID、fileID、动画路径和 Timeline 绑定，再选择原位修改或创建候选。查询当前安装的 Figma / PSD / FUI 工具及版本后按实际接口执行。
