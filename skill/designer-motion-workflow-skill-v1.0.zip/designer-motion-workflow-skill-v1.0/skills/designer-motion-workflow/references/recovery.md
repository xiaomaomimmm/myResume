# ④ 重跑与恢复

harness.py before 已封装 operation_journal.py begin 的资源版本检查。沿用同单、同 step，按返回 action 执行：

| action | 下一步 |
|---|---|
| execute | 执行一次写入 → saved → 新回读 → checked |
| inspect / verify_existing / verify_only | 只检查现存资源 → checked；不重写 |
| reuse | 已验证且未变化，跳过 |
| inspect_interruption | 查实际磁盘、Unity 内存和未保存修改，确定做到哪里 |
| conflict | 保留手调；读取变动后规划必要局部修正 |
| busy | 等待原动作；不删占用 |
| blocked | 记录具体阻碍，继续独立项 |

未知写入或失败不得直接重做。保留原回执及成果；工具断开时用 operation_journal.py fail 记录真实原因。底层命令使用返回的 task_file、stage、context.json 中的 write_token，operation 固定为 write；参数查 --help。

占用恢复：新查询同工程 editor/state 和 project/info，将原结果保存为 `{"editor_state":原查询JSON,"project_info":原查询JSON}`，运行 recover --idle-receipt <文件>。仅 60 秒内、同工程、非 Play 且空闲证据可释放匹配占用。恢复不证明原写入成功，不清理 task_record 的记录锁。

有保存检查点且版本一致时只补回读；不完整结果只做有证据的局部修复。GUID、引用、曲线、材质和手调参数按当前实物保留。
