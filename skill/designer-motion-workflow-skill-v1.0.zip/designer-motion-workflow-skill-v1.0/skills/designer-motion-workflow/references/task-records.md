# ② 任务记录

普通对话的多阶段任务，用 `task_record.py create --project-root <本次项目根目录> --title <名称> --request <真实需求>` 取得 task_file；后续命令用 `--task <该路径>` 维护同一份记录。简单查询直接回答。手动任务 finish 只汇总状态。

需要排查时用 `task_record.py show --task ...` 或 validate；具体参数查 --help。task.json 是状态源，progress.md/handoff.md 是生成的卡片。不要按标题猜任务、删除不明锁或覆盖旧修订。

报告必须来自真实检查，时间取本次执行时间；文件和 .meta 变化后旧检查失效。不要给旧回执换时间。每阶段的新报告覆盖该阶段的完整当前结果；独立对象分阶段，原报告保留。

Spine 沿用 rule_id/target_path/verification_level，脚本自动映射；scope/required 不明时保留待验。粒子桥接报告还需 record_schema_version=1、完整 source_text、resource_status（待修正/待确认/已通过）、visual_verified、designer_confirmed；原总状态不能代替逐项检查或真实确认。
