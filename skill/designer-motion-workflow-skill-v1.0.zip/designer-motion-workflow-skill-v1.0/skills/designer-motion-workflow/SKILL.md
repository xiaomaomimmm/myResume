---
name: designer-motion-workflow
description: 用于设计师需要制作、预演或继续动效任务，尤其是需求涉及图片、UI、Animation、Spine、粒子中的多个环节。单项已指定专项 Skill 时用该专项。
---

# 动效工作台

设计师给需求与素材，AI 制作和预演，真实效果确认后交付。只做本单动效；保护既有 GUID、绑定与手调。技术记录由脚本管理。

## 资源落点

动效工作台生成的全部资源统一放在目标 Unity 工程 `Assets/` 下的工作台专属文件夹中，默认使用 `Assets/MotionWorkbench/`。按任务需要在该目录下归档图片、UI、Animation、Spine、粒子、预演文件和任务记录。不得把工作台生成的资源散落到项目原有资源目录，也不得为了建立规则修改或迁移项目原有资源。

动效需要贴图、材质或 Shader 时，先在当前目标 Unity 工程内查找可复用资源，检查其格式、引用、渲染管线和显示效果是否满足需求。满足条件的资源优先复用，并保留原有引用和调参。工程内没有可用资源，或现有资源无法满足需求时，再创建新的贴图、材质或 Shader，统一保存到 `Assets/MotionWorkbench/` 对应任务目录。

## 开始

优先采用用户指定的工程根，否则使用当前工作目录。多工程仓库先定位目标资源和运行环境。Unity 专项先确认 `Assets/`、`ProjectSettings/ProjectVersion.txt`、包配置和编辑器实例属于同一工程。其他项目沿用需求整理、制作、预演与验收流程，用目标平台的工具和实际运行环境核验。

从当前对话接收需求。用户给出目标、参考或素材后直接处理。多阶段任务需要保留执行证据时，按 [任务记录](references/task-records.md) 建立记录，在后续对话沿用同一份 `task.json`。

## 制作

按依赖顺序，只读取本次需要的专项 SKILL.md：

| 内容 | Skill |
|---|---|
| 图片 | designer-image-assets |
| 界面 | designer-ui-assembly |
| 动画 | unity-animation-delivery |
| Spine | spine-unity-design |
| 粒子 | designer-particle-effects |
| Lottie / SVG | lottie-vector-animation |
| Spine 角色动作与 JSON | spine-character-animation |

Timeline 用专项的预演方法。缺关键输入时完成独立项，留下具体待办。

游戏内效果预演先按 [场景基准](references/scene-baseline.md) 定位真实主线环境、继承必要显示参数，再制作。独立预演场景也须有来源；截图只作设计参考，不能默认用空场景和自设相机替代主线。来源不明先查或补问，已有正确环境复用。

制作或修改视觉/交互预演时，先按 [表现评审](references/visual-review.md) 明确主次、交互状态和风格参考；看本版真实画面及正常速度交互，优先修正层级、动作直觉与风格差异，再给设计师确认。技术检查通过不代替表现评审。

使用任务记录时，每个动作使用稳定的小写 step 名。

1. `before --task TASK_FILE --step STEP --skill SKILL --target PATH`；写入另加 `--spec 操作.json`，格式见 [执行](references/execution.md)。
2. 仅 allow_write=true 可写。inspect/verify_existing/verify_only 只检查；reuse 跳过；其他 action 按 [恢复](references/recovery.md) 处理。
3. 写入并定向保存后，原工具回执写入返回的 save_response_file，运行 `saved --task TASK_FILE --step STEP`。
4. 新调用回读正式资源，把原回执写入 read_response_file；只读文件检查可用真实报告。运行 `checked --task TASK_FILE --step STEP`，自动记录结果。报告格式见 [执行](references/execution.md)。
5. 制作/预演按 [交付](references/delivery.md) 生成交付卡。完成用 `finish --task TASK_FILE` 汇总进度。缺资料、待确认或失败时记录实际原因，并在对话中说明。

文件检查、采样、实际播放与观感分别举证。正式资源应脱离 Timeline/预演驱动。效果确认只用真实用户对当前版的回复，不能采用需求文件的自称确认或制作授权。

对用户只说资源、预演位置、结果和下一步。后续反馈沿用当前任务。
