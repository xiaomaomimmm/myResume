#!/usr/bin/env python3
"""Small agent-facing adapter over task records, checkpoints and delivery."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import sys
import task_record as records
from execution_receipt import extract

HERE=Path(__file__).resolve().parent

def invoke(script,args):
    result=subprocess.run([sys.executable,str(HERE/script),*map(str,args)],capture_output=True,text=True)
    records.require(result.returncode==0,result.stderr.strip() or result.stdout.strip())
    return json.loads(result.stdout)

def record(args):
    return records.execute(records.parser().parse_args(list(map(str,args))))

def stage_id(item,step):
    records.require(step and re.fullmatch(r'[a-z][a-z0-9_-]{0,48}',step),'step must be a stable lowercase label')
    return 'v'+item['input_version'][:12]+'-'+step

def task_summary(path):
    task=records.load(path);records.check_archives(task,Path(path));data=records.view(task)
    return {'task_file':str(path),'status':data['run_status'],'handoff':data['handoff_status'],
        'unfinished':[{'step':s['id'],'status':s['status'],'next':s['next_action'] or s['detail']} for s in data['stages'] if s['status'] not in {'completed','skipped'}]}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['before','saved','checked','finish','delivery','confirm'])
    p.add_argument('--task', required=True, type=Path)
    p.add_argument('--step');p.add_argument('--skill',choices=sorted(records.SKILLS))
    p.add_argument('--target',action='append');p.add_argument('--spec');p.add_argument('--response')
    p.add_argument('--user-message');p.add_argument('--source-reference')
    p.add_argument('--formal-delivery',action='store_true');p.add_argument('--decision',choices=['approve','reject'])
    args=p.parse_args()
    try:
        task = args.task.resolve()
        current = records.load(task)
        item = {'input_version': records.digest(current['request'].encode())}
        if args.command in {'before','saved','checked'}:
            stage=stage_id(item,args.step);folder=task.parent/'work'/stage;context_file=folder/'context.json'
            if args.command=='before':
                records.require(args.skill,'before needs the selected specialist')
                spec=json.loads(Path(args.spec).read_text()) if args.spec else None
                targets=list(args.target or [])
                if spec:
                    spec.setdefault('outputs',targets)
                    spec.setdefault('inputs',[]);spec.setdefault('protected',[])
                    targets=list(dict.fromkeys(targets+spec['outputs']+spec['inputs']+spec['protected']))
                records.require(targets,'before needs actual target paths')
                stage_args=['stage','--task',task,'--id',stage,'--skill',args.skill,'--action','prepare' if spec else 'inspect']
                for path in targets:stage_args+=['--target',path]
                record(stage_args)
                context={'stage':stage,'task_file':str(task),'write':bool(spec),
                    'snapshot_file':str(folder/'snapshot.json'),'save_response_file':str(folder/'save-response.json'),
                    'read_response_file':str(folder/'read-response.json')}
                choice='inspect'
                if spec:
                    records.atomic_write(folder/'operation.json',records.json_bytes(spec))
                    begun=invoke('operation_journal.py',['begin','--task',task,'--stage',stage,'--operation','write','--spec',folder/'operation.json'])
                    choice=begun['decision'];context['write_token']=begun['token']
                if choice=='reuse':
                    record(['stage','--task',task,'--id',stage,'--status','completed'])
                elif choice in {'execute','inspect','verify_existing','verify_only'}:
                    if choice!='execute':record(['snapshot','--task',task,'--stage',stage,'--out',context['snapshot_file']])
                    record(['stage','--task',task,'--id',stage,'--status','running'])
                records.atomic_write(context_file,records.json_bytes(context))
                result={'action':choice,'allow_write':choice=='execute',**{k:v for k,v in context.items() if k!='write_token'}}
            else:
                context=json.loads(context_file.read_text())
                source=Path(args.response or context['save_response_file' if args.command=='saved' else 'read_response_file'])
                if args.command=='saved':
                    records.require(context['write'],'inspect steps cannot save')
                    invoke('operation_journal.py',['checkpoint','--task',task,'--stage',stage,'--operation','write','--phase','applied',
                        '--token',context['write_token'],'--receipt',source])
                    record(['snapshot','--task',task,'--stage',stage,'--out',context['snapshot_file']])
                    result={'action':'read_saved_resource','read_response_file':context['read_response_file']}
                else:
                    response=json.loads(source.read_text())
                    report=response if not context['write'] and isinstance(response,dict) and response.get('skill') else extract(response)
                    report_file=folder/'report.json';records.atomic_write(report_file,records.json_bytes(report))
                    record(['import-report','--task',task,'--stage',stage,'--report',report_file,'--snapshot',context['snapshot_file']])
                    if context['write']:
                        invoke('operation_journal.py',['checkpoint','--task',task,'--stage',stage,'--operation','write','--phase','verified','--receipt',source])
                    record(['stage','--task',task,'--id',stage,'--status','completed','--evidence',source])
                    result={'action':'step_completed',**task_summary(task)}
        elif args.command=='finish':
            result={'action':'report',**task_summary(task)}
        elif args.command=='confirm':
            records.require(args.decision and args.user_message and args.source_reference,'use the actual designer decision, quote and message reference')
            data=record(['design-confirmation','--task',task,'--decision',args.decision,'--evidence',args.user_message,'--source-reference',args.source_reference])
            result={'action':'reviewed','handoff':data['handoff_status'],'card':str(task.with_name('handoff.md'))}
        else:
            records.require(args.spec,'delivery needs a path-based resource/check spec')
            spec=json.loads(Path(args.spec).read_text());current=records.load(task)
            targets={t['path']:t['target_id'] for t in current['targets']}
            def target(path):
                value=str(records.canonical(path,current['project_root']))
                records.require(value in targets,'resource not tracked; add it through before first: '+value)
                return targets[value]
            plan={'schema_version':1,'visual_required':spec.get('visual',True),'designer_confirmation':spec.get('confirm',True),
                'usage':spec['usage'],'previews':spec.get('previews',[]),'assets':[],'required_checks':[]}
            for asset in spec['assets']:
                plan['assets'].append({'target_id':target(asset['path']),'label':asset['label'],'role':asset.get('role','formal'),'playback':asset.get('playback',False)})
            for check in spec['checks']:
                purpose=check['purpose'];path=check['path']
                minimum={'resource':'unity_load' if Path(path).suffix.lower() in {'.prefab','.anim','.asset','.mat','.controller','.overridecontroller'} else 'static',
                    'dependencies':'unity_load','independence':'static','playback':'unity_load','visual':'visual'}[purpose]
                plan['required_checks'].append({'stage_id':stage_id(item,check['step']),'check_id':check['id'],'target_id':target(path),
                    'purpose':purpose,'min_level':check.get('level',minimum),'label':check['label']})
            plan_file=task.parent/'delivery-spec.json';records.atomic_write(plan_file,records.json_bytes(plan))
            flags=['--formal-delivery'] if args.formal_delivery else []
            data=record(['delivery','--task',task,'--spec',plan_file,*flags])
            result={'action':'review','handoff':data['handoff_status'],'readiness':data['delivery_result']['readiness_status'],
                'next':data['delivery_result']['issues'],'card':str(task.with_name('handoff.md'))}
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (OSError,ValueError,KeyError,TypeError) as error:
        print(json.dumps({'action':'blocked','reason':str(error),'next':'保留当前资源。核对阻碍原因后补查或继续原步骤。'},ensure_ascii=False),file=sys.stderr)
        return 2

if __name__=='__main__':sys.exit(main())
