#!/usr/bin/env python3
"""Persistent motion task records. Records evidence; never operates on Unity assets."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import uuid
import delivery_gate

SKILLS = {'designer-image-assets', 'designer-ui-assembly', 'unity-animation-delivery',
          'spine-unity-design', 'designer-particle-effects', 'lottie-vector-animation', 'spine-character-animation', 'designer-motion-workflow'}
SCHEMA_PATH = Path(__file__).resolve().parents[1] / 'assets/task.schema.json'
STATUSES = {'passed', 'failed', 'pending', 'needs_design', 'needs_programmer', 'not_applicable'}
LEVELS = {'none', 'static', 'data_load', 'unity_load', 'visual', 'device'}
LABELS = {'planned': '待执行', 'running': '执行中', 'completed': '执行完成', 'blocked': '受阻',
          'skipped': '已跳过', 'passed': '已通过', 'failed': '需修正', 'pending': '待核验',
          'needs_design': '待设计决定/确认', 'needs_programmer': '待程序', 'not_applicable': '不适用',
          'not_started': '尚未开始', 'in_progress': '进行中', 'not_requested': '未要求正式交付', 'draft': '草稿'}
LABELS.update(delivery_gate.LABELS)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical(value, root):
    path = Path(value)
    return (path if path.is_absolute() else Path(root) / path).resolve()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(data):
    return (json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode('utf-8')


def guid(path):
    meta = Path(str(path) + '.meta')
    if not meta.is_file():
        return None
    match = re.search(r'^guid:\s*([0-9a-fA-F]{32})\s*$', meta.read_text(errors='replace'), re.M)
    return match.group(1).lower() if match else None


def check_schema(value, schema, root, at='$'):
    """Validate exactly the structural keywords used in our own schema, no dependencies."""
    if '$ref' in schema:
        ref = root
        for key in schema['$ref'].split('/')[1:]:
            ref = ref[key]
        return check_schema(value, ref, root, at)
    types = {'object': lambda x: isinstance(x, dict), 'array': lambda x: isinstance(x, list),
             'string': lambda x: isinstance(x, str), 'integer': lambda x: type(x) is int,
             'boolean': lambda x: type(x) is bool, 'null': lambda x: x is None}
    allowed = schema.get('type')
    if allowed:
        allowed = allowed if isinstance(allowed, list) else [allowed]
        require(any(types[t](value) for t in allowed), at + ': wrong type')
    if 'const' in schema:
        require(type(value) is type(schema['const']) and value == schema['const'], at + ': wrong constant')
    if 'enum' in schema:
        require(any(type(value) is type(v) and value == v for v in schema['enum']), at + ': invalid enum')
    if isinstance(value, str) and 'minLength' in schema:
        require(len(value.strip()) >= schema['minLength'], at + ': empty string')
    if type(value) is int and 'minimum' in schema:
        require(value >= schema['minimum'], at + ': below minimum')
    if isinstance(value, dict):
        for key in schema.get('required', []):
            require(key in value, at + ': missing ' + key)
        for key, child in schema.get('properties', {}).items():
            if key in value:
                check_schema(value[key], child, root, at + '.' + key)
    if isinstance(value, list) and 'items' in schema:
        for index, item in enumerate(value):
            check_schema(item, schema['items'], root, at + '[' + str(index) + ']')


def validate_task(task):
    schema = json.loads(SCHEMA_PATH.read_text())
    check_schema(task, schema, schema)
    targets = {t['target_id'] for t in task['targets']}
    stages = {s['id']: s for s in task['stages']}
    require(len(targets) == len(task['targets']), 'duplicate target ID')
    require(len(stages) == len(task['stages']), 'duplicate stage ID')
    for stage in task['stages']:
        require(stage['skill'] in SKILLS, 'unknown specialist skill')
        require(set(stage['target_ids']) <= targets, 'unknown target ID')
        require(set(stage['depends_on']) <= set(stages), 'unknown dependency')
        if stage['status'] == 'blocked':
            require(stage['detail'].strip() and stage['next_action'].strip(), 'blocked stage needs reason and next action')
        if stage['status'] == 'skipped':
            require(stage['detail'].strip(), 'skipped stage needs reason')
    def visit(node, stack):
        require(node not in stack, 'stage dependency cycle')
        for parent in stages[node]['depends_on']:
            visit(parent, stack | {node})
    for node in stages:
        visit(node, set())
    ids = set()
    for report in task['reports']:
        require(report['id'] not in ids, 'duplicate report ID')
        ids.add(report['id'])
        require(report['stage_id'] in stages, 'unknown report stage')
        require(report['skill'] == stages[report['stage_id']]['skill'], 'report skill differs from stage')
        for check in report['checks']:
            require(set(check['target_ids']) <= set(stages[report['stage_id']]['target_ids']), 'check bound to target outside its stage')
            validate_check(check)
    delivery_gate.validate_delivery(task)
    return task


def validate_check(check):
    require(check['status'] in STATUSES and check['level'] in LEVELS, 'invalid check status or level')
    if check['status'] == 'passed':
        require(check['evidence'] and check['level'] != 'none', 'passed check needs actual evidence and a verification level')
        require(all(isinstance(e, (str, dict)) and bool(e) for e in check['evidence']), 'empty passed evidence')
    if check['status'] == 'not_applicable':
        require(check['detail'].strip(), 'not_applicable needs a reason')


def output_guard(path, project):
    path, project = Path(path).resolve(), Path(project).resolve()
    for name in ('Assets', 'Library', 'Temp', 'Packages', 'ProjectSettings'):
        forbidden = project / name
        require(path != forbidden and forbidden not in path.parents, 'record output must stay outside Unity resources/cache/settings')


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix='.record-', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if Path(temporary).exists():
            Path(temporary).unlink()


def load(path):
    path = Path(path).resolve()
    require(path.name == 'task.json', 'use the exact task.json path')
    task = validate_task(json.loads(path.read_text(encoding='utf-8')))
    output_guard(path, task['project_root'])
    return task


def check_archives(task, path):
    for report in task['reports']:
        archive = (path.parent / report['archive']).resolve()
        require(path.parent in archive.parents and archive.is_file() and digest(archive.read_bytes()) == report['sha256'], 'missing/changed archived source report')


def find_stage(task, stage_id):
    found = [s for s in task['stages'] if s['id'] == stage_id]
    require(len(found) == 1, 'stage not found: ' + stage_id)
    return found[0]


def capture(task, stage):
    files = set()
    for target in task['targets']:
        if target['target_id'] not in stage['target_ids']:
            continue
        path = Path(target['path'])
        if path.is_dir():
            files.update(p.resolve() for p in path.rglob('*') if p.is_file())
            files.add(Path(str(path) + '.meta'))
        else:
            files.update((path, Path(str(path) + '.meta')))
    rows = [{'path': str(p), 'sha256': digest(p.read_bytes()) if p.is_file() else None} for p in sorted(files)]
    return {'captured_at': now(), 'project_root': task['project_root'], 'stage_id': stage['id'],
            'target_ids': sorted(stage['target_ids']), 'files': rows, 'version_id': digest(json_bytes(rows))}


def normalize(raw, skill):
    require(isinstance(raw, dict), 'report must be an object')
    require(raw.get('skill', skill) == skill, 'source report skill mismatch')
    expected_version = '1.0' if skill == 'unity-animation-delivery' else 1
    require(type(raw.get('schema_version')) is type(expected_version) and raw.get('schema_version') == expected_version,
            'unsupported source report schema_version')
    require(isinstance(raw.get('checks'), list), 'report must contain checks; do not infer success from a summary')
    checks = []
    for source in raw['checks']:
        require(isinstance(source, dict), 'check must be an object')
        status = source.get('status')
        check = {'id': source.get('id', source.get('rule_id')), 'target': source.get('target', source.get('target_path')),
            'source_target_id': source.get('target_id'), 'status': status, 'source_status': status,
            'level': source.get('level', source.get('verification_level', 'none')),
            'scope': source.get('scope'), 'required': source.get('required'),
            'detail': source.get('detail') or source.get('rule_id') or source.get('id') or '专项检查记录',
            'evidence': copy.deepcopy(source.get('evidence', [])), 'next_action': source.get('next_action'),
            'animation_name': source.get('animation_name'), 'phase': source.get('phase')}
        if 'dependency_paths' in source:
            require(isinstance(source['dependency_paths'], list) and all(isinstance(p, str) and p.strip() for p in source['dependency_paths']), 'invalid dependency inventory')
            check['dependency_paths'] = copy.deepcopy(source['dependency_paths'])
        if status in {'pending', 'failed', 'needs_design', 'needs_programmer'} and not check['next_action']:
            check['next_action'] = '按专项复查 ' + str(check['target'] or check['source_target_id'] or '本阶段') + ' 的 ' + str(check['id'])
        require(isinstance(check['id'], str) and check['id'].strip(), 'check ID missing')
        require(isinstance(check['evidence'], list), 'evidence must be an array')
        validate_check(check)
        checks.append(check)
    if skill == 'designer-particle-effects':
        require(raw.get('record_schema_version') == 1, 'particle extraction needs record_schema_version=1')
        require(isinstance(raw.get('source_text'), str) and raw['source_text'].strip(), 'particle extraction needs original source_text')
        original = raw.get('resource_status')
        require(original in {'待修正', '待确认', '已通过'}, 'unknown particle resource_status')
        status = 'failed' if original == '待修正' else ('needs_design' if original == '待确认' and raw.get('visual_verified') is True and raw.get('designer_confirmed') is False else 'pending')
        checks.append({'id': 'particle.summary', 'target': None, 'source_target_id': None, 'status': status,
            'source_status': original, 'level': 'none', 'scope': None, 'required': False,
            'detail': '粒子原交付总状态；逐项证据和确认另列，原文保留在报告副本。', 'evidence': [],
            'next_action': '核对本次逐项证据、资源版本与尚缺的观感确认；总状态不替代检查。'})
    identities = [(c['id'], c['target'], c['source_target_id'], c.get('animation_name'), c.get('phase'), c['level']) for c in checks]
    require(len(identities) == len(set(identities)), 'duplicate check identity within report')
    artifacts = []
    for item in raw.get('artifacts', []):
        require(isinstance(item, dict) and isinstance(item.get('path'), str), 'artifact path missing')
        row = copy.deepcopy(item)
        kind = str(row.get('kind', '')).lower()
        preview = Path(row['path']).suffix.lower() == '.playable' or any(t in kind for t in ('timeline', 'director', 'preview'))
        role = 'internal_preview' if preview else row.get('role', 'unclassified')
        require(role in {'formal', 'internal_preview', 'unclassified'}, 'invalid artifact role')
        row['role'] = role
        artifacts.append(row)
    changes = copy.deepcopy(raw.get('changes', []))
    if skill == 'spine-unity-design':
        changes.extend({'source_check': c.get('rule_id'), 'target_id': c.get('target_id'), 'change': change}
                       for c in raw['checks'] for change in c.get('changes', []))
    require(isinstance(changes, list), 'changes must be an array')
    return checks, changes, artifacts


def bind_checks(task, stage, raw, checks):
    source_targets = {t['target_id']: t.get('skeleton_path') for t in raw.get('targets', []) if isinstance(t, dict) and 'target_id' in t}
    for check in checks:
        value = check['target'] or source_targets.get(check['source_target_id'])
        if value:
            path = canonical(value, task['project_root'])
            check['target_ids'] = [t['target_id'] for t in task['targets'] if t['target_id'] in stage['target_ids'] and
                (path == Path(t['path']) or (Path(t['path']).is_dir() and Path(t['path']) in path.parents))]
        else:
            check['target_ids'] = list(stage['target_ids']) if check['source_target_id'] is None else []


def check_snapshot(task, stage, snapshot, raw):
    schema = json.loads(SCHEMA_PATH.read_text())
    check_schema(snapshot, schema['$defs']['snapshot'], schema)
    require(snapshot is not None, 'snapshot cannot be null when explicitly supplied')
    require(snapshot['project_root'] == task['project_root'] and snapshot['stage_id'] == stage['id'], 'snapshot belongs to another project/stage')
    require(snapshot['target_ids'] == sorted(stage['target_ids']), 'snapshot target set differs from stage')
    current = capture(task, stage)
    require(snapshot['files'] == current['files'] and snapshot['version_id'] == current['version_id'], 'snapshot differs from current resources; recheck affected inputs')
    timestamp = raw.get('created_at')
    require(isinstance(timestamp, str), 'version binding needs report created_at from actual execution')
    require(datetime.fromisoformat(timestamp.replace('Z', '+00:00')) >= datetime.fromisoformat(snapshot['captured_at']), 'report predates snapshot; do not attach current versions to historical evidence')
    expected = {f['path']: f['sha256'] for f in snapshot['files']}
    for observation in raw.get('observations', []):
        for path_key, hash_key in (('path', 'sha256'), ('source_path', 'source_sha256'), ('target_path', 'target_sha256')):
            if observation.get(path_key) and observation.get(hash_key):
                path = str(canonical(observation[path_key], task['project_root']))
                require(path in expected and expected[path] == observation[hash_key], 'source hash does not match snapshot: ' + path)


def view(task):
    result = copy.deepcopy(task)
    latest = {r['stage_id']: r for r in task['reports']}
    checks, artifacts = [], []
    for stage in task['stages']:
        report = latest.get(stage['id'])
        if not report:
            continue
        snapshot = report['snapshot']
        current = capture(task, stage)
        freshness = 'unbound' if not snapshot or not snapshot['files'] else ('current' if snapshot['version_id'] == current['version_id'] else 'stale')
        for original in report['checks']:
            check = copy.deepcopy(original)
            check_freshness = freshness if check['target_ids'] else 'unbound'
            check.update(stage_id=stage['id'], skill=stage['skill'], report_id=report['id'], freshness=check_freshness)
            check['effective_status'] = 'pending' if check_freshness != 'current' and check['status'] in {'passed', 'failed', 'not_applicable'} else check['status']
            if check_freshness != 'current':
                check['version_next_action'] = '报告未关联执行时版本，或指定资源/.meta 已变化；取得当前证据再归入。'
            checks.append(check)
        artifacts.extend({**copy.deepcopy(a), 'stage_id': stage['id'], 'report_id': report['id'], 'freshness': freshness} for a in report['artifacts'])
    by_id = {s['id']: s for s in task['stages']}
    runnable = [s['id'] for s in task['stages'] if s['status'] == 'planned' and all(by_id[d]['status'] == 'completed' for d in s['depends_on'])]
    states = [s['status'] for s in task['stages']]
    if not states:
        status = 'not_started'
    elif all(s in {'completed', 'skipped'} for s in states):
        status = 'completed'
    elif 'running' in states or runnable:
        status = 'in_progress'
    else:
        status = 'blocked'
    result.update(checks=checks, artifacts=artifacts, runnable_stages=runnable, run_status=status,
                  handoff_status='draft' if task['formal_delivery'] else 'not_requested')
    result['current_versions'] = {t['target_id']: capture(task, {'id': 'current', 'target_ids': [t['target_id']]}) for t in task['targets']}
    if task.get('delivery'):
        result['delivery_result'] = delivery_gate.evaluate(task, result)
        result['handoff_status'] = result['delivery_result']['status']
    return result


def cell(value):
    return str(value if value is not None else '未知').replace('|', '\\|').replace('\n', ' ')


def render(data):
    lines = ['# ' + data['title'] + ' · 任务进度卡', '',
        '任务：`' + data['task_id'] + '`；修订：' + str(data['revision']), '',
        '要求：' + data['request'], '',
        '执行：' + LABELS[data['run_status']] + '；交付：' + LABELS[data['handoff_status']], '',
        '阶段完成表示本次动作已执行；检查问题、观感和程序接入分别记录。', '',
        '| 阶段 / 专项 | 本次动作 | 状态 | 上游 | 下一步 |', '|---|---|---|---|---|']
    for stage in data['stages']:
        lines.append('| ' + ' | '.join(map(cell, [stage['id'] + ' / ' + stage['skill'], stage['action'],
            LABELS[stage['status']], ', '.join(stage['depends_on']) or '无', stage['next_action'] or stage['detail'] or '—'])) + ' |')
    lines += ['', '可继续的独立阶段：' + (', '.join(data['runnable_stages']) or '无待启动阶段'), '',
              '| 资源 | 任务目标 ID | 选择时 GUID | 当前文件版本 |', '|---|---|---|---|']
    for target in data['targets']:
        lines.append('| ' + ' | '.join(map(cell, [target['path'], target['target_id'], target['guid'],
            data['current_versions'][target['target_id']]['version_id'][:12]])) + ' |')
    lines += ['',
              '| 检查 / 目标 | 本次必要性 | 原状态 | 当前有效状态 | 证据来源 | 版本 | 下一步 |', '|---|---|---|---|---|---|---|']
    for check in data['checks']:
        lines.append('| ' + ' | '.join(map(cell, [check['id'] + ' / ' + str(check['target'] or check['source_target_id'] or check['stage_id']),
            '必需' if check['required'] is True else ('可选' if check['required'] is False else '待明确'),
            LABELS.get(check['source_status'], check['source_status']), LABELS[check['effective_status']],
            {'none': '未实查', 'static': '磁盘/源码', 'data_load': '数据解析', 'unity_load': 'Unity 回读', 'visual': '画面核验', 'device': '设备实测'}[check['level']],
            {'current': '版本一致', 'stale': '版本变化', 'unbound': '版本未关联'}[check['freshness']],
            check.get('version_next_action') or check['next_action'] or '—'])) + ' |')
    for role, label in [('formal', '正式资源'), ('internal_preview', '内部预演资料'), ('unclassified', '待归类产物')]:
        lines += ['', '## ' + label, '']
        lines.extend('- ' + cell(a['path']) + '（' + a['freshness'] + '）' for a in data['artifacts'] if a['role'] == role)
        if not any(a['role'] == role for a in data['artifacts']):
            lines.append('本轮未记录。')
    lines += ['', '## 记录与边界', '',
        '- 源报告保存在 reports/；旧报告留作历史，当前检查采用各阶段最新完整报告。',
        '- 版本只覆盖已指定文件及 .meta；未列依赖、Unity 加载、播放、观感不由文件哈希证明。',
        '- 原报告的 scope/required 未声明时保留未知；已设交付清单的任务另生成 handoff.md。',
        '- 继续任务先读取同目录 task.json，再重查本次要处理的资源；进度卡可由 show 重新生成。', '']
    return '\n'.join(lines)


def save(task, path):
    validate_task(task)
    atomic_write(path, json_bytes(task))
    save_cards(view(task), Path(path))


def save_cards(data, path):
    atomic_write(path.with_name('progress.md'), render(data).encode('utf-8'))
    if 'delivery_result' in data:
        atomic_write(path.with_name('handoff.md'), delivery_gate.render_card(data['title'], data['delivery_result']).encode('utf-8'))


def parser():
    root = argparse.ArgumentParser(description=__doc__)
    commands = root.add_subparsers(dest='command', required=True)
    create = commands.add_parser('create')
    for key in ('project-root', 'title', 'request'):
        create.add_argument('--' + key, required=True)
    create.add_argument('--store')
    create.add_argument('--formal-delivery', action='store_true')
    for name in ('stage', 'snapshot', 'import-report', 'show', 'validate', 'delivery', 'design-confirmation'):
        sub = commands.add_parser(name)
        sub.add_argument('--task', required=True)
        if name in {'stage', 'import-report', 'delivery', 'design-confirmation'}:
            sub.add_argument('--expected-revision', type=int)
        if name == 'delivery':
            sub.add_argument('--spec', required=True)
            sub.add_argument('--formal-delivery', action='store_true')
        if name == 'design-confirmation':
            sub.add_argument('--decision', choices=['approve', 'reject'], required=True)
            sub.add_argument('--evidence', required=True)
            sub.add_argument('--source-reference', required=True)
        if name == 'stage':
            sub.add_argument('--id', required=True)
            sub.add_argument('--skill', choices=sorted(SKILLS))
            sub.add_argument('--action')
            for key in ('target', 'depends-on', 'evidence'):
                sub.add_argument('--' + key, action='append')
            sub.add_argument('--status', choices=['planned', 'running', 'completed', 'blocked', 'skipped'])
            sub.add_argument('--detail')
            sub.add_argument('--next-action')
        if name in {'snapshot', 'import-report'}:
            sub.add_argument('--stage', required=True)
        if name == 'snapshot':
            sub.add_argument('--out', required=True)
        if name == 'import-report':
            sub.add_argument('--report', required=True)
            sub.add_argument('--snapshot')
    return root


def execute(args):
    if args.command == 'create':
        project = Path(args.project_root).resolve()
        require(project.is_dir(), 'project-root must be an existing directory')
        store = Path(args.store).resolve() if args.store else project / '.local/reports/designer-motion-workflow/tasks'
        output_guard(store, project)
        task_id = 'motion-' + uuid.uuid4().hex
        path = store / task_id / 'task.json'
        task = {'schema_version': 1, 'task_id': task_id, 'title': args.title, 'request': args.request,
            'project_root': str(project), 'formal_delivery': args.formal_delivery, 'created_at': now(), 'updated_at': now(),
            'revision': 0, 'targets': [], 'stages': [], 'reports': []}
        save(task, path)
        return {**view(task), 'task_file': str(path)}
    path = Path(args.task).resolve()
    task = load(path)
    if args.command in {'show', 'validate', 'snapshot'}:
        if args.command == 'snapshot':
            output = Path(args.out).resolve()
            output_guard(output, task['project_root'])
            require(output != path and output.name != 'progress.md', 'snapshot cannot overwrite task/card')
            snapshot = capture(task, find_stage(task, args.stage))
            atomic_write(output, json_bytes(snapshot))
            return {**snapshot, 'snapshot_file': str(output)}
        check_archives(task, path)
        data = view(task)
        if args.command == 'show':
            save_cards(data, path)
        return {**data, 'task_file': str(path)}
    lock = path.with_name('.record.lock')
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise ValueError('another record writer or interrupted lock exists; inspect before retrying')
    os.close(descriptor)
    try:
        task = load(path)
        check_archives(task, path)
        if args.expected_revision is not None:
            require(task['revision'] == args.expected_revision, 'stale revision; read current task before updating')
        if args.command == 'delivery':
            plan = json.loads(Path(args.spec).read_text(encoding='utf-8'))
            delivery_gate.validate_plan(task, plan)
            if args.formal_delivery:
                task['formal_delivery'] = True
            approvals = task.get('delivery', {}).get('approvals', [])
            task['delivery'] = {'plan': plan, 'approvals': approvals}
        elif args.command == 'design-confirmation':
            require(task.get('delivery'), 'configure this delivery before recording designer confirmation')
            require(args.evidence.strip() and args.source_reference.strip(), 'use the actual user statement and message reference')
            data = view(task)
            if args.decision == 'approve':
                require(data['delivery_result']['resource_checks_passed'], 'required resource/visual checks must pass for this version before approval')
            task['delivery']['approvals'].append({'decision': args.decision, 'evidence': args.evidence,
                'source_reference': args.source_reference, 'time': now(), 'version': data['delivery_result']['version']})
        elif args.command == 'stage':
            found = [s for s in task['stages'] if s['id'] == args.id]
            if found:
                stage = found[0]
            else:
                require(args.skill and args.action, 'new stage needs skill and action')
                stage = {'id': args.id, 'skill': args.skill, 'action': args.action, 'target_ids': [],
                    'depends_on': [], 'status': 'planned', 'detail': '', 'next_action': '', 'evidence': []}
                task['stages'].append(stage)
            for key in ('skill', 'action', 'status', 'detail', 'next_action'):
                if getattr(args, key) is not None:
                    stage[key] = getattr(args, key)
            if args.depends_on is not None:
                stage['depends_on'] = args.depends_on
            if args.evidence:
                stage['evidence'].extend(e for e in args.evidence if e not in stage['evidence'])
            if args.target is not None:
                stage['target_ids'] = []
                for value in args.target:
                    target_path = canonical(value, task['project_root'])
                    target_id = 'target-' + digest(str(target_path).encode())[:16]
                    if not any(t['target_id'] == target_id for t in task['targets']):
                        task['targets'].append({'target_id': target_id, 'path': str(target_path), 'guid': guid(target_path)})
                    if target_id not in stage['target_ids']:
                        stage['target_ids'].append(target_id)
            validate_task(task)
            if stage['status'] in {'running', 'completed'}:
                require(all(find_stage(task, d)['status'] == 'completed' for d in stage['depends_on']), 'upstream stage not completed')
            if stage['status'] == 'completed':
                require(stage['evidence'] or any(r['stage_id'] == stage['id'] for r in task['reports']), 'completed stage needs actual execution evidence or report')
        else:
            stage = find_stage(task, args.stage)
            source = Path(args.report).resolve()
            content = source.read_bytes()
            report_id = digest(stage['id'].encode() + content)
            if any(r['id'] == report_id for r in task['reports']):
                return {**view(task), 'task_file': str(path), 'duplicate_report': True}
            raw = json.loads(content)
            require(not raw.get('project_root') or str(Path(raw['project_root']).resolve()) == task['project_root'], 'source report project mismatch')
            checks, changes, artifacts = normalize(raw, stage['skill'])
            bind_checks(task, stage, raw, checks)
            snapshot = json.loads(Path(args.snapshot).read_text()) if args.snapshot else None
            if snapshot is not None:
                check_snapshot(task, stage, snapshot, raw)
            archive = 'reports/' + report_id + '.json'
            report = {'id': report_id, 'stage_id': stage['id'], 'skill': stage['skill'], 'source_path': str(source),
                'sha256': digest(content), 'archive': archive, 'imported_at': now(),
                'reported_handoff_status': raw.get('handoff_status', raw.get('resource_status')),
                'designer_approval': raw.get('designer_approval'), 'snapshot': snapshot,
                'checks': checks, 'changes': changes, 'artifacts': artifacts}
            task['reports'].append(report)
            validate_task(task)
            archived_path = path.parent / archive
            require(not archived_path.exists() or archived_path.read_bytes() == content, 'archive collision')
            if not archived_path.exists():
                atomic_write(archived_path, content)
        task['revision'] += 1
        task['updated_at'] = now()
        save(task, path)
        return {**view(task), 'task_file': str(path)}
    finally:
        lock.unlink()


def main():
    try:
        result = execute(parser().parse_args())
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (ValueError, OSError, KeyError, TypeError) as error:
        print('task_record: ' + str(error), file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
