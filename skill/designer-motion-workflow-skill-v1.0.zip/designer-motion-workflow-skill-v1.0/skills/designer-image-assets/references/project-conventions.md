# 项目约定发现

核对同用途图片、`.meta`、SpriteAtlas、TextureImporter 与导入后处理脚本。目标目录、平台压缩、尺寸、透明通道、sRGB 和 mipmap 以实际用途与当前项目配置为准。复用前核对内容和导入设置。原位更新保留 GUID 并检查共享引用。
