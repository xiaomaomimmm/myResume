#!/usr/bin/env python3
"""Verify and install the motion skill bundle into Codex's user skill directory."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys
from tempfile import TemporaryDirectory

PACKAGE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_package():
    manifest_file = PACKAGE / 'manifest.json'
    manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
    actual = {}
    for path in PACKAGE.rglob('*'):
        if path.is_symlink():
            raise ValueError(f'安装包含符号链接 {path}')
        if path.is_file() and path != manifest_file:
            actual[path.relative_to(PACKAGE).as_posix()] = digest(path)
    if actual != manifest['files']:
        raise ValueError('安装包有缺失、额外文件或内容改动，请使用完整 ZIP 重新解压。')
    skills = PACKAGE / 'skills'
    if sorted(manifest['skills']) != sorted(path.name for path in skills.iterdir()):
        raise ValueError('技能目录与清单不一致。')
    for name in manifest['skills']:
        if not (skills / name / 'SKILL.md').is_file():
            raise ValueError(f'技能缺少 SKILL.md {name}')
    return manifest['skills']


def default_destination(names):
    user = Path.home() / '.agents/skills'
    legacy = Path.home() / '.codex/skills'
    has_user = any((user / name).exists() for name in names)
    has_legacy = any((legacy / name).exists() for name in names)
    if has_user and has_legacy and user.resolve() != legacy.resolve():
        raise ValueError('两处用户技能目录均有同名技能。请用 --skills-dir 指定目标目录。')
    return legacy if has_legacy else user


def matches(source, target):
    if not target.is_dir() or target.is_symlink():
        return False
    def contents(directory):
        return {
            path.relative_to(directory): None if path.is_symlink() else digest(path)
            for path in directory.rglob('*')
            if (path.is_file() or path.is_symlink())
            and not {'__pycache__', '.DS_Store'}.intersection(path.relative_to(directory).parts)
        }
    return contents(source) == contents(target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skills-dir', type=Path, help='指定接收技能目录')
    parser.add_argument('--check', action='store_true', help='仅核对安装包与目标目录')
    args = parser.parse_args()
    try:
        names = verify_package()
        target = (args.skills_dir or default_destination(names)).expanduser().resolve()
        if target == PACKAGE or PACKAGE in target.parents:
            raise ValueError('安装目录必须在解压目录之外。')
        pending = []
        conflicts = []
        for name in names:
            installed = target / name
            if not installed.exists() and not installed.is_symlink():
                pending.append(name)
            elif not matches(PACKAGE / 'skills' / name, installed):
                conflicts.append(name)
        if conflicts:
            raise ValueError('已有内容不同的同名技能，请先将对应目录备份移出，再重试。' + '、'.join(conflicts))
        if not args.check and pending:
            target.mkdir(parents=True, exist_ok=True)
            with TemporaryDirectory(prefix='.motion-install-', dir=target) as staging:
                staging = Path(staging)
                for name in pending:
                    shutil.copytree(PACKAGE / 'skills' / name, staging / name)
                installed = []
                try:
                    for name in pending:
                        final = target / name
                        if final.exists() or final.is_symlink():
                            raise FileExistsError(final)
                        (staging / name).rename(final)
                        installed.append(name)
                except OSError:
                    for name in reversed(installed):
                        (target / name).rename(staging / name)
                    raise
        verb = '检查通过，待安装' if args.check else '安装完成，新装'
        print(f'{verb} {len(pending)} 项，已有相同版本 {len(names) - len(pending)} 项。目录 {target}')
        return 0
    except (OSError, ValueError, KeyError) as error:
        print(f'安装未完成。{error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
