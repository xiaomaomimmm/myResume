---
name: lottie-vector-animation
description: 制作、修改、分析、设计评审和验收 Lottie JSON 与 SVG 矢量动画，用于图标、LOGO、Loading、路径描边、角色弹跳与柔性形变、循环和程序化伪3D；支持透明帧与视频、Unity 图集或上下 MP4 的交付流程。普通网页交互动画、Spine 骨骼和纯位图特效优先使用对应工作流。
---

# Lottie 矢量动画

将矢量素材与动作意图落实为可编辑的路径和关键帧，再用真实播放器渲染验收。优先延续用户已有格式、工程和动作；既有动画的小改动不需要新建编辑器。

这份技能的节奏参数是制作起点，未建立商业工程统计语料。已有方块旋转、天气、笔画和角色弹跳案例用于行为验证；单个参考的专用参数不能推广为所有矢量动画的标准。

## 按任务读取

| 当前任务 | 参考 |
|---|---|
| SVG 导入、路径匹配、描边、洞和遮罩 | [paths-and-format.md](references/paths-and-format.md) |
| 确定动作风格、情绪、主次关系和多元素编排 | [motion-design.md](references/motion-design.md) |
| 设计缓动、错帧、循环、伪3D | [motion.md](references/motion.md) |
| 评审观感，诊断机械、拖沓、杂乱或风格不一致 | [motion-review.md](references/motion-review.md) |
| 卡通角色弹跳、压缩拉伸、手脚弯曲、脸部跟随及接触遮挡 | [character-jump-reference.md](references/character-jump-reference.md) |
| 用生成器从零做动画 | [generation-spec.md](references/generation-spec.md) |
| 渲染验收、透明帧、视频、Unity | [verification-and-export.md](references/verification-and-export.md) |
| 接续方块旋转或 Lottie 工坊 | [existing-tools.md](references/existing-tools.md) |

只读取相关参考。命令中的 `scripts/`、`assets/` 相对本技能目录；从其他目录运行时使用实际绝对路径。

## 制作与修改

1. 从请求或源文件确定交付格式、画布、帧率、时长、循环和透明背景。已有动画默认保留这些值；无帧率信息时以 30 fps 为起点。只询问会影响实现而又无法推断的缺失信息。
2. 修改已有 JSON 时先分析层级、预合成、图像、遮罩、表达式与帧范围。建立未改动副本或输出新文件；明确要求编辑原文件时按要求就地修改。
3. 区分整体变换、描边显露、轮廓形变和可见性：能用变换做出的运动不必逐帧改路径；描边用 Trim Paths；轮廓变化需要拓扑匹配。保持洞、透明度、层级及描边语义。
4. 新建或重设计动作时，先确定用途、风格、主体、动作节拍与必要的跟随，再安排关键帧和缓动，见动作设计参考。小改动延续原设计；仅评审时先给出有证据的发现与建议。新建基础动画可用生成器；复杂 SVG 用经过验证的导入器，或直接构建 Lottie 路径。生成器不解析任意 SVG，也不自动匹配不同拓扑。
5. 跑结构检查；循环任务加 `--loop`。修复 FAIL；WARN 结合可见性和目标播放器判断，保留有意的整圈旋转、透明跳回等行为，并记录理由。
6. 用目标播放器采样。查看起始、过程、结束的合成审查板；首尾、快速动作或遮挡切换有疑点时加采样。检查洞、接缝、裁切、方向和透明边缘。设计任务还要按视觉评审参考检查主次、节奏、跟随与风格；稀疏静帧不足以证明全速观感。
7. 交付动画与必要的预览、验证结果。评审区分源文件事实、实际播放观察和设计建议；结构检查通过不等于动作自然，设计参数也不是兼容性保证。

## 工具

分析、检查和基础生成只需 Node.js 18+，不依赖 npm 包：

```bash
node scripts/lottie_inspect.cjs input.json
node scripts/lottie_inspect.cjs input.json --json
node scripts/lottie_lint.cjs input.json --loop
node scripts/lottie_generate.cjs assets/pulse-spec.json out/pulse.json
node scripts/lottie_selftest.cjs
```

生成器支持椭圆、圆角矩形、多边形、贝塞尔路径，以及位移、旋转、缩放、透明度、同拓扑形变和描边显露。输出没有位图背景；图层列表按前景到背景排列。更多输入见生成参考。

渲染需要 Playwright 和 `lottie-web` 的 SVG 或完整运行时；优先使用项目已有依赖。找不到时定位环境运行库或按任务需要安装，不写死其他机器的路径：

```bash
node scripts/lottie_render.cjs input.json out/review --runtime /actual/path/lottie_svg.min.js --playwright /actual/path/node_modules/playwright --browser /actual/path/browser-executable
```

- `--playwright`、`--browser` 在当前环境能自动找到模块和 Chromium 时可省略。
- `--asset-root` 指定外部图片根目录，默认是输入 JSON 所在目录。
- 默认输出六个采样帧的 PNG、静态 SVG、`contact-sheet.png` 和 `report.json`。源 `ip` 非零时会换算到播放器相对帧。
- `--frames 0,15,30` 指定源时间线帧；`--sequence` 输出全部原生帧，范围 `[ip, op)`；两者不能同时用。
- 生成和渲染拒绝覆盖同名输出；确需覆盖时加 `--force`。验收截图不作为矢量源文件。

## 交付边界

- `v` 是 Lottie 数据版本，改字符串不会让播放器获得新特性。兼容性取决于实际使用的特性和目标播放器。
- Lint 是基础结构检查，不是完整 schema 验证或可见循环判定。它检查父层和素材引用、时间顺序、路径数组、形变拓扑，并提示风险；不能证明无裁切、视觉连续或任意运行时兼容。
- 静态 SVG 是一帧，不含完整时间线。SVG 的 CSS、SMIL 或 JS 动画不会自动进入 Lottie JSON。
- 只有交付需要时才栅格化为 PNG、图集或视频。透明导出保持源 Alpha；未要求时不修洞、扩边或重画遮罩。
- “导出上下 MP4 到 Unity”采用用户提供的上下白黑规范，见导出参考；普通 MP4 或其他用户的需求不自动使用同一规格。

用户明确要求让技能学习一个动画时，分析实际图层、关键帧、缓动与可见时间，再用播放器确认。把可迁移的做法、原文件快照和已知局限保存为按需参考并链接到本入口；区分源文件事实与新动画的建议，不把源中不存在的眨眼、骨骼、物理模拟等能力归因给它。

较长任务在输出目录留简短 `progress.md`，记录源文件、修改范围、目标播放器、验证和剩余问题。查看合成板优先于逐帧查看；截图数量以发现和解决问题为准。
