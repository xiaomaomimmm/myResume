# 基础生成器输入

生成标准二维形状层，不需要 AE。不解析 SVG，不自动匹配拓扑，不生成任意液滴或真实三维场景。

顶层 `name,width,height,fps,seconds,loop,layers`，默认 512×512、30 fps、2 秒，`op=round(seconds*fps)`。layers 从前景到背景。

每层 `name,geometry,fill,stroke,strokeWidth`；颜色为 `#RRGGBB`，`fill:null` 不填色。静态变换可设 `position:[x,y,0]`、`anchor:[x,y,0]`、`scale:[sx,sy,100]`（百分比）、`rotation`（度）、`opacity`（百分比）。

`animate` 各通道至少两个 `{frame,value,ease?,hold?}`，frame 严格递增且在 0..op。默认 smooth，也支持 linear；`hold:true` 设 stepped。position/scale 三通道，rotation/opacity/trimEnd 标量，path 为路径对象。

几何：

```json
{"type":"ellipse","size":[90,90]}
{"type":"rect","size":[100,80],"radius":12}
{"type":"polygon","points":[[-40,-40],[40,-40],[40,40],[-40,40]],"closed":true}
{"type":"path","path":{"v":[[-40,0],[40,0]],"i":[[0,0],[0,0]],"o":[[0,0],[0,0]],"c":false}}
```

可设 `fillRule:"evenodd"`，但生成器每层只有一个子路径。带洞的复合轮廓用同组多路径或项目导入器；不要先转换为这个精简 spec 丢失原文件特性。

## 一次描边

```json
{
  "name":"描边折线","width":256,"height":256,"fps":30,"seconds":2,
  "layers":[{
    "name":"折线","geometry":{"type":"polygon","points":[[-70,30],[-20,-40],[40,35],[75,-20]],"closed":false},
    "fill":null,"stroke":"#765235","strokeWidth":8,
    "animate":{"trimEnd":[{"frame":0,"value":0},{"frame":45,"value":100},{"frame":60,"value":100}]}
  }]
}
```

这是一次描边，末端保持。需要循环时另设计淡出/隐藏重置或来回擦除，再验收接缝。

## 同拓扑形变

把路径对象放入 `animate.path` 的 value，例如四顶点正方形到四顶点菱形再回正方形。每个对象含 v/i/o/c，顶点顺序一致。所有起值和终值都要匹配拓扑；生成器遇到点数或开放状态变化会拒绝输出，不自动补点。

输入示例 `assets/pulse-spec.json` 是两个圆的错帧缩放循环，可复制到输出目录改色、尺寸和关键帧。它是可编辑输入模板，非固定视觉要求。
