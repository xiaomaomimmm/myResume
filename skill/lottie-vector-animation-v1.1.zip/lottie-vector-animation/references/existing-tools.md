# 接续已有工具

工作区包含用户的 EffectTools 时先定位目录和适用 AGENTS.md；不假定固定盘符、用户名或端口，不为使用技能迁移工程。

## CubeRotation

engine.js 生成投影、跨面路径、可见性和动作，route-presets.js 定义走向。palette.js 处理真实导出颜色和开关，preview-controls.js 同步预览与浏览器设置。

箭头开关隐藏前后路径，保留方块、接缝、动作和关联设置。大图/角标同步，刷新保存状态。预览加载完整路径以便即时恢复，再用样式隐藏；真实 JSON、Atlas 和视频根据开关过滤图层，不能只修主预览。

atlas-export.js、atlas-format.js、video-export.js 使用导出数据。验证开关、刷新、重新构建、JSON 和实际导出中的可见性。已有透明视频检查依赖路径和浏览器 channel 需要先适配当前机器。

## LottieEditor

svg-import.js 处理导入，core.js 提供轮廓与生成逻辑。stroke-morph.js、weather-flow.js、vendor/liquid-motion.js 有各自专用参考和限制；天气、B/I 和液滴不是任意 SVG 的通用算法。

当前主界面聚焦参考液滴、天气和 B/I；不把源码残留的其他模式当成仍在界面支持的功能。保留工程保存/打开、透明 JSON、静态 SVG，预览背景与透明输出分离。

按改动范围运行现有测试，用实际导出的文件重新加载。通用分析器提供结构基线，不能代替专用参考的视觉验收。
