# 验收与导出

## 播放器和帧

结构检查后用目标播放器加载。附带工具以传入的 lottie-web 运行时及 SVG renderer 为目标；不自动证明其他播放器、移动端或 Unity 兼容。

六帧合成板适合初检。快速动作、描边端点、遮挡切换另外采样；循环比较首帧、倒数帧和下一周期首帧，观察速度。透明背景看棋盘格，必要时用白底和深底复查边缘。报告实际验证的运行时、尺寸、帧率和问题，不能把无脚本错误等同于视觉无误。

设计与观感问题按 [motion-review.md](motion-review.md) 评审。合成板用于定位形状、层次和时刻；全速节奏需结合实际播放或关键区间的连续采样。无法播放时说明观感判断的证据范围，不把静帧推测报告成已验证的播放效果。

`--sequence` 在 `[ip,op)` 输出全部原生帧，`frame_00000.png` 连续编号，report 保存源帧和时间。工具不做帧率转换；转采样应在播放器以 `ip+j*source_fps/target_fps` 取样，样本数符合目标时长。

静态 SVG 保留 viewBox、洞、描边和透明度；它没有完整时间线。复制 mask、gradient、clipPath 时一并复制 defs 并修复 ID 引用。

## Atlas / Unity

按用户或项目确定尺寸/布局。方块工具已有 128×128 / 帧、60 帧 / 30 fps / 2 秒、1024×1024、8×8、先横后竖、末四格透明的约定。检查每帧在格内、无裁切、空格透明、序号连续。元数据包含帧矩形、帧率、时长、pivot 和坐标约定；Unity bottom-left 的 y 为 `atlas_height-top_y-frame_height`。

## 透明视频

WebM 用支持 Alpha 的 VP9 路径；MOV 用 ProRes 4444；普通 H.264 MP4 不保留独立 Alpha。实际解码检查 Alpha，保留软阴影和抗锯齿的部分透明，不二值化。

```bash
ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=codec_name,width,height,avg_frame_rate,nb_read_frames,pix_fmt:format=duration -of json output.webm
```

WebM Alpha 可能需要 `libvpx-vp9` 解码；默认解码器报告 yuv420p 不足以证明 Alpha 的存在或丢失。

## 用户的 Unity 上下 MP4

本节保存用户已提供的约定。触发“导出上下 MP4 到 Unity”“导出 Unity 上下 MP4”“做成 Unity 上下 MP4”或等价表达时使用；本次明确指定优先。

- 来源 RGBA PNG 序列，确认所有连续帧和顺序，不跳过缺帧或只取预览采样。
- 无明确帧率元数据时 30 fps，有元数据按其执行。
- 每帧 Lanczos 缩放到恰好 720×720。
- 输出 720×1440：上半 RGB 合成纯白底，下半 Alpha 灰度；黑透明、白不透明，保留中间灰度。
- 不修复、腐蚀、膨胀、填洞、重着色或改变源 Alpha。
- H.264：`libx264 -preset slow -crf 15 -pix_fmt yuv420p -movflags +faststart`，无音轨。
- 默认名 `<source-name>_Unity_上白下黑.mp4`。
- 交付前验证宽、高、帧率、时长、实际解码帧数，抽查上下方向和 Alpha 对应关系。

滤镜在缩放后 split：一路 alphaextract，另一路 overlay 到纯白底，再 vstack。白底输入与采样帧率一致，shortest 限定长度。H.264 有损，灰度允许编码近似，不以逐字节相等为验收条件。
