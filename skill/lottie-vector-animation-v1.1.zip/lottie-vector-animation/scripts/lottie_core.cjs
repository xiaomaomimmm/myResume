'use strict';
const fs = require('node:fs'), path = require('node:path');

function args(argv) {
  const result = {_: []};
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (!token.startsWith('--')) result._.push(token);
    else if (['help', 'json', 'loop', 'force', 'sequence'].includes(token.slice(2))) result[token.slice(2)] = true;
    else { if (!argv[i + 1] || argv[i + 1].startsWith('--')) throw Error('Missing value for ' + token); result[token.slice(2)] = argv[++i]; }
  }
  return result;
}
function readJson(file) { return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')); }
function writeJson(file, data, force = false) {
  fs.mkdirSync(path.dirname(path.resolve(file)), {recursive: true});
  fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n', {flag: force ? 'w' : 'wx'});
}
function walk(value, fn, location = '$') {
  fn(value, location);
  if (Array.isArray(value)) value.forEach((item, i) => walk(item, fn, location + '[' + i + ']'));
  else if (value && typeof value === 'object') for (const [key, item] of Object.entries(value)) walk(item, fn, location + '.' + key);
}
function compositions(data) {
  return [{name: 'root', layers: data.layers}, ...(Array.isArray(data.assets) ? data.assets : []).filter(a => Array.isArray(a.layers)).map(a => ({name: a.id, layers: a.layers}))];
}
function animated(value) { return value && typeof value === 'object' && value.a === 1 && Array.isArray(value.k); }
function paths(value) {
  if (value && !Array.isArray(value) && Array.isArray(value.v)) return [value];
  return Array.isArray(value) ? value.flatMap(paths) : [];
}
function same(a, b, epsilon = 1e-4) {
  if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) <= epsilon;
  if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((x, i) => same(x, b[i], epsilon));
  if (a && b && typeof a === 'object' && typeof b === 'object') return Object.keys(a).length === Object.keys(b).length && Object.keys(a).every(k => same(a[k], b[k], epsilon));
  return a === b;
}
function inspect(data) {
  const layers = compositions(data).flatMap(c => Array.isArray(c.layers) ? c.layers : []), shapeTypes = {}, layerTypes = {}, features = new Set();
  let properties = 0, keyframes = 0, pathCount = 0, vertices = 0;
  walk(data, value => {
    if (!value || typeof value !== 'object') return;
    if (animated(value)) { properties++; keyframes += value.k.length; }
    if (Array.isArray(value.v)) { pathCount++; vertices += value.v.length; }
    if (typeof value.ty === 'string') shapeTypes[value.ty] = (shapeTypes[value.ty] || 0) + 1;
    if (typeof value.x === 'string' && value.x.trim()) features.add('expressions');
  });
  for (const layer of layers) {
    layerTypes[layer.ty] = (layerTypes[layer.ty] || 0) + 1;
    if (layer.ddd) features.add('3d');
    if (layer.tt || layer.td) features.add('track-mattes');
    if (layer.masksProperties?.length) features.add('masks');
    if (layer.ef?.length) features.add('effects');
    if (layer.ty === 5) features.add('text');
  }
  if (data.assets?.some(a => a.p)) features.add('raster-assets');
  if (data.assets?.some(a => a.layers)) features.add('precomps');
  return {name: data.nm,version: data.v,width: data.w,height: data.h,fps: data.fr,ip: data.ip,op: data.op,duration: (data.op - data.ip) / data.fr,
    nativeSamples: Math.max(0, Math.ceil(data.op - data.ip)),bytes: Buffer.byteLength(JSON.stringify(data)),layerCount: layers.length,layerTypes,shapeTypes,animatedProperties: properties,keyframes,pathSnapshots: pathCount,verticesAcrossSnapshots: vertices,features: [...features],
    compositions: compositions(data).map(c => ({name: c.name,layers: (Array.isArray(c.layers) ? c.layers : []).map(l => ({ind: l.ind,name: l.nm,type: l.ty,parent: l.parent,refId: l.refId,ip: l.ip,op: l.op}))}))};
}
function lint(data, options = {}) {
  const issues = [], add = (level, code, location, message) => issues.push({level,code,location,message});
  if (!data || typeof data !== 'object' || Array.isArray(data)) return [{level:'FAIL',code:'ROOT',location:'$',message:'Expected a Lottie composition object'}];
  for (const key of ['w', 'h', 'fr']) if (!Number.isFinite(data[key]) || data[key] <= 0) add('FAIL','COMPOSITION','$.' + key,'Must be a positive finite number');
  if (![data.ip, data.op].every(Number.isFinite) || data.op <= data.ip) add('FAIL','RANGE','$','Expected finite ip < op (op is exclusive)');
  if (!Array.isArray(data.layers)) add('FAIL','LAYERS','$.layers','Expected a layers array');
  if (data.assets !== undefined && !Array.isArray(data.assets)) add('FAIL','ASSETS','$.assets','Expected an assets array');
  const assets = Array.isArray(data.assets) ? data.assets : [], assetIds = new Set();
  for (const asset of assets) {
    if (assetIds.has(asset.id)) add('FAIL','ASSET_ID','$.assets','Duplicate asset id: ' + asset.id);
    assetIds.add(asset.id);
    if (asset.p) add('WARN','RASTER','$.assets','Raster asset present; this is not a pure vector export: ' + asset.id);
  }
  for (const comp of compositions(data)) {
    if (!Array.isArray(comp.layers)) continue;
    const byId = new Map();
    for (const layer of comp.layers) {
      const location = comp.name + '/layer:' + layer.ind;
      if (byId.has(layer.ind)) add('FAIL','LAYER_ID',location,'Duplicate layer index in this composition');
      byId.set(layer.ind, layer);
      if (layer.refId !== undefined && !assetIds.has(layer.refId)) add('FAIL','REFERENCE',location,'Missing asset: ' + layer.refId);
      if (![layer.ip, layer.op].every(Number.isFinite) || layer.op <= layer.ip) add('FAIL','LAYER_RANGE',location,'Expected finite layer ip < op');
      if (layer.ddd || layer.ty === 5 || layer.ef?.length || layer.tt || layer.td) add('WARN','RUNTIME',location,'Check 3D/text/effects/mattes in the chosen target runtime');
    }
    for (const layer of comp.layers) {
      const seen = new Set([layer.ind]); let current = layer;
      while (current.parent !== undefined) {
        if (!byId.has(current.parent)) { add('FAIL','PARENT',comp.name + '/layer:' + layer.ind,'Parent is missing from this composition'); break; }
        if (seen.has(current.parent)) { add('FAIL','PARENT_CYCLE',comp.name + '/layer:' + layer.ind,'Cyclic parent chain'); break; }
        seen.add(current.parent); current = byId.get(current.parent);
      }
    }
  }
  walk(data, (value, location) => {
    if (typeof value === 'number' && !Number.isFinite(value)) add('FAIL','NUMBER',location,'Non-finite number');
    if (!value || typeof value !== 'object') return;
    if (typeof value.x === 'string' && value.x.trim()) add('WARN','EXPRESSION',location,'Expression needs target-runtime verification; bake when unsupported');
    if (Array.isArray(value.v)) {
      const valid = value.v.length >= 1 && [value.v,value.i,value.o].every(list => Array.isArray(list) && list.length === value.v.length && list.every(p => Array.isArray(p) && p.length === 2 && p.every(Number.isFinite)));
      if (!valid || typeof value.c !== 'boolean') add('FAIL','PATH',location,'Path needs equally sized v/i/o arrays of finite [x,y] and boolean c');
    }
    if (!animated(value)) return;
    if (!value.k.length) { add('FAIL','KEYS',location,'Animated property has no keys'); return; }
    let previous = -Infinity, topology;
    value.k.forEach((key, i) => {
      if (!Number.isFinite(key.t) || key.t <= previous) add('FAIL','KEY_TIME',location + '.k[' + i + ']','Key times must be finite and strictly increasing');
      previous = key.t;
      if (key.s === undefined && i < value.k.length - 1) add('FAIL','KEY_VALUE',location + '.k[' + i + ']','Nonterminal key is missing its start value');
      for (const shape of [...paths(key.s), ...paths(key.e)]) {
        const signature = shape.v.length + '/' + shape.c;
        if (topology !== undefined && signature !== topology) add('FAIL','MORPH_TOPOLOGY',location,'Path morph changes vertex count or open/closed state');
        topology = signature;
      }
    });
    if (options.loop && value.k.length > 1) {
      const first = value.k[0].s, lastKey = value.k.at(-1), last = lastKey.s ?? value.k.at(-2)?.e;
      if (first !== undefined && last !== undefined && !same(first, last)) add('WARN','LOOP_VALUES',location,'Endpoint values differ; inspect loop visually (periodic rotation, hidden reset, or layer timing may make this intentional)');
    }
  });
  return issues;
}
module.exports = {args,readJson,writeJson,walk,inspect,lint,same};
