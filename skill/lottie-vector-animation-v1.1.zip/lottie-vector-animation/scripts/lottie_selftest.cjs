#!/usr/bin/env node
'use strict';
const assert=require('node:assert/strict'),path=require('node:path'),core=require('./lottie_core.cjs'),{compile}=require('./lottie_generate.cjs');
const clone=value=>JSON.parse(JSON.stringify(value)),fixture=core.readJson(path.join(__dirname,'../assets/pulse-spec.json'));
let count=0;
function test(name,fn){fn();count++;console.log('PASS '+name);}
const errors=data=>core.lint(data).filter(issue=>issue.level==='FAIL');
test('pure vector pulse: two-second range and closed transform keys',()=>{
  const {data,issues}=compile(fixture),report=core.inspect(data);
  assert.equal(data.op,60);assert.equal(report.duration,2);assert.equal(report.nativeSamples,60);assert.equal(data.layers.length,2);assert.equal(data.assets.length,0);assert.deepEqual(issues,[]);
});
test('reject duplicate key times and invalid static transforms',()=>{
  const duplicate=clone(fixture);duplicate.layers[0].animate.scale[1].frame=0;assert.throws(()=>compile(duplicate),/increase/);
  const transform=clone(fixture);transform.layers[0].position=[10,10];assert.throws(()=>compile(transform),/three finite/);
});
test('reject mismatched path topology during generation',()=>{
  const polygon=points=>({v:points,i:points.map(()=>[0,0]),o:points.map(()=>[0,0]),c:true}),a=polygon([[0,0],[10,0],[10,10]]),b=polygon([[0,0],[10,0],[10,10],[0,10]]);
  assert.throws(()=>compile({layers:[{geometry:{type:'path',path:a},animate:{path:[{frame:0,value:a},{frame:60,value:b}]}}]}),/MORPH_TOPOLOGY/);
});
test('reject missing parents and cyclic parent chains',()=>{
  const {data}=compile(fixture);data.layers[0].parent=99;assert(errors(data).some(issue=>issue.code==='PARENT'));
  data.layers[0].parent=2;data.layers[1].parent=1;assert(errors(data).some(issue=>issue.code==='PARENT_CYCLE'));
});
test('track precomp asset references and reject missing assets',()=>{
  const {data}=compile(fixture),child=clone(data.layers[0]);data.assets.push({id:'precomp',layers:[child]});data.layers.push({...clone(child),ind:3,ty:0,refId:'precomp'});
  assert.deepEqual(errors(data),[]);assert(core.inspect(data).features.includes('precomps'));data.layers.at(-1).refId='missing';assert(errors(data).some(issue=>issue.code==='REFERENCE'));
});
test('accept terminal time-only keyframe without hiding missing starts',()=>{
  const {data}=compile(fixture),keys=data.layers[0].ks.s.k;delete keys.at(-1).s;assert.deepEqual(errors(data),[]);
  delete keys[1].s;assert(errors(data).some(issue=>issue.code==='KEY_VALUE'));
});
test('continuous rotation receives a warning, not an invalid-data error',()=>{
  const {data}=compile({loop:true,layers:[{geometry:{type:'ellipse',size:[20,30]},animate:{rotation:[{frame:0,value:0,ease:'linear'},{frame:60,value:360}]}}]});
  const issues=core.lint(data,{loop:true});assert(issues.some(issue=>issue.code==='LOOP_VALUES'));assert(!issues.some(issue=>issue.level==='FAIL'));
});
test('nonzero source in-point preserves sample count and duration',()=>{
  const {data}=compile(fixture);data.ip+=10;data.op+=10;data.layers.forEach(layer=>{layer.ip+=10;layer.op+=10;core.walk(layer,value=>{if(value&&value.a===1&&Array.isArray(value.k))value.k.forEach(key=>key.t+=10);});});
  assert.deepEqual(errors(data),[]);assert.equal(core.inspect(data).nativeSamples,60);assert.equal(core.inspect(data).duration,2);
});
console.log('All '+count+' structural and generation checks passed. Renderer behavior is tested separately with a real runtime.');
