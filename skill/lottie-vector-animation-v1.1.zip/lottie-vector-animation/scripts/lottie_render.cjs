#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{createRequire}=require('node:module');
const core=require('./lottie_core.cjs');
async function render(input,output,options={}) {
  const data=core.readJson(input),issues=core.lint(data),failures=issues.filter(x=>x.level==='FAIL');
  if(failures.length)throw Error('Invalid Lottie: '+JSON.stringify(failures));
  if(!options.runtime)throw Error('Pass --runtime /path/to/lottie_svg.min.js (or a full lottie-web runtime)');
  const runtime=path.resolve(options.runtime);if(!fs.existsSync(runtime))throw Error('Lottie runtime not found: '+runtime);
  let playwright;
  try {playwright=options.playwright?require(path.resolve(options.playwright)):createRequire(path.join(process.cwd(),'package.json'))('playwright');}
  catch {throw Error('Playwright not found. Pass --playwright /path/to/node_modules/playwright or install it in the working project.');}
  const assetRoot=path.resolve(options['asset-root']??path.dirname(path.resolve(input))),out=path.resolve(output);
  const span=data.op-data.ip,last=data.ip+Math.max(0,span-1);
  if(options.sequence&&options.frames)throw Error('Choose --sequence or --frames');
  const frames=options.sequence?Array.from({length:Math.ceil(span)},(_,j)=>data.ip+j):options.frames?String(options.frames).split(',').map(Number):[0,.2,.4,.6,.8,1].map(t=>data.ip+(last-data.ip)*t);
  if(!frames.length||!frames.every(f=>Number.isFinite(f)&&f>=data.ip&&f<data.op))throw Error('Frames must fall in [ip, op); op is exclusive');
  const samples=frames.map((frame,j)=>({index:j,sourceFrame:frame,time:(frame-data.ip)/data.fr,png:'frame_'+String(j).padStart(5,'0')+'.png',svg:'frame_'+String(j).padStart(5,'0')+'.svg'}));
  const names=['report.json','contact-sheet.png',...samples.flatMap(s=>[s.png,s.svg])];
  if(!options.force&&names.some(name=>fs.existsSync(path.join(out,name))))throw Error('Output artifacts exist; choose a new directory or pass --force');
  fs.mkdirSync(out,{recursive:true});
  const html='<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:transparent}#animation{width:'+data.w+'px;height:'+data.h+'px}svg{display:block}</style><div id="animation"></div>';
  const server=http.createServer((req,res)=>{
    if(req.url==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
    let file;
    try {file=path.resolve(assetRoot,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!file.startsWith(assetRoot+path.sep))throw Error();}
    catch {res.writeHead(400);res.end();return;}
    fs.readFile(file,(error,bytes)=>{if(error){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',({'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.json':'application/json','.js':'text/javascript'})[path.extname(file).toLowerCase()]??'application/octet-stream');res.end(bytes);});
  });
  let browser;
  try {
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
    browser=await playwright.chromium.launch({headless:true,...(options.browser?{executablePath:path.resolve(options.browser)}:{})});
    const page=await browser.newPage({viewport:{width:Math.ceil(data.w),height:Math.ceil(data.h)},deviceScaleFactor:1}),errors=[];
    page.on('pageerror',error=>errors.push(error.message));
    page.on('requestfailed',request=>errors.push('Request failed: '+request.url()));
    page.on('response',response=>{if(response.status()>=400)errors.push('HTTP '+response.status()+': '+response.url());});
    await page.goto('http://127.0.0.1:'+server.address().port+'/');await page.addScriptTag({path:runtime});
    await page.evaluate(data=>new Promise((resolve,reject)=>{
      if(typeof lottie==='undefined'){reject(Error('Runtime does not expose window.lottie'));return;}
      const timer=setTimeout(()=>reject(Error('Lottie load timed out')),15000);
      window.player=lottie.loadAnimation({container:document.querySelector('#animation'),renderer:'svg',autoplay:false,loop:false,animationData:data,rendererSettings:{progressiveLoad:false}});
      const ready=()=>{clearTimeout(timer);resolve();};player.addEventListener('DOMLoaded',ready);player.addEventListener('data_failed',()=>{clearTimeout(timer);reject(Error('Lottie data failed'));});if(player.isLoaded)ready();
    }),data);
    for(const sample of samples) {
      const svg=await page.evaluate(({frame,ip})=>{
        player.goToAndStop(frame-ip,true);
        const node=document.querySelector('#animation svg');if(!node)throw Error('SVG renderer produced no SVG');
        for(const p of node.querySelectorAll('path'))if(/NaN|undefined|Infinity/.test(p.getAttribute('d')??''))throw Error('Invalid rendered SVG path');
        const clone=node.cloneNode(true);clone.setAttribute('xmlns','http://www.w3.org/2000/svg');return new XMLSerializer().serializeToString(clone);
      },{frame:sample.sourceFrame,ip:data.ip});
      fs.writeFileSync(path.join(out,sample.svg),svg);
      await page.locator('#animation').screenshot({path:path.join(out,sample.png),omitBackground:true});
    }
    if(errors.length)throw Error('Runtime errors: '+errors.join('; '));
    const chosen=samples.length<=6?samples:[0,.2,.4,.6,.8,1].map(t=>samples[Math.round((samples.length-1)*t)]);
    const cards=chosen.map(sample=>({label:'frame '+Number(sample.sourceFrame.toFixed(3))+' · '+sample.time.toFixed(3)+'s',url:'data:image/png;base64,'+fs.readFileSync(path.join(out,sample.png)).toString('base64')}));
    await page.evaluate(cards=>{
      player.destroy();document.body.innerHTML='<div id="board"></div>';
      const style=document.createElement('style');style.textContent='body{background:#101217;color:#f1f2f5;font:13px sans-serif}#board{display:grid;grid-template-columns:repeat(3,256px);gap:12px;padding:12px;width:max-content}.cell{width:256px}.image{height:256px;display:flex;align-items:center;justify-content:center;background-color:#ddd;background-image:linear-gradient(45deg,#bbb 25%,transparent 25%),linear-gradient(-45deg,#bbb 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#bbb 75%),linear-gradient(-45deg,transparent 75%,#bbb 75%);background-size:16px 16px;background-position:0 0,0 8px,8px -8px,-8px 0}.image img{max-width:256px;max-height:256px}.label{padding:8px 0}';document.head.appendChild(style);
      for(const card of cards){const cell=document.createElement('div');cell.className='cell';const image=document.createElement('div');image.className='image';const img=document.createElement('img');img.src=card.url;image.appendChild(img);const label=document.createElement('div');label.className='label';label.textContent=card.label;cell.append(image,label);document.querySelector('#board').appendChild(cell);}
    },cards);
    await page.evaluate(()=>Promise.all([...document.images].map(image=>image.decode())));
    await page.locator('#board').screenshot({path:path.join(out,'contact-sheet.png')});
    const report={input:path.resolve(input),runtime,renderer:'lottie-web/svg',width:data.w,height:data.h,fps:data.fr,ip:data.ip,op:data.op,duration:span/data.fr,decodedSamples:samples.length,sequence:Boolean(options.sequence),samples,issues,runtimeErrors:errors};
    core.writeJson(path.join(out,'report.json'),report,options.force);return report;
  } finally {if(browser)await browser.close();if(server.listening)await new Promise(resolve=>server.close(resolve));}
}
if(require.main===module)(async()=>{
  const options=core.args(process.argv.slice(2));
  if(options.help||options._.length!==2){console.log('node lottie_render.cjs input.json output-dir --runtime lottie_svg.min.js [--playwright module-dir] [--browser executable] [--asset-root directory] [--frames 0,15,30] [--sequence] [--force]');process.exit(options.help?0:1);}
  const report=await render(options._[0],options._[1],options);console.log(`Rendered ${report.decodedSamples} samples, ${report.width}×${report.height}, ${report.fps}fps; contact-sheet.png and report.json written.`);
})().catch(error=>{console.error(error.message);process.exitCode=1;});
module.exports={render};
