#!/usr/bin/env node
'use strict';
const core = require('./lottie_core.cjs');
try {
  const options = core.args(process.argv.slice(2));
  if (options.help || !options._[0]) { console.log('node lottie_lint.cjs animation.json [--loop] [--json]'); process.exit(options.help ? 0 : 1); }
  const issues = core.lint(core.readJson(options._[0]), options), failures = issues.filter(x=>x.level==='FAIL').length;
  if (options.json) console.log(JSON.stringify({status:failures?'FAIL':issues.length?'WARN':'PASS',issues},null,2));
  else { for (const issue of issues) console.log(`${issue.level} ${issue.code} ${issue.location}: ${issue.message}`); console.log(`${failures?'FAIL':issues.length?'WARN':'PASS'}: ${failures} errors, ${issues.length-failures} warnings`); }
  process.exitCode = failures ? 1 : 0;
} catch (error) { console.error(error.message); process.exitCode = 1; }
