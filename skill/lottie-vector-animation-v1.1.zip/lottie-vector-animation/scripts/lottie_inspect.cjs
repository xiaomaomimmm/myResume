#!/usr/bin/env node
'use strict';
const core = require('./lottie_core.cjs');
try {
  const options = core.args(process.argv.slice(2));
  if (options.help || !options._[0]) { console.log('node lottie_inspect.cjs animation.json [--json]'); process.exit(options.help ? 0 : 1); }
  const data = core.readJson(options._[0]), issues = core.lint(data), failures = issues.filter(x => x.level === 'FAIL');
  if (failures.length) { console.error(JSON.stringify(failures,null,2)); process.exit(1); }
  const report = core.inspect(data);
  if (options.json) console.log(JSON.stringify(report,null,2));
  else {
    console.log(`${report.name || '(unnamed)'} | ${report.width}×${report.height} | ${report.fps}fps | ${report.duration.toFixed(3)}s | ${report.nativeSamples} samples`);
    console.log(`${report.layerCount} layers | ${report.keyframes} keys | ${(report.bytes/1024).toFixed(1)}KiB | features: ${report.features.join(', ') || 'basic vector'}`);
    for (const comp of report.compositions) { console.log('\n[' + comp.name + ']'); for (const l of comp.layers) console.log(`  ${l.ind}: ${l.name || '(unnamed)'} ty=${l.type} parent=${l.parent ?? '-'} ref=${l.refId ?? '-'} [${l.ip},${l.op})`); }
  }
} catch (error) { console.error(error.message); process.exitCode = 1; }
