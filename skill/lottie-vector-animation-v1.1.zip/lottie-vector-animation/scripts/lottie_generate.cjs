#!/usr/bin/env node
'use strict';
const core = require('./lottie_core.cjs');
const prop = k => ({a:0,k});
const zeros = points => points.map(()=>[0,0]);
function color(hex) { if (!/^#[\da-f]{6}$/i.test(hex)) throw Error('Colors must be #RRGGBB'); return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255).concat(1); }
function curve(name) {
  if (name === 'linear') return {o:{x:[1/3],y:[1/3]},i:{x:[2/3],y:[2/3]}};
  if (name === 'smooth' || name === undefined) return {o:{x:[.25],y:[0]},i:{x:[.75],y:[1]}};
  throw Error('Unknown easing: ' + name);
}
function compile(spec) {
  const w=spec.width??512,h=spec.height??512,fr=spec.fps??30,op=Math.round((spec.seconds??2)*fr);
  if (![w,h,fr,op].every(n=>Number.isFinite(n)&&n>0) || !Number.isInteger(w) || !Number.isInteger(h) || op<2) throw Error('Positive integer width/height, positive fps and at least two frames are required');
  if (!Array.isArray(spec.layers)||!spec.layers.length) throw Error('Spec must contain at least one layer');
  function keys(list, shape = false, dimensions) {
    if (!Array.isArray(list)||list.length<2) throw Error('Animation needs at least two keys');
    let previous=-1;
    return {a:1,k:list.map((key,i)=>{
      if (!Number.isFinite(key.frame)||key.frame<0||key.frame>op||key.frame<=previous) throw Error('Key frames must increase within 0..op');
      previous=key.frame;
      if (dimensions && (!Array.isArray(key.value)||key.value.length!==dimensions||!key.value.every(Number.isFinite))) throw Error('Expected '+dimensions+' numeric channels');
      if (!shape&&!dimensions&&!Number.isFinite(key.value)) throw Error('Expected numeric value');
      const wrap=v=>shape?[v]:Array.isArray(v)?v:[v];
      return {t:key.frame,s:wrap(key.value),...(i===list.length-1?{}:{e:wrap(list[i+1].value),...(key.hold?{h:1}:curve(key.ease))})};
    })};
  }
  const data={v:'5.13.0',fr,w,h,ip:0,op,nm:spec.name??'Vector animation',ddd:0,assets:[],layers:[]};
  data.layers=spec.layers.map((layer,j)=>{
    const g=layer.geometry,animation=layer.animate??{},items=[];
    if (!g) throw Error('Layer is missing geometry');
    for(const key of ['position','anchor','scale'])if(layer[key]!==undefined&&(!Array.isArray(layer[key])||layer[key].length!==3||!layer[key].every(Number.isFinite)))throw Error(key+' requires three finite numeric channels');
    for(const key of ['rotation','opacity','strokeWidth'])if(layer[key]!==undefined&&!Number.isFinite(layer[key]))throw Error(key+' must be finite');
    if(layer.opacity!==undefined&&(layer.opacity<0||layer.opacity>100))throw Error('Opacity must be within 0..100');
    if(layer.strokeWidth!==undefined&&layer.strokeWidth<0)throw Error('Stroke width must be nonnegative');
    if (g.type==='ellipse'||g.type==='rect') {
      if (!Array.isArray(g.size)||g.size.length!==2||!g.size.every(n=>Number.isFinite(n)&&n>0)) throw Error('Geometry size needs two positive numbers');
      if(g.radius!==undefined&&(!Number.isFinite(g.radius)||g.radius<0))throw Error('Radius must be nonnegative and finite');
      items.push({ty:g.type==='ellipse'?'el':'rc',p:prop([0,0]),s:prop(g.size),...(g.type==='rect'?{r:prop(g.radius??0)}:{})});
    } else if (g.type==='path'||g.type==='polygon') {
      const shape=g.type==='polygon'?{v:g.points,i:zeros(g.points),o:zeros(g.points),c:g.closed!==false}:g.path;
      items.push({ty:'sh',ks:animation.path?keys(animation.path,true):prop(shape)});
    } else throw Error('Unsupported geometry type: '+g.type);
    if (layer.fill!==null) items.push({ty:'fl',c:prop(color(layer.fill??'#765235')),o:prop(100),r:g.fillRule==='evenodd'?2:1});
    if (layer.stroke) items.push({ty:'st',c:prop(color(layer.stroke)),o:prop(100),w:prop(layer.strokeWidth??4),lc:2,lj:2,ml:4});
    if (animation.trimEnd) { if (!layer.stroke) throw Error('trimEnd requires a stroke'); items.push({ty:'tm',s:prop(0),e:keys(animation.trimEnd),o:prop(0),m:1}); }
    const ks={p:prop(layer.position??[w/2,h/2,0]),a:prop(layer.anchor??[0,0,0]),s:prop(layer.scale??[100,100,100]),r:prop(layer.rotation??0),o:prop(layer.opacity??100)};
    const channels={position:['p',3],scale:['s',3],rotation:['r'],opacity:['o']};
    for (const [name,list] of Object.entries(animation)) {
      if (channels[name]) ks[channels[name][0]]=keys(list,false,channels[name][1]);
      else if (name!=='path'&&name!=='trimEnd') throw Error('Unsupported animation channel: '+name);
    }
    if (animation.path&&!['path','polygon'].includes(g.type)) throw Error('Path animation requires path/polygon geometry');
    return {ddd:0,ind:j+1,ty:4,nm:layer.name??'Shape '+(j+1),sr:1,ks,ao:0,shapes:items,ip:0,op,st:0,bm:0};
  });
  const issues=core.lint(data,{loop:spec.loop});
  if (issues.some(x=>x.level==='FAIL')) throw Error(JSON.stringify(issues,null,2));
  return {data,issues};
}
if (require.main===module) try {
  const options=core.args(process.argv.slice(2));
  if(options.help||options._.length!==2){console.log('node lottie_generate.cjs spec.json output.json [--force]');process.exit(options.help?0:1);}
  const {data,issues}=compile(core.readJson(options._[0]));core.writeJson(options._[1],data,options.force);
  console.log(`Wrote ${data.w}×${data.h}, ${data.fr}fps, ${data.op} frames, ${data.layers.length} vector layers`);
  for(const issue of issues)console.log(`${issue.level} ${issue.code}: ${issue.message}`);
} catch(error){console.error(error.message);process.exitCode=1;}
module.exports={compile};
