---
name: spine-character-animation
description: Spine 2D 角色骨骼动画规范与生成技能。用于：为立绘/角色搭建 Spine 骨骼（层级、命名、IK、伪3D转面）、设计待机 idle 呼吸循环、制作头发/飘带/披风/尾巴/烟雾/蒸汽等链式次级动画、眨眼与表情、角色与道具/场景互动（坐、持物、悬浮伴随物、脚底钉地）、时间与节奏（帧网格、错帧、循环长度）。也用于读取、诊断、批量生成或修改 Spine JSON（3.7–4.3，支持指定目标版本），以及在无编辑器环境下渲染预览。触发词：Spine、骨骼动画、idle、待机动画、呼吸、头发飘动、飘带、链式骨骼、眨眼、动作节奏、错帧、spine json、skeleton json、atlas。
---

# Spine 角色动画技能（Spine Character Animation）

本技能把 **220 个商业级 Spine 3.8 工程**（卡牌/放置类游戏立绘、NPC、怪物、场景物件）的量化分析结果沉淀为可执行规范，并提供零依赖 Node.js 工具，让 AI agent 能 **读懂 → 诊断 → 生成 → 预览校验** Spine 动画。所有数字都来自语料统计（见 `examples/case-studies.md`），不是拍脑袋的经验值。

## 什么时候读哪份文档

| 任务 | 先读 | 再读 |
|---|---|---|
| 从零搭骨骼 / 审查骨骼结构 | `references/01-rigging.md` | `08-naming-glossary.md` |
| 做待机 idle / 呼吸循环 | `references/02-idle.md` | `06-timing-rhythm.md` |
| 头发、飘带、披风、尾巴、耳朵、烟雾、蒸汽、水流 | `references/03-chain-secondary.md` | `02-idle.md` |
| 眨眼、眉眼联动、表情 | `references/04-blink-face.md` | |
| 坐/靠/持物/悬浮伴随物/场景道具 | `references/05-scene-interaction.md` | `01-rigging.md` |
| 时间、节奏、循环长度、表演段落 | `references/06-timing-rhythm.md` | |
| 直接读写 JSON / 指定兼容版本（3.7–最新已验证版本） | `references/07-json-format.md` | |
| 交付前验收 | `references/09-checklist.md` | |
| 参考真实工程的数据 | `examples/case-studies.md` | |

## 版本兼容（生成前确认）

- 支持目标版本：**3.7、3.8、4.0、4.1、4.2、4.3**。2026-10-27 核实的最新正式版是 **4.3.26**；`latest` 固定解析到这个已验证版本。后续发布需核对官方解析源码、增加 profile 并跑回归，不能把未知版本当成 4.x 通用格式。
- 新建 rig 默认 **3.8.99**；修改已有 JSON 默认保留其 `skeleton.spine`。用 `--spine-version` 明确生成目标，不能只改版本字符串。编辑器与运行时的 **major.minor 必须对应**，一个 JSON 不能直接由所有版本运行时通读。
- 骨骼、蒙皮、普通动画及该技能生成的时间轴可以按目标格式转换。新版特性在旧版中没有等价表示时，转换器报错并停止写出；具体范围见 `references/07-json-format.md`。

```bash
node scripts/spine_rig_from_layers.js landmarks.json layers.json out/rig.json --spine-version 3.7
node scripts/spine_gen_secondary.js in.json out/idle.json --spine-version latest --breath hip ty=-8
node scripts/spine_convert.js in.json out/compatible.json --spine-version 4.1
node scripts/spine_convert.js in.json --check
node scripts/spine_compat_test.js
```

转换检查与 lint 是工具检查；交付时还要用对应官方运行时加载/采样，或用对应编辑器 Import Data 检查。软件预览对不支持的约束会给出警告，不能替代完整官方行为验证。

## 黄金参数速查（30 fps）

| 项 | 推荐值 | 语料依据 |
|---|---|---|
| idle 循环长度 | **160f（5.33s）= 2 次呼吸**；短版 80f；长版 240/270/320f | 160f 占 56%，80f 占 26% |
| 一次呼吸周期 | **80f**（2.67s），可用 60/90/100f | 身体骨骼周期 80f 占绝对多数 |
| 关键帧网格 | 主体关键帧落在 **1/4 周期（20f）** 和 **10f** 网格上 | 中位 77% 的 key 落在 10f 网格 |
| 默认缓动 | **bezier (0.25, 0, 0.75, 1)**（ease-in-out） | 占全部曲线 ~47%，其余多为它被错帧切开后的两半 |
| 链式错帧 | 每节延迟 **≈周期/8**（可在 1/10–1/6 之间）：80f → **10f**，40f → 5f，60f → 10f，120f → 18f | 4090 条链中位 10f，71% 全链等延迟 |
| 链式振幅增长 | 子节 ≈ 父节 × **1.6–2.2**（第 2 节≈1.8×、第 3 节≈2.9×、第 4 节≈4.2× 根节） | 中位比 1.77 |
| 链**末节**摆幅 | 刘海 ~20°，后发 ~33°，辫子 ~40°，兽耳 ~37°，尾巴 ~47°，披风 ~18–30°，**裙摆 ~13°**；全体中位 17°，**低于 8° 会显得静止** | 分类统计（这是末节，不是根节，见 03 §1） |
| 链末端位移 | 链长 <5% 身高 → 末端走 18‰ 身高；5–12% → 23‰；12–25% → 39‰；>25% → 65‰；**裙子单独 ~37‰** | 3787 条链实测 |
| 躯干旋转 | 自下而上递增：髋 0–0.5° → 腰 1.4° → 胸 1.8–2.8° → 头 3–8° | spine path 分段统计 |
| 呼吸位移 | 髋/主骨 Y 向 ≈ **身高的 0.4–0.7%**（1300px 立绘约 5–10px） | 中位 7.4‰ |
| 眨眼 | 总长 **7–10f**：闭 2–4f（加速）→ 保持 2–4f（stepped）→ 睁 3–5f（减速） | 中位 9f，59% 工程有眨眼 |
| 眨眼做法 | **网格形变**：睫毛层整体下移到下眼睑（不拉伸，A19），眼皮皮肤压缩；眼白、瞳孔用同一组 key 压扁在眼皮下面；瞳孔不靠隐藏 | 120/128 个眨眼工程用 deform；盖在眼上的 974 个插槽只有 6 个被隐藏 |
| 眼睛几何 | 两眼连线、下眼睑、眼睛中心都按**不透明像素**算，不按网格顶点（整图网格有透明边） | 004 V4：顶点算 30.5°，像素算 16°，原版闭眼线 14.2° |
| 眨眼频率 | 160f 循环 1–2 次；可 25% 概率双眨（间隔 ≤10f） | 1 次 65%，2 次 23% |
| 伪3D 转面 | 平移约束 translateMix **-1**（反向层）+ ±0.02–0.5（随动层），控制骨移动 ~100px | 66% 工程使用 |
| 网格 | 顶点中位 18、p90 48；每网格影响骨中位 2、p95 7（>12 应拆分）；每顶点建议 2–4 骨 | |

## 标准工作流

### ⚠ 图片预算（先读）

图片会占用对话上下文，部分 agent 平台还限制图片总数。为避免大量图层和逐帧预览耗尽上下文，执行以下任务级预算；不要把某个平台的限制当作所有平台的固定上限。

规则：
1. **整个任务最多查看 20 张图，建议控制在 15 张以内**。源素材总览、动画审查板和复查图片共用预算；在 `progress.md` 记录已查看的文件、累计张数及剩余预算。生成但未查看的图片不计入预算；已看过的图只在有具体问题时重看。
2. **能用文本判断的就不看图**：结构看 `spine_inspect.js`，规范看 `spine_lint.js`，运动幅度和接触点看 `spine_render.js --motion`，拆件对应关系看 `--parts` 的控制台输出。
3. **需要看图时只用合成图**：
   - `--sheet`：1 张图包含 6 帧、轨迹、极值帧、setup、洋葱皮和 3 个放大区，代替 strip、trails 加若干 crop；
   - `--parts`：每页 48 个部件，代替逐个部件的 `--isolate`。
   - **不要**逐个部件、逐帧单独出图。
4. **源素材（PSD 图层、贴图页）不要逐张查看**：先用脚本合成一张缩略总览，或直接读图层名和尺寸。
5. **记录进度**：每完成一个阶段（拆件映射 → 骨骼 → 动画 → 验收），把结论写进工作目录的 `progress.md`。即使会话因图片上限中断，新会话读一下 `progress.md` 就能接着做，不必重看已经看过的图。
6. 一次审查循环的建议用量：`--parts` 1–4 张、`--sheet` 每轮 1 张，问题集中的区域用 `--crop` 补看 1 张。一共 3 轮以内。

### A. 分析已有工程（任何 Spine JSON）
```bash
node scripts/spine_inspect.js <dir|file.json>            # 结构 + 节奏 + 链 + 眨眼报告（文本）
node scripts/spine_inspect.js <file.json> --tree         # 附骨骼树（* = 有动画）
node scripts/spine_lint.js   <file.json>                 # 按本规范打分：PASS/WARN/FAIL + 修复建议（文本）
node scripts/spine_render.js <dir|file.json> x --motion  # 各骨骼末端位移 + 接触点是否钉住（文本，不出图）
node scripts/spine_render.js <dir|file.json> out/x --sheet       # ★ 1 张图完成目检
node scripts/spine_render.js <dir|file.json> out/x --parts       # ★ 部件索引板（48 个/页）
```
渲染器需要同目录的 `.atlas` 与贴图页。`--strip N`、`--trails`、`--crop x,y,w,h`、`--frame F`、`--isolate BONE` 仍可使用，但每次都是一张单独的图，只用于 `--sheet` 发现问题后的定点复查。

### B. 从零制作（agent 可执行步骤）
1. **拆件检查**：确认 PSD/图层已按 `01-rigging.md §1` 拆分（头发分前/侧/后、眼睛分眼白/瞳孔/睫毛/闭眼图、衣摆分片、被遮挡部位补画）。不要逐层看图：
   ```bash
   node scripts/psd_layers.js art.psd                          # 文本：编号、组/名称、位置、尺寸、可见性
   node scripts/psd_layers.js art.psd --sheet out/art          # 1 张图：全部图层编号缩略（60 个/页）
   node scripts/psd_layers.js art.psd --composite out/art      # 1 张图：合成预览
   node scripts/psd_layers.js art.psd --export images/         # 每个图层导出 PNG，供 Spine 导入
   ```
   `--sheet` 每页 60 层；多页时用 `--page 2`、`--page 3` 等补齐。先运行编号总览，再结合文字清单判断角色和效果分组；脚本展示图层，不会自动识别角色。**在生成骨骼或动画之前，先把分组结果写入输出工作目录的 `progress.md`**，列出每组 ID、角色/道具/特效用途、图层编号、处理顺序和阶段状态，并检查所有待处理图层都有归属且没有误重复。无 PSD 原生分组时用总览、坐标和遮挡关系判断，不根据无语义的导出名猜测。

   **之后一次只处理一个角色或效果组**：完成该组的拆件映射 → 骨骼/蒙皮 → 动画 → 文本检查与合成图验收，把结论、文件路径、未解决问题和预算写回 `progress.md`，再开始下一组。保持手持道具和角色的挂点关系；共享场景和效果独立成组，全部组完成后才合成完整场景。使用图层选择参数只导出当前组，例如 `--select 9-30,32-108 --export out/warrior/images`；编号沿用原 PSD 清单，文件名带原编号。

   输出位置采用用户本次指定的目录；多 PSD 时用文件名建立子目录，避免覆盖其他作品。用户没有指定时选用当前任务工作目录。绝对路径是任务参数，不固化成该技能在所有机器上的默认路径。
2. **搭骨骼**：按 `01-rigging.md §2` 的标准层级：`root → (IK目标们) + master(髋) → 腰 → 胸 → 颈 → 头 → 面部/头发`；四肢、链条、道具挂点、伪3D 控制骨各就各位，**语义命名**。
   - **脊柱从骨盆向上建**：每根躯干骨从自己的关节指向上一节（世界角度约 90°）；
   - **五官是点**：眼、耳、鼻、嘴是长度 0 的点骨，父骨骼 head；
   - 有 PSD 时先标 25 个定位点，再用 `spine_rig_from_layers.js` 一次生成骨骼、插槽、网格、权重（01 §2.2）：
     ```bash
     node scripts/spine_rig_from_layers.js --template humanoid > landmarks.json   # 改成实际像素坐标
     node scripts/spine_rig_from_layers.js landmarks.json layers.json out/rig.json
     ```
3. **蒙皮**：按 Alpha 轮廓建网格，不用整图矩形网格（01 §4.1）：外轮廓贴着不透明像素走，内部顶点按面积均匀分布；每个图层只沿自己骨骼的同类下游链加权重，关节两侧 smoothstep 过渡。链条网格沿链均匀分配；伪3D 控制骨只给 **小权重（中位 0.035）**。
4. **idle 主体**：用 `02-idle.md` 的“呼吸波”自下而上错帧：髋 0f → 腰 5f → 胸 10f → 颈/头 10–15f → 肩臂 15–20f。
5. **次级动画**：所有链用 `03-chain-secondary.md` 的公式；可直接用生成器：
   ```bash
   node scripts/spine_gen_secondary.js in.json out.json --anim idle --frames 160 \
     --breath hip ty=-10 --breath chest rot=2 sy=0.02 phase=10 --sway head rot=4 phase=17 \
     --chain hair_back_01,hair_back_02,hair_back_03 kind=back_hair phase=20 \
     --chain ear_L_01,ear_L_02,ear_L_03 kind=ear phase=20 --chain ear_R_01,ear_R_02,ear_R_03 kind=ear tip=33 phase=35 \
     --chain ribbon_L_01,ribbon_L_02,ribbon_L_03 kind=ribbon phase=20 \
     --float pet rot=4 ty=12 cycles=2 phase=8 \
     --blink eye_L at=100 closed=eye_L_close            # 附件模式：eye_L 是【插槽】名，closed 是该插槽里的闭眼附件
   # 有上眼皮/睫毛网格时首选网格形变（语料主流，最自然）：每只眼一个 op，左右连着写；眼白、瞳孔放 inner=，不要隐藏瞳孔
   #   --blink eyeL mode=deform lid=lash_L,lid_L inner=white_L,pupil_L brow=brow_L at=100 --blink eyeR mode=deform lid=lash_R inner=white_R,pupil_R at=100
   # 或骨骼模式：--blink eyelid_L mode=scaleY at=100 close=2 hold=3 open=4 minScale=0.1   （eyelid_L 是【骨骼】名）
   # 头是歪的、或眼骨原点不在下眼睑：先插专用眨眼骨，再对新骨骼眨眼（04 §3.3）
   #   --blinkrig eye_L_ctrl --blinkrig eye_R_ctrl --blink eye_L_ctrl_blink mode=scaleY --blink eye_R_ctrl_blink mode=scaleY
   ```
   流体和粒子：大片烟、蒸汽、水流用 `--wave`（控制点波）加 `--alpha`；同类小粒子（火星、气泡、花瓣、小烟球）用 `--drift bone:slot,...`，单向推进、淡入淡出，透明时跳回，按 N 个错开。选法见 `03 §4`。**不要用 `kind=plant` 的旋转链做烟或水**。
   参数单位：`amp/tip/rot` 度（峰峰值），`tx/ty` 像素，`sx/sy` 缩放增量（0.02 = +2%），`lag/phase/at/close/hold/open/life` 帧，`cycles` = 循环内周期数。
   **链条优先用 `kind=`**（bangs / side_hair / back_hair / braid / ahoge / ear / tail / cape / skirt / sleeve / ribbon / pendant / tassel / wing / plant，取语料中位）或 `tip=`（末节摆幅）。`amp=` 是**根节**摆幅，末节 = amp × growth^(节数-1)，直接拿参考表的数填 `amp` 会小好几倍。
   生成器在幅度远低于语料时会打印 WARNINGS；每个 op 的完整参数见脚本头注释（不带参数运行会打印）。
6. **眨眼/表情**：按 `04-blink-face.md`；可放 idle 内或单独 `blink` 动画（track 1，随机间隔）。
   **表演段（只在用户点名时加）**：默认 idle 是纯呼吸循环。用户要求“加一个小动作 / 表演段”时，在循环上叠一个单次动作（撩发、看手、推眼镜、举杯）：
   ```bash
   --beat arm_l,forearm_l at=60 len=60 rot=18 lag=10 kids=hand_l    # 放在同骨骼的 breath/sway/chain 之后
   ```
   它写出五拍（预备 1/3 反向 → 慢起快落 → 过冲 15% → 微动保持 → 回到循环值），子骨骼按 `lag` 延迟、逐级放大 1.3 倍，结束后再摆 2 次衰减。首尾回到循环值，接缝不变，lint 的 A01/A02/A04/A05 不受影响。节奏见 `06-timing-rhythm.md §4`。
7. **互动**：按 `05-scene-interaction.md` 决定道具挂在谁下面、IK 目标挂在谁下面。
8. **节奏审查**：`06-timing-rhythm.md` 的 5 条节奏规则，加上 `spine_render.js --motion`（文本）。
9. **验收**：`spine_lint.js` 0 FAIL，`09-checklist.md` 逐条打勾，最后看一张 `--sheet`。效果、道具、场景组的骨骼用 `fx_`/`prop_`/`scenery_` 前缀命名，lint 会自动识别并跳过人体规则（R04 A11 A12 A13）；也可以用 `--kind fx` 显式指定。不要为了消掉 WARN 给烟雾或地面加躯干。如果 6 帧看起来几乎一样，就是幅度太小（lint A11/A12/A13 会报）；如果洋葱皮或放大区里有缝、撕裂或露底，回到对应步骤修正。

### C. 修改 / 批量处理
- 改动 JSON 前先 `spine_inspect.js` 记录基线；改完再跑一次对比链延迟、循环闭合、网格对齐。
- 生成器会**替换**同骨骼同类型时间轴；先备份。版本由 `skeleton.spine` 自动判断；3.7、3.8、4.0、4.1、4.2、4.3 各有差异，跨版本用 `--spine-version` 或转换器（见 `07-json-format.md`）。
- 导出到运行时用 binary（.skel），JSON 仅供工具链；要回导编辑器需勾选 Nonessential data。

## 核心原则（违反任何一条都会显得“假”）

1. **root 永不动画**，身体运动从 master/髋骨开始；脚的 IK 目标挂 root 或静止的地面骨，保证脚底钉地（语料 78% 的脚部 IK 目标全程不动）。
2. **循环必须闭合**：每条时间轴的末帧 = 首帧（语料 99.2% 闭合）；呼吸周期整除循环长度。唯一例外：单向粒子（纸屑、火星、音符）可以不闭合，前提是它们在循环接缝处 alpha=0 或没有附件。
3. **运动从根传到梢**：躯干自下而上、链条自根到尖，每级延迟同一个“错帧量”，振幅逐级放大。
4. **主体守网格，次级才错帧**：身体主 key 在 10/20f 网格上，头发/饰品错开 5/10/15f 起点（语料 70% 的时间轴有起点偏移）。
5. **同类不同相，叠压层同相**：多缕头发、多条飘带、两只耳朵不同步，给每缕不同起始偏移或镜像反相；但互相叠压的布料层（内外裙、前后摆）要同相（相位差 ≤5f），宽布料沿宽度并排多条链，否则会张开露底（03 §3.1）。
6. **待机 ≠ 静止，幅度太小也是错**：91% 的骨骼都有动画。躯干幅度小（1–3°），末端次级大（末节中位 17°）。时间结构全对、幅度却只有参考值 1/5 的 idle，看起来就是一张静图。这是生成式 idle 最常见的失败，遮挡/拆件不足不能当缩幅的理由（应缩短可动链，而不是整体缩小）。
7. **眨眼要快**：7–10f，闭眼比睁眼快，闭合帧 stepped 保持。
8. **伪3D 用约束不用逐帧**：一根控制骨 + 平移约束（-1 反向 / 小正值随动）驱动整张脸或身体的“转动”。
9. **道具跟随谁就挂谁下面**：手持物挂手/前臂；坐具、地面、背景挂 root；悬浮伴随物挂 root 自带漂浮循环。
10. **命名语义化**：语料 79% 工程是 `bone12` / `X_spine_34` 这种无意义命名——这是要改掉的坏习惯，不是要学的范式。

## 文件清单
```
SKILL.md                      本文件：入口、速查、工作流
references/01-rigging.md      骨骼创建规范（拆件、层级、命名、IK、伪3D、网格权重）
references/02-idle.md         骨骼 idle 动画规范（呼吸波、分部位参数、变体）
references/03-chain-secondary.md 链式骨骼：头发/飘带/披风/尾巴/烟雾/蒸汽/水
references/04-blink-face.md   眨眼与面部
references/05-scene-interaction.md 角色与场景/道具互动
references/06-timing-rhythm.md 时间与节奏把控
references/07-json-format.md  Spine JSON 速查（3.7 / 3.8 / 4.0 / 4.1 / 4.2 / 4.3 差异与转换边界）
references/08-naming-glossary.md 命名规范 + 拼音/英文部位词典
references/09-checklist.md    交付验收清单
examples/case-studies.md      10 个样本工程的实测拆解 + 1 个端到端实测（含“幅度过小”反例与修正）+ 全语料统计
scripts/spine_core.js         公共库（版本归一、曲线、采样、链检测）
scripts/spine_inspect.js      分析报告
scripts/spine_lint.js         规范检查
scripts/spine_render.js       无依赖渲染：--sheet 审查板、--parts 部件索引、--motion 文本，以及单帧/连拍/轨迹/裁切
scripts/spine_gen_secondary.js 程序化生成呼吸/链条/漂浮/眨眼/波动/透明度脉冲/表演段（3.7–4.3 目标版本）
scripts/spine_rig_from_layers.js 定位点 + 图层 PNG → 骨骼（脊柱向上、五官为点）+ Alpha 轮廓网格 + 关节权重
scripts/spine_compat.js       版本 profile、格式验证、拒绝有损降级的转换库
scripts/spine_convert.js      JSON 版本转换 / --check
scripts/spine_compat_test.js  零依赖兼容回归测试
scripts/spine_convert_38_to_42.js 旧命令兼容入口（调用同一转换库）
scripts/psd_layers.js         PSD/PSB 图层读取：文本清单、编号总览图、合成预览、逐层导出 PNG
```
所有脚本只依赖 Node.js（≥14，无 npm 包），可在 Windows / macOS / Linux 运行。
