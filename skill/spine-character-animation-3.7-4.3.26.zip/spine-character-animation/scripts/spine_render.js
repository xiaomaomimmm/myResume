#!/usr/bin/env node
// spine_render.js — dependency-free Spine JSON (3.7–4.3) software renderer -> PNG.
// Renders the setup pose or any animation frame, a strip of frames, or motion trails of every
// animated bone tip — so an agent can *see* a rig / animation without the Spine editor.
//
// Usage:
//   node spine_render.js <dir|file.json> <outPrefix> [--anim NAME] [--frame F] [--max PX]
//        [--sheet]          ★ ONE review image: 6 frames + trails + extreme frame + setup + onion skin
//                           + zoomed regions at F0/extreme. Use this instead of many separate images.
//        [--regions "x,y,w,h;x,y,w,h"]  zoom regions for --sheet (default: auto = biggest movers + feet)
//        [--parts] [--page N]  ★ ONE contact sheet of all slots (48 per page) with index labels;
//                           console prints index → slot / bone. Replaces one --isolate image per part.
//        [--motion]         ★ TEXT only: tip travel of every moving bone + contact check (no PNG)
//        [--strip N]        N evenly spaced frames side by side (frame numbers printed)
//        [--trails]         dim the character and draw bone-tip paths over one loop
//        [--isolate BONE]   draw only slots under BONE      [--hide BONE] hide slots under BONE
//        [--atlas FILE]     atlas path if not next to the json
//        [--crop x,y,w,h]   render only this region (skeleton units, y up — same as the Spine editor);
//                           get coordinates from --bones
//        [--bones]          print every bone's world position (x,y) at --frame and exit (no PNG)
// Limits: path & physics constraints are not simulated, clipping is ignored, transform
// constraints are evaluated in world/absolute mode only. Good enough for pose/timing review.
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const C = require('./spine_core');

// ---------------- PNG ----------------
function decodePNG(buf) {
  if (buf.readUInt32BE(0) !== 0x89504e47) throw new Error('not a png');
  let pos = 8, w = 0, h = 0, bd = 0, ct = 0, il = 0, palette = null, trns = null;
  const idat = [];
  while (pos < buf.length) {
    const len = buf.readUInt32BE(pos), type = buf.toString('ascii', pos + 4, pos + 8);
    const data = buf.subarray(pos + 8, pos + 8 + len);
    if (type === 'IHDR') { w = data.readUInt32BE(0); h = data.readUInt32BE(4); bd = data[8]; ct = data[9]; il = data[12]; }
    else if (type === 'PLTE') palette = data;
    else if (type === 'tRNS') trns = data;
    else if (type === 'IDAT') idat.push(data);
    else if (type === 'IEND') break;
    pos += 12 + len;
  }
  if (bd !== 8 || il !== 0) throw new Error(`unsupported png bitDepth=${bd} interlace=${il}`);
  const ch = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[ct];
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = w * ch, out = new Uint8Array(w * h * 4);
  let prev = new Uint8Array(stride), cur = new Uint8Array(stride), p = 0;
  for (let y = 0; y < h; y++) {
    const f = raw[p++];
    for (let x = 0; x < stride; x++) {
      const r = raw[p++], a = x >= ch ? cur[x - ch] : 0, b = prev[x], c = x >= ch ? prev[x - ch] : 0;
      let v;
      if (f === 0) v = r;
      else if (f === 1) v = r + a;
      else if (f === 2) v = r + b;
      else if (f === 3) v = r + ((a + b) >> 1);
      else { const pp = a + b - c, pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c); v = r + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c); }
      cur[x] = v & 255;
    }
    for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4, i = x * ch;
      if (ct === 6) { out[o] = cur[i]; out[o + 1] = cur[i + 1]; out[o + 2] = cur[i + 2]; out[o + 3] = cur[i + 3]; }
      else if (ct === 2) { out[o] = cur[i]; out[o + 1] = cur[i + 1]; out[o + 2] = cur[i + 2]; out[o + 3] = 255; }
      else if (ct === 0) { out[o] = out[o + 1] = out[o + 2] = cur[i]; out[o + 3] = 255; }
      else if (ct === 4) { out[o] = out[o + 1] = out[o + 2] = cur[i]; out[o + 3] = cur[i + 1]; }
      else { const k = cur[i]; out[o] = palette[k * 3]; out[o + 1] = palette[k * 3 + 1]; out[o + 2] = palette[k * 3 + 2]; out[o + 3] = trns && k < trns.length ? trns[k] : 255; }
    }
    const t = prev; prev = cur; cur = t;
  }
  return { w, h, data: out };
}
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(b) { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function encodePNG(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) Buffer.from(rgba.buffer, rgba.byteOffset + y * w * 4, w * 4).copy(raw, y * (w * 4 + 1) + 1);
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

// ---------------- atlas ----------------
function parseAtlas(file) {
  const lines = fs.readFileSync(file, 'utf8').replace(/^﻿/, '').split(/\r?\n/);
  const pages = [], regions = new Map();
  let page = null, region = null, expectPage = true;
  for (const raw of lines) {
    if (!raw.trim()) { expectPage = true; region = null; continue; }
    const indented = /^\s/.test(raw), line = raw.trim(), ci = line.indexOf(':');
    if (ci < 0) {
      if (expectPage || !page) { page = { name: line }; pages.push(page); region = null; }
      else { region = { name: line, page, rotate: false, index: -1 }; if (!regions.has(line)) regions.set(line, region); }
      expectPage = false;
      continue;
    }
    expectPage = false;
    const key = line.slice(0, ci).trim(), vals = line.slice(ci + 1).split(',').map(s => s.trim());
    if (!region) { page[key] = vals; continue; } // page props (3.8: flush left, 4.x: indented)
    if (key === 'rotate') { region.degrees = vals[0] === 'true' ? 90 : vals[0] === 'false' ? 0 : +vals[0]; region.rotate = region.degrees === 90 || region.degrees === 270; if (![0, 90, 180, 270].includes(region.degrees)) throw new Error(`unsupported atlas rotation ${vals[0]}`); }
    else if (key === 'xy') { region.x = +vals[0]; region.y = +vals[1]; }
    else if (key === 'size') { region.w = +vals[0]; region.h = +vals[1]; }
    else if (key === 'orig') { region.ow = +vals[0]; region.oh = +vals[1]; }
    else if (key === 'offset') { region.ox = +vals[0]; region.oy = +vals[1]; }
    else if (key === 'bounds') { region.x = +vals[0]; region.y = +vals[1]; region.w = +vals[2]; region.h = +vals[3]; } // 4.x
    else if (key === 'offsets') { region.ox = +vals[0]; region.oy = +vals[1]; region.ow = +vals[2]; region.oh = +vals[3]; } // 4.x
    else if (key === 'index') region.index = +vals[0];
  }
  for (const r of regions.values()) {
    if (r.ow === undefined) { r.ow = r.w; r.oh = r.h; }
    if (r.ox === undefined) { r.ox = 0; r.oy = 0; }
    if (r.index >= 0 && !regions.has(`${r.name}_${r.index}`)) regions.set(`${r.name}_${r.index}`, r);
  }
  return { pages, regions };
}

// ---------------- math ----------------
const D2R = Math.PI / 180, R2D = 180 / Math.PI;
const cosd = a => Math.cos(a * D2R), sind = a => Math.sin(a * D2R);
const def = (v, d) => (v === undefined ? d : v);
const wrap = r => r - (16384 - Math.floor(16384.499999999996 - r / 360)) * 360;
function bezierY(x1, y1, x2, y2, t) {
  let lo = 0, hi = 1, s = t;
  for (let i = 0; i < 24; i++) {
    s = (lo + hi) / 2;
    const x = 3 * (1 - s) * (1 - s) * s * x1 + 3 * (1 - s) * s * s * x2 + s * s * s;
    if (x < t) lo = s; else hi = s;
  }
  return 3 * (1 - s) * (1 - s) * s * y1 + 3 * (1 - s) * s * s * y2 + s * s * s;
}
function hexColor(h) {
  const v = h || 'ffffffff';
  return [0, 2, 4, 6].map(i => (i < v.length ? parseInt(v.substr(i, 2), 16) / 255 : 1));
}

// ---------------- skeleton ----------------
// `input` = directory containing one .json + .atlas + pages, or a .json path; atlasFile optional.
function loadProject(input, atlasFile) {
  let dir = input, jf;
  if (fs.statSync(input).isFile()) { dir = path.dirname(input); jf = path.basename(input); }
  const files = fs.readdirSync(dir);
  jf = jf || files.find(f => f.toLowerCase().endsWith('.json'));
  if (!jf) throw new Error(`no .json in ${dir}`);
  const j = JSON.parse(fs.readFileSync(path.join(dir, jf), 'utf8').replace(/^﻿/, ''));
  return Object.assign(buildSkeleton(j), { atlas: loadAtlasFor(path.join(dir, jf), atlasFile) });
}
// Atlas (pages decoded) for a skeleton JSON: <stem>.atlas or the only .atlas next to it. Throws if none.
function loadAtlasFor(jsonFile, atlasFile) {
  const dir = path.dirname(jsonFile), files = fs.readdirSync(dir), stem = path.basename(jsonFile).replace(/\.json$/i, '');
  const af = atlasFile || path.join(dir, files.find(f => f === stem + '.atlas') || files.find(f => /\.atlas(\.txt)?$/i.test(f)) || '');
  if (!af || !fs.existsSync(af) || !fs.statSync(af).isFile()) throw new Error(`no .atlas next to ${path.basename(jsonFile)}; pass --atlas`);
  const atlas = parseAtlas(af);
  for (const pg of atlas.pages) pg.img = decodePNG(fs.readFileSync(path.join(path.dirname(af), pg.name)));
  // 4.x "pma:true" pages store premultiplied colour; un-premultiply so blending below stays straight-alpha
  for (const pg of atlas.pages) if (pg.pma && pg.pma[0] === 'true') { const d = pg.img.data; for (let i = 0; i < d.length; i += 4) { const a = d[i + 3]; if (a > 0 && a < 255) { d[i] = Math.min(255, d[i] * 255 / a); d[i + 1] = Math.min(255, d[i + 1] * 255 / a); d[i + 2] = Math.min(255, d[i + 2] * 255 / a); } } }
  for (const r of atlas.regions.values()) {
    const pw = r.page.img.w, ph = r.page.img.h;
    r.u = r.x / pw; r.v = r.y / ph;
    if (r.rotate) { r.u2 = (r.x + r.h) / pw; r.v2 = (r.y + r.w) / ph; } else { r.u2 = (r.x + r.w) / pw; r.v2 = (r.y + r.h) / ph; }
  }
  return atlas;
}

// Setup-pose bounds {x, y, width, height} from attachment vertices (regions use width/height,
// meshes their vertices); falls back to bone positions. Needed because skeleton.x/y/width/height
// are nonessential data and may be missing or 0 in editor exports.
// World-space outline points of a slot's current attachment WITHOUT an atlas (regions: width/height box,
// meshes: vertices incl. weights; deform only with withDeform after pose(..., false)). Empty if none.
function slotPoints(sk, s, attName, withDeform) {
  const name = attName === undefined ? (s.attName !== undefined ? s.attName : s.data.attachment) : attName;
  if (!name) return [];
  const att = getAttachment(sk, s.name, name);
  if (!att) return [];
  const sourceName = att.source || att.parent;
  const geometry = sourceName ? getAttachment(sk, att.slot || s.name, sourceName, att.skin || 'default') : att;
  if (!geometry) return [];
  const timelineSource = att.timelines !== false && att.deform !== false;
  const sourceSlot = sk.slotByName.get(att.slot || s.name);
  const dm = withDeform && (s.deform && s.deform[name] || timelineSource && sourceSlot && sourceSlot.deform && sourceSlot.deform[sourceName]);
  const dv = i => (dm ? def(dm.get(i), 0) : 0);
  const out = [], b = s.bone;
  const add = (x, y) => out.push([x * b.a + y * b.b + b.worldX, x * b.c + y * b.d + b.worldY]);
  const type = att.type || 'region';
  if (type === 'region') {
    const w = def(att.width, 0) * def(att.scaleX, 1) / 2, h = def(att.height, 0) * def(att.scaleY, 1) / 2;
    const c = cosd(def(att.rotation, 0)), sn = sind(def(att.rotation, 0)), ox = def(att.x, 0), oy = def(att.y, 0);
    for (const [px, py] of [[-w, -h], [w, -h], [w, h], [-w, h]]) add(px * c - py * sn + ox, px * sn + py * c + oy);
  } else if ((type === 'mesh' || type === 'linkedmesh') && geometry.vertices && geometry.uvs) {
    const v = geometry.vertices;
    if (v.length === geometry.uvs.length) { for (let i = 0; i < v.length; i += 2) add(v[i] + dv(i), v[i + 1] + dv(i + 1)); }
    else for (let i = 0, f = 0; i < v.length;) {
      const n = v[i++];
      let wx = 0, wy = 0;
      for (let k = 0; k < n; k++, i += 4, f += 2) { const bb = sk.bones[v[i]], w = v[i + 3], x = v[i + 1] + dv(f), y = v[i + 2] + dv(f + 1); wx += (x * bb.a + y * bb.b + bb.worldX) * w; wy += (x * bb.c + y * bb.d + bb.worldY) * w; }
      out.push([wx, wy]);
    }
  }
  return out;
}

// Geometry check for a scaleY blink on `bone` (setup pose): where its origin sits inside the eye it
// squashes, whether its local Y is vertical, and whether the slots are whole-eye drawings.
// t: 0 = origin on the lower lid, 1 = on the upper lid (>0.6 closes upward). null if no eye geometry.
// The eye must squash PERPENDICULAR TO THE FACE'S HORIZONTAL LINE (the line through both eyes), not
// to the world vertical — a tilted head (e.g. 23°) otherwise gets a slanted blink. `partner` = the other
// eye's bone (auto: same name with L/R swapped, or another eye-named sibling); without one, the head
// bone's world X axis is used as the face line.
function eyeSlotsOf(sk, bone) {
  const under = s => { for (let x = s.bone; x; x = x.parent) if (x === bone) return true; return false; };
  return sk.slots.filter(under);
}
// Centre of what is DRAWN, not the mean of mesh vertices (an equal-weight vertex mean is pulled toward small
// parts and transparent margins — 004 V4: 30.5° face line from vertices vs 21° from pixels):
// opaque-texel centroid when sk.atlas is loaded, else triangle-area-weighted centroid.
function drawnCentre(sk, slots) {
  let sx = 0, sy = 0, n = 0;
  if (sk.atlas) {
    for (const s of slots) for (const p of opaqueTexels(sk, s, 2)) { sx += p.x; sy += p.y; n++; }
    if (n) return [sx / n, sy / n];
  }
  for (const s of slots) {
    const pts = slotPoints(sk, s, s.attName !== undefined && s.attName !== null ? s.attName : s.data.attachment, true);
    const att = getAttachment(sk, s.name, s.attName || s.data.attachment);
    const tris = att && att.triangles;
    if (tris && pts.length) for (let t = 0; t < tris.length; t += 3) {
      const [a, b, c] = [pts[tris[t]], pts[tris[t + 1]], pts[tris[t + 2]]];
      if (!a || !b || !c) continue;
      const A = Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
      sx += A * (a[0] + b[0] + c[0]) / 3; sy += A * (a[1] + b[1] + c[1]) / 3; n += A;
    } else if (pts.length === 4) { // region quad: its centre, weighted by area
      const A = Math.hypot(pts[1][0] - pts[0][0], pts[1][1] - pts[0][1]) * Math.hypot(pts[3][0] - pts[0][0], pts[3][1] - pts[0][1]);
      sx += A * pts.reduce((t, p) => t + p[0], 0) / 4; sy += A * pts.reduce((t, p) => t + p[1], 0) / 4; n += A;
    }
  }
  return n ? [sx / n, sy / n] : null;
}
// Eye centre = drawn centre of the MAIN eye drawing (the slot with the most opaque texels / largest area):
// small extra pieces parented to the eye bone (highlights, a white patch beside the eye, 004 V4 eye_R_127)
// pull an all-slot centroid sideways and tilt the face line (alchemist: 20.9° all slots vs 16.0° main drawing;
// the footage/004 reference closes that eye along 14.2°).
function eyeCentre(sk, bone) {
  const slots = eyeSlotsOf(sk, bone);
  if (!slots.length) return null;
  const size = s => (sk.atlas ? opaqueTexels(sk, s, 2).length : (() => { const p = slotPoints(sk, s, s.data.attachment, true); if (p.length < 3) return 0; const xs = p.map(q => q[0]), ys = p.map(q => q[1]); return (Math.max(...xs) - Math.min(...xs)) * (Math.max(...ys) - Math.min(...ys)); })());
  const main = slots.map(s => [s, size(s)]).sort((a, b) => b[1] - a[1])[0];
  return main[1] > 0 ? drawnCentre(sk, [main[0]]) : drawnCentre(sk, slots);
}
// Visible texture smear of deformed meshes at time t: rasterise the region around `slotNames` (Set) top-most-wins,
// and count visible DETAILED texels (max |Δlum|,|Δalpha| to 4 neighbours > 0.25) of those slots whose triangle's
// affine map from the undeformed pose (same bones, deform removed) stretches > 1.8× in some direction or flips.
// Returns { detail, bad, maxStretch, per: [{slot, detail, bad}] } or null. Needs sk.atlas.
function deformSmear(sk, anim, t, slotNames) {
  if (!sk.atlas) return null;
  const noDef = Object.assign({}, anim, { deform: undefined, attachments: undefined });
  pose(sk, noDef, t, false);
  const base = new Map();
  for (const s of sk.slots) if (slotNames.has(s.name) && s.attName) { const g = slotGeom(sk, s); if (g) base.set(s.name, g.pts.map(p => p.slice())); }
  pose(sk, anim, t, false);
  const geo = [];
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const s of sk.drawOrder) {
    if (!s.attName || s.color[3] < 0.05) continue;
    const g = slotGeom(sk, s); if (!g) continue;
    geo.push([s, g]);
    if (slotNames.has(s.name)) for (const p of g.pts) { x0 = Math.min(x0, p[0]); y0 = Math.min(y0, p[1]); x1 = Math.max(x1, p[0]); y1 = Math.max(y1, p[1]); }
  }
  if (!isFinite(x0) || (x1 - x0) * (y1 - y0) > 600 * 600) return null;
  const W = Math.ceil(x1 - x0) + 1, H = Math.ceil(y1 - y0) + 1;
  const top = new Int32Array(W * H).fill(-1), info = [];
  for (const [s, g] of geo) {
    const img = g.region.page.img, b0 = slotNames.has(s.name) && base.get(s.name);
    const lumA = (x, y) => { x = Math.min(img.w - 1, Math.max(0, x)); y = Math.min(img.h - 1, Math.max(0, y)); const i = (y * img.w + x) * 4; return [(0.3 * img.data[i] + 0.59 * img.data[i + 1] + 0.11 * img.data[i + 2]) / 255, img.data[i + 3] / 255]; };
    for (let q = 0; q < g.tris.length; q += 3) {
      const ids = [g.tris[q], g.tris[q + 1], g.tris[q + 2]], P = ids.map(i => g.pts[i]), UV = ids.map(i => g.uvs[i]);
      const d = (P[1][1] - P[2][1]) * (P[0][0] - P[2][0]) + (P[2][0] - P[1][0]) * (P[0][1] - P[2][1]);
      if (Math.abs(d) < 1e-9) continue;
      let sig = 1, flip = false;
      if (b0 && b0.length === g.pts.length) {
        const Q = ids.map(i => b0[i]);
        const a = Q[1][0] - Q[0][0], b = Q[2][0] - Q[0][0], c = Q[1][1] - Q[0][1], e = Q[2][1] - Q[0][1], dq = a * e - b * c;
        if (Math.abs(dq) > 1e-9) {
          const ia = e / dq, ib = -b / dq, ic = -c / dq, id2 = a / dq;
          const m1 = P[1][0] - P[0][0], m2 = P[2][0] - P[0][0], m3 = P[1][1] - P[0][1], m4 = P[2][1] - P[0][1];
          const A11 = m1 * ia + m2 * ic, A12 = m1 * ib + m2 * id2, A21 = m3 * ia + m4 * ic, A22 = m3 * ib + m4 * id2;
          const s1 = A11 * A11 + A12 * A12 + A21 * A21 + A22 * A22, s2 = A11 * A22 - A12 * A21;
          sig = Math.sqrt(s1 / 2 + Math.sqrt(Math.max(0, s1 * s1 / 4 - s2 * s2)));
          flip = Math.sign(dq) !== Math.sign(d);
        }
      }
      const bx0 = Math.max(0, Math.floor(Math.min(P[0][0], P[1][0], P[2][0]) - x0)), bx1 = Math.min(W - 1, Math.ceil(Math.max(P[0][0], P[1][0], P[2][0]) - x0));
      const by0 = Math.max(0, Math.floor(Math.min(P[0][1], P[1][1], P[2][1]) - y0)), by1 = Math.min(H - 1, Math.ceil(Math.max(P[0][1], P[1][1], P[2][1]) - y0));
      for (let py = by0; py <= by1; py++) for (let px = bx0; px <= bx1; px++) {
        const X = px + 0.5 + x0, Y = py + 0.5 + y0;
        const l1 = ((P[1][1] - P[2][1]) * (X - P[2][0]) + (P[2][0] - P[1][0]) * (Y - P[2][1])) / d, l2 = ((P[2][1] - P[0][1]) * (X - P[2][0]) + (P[0][0] - P[2][0]) * (Y - P[2][1])) / d, l3 = 1 - l1 - l2;
        if (l1 < 0 || l2 < 0 || l3 < 0) continue;
        const u = UV[0][0] * l1 + UV[1][0] * l2 + UV[2][0] * l3, v = UV[0][1] * l1 + UV[1][1] * l2 + UV[2][1] * l3;
        const tx = Math.min(img.w - 1, Math.max(0, Math.floor(u * img.w))), ty = Math.min(img.h - 1, Math.max(0, Math.floor(v * img.h)));
        if (img.data[(ty * img.w + tx) * 4 + 3] < 128) continue;
        let det = 0;
        if (b0) { const c0 = lumA(tx, ty); for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const n = lumA(tx + dx, ty + dy); det = Math.max(det, Math.abs(n[0] - c0[0]), Math.abs(n[1] - c0[1])); } }
        top[py * W + px] = info.length; info.push([s.name, det > 0.25, flip || sig > 1.8, sig]);
      }
    }
  }
  const per = new Map(); let detail = 0, bad = 0, maxStretch = 1;
  for (let i = 0; i < top.length; i++) {
    if (top[i] < 0) continue;
    const [sn, isDet, isBad, sig] = info[top[i]];
    if (!slotNames.has(sn) || !isDet) continue;
    detail++; const e = per.get(sn) || { slot: sn, detail: 0, bad: 0 }; e.detail++;
    if (isBad) { bad++; e.bad++; maxStretch = Math.max(maxStretch, sig); }
    per.set(sn, e);
  }
  return { detail, bad, maxStretch, per: [...per.values()] };
}
// Skeleton plus its atlas when one sits next to the JSON (texel-accurate eye geometry); atlas-free otherwise.
function skeletonFor(j, jsonFile) {
  const sk = buildSkeleton(j);
  if (jsonFile) try { sk.atlas = loadAtlasFor(jsonFile); } catch (e) { /* no atlas: vertex geometry */ }
  return sk;
}
// What a slot draws, as world points: opaque texels with an atlas (meshes are often grids over the whole image
// rect — their vertices include transparent margins), else the attachment outline. Pose with bonesOnly=false.
function drawnPoints(sk, s, step = 1) {
  if (sk.atlas) { const t = opaqueTexels(sk, s, step); if (t.length) return t.map(p => [p.x, p.y]); }
  return slotPoints(sk, s, s.attName !== undefined && s.attName !== null ? s.attName : s.data.attachment, true);
}
// World positions of OPAQUE texels (alpha ≥ 0.5) of a slot's current attachment, mapped through its triangles
// with the current pose (deform included; call pose(..., false) first). Needs sk.atlas (loadProject).
// Returns [{x, y, tx, ty, lum}] — tx,ty = atlas page texel, lum = 0..1 luminance.
function opaqueTexels(sk, slot, step = 1) {
  if (!sk.atlas) return [];
  if (slot.attName === undefined) slot.attName = slot.data.attachment || null;
  const g = slotGeom(sk, slot);
  if (!g) return [];
  const img = g.region.page.img, out = [], T = g.tris;
  for (let t = 0; t < T.length; t += 3) {
    const ids = [T[t], T[t + 1], T[t + 2]];
    const uv = ids.map(i => [g.uvs[i][0] * img.w, g.uvs[i][1] * img.h]), P = ids.map(i => g.pts[i]);
    const d = (uv[1][1] - uv[2][1]) * (uv[0][0] - uv[2][0]) + (uv[2][0] - uv[1][0]) * (uv[0][1] - uv[2][1]);
    if (Math.abs(d) < 1e-9) continue;
    const x0 = Math.max(0, Math.floor(Math.min(uv[0][0], uv[1][0], uv[2][0]))), x1 = Math.min(img.w - 1, Math.ceil(Math.max(uv[0][0], uv[1][0], uv[2][0])));
    const y0 = Math.max(0, Math.floor(Math.min(uv[0][1], uv[1][1], uv[2][1]))), y1 = Math.min(img.h - 1, Math.ceil(Math.max(uv[0][1], uv[1][1], uv[2][1])));
    for (let y = y0; y <= y1; y += step) for (let x = x0; x <= x1; x += step) {
      const px = x + 0.5, py = y + 0.5;
      const l1 = ((uv[1][1] - uv[2][1]) * (px - uv[2][0]) + (uv[2][0] - uv[1][0]) * (py - uv[2][1])) / d;
      const l2 = ((uv[2][1] - uv[0][1]) * (px - uv[2][0]) + (uv[0][0] - uv[2][0]) * (py - uv[2][1])) / d, l3 = 1 - l1 - l2;
      if (l1 < -1e-6 || l2 < -1e-6 || l3 < -1e-6) continue;
      const i = (y * img.w + x) * 4;
      if (img.data[i + 3] < 128) continue;
      out.push({ x: P[0][0] * l1 + P[1][0] * l2 + P[2][0] * l3, y: P[0][1] * l1 + P[1][1] * l2 + P[2][1] * l3, tx: x, ty: y, lum: (0.3 * img.data[i] + 0.59 * img.data[i + 1] + 0.11 * img.data[i + 2]) / 255 });
    }
  }
  return out;
}
function partnerEye(sk, bone) {
  const swaps = [[/_L(?=_|$)/, '_R'], [/_R(?=_|$)/, '_L'], [/left/i, 'right'], [/right/i, 'left'], [/zuo/, 'you'], [/you/, 'zuo'], [/(?<=^|_)L(?=_|\d|$)/, 'R'], [/(?<=^|_)R(?=_|\d|$)/, 'L']];
  for (const [re, rep] of swaps) if (re.test(bone.name)) { const p = sk.boneByName.get(bone.name.replace(re, rep)); if (p && p !== bone) return p; }
  const sib = (bone.parent ? bone.parent.children : []).find(b => b !== bone && /(eye|yan|lid|yanjing)/i.test(b.name) && eyeCentre(sk, b));
  return sib || null;
}
function blinkGeometry(sk, boneName) {
  pose(sk, null, 0, false);
  const bone = sk.boneByName.get(boneName);
  if (!bone) return null;
  const slots = eyeSlotsOf(sk, bone);
  const pts = slots.flatMap(s => drawnPoints(sk, s, 1));
  if (!pts.length) return null;
  const det = bone.a * bone.d - bone.b * bone.c;
  const ly = pts.map(([x, y]) => { const dx = x - bone.worldX, dy = y - bone.worldY; return (-bone.c * dx + bone.a * dy) / det; });
  const yMin = Math.min(...ly), yMax = Math.max(...ly), eyeH = Math.max(1e-6, yMax - yMin);
  // face horizontal line (degrees, world): through both eye centres, else the head-ish parent's X axis
  const partner = partnerEye(sk, bone), c0 = eyeCentre(sk, bone), c1 = partner && eyeCentre(sk, partner);
  let faceLine, faceRef;
  if (c0 && c1 && Math.hypot(c1[0] - c0[0], c1[1] - c0[1]) > 1) { faceLine = Math.atan2(c1[1] - c0[1], c1[0] - c0[0]) * 180 / Math.PI; faceRef = `line through ${bone.name} and ${partner.name}`; }
  else { const h = bone.parent || bone; faceLine = Math.atan2(h.c, h.a) * 180 / Math.PI; faceRef = `${h.name} X axis`; }
  const squash = Math.atan2(bone.d, bone.b) * 180 / Math.PI;           // world direction of local +Y
  const wrap90 = v => ((v % 180) + 270) % 180 - 90;                   // fold to (-90, 90]
  const tilt = wrap90(squash - (faceLine + 90));                      // 0 = perpendicular to the face line
  // rotation the bone needs (added to its current setup rotation) so local Y is perpendicular to the face line
  const fixRotation = (bone.data.rotation || 0) - tilt;
  const vertical = Math.cos(tilt * Math.PI / 180);                    // kept for backwards compatibility
  const t = bone.d > 0 ? (0 - yMin) / eyeH : (yMax - 0) / eyeH;
  const lidLike = slots.some(s => /(lid|lash|jiemao|yanpi|close|biyan|shut)/i.test(s.name + ' ' + (s.data.attachment || '')));
  return { t, vertical, tilt, faceLine, faceRef, fixRotation, slots: slots.map(s => s.name), lidLike };
}

function computeBounds(j) {
  const sk = buildSkeleton(j);
  pose(sk, null, 0, true);
  const xs = [], ys = [];
  for (const s of sk.slots) for (const [x, y] of slotPoints(sk, s, s.data.attachment)) { xs.push(x); ys.push(y); }
  if (!xs.length) for (const b of sk.bones) { xs.push(b.worldX); ys.push(b.worldY); }
  const x = Math.min(...xs), y = Math.min(...ys);
  return { x, y, width: Math.max(1, Math.max(...xs) - x), height: Math.max(1, Math.max(...ys) - y) };
}
// skeleton.{x,y,width,height} when valid, else computed setup-pose bounds
function boundsOf(j) {
  const s = j.skeleton || {};
  if (s.width > 0 && s.height > 0 && isFinite(s.x) && isFinite(s.y)) return { x: s.x, y: s.y, width: s.width, height: s.height };
  return computeBounds(j);
}

// Skeleton only (bones, slots, constraints) — enough for pose() with bonesOnly=true; no atlas needed.
function buildSkeleton(j) {
  // Work on copies: rendering must not rewrite the input JSON's inherit/mix fields.
  const bones = j.bones.map((d, i) => ({ data: Object.assign({}, d), index: i, name: d.name, parent: null, children: [] }));
  const boneByName = new Map(bones.map(b => [b.name, b]));
  for (const b of bones) if (b.data.parent) { b.parent = boneByName.get(b.data.parent); b.parent.children.push(b); }
  const slots = (j.slots || []).map((d, i) => ({ data: d, index: i, name: d.name, bone: boneByName.get(d.bone) }));
  const slotByName = new Map(slots.map(s => [s.name, s]));
  const skins = Array.isArray(j.skins) ? j.skins : Object.entries(j.skins || {}).map(([name, attachments]) => ({ name, attachments }));
  const version = C.versionOf(j), is4 = version.is4;
  if (!version.supported) throw new Error(`unsupported Spine schema ${version.raw}; supported versions: 3.7, 3.8, 4.0–4.3`);
  // 4.2 renamed bone `transform` (inherit mode) to `inherit`
  for (const b of bones) if (b.data.inherit && !b.data.transform) b.data.transform = b.data.inherit;
  const cons = [];
  const warnings = [];
  const normTC = c => { // normalise 4.x mix names onto the 3.8 names used by applyTC
    c = Object.assign({}, c);
    if (is4 || c.mixRotate !== undefined || c.mixX !== undefined) {
      c.rotateMix = def(c.mixRotate, 1); c.translateMix = def(c.mixX, 1); c.translateMixY = def(c.mixY, c.translateMix);
      c.scaleMix = def(c.mixScaleX, 1); c.scaleMixY = def(c.mixScaleY, c.scaleMix); c.shearMix = def(c.mixShearY, 1);
    }
    if (version.major === 4 && version.minor >= 3) {
      c.target = c.source;
      const active = new Set();
      let identity = true;
      for (const [from, map] of Object.entries(c.properties || {})) for (const [to, mapping] of Object.entries(map.to || {})) {
        active.add(to);
        if (from !== to || def(map.offset, 0) !== 0 || def(mapping.offset, 0) !== 0 || def(mapping.scale, 1) !== 1) identity = false;
      }
      for (const [property, field] of [['rotate', 'rotateMix'], ['x', 'translateMix'], ['y', 'translateMixY'], ['scaleX', 'scaleMix'], ['scaleY', 'scaleMixY'], ['shearY', 'shearMix']]) if (!active.has(property)) c[field] = 0;
      if (!identity || c.localSource || c.localTarget || c.additive || c.clamp) {
        warnings.push(`transform ${c.name}: property mapping/local/additive/clamp is not simulated`);
        c._unsupported = true;
      }
    } else if (c.local || c.relative) { warnings.push(`transform ${c.name}: local/relative mode is not simulated`); c._unsupported = true; }
    return c;
  };
  const add = (kind, c, order) => { const data = kind === 'tc' ? normTC(c) : Object.assign({}, c); cons.push({ kind, data, order, bones: (c.bones || []).map(n => boneByName.get(n)), target: kind === 'path' ? slotByName.get(c.slot || c.target) : boneByName.get(data.target) }); };
  // ≤4.2: separate lists, `order` omitted when 0
  for (const c of j.ik || []) add('ik', c, def(c.order, 0));
  for (const c of j.transform || []) add('tc', c, def(c.order, 0));
  for (const c of j.path || []) add('path', c, def(c.order, 0));
  // 4.3+: single `constraints` array, order = position
  (j.constraints || []).forEach((c, i) => { const k = { ik: 'ik', transform: 'tc', path: 'path' }[c.type]; if (k) add(k, c, i); });
  for (const type of ['path', 'physics', 'slider']) if (C.constraintsOf(j, type).length) warnings.push(`${type} constraints are not simulated`);
  for (const sk of skins) for (const atts of Object.values(sk.attachments || {})) for (const a of Object.values(atts)) {
    if (a.type === 'clipping' && !warnings.includes('clipping is not simulated')) warnings.push('clipping is not simulated');
    if (a.sequence && !warnings.includes('attachment sequences are not simulated')) warnings.push('attachment sequences are not simulated');
  }
  if (Object.values(j.animations || {}).some(a => a.drawOrderFolder)) warnings.push('drawOrderFolder timelines are not simulated');
  cons.sort((a, b) => a.order - b.order);
  return { j, bones, boneByName, slots, slotByName, skins, cons, is4, version, warnings };
}

function getAttachment(sk, slotName, attName, skinName) {
  for (const s of sk.skins) {
    if (skinName && s.name !== skinName) continue;
    const a = s.attachments && s.attachments[slotName] && s.attachments[slotName][attName];
    if (a) return a;
  }
  return null;
}

function updateBone(b, x, y, rot, sx, sy, shx, shy) {
  const p = b.parent;
  if (!p) {
    const ry = rot + 90 + shy;
    b.a = cosd(rot + shx) * sx; b.b = cosd(ry) * sy; b.c = sind(rot + shx) * sx; b.d = sind(ry) * sy;
    b.worldX = x; b.worldY = y;
    return;
  }
  let pa = p.a, pb = p.b, pc = p.c, pd = p.d;
  b.worldX = pa * x + pb * y + p.worldX;
  b.worldY = pc * x + pd * y + p.worldY;
  const mode = b.inherit || b.data.transform || 'normal';
  if (mode === 'normal') {
    const ry = rot + 90 + shy;
    const la = cosd(rot + shx) * sx, lb = cosd(ry) * sy, lc = sind(rot + shx) * sx, ld = sind(ry) * sy;
    b.a = pa * la + pb * lc; b.b = pa * lb + pb * ld; b.c = pc * la + pd * lc; b.d = pc * lb + pd * ld;
  } else if (mode === 'onlyTranslation') {
    const ry = rot + 90 + shy;
    b.a = cosd(rot + shx) * sx; b.b = cosd(ry) * sy; b.c = sind(rot + shx) * sx; b.d = sind(ry) * sy;
  } else if (mode === 'noRotationOrReflection') {
    let s = pa * pa + pc * pc, prx;
    if (s > 0.0001) { s = Math.abs(pa * pd - pb * pc) / s; pb = pc * s; pd = pa * s; prx = Math.atan2(pc, pa) * R2D; }
    else { pa = 0; pc = 0; prx = 90 - Math.atan2(pd, pb) * R2D; }
    const rx = rot + shx - prx, ry = rot + shy - prx + 90;
    const la = cosd(rx) * sx, lb = cosd(ry) * sy, lc = sind(rx) * sx, ld = sind(ry) * sy;
    b.a = pa * la - pb * lc; b.b = pa * lb - pb * ld; b.c = pc * la + pd * lc; b.d = pc * lb + pd * ld;
  } else {
    const cos = cosd(rot), sin = sind(rot);
    let za = pa * cos + pb * sin, zc = pc * cos + pd * sin;
    let s = Math.sqrt(za * za + zc * zc);
    if (s > 0.00001) s = 1 / s;
    za *= s; zc *= s;
    s = Math.sqrt(za * za + zc * zc);
    if (mode === 'noScale' && pa * pd - pb * pc < 0) s = -s;
    const r = Math.PI / 2 + Math.atan2(zc, za), zb = Math.cos(r) * s, zd = Math.sin(r) * s;
    const la = cosd(shx) * sx, lb = cosd(90 + shy) * sy, lc = sind(shx) * sx, ld = sind(90 + shy) * sy;
    b.a = za * la + zb * lc; b.b = za * lb + zb * ld; b.c = zc * la + zd * lc; b.d = zc * lb + zd * ld;
  }
}
const updateLocal = b => updateBone(b, b.x, b.y, b.rotation, b.scaleX, b.scaleY, b.shearX, b.shearY);

function ik1(bone, tx0, ty0, compress, stretch, uniform, alpha) {
  const p = bone.parent;
  let pa = p.a, pb = p.b, pc = p.c, pd = p.d, rotationIK = -bone.shearX - bone.rotation, tx, ty;
  const mode = bone.inherit || bone.data.transform || 'normal';
  if (mode === 'onlyTranslation') { tx = tx0 - bone.worldX; ty = ty0 - bone.worldY; }
  else {
    if (mode === 'noRotationOrReflection') {
      const s = Math.abs(pa * pd - pb * pc) / (pa * pa + pc * pc), sa = pa, sc = pc;
      pb = -sc * s; pd = sa * s; rotationIK += Math.atan2(sc, sa) * R2D;
    }
    const x = tx0 - p.worldX, y = ty0 - p.worldY, d = pa * pd - pb * pc;
    tx = (x * pd - y * pb) / d - bone.x; ty = (y * pa - x * pc) / d - bone.y;
  }
  rotationIK += Math.atan2(ty, tx) * R2D;
  if (bone.scaleX < 0) rotationIK += 180;
  if (rotationIK > 180) rotationIK -= 360; else if (rotationIK < -180) rotationIK += 360;
  let sx = bone.scaleX, sy = bone.scaleY;
  if (compress || stretch) {
    const bl = (bone.data.length || 0) * sx, dd = Math.sqrt(tx * tx + ty * ty);
    if (((compress && dd < bl) || (stretch && dd > bl)) && bl > 0.0001) { const s = (dd / bl - 1) * alpha + 1; sx *= s; if (uniform) sy *= s; }
  }
  updateBone(bone, bone.x, bone.y, bone.rotation + rotationIK * alpha, sx, sy, bone.shearX, bone.shearY);
}

function ik2(parent, child, targetX, targetY, bendDir, stretch, softness, alpha) {
  if (alpha === 0) { updateLocal(child); return; }
  let px = parent.x, py = parent.y, psx = parent.scaleX, sx = psx, psy = parent.scaleY, csx = child.scaleX;
  let os1, os2, s2;
  if (psx < 0) { psx = -psx; os1 = 180; s2 = -1; } else { os1 = 0; s2 = 1; }
  if (psy < 0) { psy = -psy; s2 = -s2; }
  if (csx < 0) { csx = -csx; os2 = 180; } else os2 = 0;
  let cx = child.x, cy, cwx, cwy, a = parent.a, b = parent.b, c = parent.c, d = parent.d;
  const u = Math.abs(psx - psy) <= 0.0001;
  if (!u) { cy = 0; cwx = a * cx + parent.worldX; cwy = c * cx + parent.worldY; }
  else { cy = child.y; cwx = a * cx + b * cy + parent.worldX; cwy = c * cx + d * cy + parent.worldY; }
  const pp = parent.parent;
  a = pp.a; b = pp.b; c = pp.c; d = pp.d;
  const id = 1 / (a * d - b * c);
  let x = cwx - pp.worldX, y = cwy - pp.worldY;
  const dx = (x * d - y * b) * id - px, dy = (y * a - x * c) * id - py;
  const l1 = Math.sqrt(dx * dx + dy * dy);
  let l2 = (child.data.length || 0) * csx, a1, a2;
  if (l1 < 0.0001) {
    ik1(parent, targetX, targetY, false, stretch, false, alpha);
    updateBone(child, cx, cy, 0, child.scaleX, child.scaleY, child.shearX, child.shearY);
    return;
  }
  x = targetX - pp.worldX; y = targetY - pp.worldY;
  let tx = (x * d - y * b) * id - px, ty = (y * a - x * c) * id - py;
  let dd = tx * tx + ty * ty;
  if (softness !== 0) {
    softness *= psx * (csx + 1) / 2;
    const td = Math.sqrt(dd), sd = td - l1 - l2 * psx + softness;
    if (sd > 0) {
      let p = Math.min(1, sd / (softness * 2)) - 1;
      p = (sd - softness * (1 - p * p)) / td;
      tx -= p * tx; ty -= p * ty; dd = tx * tx + ty * ty;
    }
  }
  outer: {
    if (u) {
      l2 *= psx;
      let cos = (dd - l1 * l1 - l2 * l2) / (2 * l1 * l2);
      if (cos < -1) cos = -1;
      else if (cos > 1) { cos = 1; if (stretch) sx *= (Math.sqrt(dd) / (l1 + l2) - 1) * alpha + 1; }
      a2 = Math.acos(cos) * bendDir;
      a = l1 + l2 * cos; b = l2 * Math.sin(a2);
      a1 = Math.atan2(ty * a - tx * b, tx * a + ty * b);
    } else {
      a = psx * l2; b = psy * l2;
      const aa = a * a, bb = b * b, ta = Math.atan2(ty, tx);
      c = bb * l1 * l1 + aa * dd - aa * bb;
      const c1 = -2 * bb * l1, c2 = bb - aa;
      d = c1 * c1 - 4 * c2 * c;
      if (d >= 0) {
        let q = Math.sqrt(d);
        if (c1 < 0) q = -q;
        q = -(c1 + q) / 2;
        const r0 = q / c2, r1 = c / q, r = Math.abs(r0) < Math.abs(r1) ? r0 : r1;
        if (r * r <= dd) {
          y = Math.sqrt(dd - r * r) * bendDir;
          a1 = ta - Math.atan2(y, r);
          a2 = Math.atan2(y / psy, (r - l1) / psx);
          break outer;
        }
      }
      let minAngle = Math.PI, minX = l1 - a, minDist = minX * minX, minY = 0;
      let maxAngle = 0, maxX = l1 + a, maxDist = maxX * maxX, maxY = 0;
      c = -a * l1 / (aa - bb);
      if (c >= -1 && c <= 1) {
        c = Math.acos(c);
        x = a * Math.cos(c) + l1; y = b * Math.sin(c); d = x * x + y * y;
        if (d < minDist) { minAngle = c; minDist = d; minX = x; minY = y; }
        if (d > maxDist) { maxAngle = c; maxDist = d; maxX = x; maxY = y; }
      }
      if (dd <= (minDist + maxDist) / 2) { a1 = ta - Math.atan2(minY * bendDir, minX); a2 = minAngle * bendDir; }
      else { a1 = ta - Math.atan2(maxY * bendDir, maxX); a2 = maxAngle * bendDir; }
    }
  }
  const os = Math.atan2(cy, cx) * s2;
  let rotation = parent.rotation;
  a1 = (a1 - os) * R2D + os1 - rotation;
  if (a1 > 180) a1 -= 360; else if (a1 < -180) a1 += 360;
  updateBone(parent, px, py, rotation + a1 * alpha, sx, parent.scaleY, 0, 0);
  rotation = child.rotation;
  a2 = ((a2 + os) * R2D - child.shearX) * s2 + os2 - rotation;
  if (a2 > 180) a2 -= 360; else if (a2 < -180) a2 += 360;
  updateBone(child, cx, cy, rotation + a2 * alpha, child.scaleX, child.scaleY, child.shearX, child.shearY);
}

function applyTC(c) {
  if (c.data._unsupported) return;
  const t = c.target, d = c.data;
  const ta = t.a, tb = t.b, tc = t.c, td = t.d;
  const refl = ta * td - tb * tc > 0 ? D2R : -D2R;
  const offR = def(d.rotation, 0) * refl;
  for (const bone of c.bones) {
    if (c.rotateMix !== 0) {
      const a = bone.a, b = bone.b, cc = bone.c, dd = bone.d;
      let r = Math.atan2(tc, ta) - Math.atan2(cc, a) + offR;
      if (r > Math.PI) r -= 2 * Math.PI; else if (r < -Math.PI) r += 2 * Math.PI;
      r *= c.rotateMix;
      const cos = Math.cos(r), sin = Math.sin(r);
      bone.a = cos * a - sin * cc; bone.b = cos * b - sin * dd; bone.c = sin * a + cos * cc; bone.d = sin * b + cos * dd;
    }
    if (c.translateMix !== 0 || c.translateMixY !== 0) {
      const ox = def(d.x, 0), oy = def(d.y, 0);
      const wx = ta * ox + tb * oy + t.worldX, wy = tc * ox + td * oy + t.worldY;
      bone.worldX += (wx - bone.worldX) * c.translateMix;
      bone.worldY += (wy - bone.worldY) * c.translateMixY;
    }
    if (c.scaleMix !== 0 || c.scaleMixY !== 0) {
      let s = Math.sqrt(bone.a * bone.a + bone.c * bone.c);
      if (s !== 0) s = (s + (Math.sqrt(ta * ta + tc * tc) - s + def(d.scaleX, 0)) * c.scaleMix) / s;
      bone.a *= s; bone.c *= s;
      s = Math.sqrt(bone.b * bone.b + bone.d * bone.d);
      if (s !== 0) s = (s + (Math.sqrt(tb * tb + td * td) - s + def(d.scaleY, 0)) * c.scaleMixY) / s;
      bone.b *= s; bone.d *= s;
    }
    if (c.shearMix !== 0) {
      const b = bone.b, dd = bone.d, length = Math.sqrt(b * b + dd * dd);
      const by = Math.atan2(dd, b);
      let r = Math.atan2(td, tb) - Math.atan2(tc, ta) - (by - Math.atan2(bone.c, bone.a));
      if (r > Math.PI) r -= 2 * Math.PI; else if (r < -Math.PI) r += 2 * Math.PI;
      r = by + (r + def(d.shearY, 0) * refl) * c.shearMix;
      bone.b = Math.cos(r) * length; bone.d = Math.sin(r) * length;
    }
  }
}

function updateWorld(sk) {
  for (const b of sk.bones) updateLocal(b);
  for (const c of sk.cons) {
    if (c.kind === 'ik') {
      if (c.bones.length === 1) ik1(c.bones[0], c.target.worldX, c.target.worldY, c.compress, c.stretch, !!c.data.uniform, c.mix);
      else ik2(c.bones[0], c.bones[1], c.target.worldX, c.target.worldY, c.bendDir, c.stretch, c.softness, c.mix);
    } else if (c.kind === 'tc') applyTC(c);
    else continue;
    const set = new Set(c.bones), dirty = new Set();
    for (const b of sk.bones) {
      if (set.has(b) || !b.parent) continue;
      if (set.has(b.parent) || dirty.has(b.parent)) { updateLocal(b); dirty.add(b); }
    }
  }
}

// ---------------- animation ----------------
function findFrame(keys, t) {
  if (!keys.length || t < def(keys[0].time, 0)) return -1;
  for (let i = keys.length - 1; i >= 0; i--) if (t >= def(keys[i].time, 0)) return i;
  return -1;
}
// Segment progress 0..1 with easing.
// 3.8: curve=number (cx1) + c2,c3,c4 normalised.  4.x: curve=[cx1,cy1,cx2,cy2]*channels in absolute
// time/value units (deform: cy normalised 0..1). `ch` selects the channel, v0/v1 the channel values.
function percent(k0, k1, t, ch = 0, v0 = 0, v1 = 1, normY = false, version) {
  const t0 = def(k0.time, 0), t1 = def(k1.time, 0);
  const p = t1 > t0 ? Math.min(1, Math.max(0, (t - t0) / (t1 - t0))) : 1;
  const c = k0.curve;
  if (c === undefined) return p;
  if (c === 'stepped') return 0;
  if (typeof c === 'number') return bezierY(c, def(k0.c2, 0), def(k0.c3, 1), def(k0.c4, 1), p);
  if (Array.isArray(c)) {
    if (version && !version.is4) return bezierY(c[0], c[1], c[2], c[3], p);
    const o = ch * 4;
    if (c.length < o + 4) return p;
    const dt = t1 - t0 || 1, dv = v1 - v0;
    const nx = x => (x - t0) / dt;
    const ny = y => (normY ? y : Math.abs(dv) < 1e-9 ? 0 : (y - v0) / dv);
    if (!normY && Math.abs(dv) < 1e-9) return p;
    return bezierY(nx(c[o]), ny(c[o + 1]), nx(c[o + 2]), ny(c[o + 3]), p);
  }
  return p;
}
function evalScalar(keys, t, get, ch = 0, version) {
  const i = findFrame(keys, t);
  if (i < 0) return null;
  if (i === keys.length - 1) return get(keys[i]);
  const a = get(keys[i]), b = get(keys[i + 1]);
  const cv = C.segCurve(keys[i], keys[i + 1], ch, a, b, version);
  const p = (t - def(keys[i].time, 0)) / (def(keys[i + 1].time, 0) - def(keys[i].time, 0));
  const y = C.bezierY(cv, p);
  return cv.absolute ? y : a + (b - a) * y;
}
// 3.x interpolates rotation along the shortest arc between keys; 4.x interpolates raw values.
function evalRotate(keys, t, version) {
  const i = findFrame(keys, t);
  if (i < 0) return null;
  const A = k => def(k.angle, def(k.value, 0));
  if (i === keys.length - 1) return A(keys[i]);
  const prev = A(keys[i]), next = A(keys[i + 1]);
  if (version.is4) return evalScalar(keys, t, A, 0, version);
  return wrap(prev + wrap(next - prev) * percent(keys[i], keys[i + 1], t, 0, prev, next, false, version));
}

function pose(sk, anim, t, bonesOnly) {
  const sample = (keys, time, get, ch = 0) => evalScalar(keys, time, get, ch, sk.version);
  for (const b of sk.bones) {
    const d = b.data;
    b.x = def(d.x, 0); b.y = def(d.y, 0); b.rotation = def(d.rotation, 0);
    b.scaleX = def(d.scaleX, 1); b.scaleY = def(d.scaleY, 1); b.shearX = def(d.shearX, 0); b.shearY = def(d.shearY, 0);
    b.inherit = d.inherit || d.transform || 'normal';
  }
  for (const c of sk.cons) {
    const d = c.data;
    c.mix = def(d.mix, 1); c.bendDir = d.bendPositive === false ? -1 : 1; c.softness = def(d.softness, 0); c.compress = !!d.compress; c.stretch = !!d.stretch;
    c.rotateMix = def(d.rotateMix, 1); c.translateMix = def(d.translateMix, 1); c.translateMixY = def(d.translateMixY, c.translateMix);
    c.scaleMix = def(d.scaleMix, 1); c.scaleMixY = def(d.scaleMixY, c.scaleMix); c.shearMix = def(d.shearMix, 1);
  }
  if (!bonesOnly) {
    for (const s of sk.slots) { s.attName = def(s.data.attachment, null); s.color = hexColor(s.data.color); s.deform = null; }
    sk.drawOrder = sk.slots.slice();
  }
  if (anim) {
    const is4 = sk.is4;
    for (const [bn, tl] of Object.entries(anim.bones || {})) {
      const b = sk.boneByName.get(bn);
      if (!b) continue;
      if (tl.rotate) { const r = evalRotate(tl.rotate, t, sk.version); if (r !== null) b.rotation = def(b.data.rotation, 0) + r; }
      if (tl.translate) {
        const x = sample(tl.translate, t, k => def(k.x, 0), 0), y = sample(tl.translate, t, k => def(k.y, 0), is4 ? 1 : 0);
        if (x !== null) { b.x = def(b.data.x, 0) + x; b.y = def(b.data.y, 0) + y; }
      }
      if (tl.scale) {
        const x = sample(tl.scale, t, k => def(k.x, 1), 0), y = sample(tl.scale, t, k => def(k.y, 1), is4 ? 1 : 0);
        if (x !== null) { b.scaleX = def(b.data.scaleX, 1) * x; b.scaleY = def(b.data.scaleY, 1) * y; }
      }
      if (tl.shear) {
        const x = sample(tl.shear, t, k => def(k.x, 0), 0), y = sample(tl.shear, t, k => def(k.y, 0), is4 ? 1 : 0);
        if (x !== null) { b.shearX = def(b.data.shearX, 0) + x; b.shearY = def(b.data.shearY, 0) + y; }
      }
      // 4.x split timelines
      const V = (k, d) => def(k.value, d);
      if (tl.translatex) { const v = sample(tl.translatex, t, k => V(k, 0)); if (v !== null) b.x = def(b.data.x, 0) + v; }
      if (tl.translatey) { const v = sample(tl.translatey, t, k => V(k, 0)); if (v !== null) b.y = def(b.data.y, 0) + v; }
      if (tl.scalex) { const v = sample(tl.scalex, t, k => V(k, 1)); if (v !== null) b.scaleX = def(b.data.scaleX, 1) * v; }
      if (tl.scaley) { const v = sample(tl.scaley, t, k => V(k, 1)); if (v !== null) b.scaleY = def(b.data.scaleY, 1) * v; }
      if (tl.shearx) { const v = sample(tl.shearx, t, k => V(k, 0)); if (v !== null) b.shearX = def(b.data.shearX, 0) + v; }
      if (tl.sheary) { const v = sample(tl.sheary, t, k => V(k, 0)); if (v !== null) b.shearY = def(b.data.shearY, 0) + v; }
      if (tl.inherit) { const i = findFrame(tl.inherit, t); if (i >= 0) b.inherit = def(tl.inherit[i].inherit, 'normal'); }
    }
    const consByName = new Map(sk.cons.map(c => [c.data.name, c]));
    for (const [cn, keys] of Object.entries(anim.ik || {})) {
      const c = consByName.get(cn);
      if (!c) continue;
      const m = sample(keys, t, k => def(k.mix, 1), 0);
      if (m !== null) {
        c.mix = m;
        const k = keys[findFrame(keys, t)];
        c.bendDir = k.bendPositive === false ? -1 : 1; c.compress = !!k.compress; c.stretch = !!k.stretch;
        c.softness = sample(keys, t, q => def(q.softness, 0), is4 ? 1 : 0);
      }
    }
    for (const [cn, keys] of Object.entries(anim.transform || {})) {
      const c = consByName.get(cn);
      if (!c) continue;
      const map = is4 ? [['rotateMix', 'mixRotate'], ['translateMix', 'mixX'], ['scaleMix', 'mixScaleX'], ['shearMix', 'mixShearY']] : [['rotateMix', 'rotateMix'], ['translateMix', 'translateMix'], ['scaleMix', 'scaleMix'], ['shearMix', 'shearMix']];
      map.forEach(([f, src], ch) => { const v = sample(keys, t, k => def(k[src], 1), is4 ? [0, 1, 3, 5][ch] : 0); if (v !== null) c[f] = v; });
      if (is4) {
        const y = sample(keys, t, k => def(k.mixY, def(k.mixX, 1)), 2), sy = sample(keys, t, k => def(k.mixScaleY, def(k.mixScaleX, 1)), 4);
        if (y !== null) c.translateMixY = y; if (sy !== null) c.scaleMixY = sy;
      } else { c.translateMixY = c.translateMix; c.scaleMixY = c.scaleMix; }
    }
    if (!bonesOnly) {
      for (const [sn, tl] of Object.entries(anim.slots || {})) {
        const s = sk.slotByName.get(sn);
        if (!s) continue;
        if (tl.attachment) { const i = findFrame(tl.attachment, t); if (i >= 0) s.attName = tl.attachment[i].name; }
        const ctl = tl.color || tl.rgba || tl.rgb || (tl.twoColor || tl.rgba2 || tl.rgb2 ? (tl.twoColor || tl.rgba2 || tl.rgb2).map(k => Object.assign({}, k, { color: k.light })) : null);
        if (ctl) {
          const i = findFrame(ctl, t);
          if (i >= 0) {
            const c0 = hexColor(ctl[i].color);
            if (i < ctl.length - 1) { const c1 = hexColor(ctl[i + 1].color); s.color = c0.map((v, q) => v + (c1[q] - v) * percent(ctl[i], ctl[i + 1], t, is4 ? q : 0, v, c1[q], false, sk.version)); }
            else s.color = c0;
            if ((tl.rgb || tl.rgb2) && !tl.alpha) s.color[3] = hexColor(s.data.color)[3];
          }
        }
        if (tl.alpha) { const v = sample(tl.alpha, t, k => def(k.value, 1)); if (v !== null) s.color[3] = v; }
      }
      // deform: 3.8/4.0 anim.deform[skin][slot][att]; 4.1+ anim.attachments[skin][slot][att].deform
      const deformSets = [];
      for (const sl of Object.values(anim.deform || {})) for (const [sn, atts] of Object.entries(sl)) for (const [an, keys] of Object.entries(atts)) deformSets.push([sn, an, keys]);
      for (const sl of Object.values(anim.attachments || {})) for (const [sn, atts] of Object.entries(sl)) for (const [an, tls] of Object.entries(atts)) if (tls.deform) deformSets.push([sn, an, tls.deform]);
      for (const [sn, an, keys] of deformSets) {
        const s = sk.slotByName.get(sn);
        if (!s) continue;
        const i = findFrame(keys, t);
        if (i < 0) continue;
        const vec = k => { const out = new Map(); if (k.vertices) { const off = k.offset || 0; k.vertices.forEach((v, q) => out.set(off + q, v)); } return out; };
        const a = vec(keys[i]);
        if (i < keys.length - 1) {
          const b = vec(keys[i + 1]), p = percent(keys[i], keys[i + 1], t, 0, 0, 1, true, sk.version);
          for (const q of new Set([...a.keys(), ...b.keys()])) a.set(q, def(a.get(q), 0) + (def(b.get(q), 0) - def(a.get(q), 0)) * p);
        }
        s.deform = s.deform || {};
        s.deform[an] = a;
      }
      const dOrd = anim.drawOrder || anim.draworder;
      if (dOrd) {
        const i = findFrame(dOrd, t);
        if (i >= 0 && dOrd[i].offsets) {
          const n = sk.slots.length, order = new Array(n).fill(-1), unchanged = [];
          let orig = 0;
          for (const o of dOrd[i].offsets) {
            const si = sk.slotByName.get(o.slot).index;
            while (orig !== si) unchanged.push(orig++);
            order[orig + o.offset] = orig++;
          }
          while (orig < n) unchanged.push(orig++);
          for (let q = n - 1; q >= 0; q--) if (order[q] === -1) order[q] = unchanged.pop();
          sk.drawOrder = order.map(q => sk.slots[q]);
        }
      }
    }
  }
  updateWorld(sk);
}

// ---------------- geometry ----------------
function regionGeom(att, region, bone) {
  const w = def(att.width, region.ow), h = def(att.height, region.oh), sx = def(att.scaleX, 1), sy = def(att.scaleY, 1);
  const rsx = w / region.ow * sx, rsy = h / region.oh * sy;
  const lx = -w / 2 * sx + region.ox * rsx, ly = -h / 2 * sy + region.oy * rsy;
  const lx2 = lx + region.w * rsx, ly2 = ly + region.h * rsy;
  const cos = cosd(def(att.rotation, 0)), sin = sind(def(att.rotation, 0)), x = def(att.x, 0), y = def(att.y, 0);
  const loc = [[lx, ly], [lx, ly2], [lx2, ly2], [lx2, ly]].map(([px, py]) => [px * cos - py * sin + x, px * sin + py * cos + y]);
  const pts = loc.map(([px, py]) => [px * bone.a + py * bone.b + bone.worldX, px * bone.c + py * bone.d + bone.worldY]);
  const { u, v, u2, v2 } = region;
  const uvs = ({ 0: [[u, v2], [u, v], [u2, v], [u2, v2]], 90: [[u2, v2], [u, v2], [u, v], [u2, v]], 180: [[u2, v], [u2, v2], [u, v2], [u, v]], 270: [[u, v], [u2, v], [u2, v2], [u, v2]] })[region.degrees || 0];
  return { pts, uvs, tris: [0, 1, 2, 2, 3, 0] };
}
function meshGeom(sk, att, geomSrc, region, slot) {
  const ruv = geomSrc.uvs, n = ruv.length;
  const tw = region.page.img.w, th = region.page.img.h;
  const uvs = [];
  if (region.degrees === 180) {
    for (let i = 0; i < n; i += 2) uvs.push([region.u + ((1 - ruv[i]) * region.ow - (region.ow - region.ox - region.w)) / tw, region.v + ((1 - ruv[i + 1]) * region.oh - region.oy) / th]);
  } else if (region.degrees === 270) {
    for (let i = 0; i < n; i += 2) uvs.push([region.u + ((1 - ruv[i + 1]) * region.oh - region.oy) / tw, region.v + (ruv[i] * region.ow - region.ox) / th]);
  } else if (region.rotate) {
    const u = region.u - (region.oh - region.oy - region.h) / tw, v = region.v - (region.ow - region.ox - region.w) / th;
    const W = region.oh / tw, H = region.ow / th;
    for (let i = 0; i < n; i += 2) uvs.push([u + ruv[i + 1] * W, v + (1 - ruv[i]) * H]);
  } else {
    const u = region.u - region.ox / tw, v = region.v - (region.oh - region.oy - region.h) / th;
    const W = region.ow / tw, H = region.oh / th;
    for (let i = 0; i < n; i += 2) uvs.push([u + ruv[i] * W, v + ruv[i + 1] * H]);
  }
  const sourceName = att.source || att.parent, sourceSlot = sk.slotByName.get(att.slot || slot.name);
  const inherit = att.timelines !== false && att.deform !== false;
  const verts = geomSrc.vertices, deform = slot.deform && slot.deform[att._name] || inherit && sourceSlot && sourceSlot.deform && sourceSlot.deform[sourceName];
  const pts = [];
  if (verts.length === n) {
    const b = slot.bone;
    for (let i = 0; i < n; i += 2) {
      const x = verts[i] + (deform ? def(deform.get(i), 0) : 0), y = verts[i + 1] + (deform ? def(deform.get(i + 1), 0) : 0);
      pts.push([x * b.a + y * b.b + b.worldX, x * b.c + y * b.d + b.worldY]);
    }
  } else {
    let f = 0;
    for (let i = 0; i < verts.length;) {
      const cnt = verts[i++];
      let wx = 0, wy = 0;
      for (let k = 0; k < cnt; k++, i += 4, f += 2) {
        const b = sk.bones[verts[i]], w = verts[i + 3];
        const x = verts[i + 1] + (deform ? def(deform.get(f), 0) : 0), y = verts[i + 2] + (deform ? def(deform.get(f + 1), 0) : 0);
        wx += (x * b.a + y * b.b + b.worldX) * w; wy += (x * b.c + y * b.d + b.worldY) * w;
      }
      pts.push([wx, wy]);
    }
  }
  return { pts, uvs, tris: geomSrc.triangles };
}
function slotGeom(sk, slot) {
  if (!slot.attName) return null;
  const stored = getAttachment(sk, slot.name, slot.attName);
  if (!stored) return null;
  const att = Object.assign({ _name: slot.attName }, stored);
  const type = att.type || 'region';
  const rname = att.path || slot.attName;
  const region = sk.atlas.regions.get(rname);
  if (!region) return null;
  if (type === 'region') return Object.assign(regionGeom(att, region, slot.bone), { region, color: hexColor(att.color) });
  if (type === 'mesh' && !att.source && !att.parent) return Object.assign(meshGeom(sk, att, att, region, slot), { region, color: hexColor(att.color) });
  if (type === 'linkedmesh' || type === 'mesh' && (att.source || att.parent)) {
    const parent = getAttachment(sk, att.slot || slot.name, att.source || att.parent, att.skin || 'default');
    if (!parent || !parent.uvs) return null;
    return Object.assign(meshGeom(sk, att, parent, region, slot), { region, color: hexColor(att.color) });
  }
  return null;
}

// ---------------- raster ----------------
function makeCanvas(W, H, bg) {
  const c = new Float32Array(W * H * 3);
  for (let i = 0; i < W * H; i++) { c[i * 3] = bg[0]; c[i * 3 + 1] = bg[1]; c[i * 3 + 2] = bg[2]; }
  return { W, H, c };
}
function rasterTri(cv, P, UV, tex, col, blend, dim) {
  const { W, H, c } = cv;
  const [x0, y0, x1, y1, x2, y2] = P;
  const k = cv.clip || [0, 0, W, H]; // optional clip rect [x0,y0,x1,y1) for panel drawing
  const minX = Math.max(k[0], Math.floor(Math.min(x0, x1, x2))), maxX = Math.min(k[2] - 1, Math.ceil(Math.max(x0, x1, x2)));
  const minY = Math.max(k[1], Math.floor(Math.min(y0, y1, y2))), maxY = Math.min(k[3] - 1, Math.ceil(Math.max(y0, y1, y2)));
  const area = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0);
  if (Math.abs(area) < 1e-9) return;
  const inv = 1 / area, tw = tex.w, th = tex.h, td = tex.data;
  for (let y = minY; y <= maxY; y++) {
    const py = y + 0.5;
    for (let x = minX; x <= maxX; x++) {
      const px = x + 0.5;
      const w0 = ((x2 - x1) * (py - y1) - (y2 - y1) * (px - x1)) * inv;
      const w1 = ((x0 - x2) * (py - y2) - (y0 - y2) * (px - x2)) * inv;
      const w2 = 1 - w0 - w1;
      if (w0 < -1e-6 || w1 < -1e-6 || w2 < -1e-6) continue;
      const u = w0 * UV[0] + w1 * UV[2] + w2 * UV[4], v = w0 * UV[1] + w1 * UV[3] + w2 * UV[5];
      const tx = Math.min(tw - 1, Math.max(0, Math.floor(u * tw))), ty = Math.min(th - 1, Math.max(0, Math.floor(v * th)));
      const ti = (ty * tw + tx) * 4;
      const sa = td[ti + 3] / 255 * col[3];
      if (sa <= 0.003) continue;
      const o = (y * W + x) * 3;
      for (let k = 0; k < 3; k++) {
        const s = td[ti + k] / 255 * col[k] * dim, d = c[o + k];
        let r;
        if (blend === 'additive') r = d + s * sa;
        else if (blend === 'multiply') r = d * (s * sa + 1 - sa);
        else if (blend === 'screen') r = 1 - (1 - d) * (1 - s * sa);
        else r = s * sa + d * (1 - sa);
        c[o + k] = r > 1 ? 1 : r;
      }
    }
  }
}
function plot(cv, x, y, col, rad) {
  const { W, H, c } = cv;
  const k = cv.clip || [0, 0, W, H];
  for (let dy = -rad; dy <= rad; dy++) for (let dx = -rad; dx <= rad; dx++) {
    if (dx * dx + dy * dy > rad * rad + 0.5) continue;
    const px = Math.round(x + dx), py = Math.round(y + dy);
    if (px < k[0] || py < k[1] || px >= k[2] || py >= k[3]) continue;
    const o = (py * W + px) * 3;
    c[o] = col[0]; c[o + 1] = col[1]; c[o + 2] = col[2];
  }
}
function line(cv, ax, ay, bx, by, col, rad) {
  const n = Math.max(1, Math.ceil(Math.hypot(bx - ax, by - ay)));
  for (let i = 0; i <= n; i++) plot(cv, ax + (bx - ax) * i / n, ay + (by - ay) * i / n, col, rad);
}
// 3x5 bitmap font: digits, A–Z (lowercase rendered as uppercase) and _-.:/# — enough for labels.
const FONT = {
  0: '111101101101111', 1: '010110010010111', 2: '111001111100111', 3: '111001111001111', 4: '101101111001001',
  5: '111100111001111', 6: '111100111101111', 7: '111001001001001', 8: '111101111101111', 9: '111101111001111',
  A: '010101111101101', B: '110101110101110', C: '011100100100011', D: '110101101101110', E: '111100110100111',
  F: '111100110100100', G: '011100101101011', H: '101101111101101', I: '111010010010111', J: '001001001101010',
  K: '101101110101101', L: '100100100100111', M: '101111111101101', N: '110101101101101', O: '010101101101010',
  P: '110101110100100', Q: '010101101110011', R: '110101110101101', S: '011100010001110', T: '111010010010010',
  U: '101101101101111', V: '101101101101010', W: '101101111111101', X: '101101010101101', Y: '101101010010010',
  Z: '111001010100111', _: '000000000000111', '-': '000000111000000', '.': '000000000000010', ':': '000010000010000',
  '/': '001001010100100', '#': '101111101111101',
};
function text(cv, x, y, str, col, sc) {
  let cx = x;
  for (const raw of String(str)) {
    const ch = /[a-z]/.test(raw) ? raw.toUpperCase() : raw;
    const g = FONT[ch];
    if (g) for (let r = 0; r < 5; r++) for (let q = 0; q < 3; q++) if (g[r * 3 + q] === '1') {
      for (let oy = -1; oy <= sc; oy++) for (let ox = -1; ox <= sc; ox++) { const px = cx + q * sc + ox, py = y + r * sc + oy; if (px >= 0 && py >= 0 && px < cv.W && py < cv.H) { const o = (py * cv.W + px) * 3; cv.c[o] = 0; cv.c[o + 1] = 0; cv.c[o + 2] = 0; } }
    }
    if (g) for (let r = 0; r < 5; r++) for (let q = 0; q < 3; q++) if (g[r * 3 + q] === '1') {
      for (let oy = 0; oy < sc; oy++) for (let ox = 0; ox < sc; ox++) { const px = cx + q * sc + ox, py = y + r * sc + oy; if (px >= 0 && py >= 0 && px < cv.W && py < cv.H) { const o = (py * cv.W + px) * 3; cv.c[o] = col[0]; cv.c[o + 1] = col[1]; cv.c[o + 2] = col[2]; } }
    }
    cx += 4 * sc;
  }
}
function savePNG(cv, file) {
  const out = new Uint8Array(cv.W * cv.H * 4);
  for (let i = 0; i < cv.W * cv.H; i++) { out[i * 4] = Math.round(cv.c[i * 3] * 255); out[i * 4 + 1] = Math.round(cv.c[i * 3 + 1] * 255); out[i * 4 + 2] = Math.round(cv.c[i * 3 + 2] * 255); out[i * 4 + 3] = 255; }
  fs.writeFileSync(file, encodePNG(cv.W, cv.H, out));
}

function isDesc(b, root) { for (let x = b; x; x = x.parent) if (x === root) return true; return false; }

function drawSkeleton(sk, cv, toPx, dim, filter) {
  for (const slot of sk.drawOrder) {
    if (filter && !filter(slot)) continue;
    const g = slotGeom(sk, slot);
    if (!g) continue;
    const col = slot.color.map((v, i) => v * g.color[i]);
    if (col[3] <= 0.003) continue;
    const P = g.pts.map(toPx);
    for (let i = 0; i < g.tris.length; i += 3) {
      const a = g.tris[i], b = g.tris[i + 1], c = g.tris[i + 2];
      rasterTri(cv, [P[a][0], P[a][1], P[b][0], P[b][1], P[c][0], P[c][1]], [g.uvs[a][0], g.uvs[a][1], g.uvs[b][0], g.uvs[b][1], g.uvs[c][0], g.uvs[c][1]], g.region.page.img, col, slot.data.blend || 'normal', dim);
    }
  }
}

// ---------------- main ----------------
// ---------------- one-image review boards (keep the number of images an agent must view low) ----------------
const BG = [0.47, 0.47, 0.5];
// world rect {x,y,w,h} (y up) → pixel viewport {px,py,pw,ph} of canvas, aspect preserved, centred
function viewport(rect, px, py, pw, ph) {
  const s = Math.min(pw / rect.w, ph / rect.h);
  const ox = px + (pw - rect.w * s) / 2, oy = py + (ph - rect.h * s) / 2;
  return { s, toPx: ([x, y]) => [ox + (x - rect.x) * s, oy + (rect.y + rect.h - y) * s] };
}
function frame(cv, x, y, w, h, col) {
  line(cv, x, y, x + w - 1, y, col, 0); line(cv, x, y + h - 1, x + w - 1, y + h - 1, col, 0);
  line(cv, x, y, x, y + h - 1, col, 0); line(cv, x + w - 1, y, x + w - 1, y + h - 1, col, 0);
}
function boneTipPaths(sk, anim, fps, nf, step = 1) {
  const paths = sk.bones.map(() => []);
  for (let f = 0; f <= nf; f += step) {
    pose(sk, anim, f / fps, true);
    sk.bones.forEach((b, i) => { const L = b.data.length || 0; paths[i].push([b.worldX + b.a * L, b.worldY + b.c * L]); });
  }
  return paths;
}
const pathExtent = p => Math.hypot(Math.max(...p.map(q => q[0])) - Math.min(...p.map(q => q[0])), Math.max(...p.map(q => q[1])) - Math.min(...p.map(q => q[1])));

// --sheet: ONE image = 6 frames across the loop + trails + extreme frame + up to 6 zoomed regions.
// Regions: --regions "x,y,w,h;x,y,w,h" (skeleton units) or automatic (fastest-moving chain tips + feet).
function renderSheet(sk, anim, animName, outPrefix, opt) {
  const fps = opt.fps, j = sk.j;
  const b = boundsOf(j), mg = 0.03 * Math.max(b.width, b.height);
  const full = { x: b.x - mg, y: b.y - mg, w: b.width + 2 * mg, h: b.height + 2 * mg };
  const nf = anim ? animFrames(anim, fps) : 1;
  const cellW = 260, cellH = Math.round(cellW * Math.min(2.2, Math.max(0.6, full.h / full.w)));
  const cols = 6, zoom = 260, pad = 6, head = 18;
  const paths = anim ? boneTipPaths(sk, anim, fps, nf, 2) : sk.bones.map(() => []);
  const ext = paths.map(p => (p.length ? pathExtent(p) : 0));
  // automatic regions (3): R1 biggest mover, R2 biggest mover in the lower half (cloth/skirt/tail —
  // where layers detach), R3 ground contact (lowest bone: feet / seat). Each region is a square.
  let regions = opt.regions;
  if (!regions || !regions.length) {
    const half = 0.1 * Math.max(b.width, b.height);
    // only bones that actually draw something (own a slot or weight a mesh in a subtree) — bare
    // control points of fx groups otherwise put the zoom on empty canvas
    const draws = new Set();
    for (const s of sk.slots) for (let x = s.bone; x; x = x.parent) draws.add(x.index);
    for (const sk2 of sk.skins) for (const atts of Object.values(sk2.attachments || {})) for (const a of Object.values(atts)) {
      if (a.type !== 'mesh' || !a.uvs || a.vertices.length === a.uvs.length) continue;
      for (let q = 0; q < a.vertices.length;) { const n = a.vertices[q++]; for (let k = 0; k < n; k++, q += 4) draws.add(a.vertices[q]); }
    }
    const order = ext.map((e, i) => i).filter(i => ext[i] > 2 && draws.has(i)).sort((p, q) => ext[q] - ext[p]);
    // centre of a moving bone = centre of the geometry it draws at frame 0 (falls back to its tip path)
    pose(sk, anim, 0, false);
    // geometry centre per bone that draws: the slot's own bone, plus bones weighting its mesh (not ancestors —
    // a shared fx/master control at the origin would otherwise count as "drawing")
    const geoCentre = new Map();
    for (const s of sk.slots) {
      const g = slotGeom(sk, s);
      if (!g || !g.pts.length) continue;
      const c = [g.pts.reduce((t, q) => t + q[0], 0) / g.pts.length, g.pts.reduce((t, q) => t + q[1], 0) / g.pts.length];
      const owners = new Set([s.bone.index]);
      const att = getAttachment(sk, s.name, s.attName);
      if (att && att.type === 'mesh' && att.uvs && att.vertices.length !== att.uvs.length) for (let q = 0; q < att.vertices.length;) { const n = att.vertices[q++]; for (let k = 0; k < n; k++, q += 4) owners.add(att.vertices[q]); }
      for (const ix of owners) if (!geoCentre.has(ix)) geoCentre.set(ix, c);
    }
    const centre = i => { if (geoCentre.has(i)) return geoCentre.get(i); const p = paths[i]; return [p.reduce((s, q) => s + q[0], 0) / p.length, p.reduce((s, q) => s + q[1], 0) / p.length]; };
    const picks = [];
    if (order.length) picks.push(centre(order[0]));
    const midY = b.y + b.height * 0.5;
    const lower = order.find(i => centre(i)[1] < midY && (!picks.length || Math.hypot(centre(i)[0] - picks[0][0], centre(i)[1] - picks[0][1]) > half * 1.5));
    if (lower !== undefined) picks.push(centre(lower));
    pose(sk, anim, 0, true);
    const far = c => picks.every(p => Math.hypot(p[0] - c[0], p[1] - c[1]) > half * 1.5);
    const inside = bn => bn.worldX >= b.x && bn.worldX <= b.x + b.width && bn.worldY >= b.y && bn.worldY <= b.y + b.height;
    // ignore off-figure helper bones and bones that draw nothing (root / bare controls of fx groups)
    const low = sk.bones.filter(bn => inside(bn) && geoCentre.has(bn.index) && bn.parent).sort((p, q) => p.worldY - q.worldY)[0];
    const lowC = low && [low.worldX, low.worldY + half * 0.5];
    if (lowC && far(lowC)) picks.push(lowC);
    else {
      // root of the most-animated moving chains (waist / cloth root): seams and tearing show here
      const roots = order.map(i => sk.bones[i]).map(bn => { let x = bn; while (x.parent && x.parent.children.length === 1) x = x.parent; return x.parent || x; });
      const cnt = new Map(); roots.forEach(r => cnt.set(r, (cnt.get(r) || 0) + 1));
      const hub = [...cnt.entries()].sort((p, q) => q[1] - p[1]).map(([r]) => r).filter(r => r.parent && inside(r) && (geoCentre.has(r.index) || r.children.some(c => geoCentre.has(c.index)))).map(r => [r.worldX, r.worldY]).find(far)
        || order.map(centre).find(far); // fx groups: next distinct drawn mover
      if (hub) picks.push(hub);
    }
    regions = picks.map(([x, y]) => [x - half, y - half, half * 2, half * 2]);
  }
  const W = cols * (cellW + pad) + pad, H = pad + (cellH + head + pad) * 2 + (regions.length ? zoom + head + pad : 0);
  const cv = makeCanvas(W, H, [0.28, 0.29, 0.32]);
  const panel = (k, row, title, rect, draw, wide = 1) => {
    const x = pad + k * (cellW + pad), y = pad + row * (cellH + head + pad);
    const w = cellW * wide + pad * (wide - 1), h = row === 2 ? zoom : cellH;
    for (let yy = y + head; yy < y + head + h; yy++) for (let xx = x; xx < x + w; xx++) { const o = (yy * W + xx) * 3; cv.c[o] = BG[0]; cv.c[o + 1] = BG[1]; cv.c[o + 2] = BG[2]; }
    text(cv, x + 2, y + 3, title, [1, 1, 0.3], 2);
    cv.clip = [x, y + head, x + w, y + head + h];
    draw(viewport(rect, x, y + head, w, h));
    cv.clip = null;
    frame(cv, x, y + head, w, h, [0.2, 0.2, 0.22]);
  };
  // row 0: 6 frames
  const frames = [];
  for (let k = 0; k < cols; k++) frames.push(Math.round(k * nf / cols));
  frames.forEach((f, k) => panel(k, 0, `F${f}`, full, vp => { pose(sk, anim, f / fps, false); drawSkeleton(sk, cv, vp.toPx, 1, null); }));
  // row 1: trails (2 cells wide) + extreme frame (largest total displacement from frame 0) + onion of 3 frames
  let extreme = 0, best = -1;
  if (anim) for (let f = 0; f < nf; f += 2) { const d = paths.reduce((s, p, i) => s + (ext[i] > 2 ? Math.hypot(p[f / 2][0] - p[0][0], p[f / 2][1] - p[0][1]) : 0), 0); if (d > best) { best = d; extreme = f; } }
  const CATC = [[/(toufa|liuhai|houfa|qianfa|bianzi|hair|fa\d|bang|ahoge|daimao)/i, [1, 0.9, 0.1]], [/(pifeng|cape|qun|skirt|xiu|sleeve|coat|dress|scarf|weijin|robe)/i, [0.1, 0.9, 1]], [/(piaodai|ribbon|dai\d|rope|strap|chain|pendant|tassel|ling)/i, [1, 0.3, 1]], [/(weiba|tail|erduo|ear|wing|chibang)/i, [0.3, 1, 0.3]], [/(texiao|fx|guang|light|fire|smoke|steam|water|spark|yan\d|wu\d|shui)/i, [1, 0.55, 0.1]]];
  const colOf = bn => { for (let x = bn, k = 0; x && k < 4; x = x.parent, k++) for (const [re, c] of CATC) if (re.test(x.name)) return c; return [1, 0.3, 0.3]; };
  panel(0, 1, 'TRAILS', full, vp => {
    pose(sk, anim, 0, false); drawSkeleton(sk, cv, vp.toPx, 0.5, null);
    paths.forEach((p, i) => { if (ext[i] <= 2) return; const c = colOf(sk.bones[i]); for (let f = 1; f < p.length; f++) { const a = vp.toPx(p[f - 1]), q = vp.toPx(p[f]); line(cv, a[0], a[1], q[0], q[1], c, 0); } });
  }, 2);
  panel(2, 1, `EXTREME F${extreme}`, full, vp => { pose(sk, anim, extreme / fps, false); drawSkeleton(sk, cv, vp.toPx, 1, null); });
  panel(3, 1, 'SETUP', full, vp => { pose(sk, null, 0, false); drawSkeleton(sk, cv, vp.toPx, 1, null); });
  // onion: frame 0 dim + extreme bright, shows silhouette change (gaps, detaching layers)
  panel(4, 1, `ONION 0/${extreme}`, full, vp => { pose(sk, anim, 0, false); drawSkeleton(sk, cv, vp.toPx, 0.45, null); pose(sk, anim, extreme / fps, false); drawSkeleton(sk, cv, vp.toPx, 1, null); }, 2);
  // row 2: zoomed regions at frame 0 and the extreme frame side by side (2 cells per region → max 3)
  const regs = regions.slice(0, 3);
  regs.forEach((r, k) => {
    const rect = { x: r[0], y: r[1], w: r[2], h: r[3] };
    const x = pad + k * 2 * (cellW + pad), y = pad + 2 * (cellH + head + pad), w = cellW, h = zoom;
    for (const [m, f] of [[0, 0], [1, extreme]]) {
      const xx0 = x + m * (cellW + pad);
      for (let yy = y + head; yy < y + head + h; yy++) for (let xx = xx0; xx < xx0 + w; xx++) { const o = (yy * W + xx) * 3; cv.c[o] = BG[0]; cv.c[o + 1] = BG[1]; cv.c[o + 2] = BG[2]; }
      text(cv, xx0 + 2, y + 3, `R${k + 1} F${f}`, [1, 1, 0.3], 2);
      pose(sk, anim, f / fps, false);
      cv.clip = [xx0, y + head, xx0 + w, y + head + h];
      drawSkeleton(sk, cv, viewport(rect, xx0, y + head, w, h).toPx, 1, null);
      cv.clip = null;
      frame(cv, xx0, y + head, w, h, [0.2, 0.2, 0.22]);
    }
  });
  savePNG(cv, `${outPrefix}_sheet.png`);
  const r1 = x => Math.round(x);
  console.log(`wrote ${outPrefix}_sheet.png ${W}x${H} (anim ${animName}, ${nf}f) — rows: 6 frames | trails, extreme F${extreme}, setup, onion 0/${extreme} | zoom R1–R${regs.length} at F0 and F${extreme}`);
  regs.forEach((r, k) => console.log(`  R${k + 1} = --crop ${r.map(r1).join(',')}`));
  const movers = ext.map((e, i) => [e, i]).filter(([e]) => e > 2).sort((p, q) => q[0] - p[0]).slice(0, 12);
  console.log('  biggest tip travel: ' + movers.map(([e, i]) => `${sk.bones[i].name} ${r1(e)}`).join(', '));
}

// --motion: TEXT only (no image). Per moving bone: tip travel px / ‰ of height, and a contact check
// for the lowest bones (feet/seat) and IK targets — lets an agent verify most motion without images.
function printMotion(sk, anim, animName, opt) {
  const fps = opt.fps, H = boundsOf(sk.j).height;
  const nf = anim ? animFrames(anim, fps) : 1;
  const paths = anim ? boneTipPaths(sk, anim, fps, nf, 1) : sk.bones.map(() => []);
  const rows = sk.bones.map((b, i) => ({ b, e: paths[i].length ? pathExtent(paths[i]) : 0 })).filter(r => r.e > 0.5).sort((p, q) => q.e - p.e);
  console.log(`# motion ${animName} ${nf}f, height ${Math.round(H)}px — tip travel (peak-to-peak) of moving bones`);
  for (const r of rows.slice(0, 60)) console.log(`${r.b.name}\t${r.e.toFixed(1)}px\t${(r.e / H * 1000).toFixed(1)}‰`);
  if (rows.length > 60) console.log(`... ${rows.length - 60} more`);
  // contact candidates by rig convention (01-rigging §2): IK targets, and small groups directly under
  // root other than the main body (feet, ground props, seats). Floating companions will show as moving.
  const root = sk.bones[0];
  const size = b => 1 + b.children.reduce((s, c) => s + size(c), 0);
  const body = root.children.slice().sort((p, q) => size(q) - size(p))[0];
  const rootKids = root.children.filter(b => b !== body);
  const ikT = new Set(sk.cons.filter(c => c.kind === 'ik').map(c => c.target));
  console.log('# contact check: IK targets + non-body bones under root (planted feet / seats / ground props should stay ~0px; floating companions move)');
  for (const b of new Set([...ikT, ...rootKids])) { const p = paths[b.index]; const e = p && p.length ? pathExtent(p) : 0; console.log(`${b.name}\t${e.toFixed(1)}px${e > 2 ? '\t<-- moves' : ''}`); }
}

// --parts: contact sheet of every slot's attachment in setup pose, labelled with an index; the
// console prints index → slot/bone. One page holds up to 48 parts (--page N for the next page).
function renderParts(sk, outPrefix, opt) {
  pose(sk, null, 0, false);
  const items = [];
  for (const s of sk.drawOrder) {
    const g = slotGeom(sk, s);
    if (!g) continue;
    const xs = g.pts.map(p => p[0]), ys = g.pts.map(p => p[1]);
    const rect = { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(1, Math.max(...xs) - Math.min(...xs)), h: Math.max(1, Math.max(...ys) - Math.min(...ys)) };
    items.push({ s, rect });
  }
  const per = 48, page = Math.max(0, (opt.page || 1) - 1), pages = Math.ceil(items.length / per);
  const list = items.slice(page * per, page * per + per);
  const cols = 8, cell = 150, head = 16, pad = 4;
  const rows = Math.ceil(list.length / cols);
  const W = cols * (cell + pad) + pad, H = rows * (cell + head + pad) + pad;
  const cv = makeCanvas(W, Math.max(H, 40), [0.28, 0.29, 0.32]);
  list.forEach((it, k) => {
    const x = pad + (k % cols) * (cell + pad), y = pad + Math.floor(k / cols) * (cell + head + pad);
    for (let yy = y + head; yy < y + head + cell; yy++) for (let xx = x; xx < x + cell; xx++) { const o = (yy * W + xx) * 3; cv.c[o] = BG[0]; cv.c[o + 1] = BG[1]; cv.c[o + 2] = BG[2]; }
    const idx = page * per + k;
    text(cv, x + 2, y + 3, `${idx} ${it.s.name}`.slice(0, 18), [1, 1, 0.3], 2);
    const r = it.rect, m = 0.06 * Math.max(r.w, r.h);
    const vp = viewport({ x: r.x - m, y: r.y - m, w: r.w + 2 * m, h: r.h + 2 * m }, x, y + head, cell, cell);
    drawSkeleton(sk, cv, vp.toPx, 1, s => s === it.s);
  });
  const file = `${outPrefix}_parts${pages > 1 ? '_p' + (page + 1) : ''}.png`;
  savePNG(cv, file);
  console.log(`wrote ${file} — parts ${page * per}–${page * per + list.length - 1} of ${items.length} (page ${page + 1}/${pages}${pages > 1 ? ', use --page N' : ''})`);
  list.forEach((it, k) => console.log(`  ${page * per + k}\t${it.s.name}\tbone=${it.s.bone.name}\tattachment=${it.s.attName}\t${Math.round(it.rect.w)}x${Math.round(it.rect.h)}`));
}

function animFrames(anim, fps) {
  let dur = 0;
  const walk = o => { if (Array.isArray(o)) o.forEach(k => { if (k && typeof k === 'object') { if (typeof k.time === 'number') dur = Math.max(dur, k.time); walk(k); } }); else if (o && typeof o === 'object') Object.values(o).forEach(walk); };
  walk(anim);
  return Math.max(1, Math.round(dur * fps));
}

function main() {
  const args = process.argv.slice(2);
  if (args.length < 2) { console.error(fs.readFileSync(__filename, 'utf8').split('\n').slice(1, 14).map(l => l.replace(/^\/\/ ?/, '')).join('\n')); process.exit(2); }
  const input = args[0], outPrefix = args[1];
  const opt = { max: 1100, frame: 0, trails: false, strip: 0, fps: 30 };
  for (let i = 2; i < args.length; i++) {
    const a = args[i];
    if (a === '--anim') opt.anim = args[++i];
    else if (a === '--frame') opt.frame = +args[++i];
    else if (a === '--max') opt.max = +args[++i];
    else if (a === '--trails') opt.trails = true;
    else if (a === '--strip') opt.strip = +args[++i];
    else if (a === '--isolate') opt.isolate = args[++i];
    else if (a === '--hide') opt.hide = args[++i];
    else if (a === '--atlas') opt.atlas = args[++i];
    else if (a === '--fps') opt.fps = +args[++i];
    else if (a === '--crop') opt.crop = args[++i].split(',').map(Number); // x,y,w,h in skeleton units (y up, like Spine)
    else if (a === '--bones') opt.bones = true;
    else if (a === '--sheet') opt.sheet = true;
    else if (a === '--regions') opt.regions = args[++i].split(';').map(s => s.split(',').map(Number)).filter(r => r.length === 4 && r.every(isFinite));
    else if (a === '--parts') opt.parts = true;
    else if (a === '--motion') opt.motion = true;
    else if (a === '--page') opt.page = +args[++i];
  }
  const sk = opt.motion || opt.bones ? skeletonFor(C.readJson(C.resolveJson(input)), C.resolveJson(input)) : loadProject(input, opt.atlas);
  if ((opt.motion || opt.bones) && opt.atlas) sk.atlas = loadAtlasFor(C.resolveJson(input), opt.atlas);
  for (const warning of sk.warnings) console.error(`PREVIEW LIMIT: ${warning}`);
  const j = sk.j;
  const animName = opt.anim || Object.keys(j.animations || {})[0];
  const anim = animName ? (j.animations || {})[animName] : null;
  if (opt.anim && !anim) throw new Error(`animation not found: ${opt.anim}; have ${Object.keys(j.animations || {}).join(', ')}`);
  const fps = opt.fps;
  const bnd = boundsOf(j);
  let sx0 = bnd.x, sy0 = bnd.y, sw = bnd.width, sh = bnd.height;
  if (opt.crop && opt.crop.length === 4 && opt.crop.every(isFinite)) [sx0, sy0, sw, sh] = opt.crop; // zoom on a region
  const margin = opt.crop ? 0 : 0.04 * Math.max(sw, sh);
  const iso = opt.isolate && sk.boneByName.get(opt.isolate), hide = opt.hide && sk.boneByName.get(opt.hide);
  const filter = (iso || hide) ? s => (!iso || isDesc(s.bone, iso)) && (!hide || !isDesc(s.bone, hide)) : null;
  if (opt.motion) return printMotion(sk, anim, animName, opt);
  if (opt.sheet) return renderSheet(sk, anim, animName, outPrefix, opt);
  if (opt.parts) return renderParts(sk, outPrefix, opt);
  if (opt.strip > 0) {
    // N frames side by side, each cell opt.max/N wide (min 220px), frame number printed
    const nf = anim ? animFrames(anim, fps) : 1, n = opt.strip;
    const cell = Math.max(220, Math.floor(opt.max / Math.min(n, 6)));
    const scale = cell / (Math.max(sw, sh) + 2 * margin);
    const cw = Math.ceil((sw + 2 * margin) * scale), ch = Math.ceil((sh + 2 * margin) * scale);
    const cols = Math.min(n, 6), rows = Math.ceil(n / cols);
    const cv = makeCanvas(cw * cols, ch * rows, [0.47, 0.47, 0.5]);
    const frames = [];
    for (let k = 0; k < n; k++) frames.push(Math.round(k * nf / n));
    frames.forEach((f, k) => {
      pose(sk, anim, f / fps, false);
      const ox = (k % cols) * cw, oy = Math.floor(k / cols) * ch;
      drawSkeleton(sk, cv, ([x, y]) => [ox + (x - sx0 + margin) * scale, oy + (sy0 + sh + margin - y) * scale], 1, filter);
      text(cv, ox + 4, oy + 4, f, [1, 1, 0.2], 3);
    });
    savePNG(cv, `${outPrefix}_strip.png`);
    console.log(`wrote ${outPrefix}_strip.png frames ${frames.join(',')} of ${nf} (anim ${animName})`);
    return;
  }
  pose(sk, anim, opt.frame / fps, false);
  if (opt.bones) {
    const r1 = x => Math.round(x * 10) / 10;
    console.log(`# bone world positions at frame ${opt.frame} (skeleton units, y up): name x y [tip x y]`);
    for (const b of sk.bones) { const L = b.data.length || 0; console.log(`${b.name} ${r1(b.worldX)} ${r1(b.worldY)}${L ? ` tip ${r1(b.worldX + b.a * L)} ${r1(b.worldY + b.c * L)}` : ''}`); }
    return;
  }
  const scale = opt.max / (Math.max(sw, sh) + 2 * margin);
  const W = Math.ceil((sw + 2 * margin) * scale), H = Math.ceil((sh + 2 * margin) * scale);
  const toPx = ([x, y]) => [(x - sx0 + margin) * scale, (sy0 + sh + margin - y) * scale];
  const cv = makeCanvas(W, H, [0.47, 0.47, 0.5]);
  drawSkeleton(sk, cv, toPx, opt.trails ? 0.55 : 1, filter);
  if (!opt.trails) {
    savePNG(cv, `${outPrefix}_f${opt.frame}.png`);
    console.log(`wrote ${outPrefix}_f${opt.frame}.png ${W}x${H} scale=${scale.toFixed(3)} anim=${animName}`);
    return;
  }
  // trails: bone-tip paths over the whole animation, coloured by category, tips numbered
  const nf = animFrames(anim, fps);
  const tips = sk.bones.map(() => []);
  for (let f = 0; f <= nf; f++) {
    pose(sk, anim, f / fps, true);
    sk.bones.forEach((b, i) => { const L = b.data.length || 0; tips[i].push(toPx([b.worldX + b.a * L, b.worldY + b.c * L])); });
  }
  const CAT = [
    ['hair', [1, 0.9, 0.1], /(toufa|liuhai|houfa|qianfa|bianzi|mawei|hair|fa\d|^fa|daimao|bang)/i],
    ['cloth', [0.1, 0.9, 1], /(pifeng|cape|qun|skirt|xiu|sleeve|yifu|waitao|coat|dress|pao|scarf|weijin|bu\d)/i],
    ['ribbon', [1, 0.3, 1], /(piaodai|dai|ribbon|sheng|rope|strap|lian\d|chain|suolian|xianglian|ling)/i],
    ['tail/ear', [0.3, 1, 0.3], /(weiba|tail|erduo|ear)/i],
    ['fx', [1, 0.55, 0.1], /(texiao|tx|guang|light|fire|huo|yan|smoke|wu|smell|qi\d|xing|star|sanguang|suishi)/i],
  ];
  const slotNamesOf = new Map();
  for (const s of sk.slots) { if (!slotNamesOf.has(s.bone.name)) slotNamesOf.set(s.bone.name, []); slotNamesOf.get(s.bone.name).push(s.name); }
  const catOf = b => { const names = [b.name, ...(slotNamesOf.get(b.name) || [])]; for (let x = b.parent, k = 0; x && k < 3; x = x.parent, k++) names.push(x.name); for (const [n, col, re] of CAT) if (names.some(q => re.test(q))) return [n, col]; return ['other', [1, 0.25, 0.25]]; };
  const moving = [];
  sk.bones.forEach((b, i) => {
    const t = tips[i];
    const xs = t.map(p => p[0]), ys = t.map(p => p[1]);
    const ext = Math.hypot(Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys));
    if (ext < 2) return;
    if (filter && !(!iso || isDesc(b, iso))) return;
    const [cat, col] = catOf(b);
    for (let f = 1; f < t.length; f++) line(cv, t[f - 1][0], t[f - 1][1], t[f][0], t[f][1], col, 1);
    plot(cv, t[0][0], t[0][1], [1, 1, 1], 2);
    moving.push({ i, name: b.name, cat, ext });
  });
  // label chain tips: bones with no animated child (end of motion chain)
  const movingSet = new Set(moving.map(m => m.i));
  const labels = moving.filter(m => !sk.bones[m.i].children.some(c => movingSet.has(c.index))).sort((a, b) => b.ext - a.ext).slice(0, 60);
  labels.forEach((m, k) => { const p = tips[m.i][0]; text(cv, Math.round(p[0]) + 4, Math.round(p[1]) - 6, k, [1, 1, 1], 2); });
  savePNG(cv, `${outPrefix}_trails.png`);
  console.log(`wrote ${outPrefix}_trails.png ${W}x${H} scale=${scale.toFixed(3)} anim=${animName} frames=${nf}`);
  console.log('labels (tip bones, sorted by travel px):');
  console.log(labels.map((m, k) => { const chain = []; for (let x = sk.bones[m.i]; x && movingSet.has(x.index); x = x.parent) chain.unshift(x.name); return `${k}:${m.cat}:${chain.join('>')}(${m.ext.toFixed(0)}px)`; }).join('\n'));
}

if (require.main === module) main();
module.exports = { loadProject, loadAtlasFor, skeletonFor, drawnPoints, deformSmear, buildSkeleton, computeBounds, boundsOf, slotPoints, opaqueTexels, drawnCentre, blinkGeometry, pose, slotGeom, decodePNG, encodePNG, parseAtlas, makeCanvas, drawSkeleton, savePNG, text, line, plot };
