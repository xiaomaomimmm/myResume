#!/usr/bin/env node
// Convert the common Spine JSON feature set using explicit version profiles.
'use strict';
const fs=require('fs'),path=require('path'),C=require('./spine_core'),V=require('./spine_compat');
function main(argv=process.argv.slice(2)){
  const input=argv[0],output=argv[1],index=argv.indexOf('--spine-version');
  if(!input || (!argv.includes('--check') && (!output || index<0 || !argv[index+1]))) {
    console.error('usage: node spine_convert.js <in.json> <out.json> --spine-version 3.7|3.8|4.0|4.1|4.2|4.3|latest\n       node spine_convert.js <in.json> --check');return 2;
  }
  try{
    const j=C.readJson(C.resolveJson(input));
    if(argv.includes('--check')){const report=V.validateVersion(j);console.log(JSON.stringify(report,null,2));return report.errors.length?1:0;}
    if(path.resolve(C.resolveJson(input))===path.resolve(output))throw new Error('Choose a different output path; the source file is preserved');
    const result=V.convertVersion(j,argv[index+1]);
    fs.mkdirSync(path.dirname(path.resolve(output)),{recursive:true});fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n','utf8');
    console.log(`wrote ${output} (Spine ${result.skeleton.spine}); atlases/images are preserved separately`);return 0;
  }catch(e){console.error(e.message);return 1;}
}
if(require.main===module)process.exitCode=main();
module.exports={main};
