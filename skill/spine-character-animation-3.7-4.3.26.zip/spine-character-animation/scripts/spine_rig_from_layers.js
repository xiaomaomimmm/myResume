#!/usr/bin/env node
// spine_rig_from_layers.js — build a Spine skeleton (bones + slots + alpha-contour meshes + joint weights) from
// landmark points and layer PNGs, following the conventions of the MintS Photoshop exporter:
//   * bones come from 25 landmark POINTS (template humanoid-basic): each bone starts at its own point and points
//     at its primary child's point (length = distance). The torso chain root → body → waist → neck → head is built
//     from the pelvis UP to the chin, so every torso bone points UP the body;
//   * face features (eye_l/r, ear_l/r, nose, mouth) are POINTS: zero-length bones parented to head;
//   * meshes are traced from the layer's alpha: an outline 1px outside the opaque pixels, simplified with a
//     chord-length + sagitta limit, then filled with evenly spaced interior points (farthest-point sampling),
//     area-based vertex budget, Delaunay-like edge flips;
//   * weights: each layer is bound to one bone and may only be weighted along that bone's downstream chain of the
//     same family (arm/leg/torso/hair, same side). Two adjacent bones blend with a smoothstep across the joint,
//     radius = clamp(0.1 × shorter segment, 6, 28) px; weights < 0.035 are dropped.
//
// Usage:
//   node spine_rig_from_layers.js <landmarks.json> <layers.json> <out.json>
//        [--spine-version 3.7|3.8|4.0|4.1|4.2|4.3|latest] [--images ./images/]
//        [--mesh all|weighted|none] [--weights on|off] [--template]
//   node spine_rig_from_layers.js --template humanoid > landmarks.json   (normalised template to adjust)
//   Default is 3.8.99. --spine is retained as an alias for --spine-version. Exact patch versions are preserved.
//
// landmarks.json: { "width": W, "height": H, "coords": "px"|"normalized", "points": [
//     { "name": "root", "x": .., "y": .. }, { "name": "body", .. }, ... ],          (image coords: y DOWN)
//   optional "extra": [ { "name": "hair_back_01", "parent": "head", "x": .., "y": .. }, ... ] }
//   Names follow the 25-point template: root body waist neck head eye_l eye_r ear_l ear_r nose mouth
//   shoulder_l arm_l forearm_l hand_l shoulder_r arm_r forearm_r hand_r thigh_l calves_l foot_l thigh_r calves_r
//   foot_r. _l/_r = the CHARACTER's left/right (front view: _r is on the viewer's left). root = ground point
//   between the feet; body = pelvis; head = chin / jaw pivot (not the face centre). Extra points chain by name
//   (hair_01 → hair_02 …) or by "parent".
// layers.json: [ { "name": "arm_upper_l", "png": "images/arm_upper_l.png", "left": .., "top": .., "bone": "arm_l"? } ]
//   in draw order (first = back; psd_layers.js index 0 = bottom). left/top = layer position in the image
//   (psd_layers.js --json gives it). bone is optional: otherwise bound by name (eye*/white*/brow*/mouth*/hair*/face*
//   → head or the eye/ear/nose/mouth point, arm/forearm/hand/thigh/calf/foot + side, neck, waist, body/torso →
//   body; these may be weighted) or, unnamed, to the nearest torso/head bone WITHOUT weights. Also writes
//   <out>.atlas (one page per layer PNG) so spine_render.js / spine_lint.js can check the result.
'use strict';
const fs = require('fs');
const path = require('path');
const R = require('./spine_render');
const V = require('./spine_compat');

// ---------------- template (MintS humanoid-basic) ----------------
const TEMPLATE = [
  ['root', null, 0.5, 0.98], ['body', 'root', 0.5, 0.7], ['waist', 'body', 0.5, 0.56], ['neck', 'waist', 0.5, 0.31], ['head', 'neck', 0.5, 0.22],
  ['eye_l', 'head', 0.53, 0.16], ['eye_r', 'head', 0.47, 0.16], ['ear_l', 'head', 0.57, 0.18], ['ear_r', 'head', 0.43, 0.18], ['nose', 'head', 0.5, 0.185], ['mouth', 'head', 0.5, 0.205],
  ['shoulder_l', 'waist', 0.57, 0.32], ['arm_l', 'shoulder_l', 0.66, 0.34], ['forearm_l', 'arm_l', 0.72, 0.52], ['hand_l', 'forearm_l', 0.78, 0.66],
  ['shoulder_r', 'waist', 0.43, 0.32], ['arm_r', 'shoulder_r', 0.34, 0.34], ['forearm_r', 'arm_r', 0.28, 0.52], ['hand_r', 'forearm_r', 0.22, 0.66],
  ['thigh_l', 'body', 0.58, 0.71], ['calves_l', 'thigh_l', 0.6, 0.84], ['foot_l', 'calves_l', 0.62, 0.95],
  ['thigh_r', 'body', 0.42, 0.71], ['calves_r', 'thigh_r', 0.4, 0.84], ['foot_r', 'calves_r', 0.38, 0.95],
];
const PARENT = Object.fromEntries(TEMPLATE.map(([n, p]) => [n, p]));
// bone → the child point it points at (torso goes UP: body→waist→neck→head)
const TIP = { body: 'waist', waist: 'neck', neck: 'head', shoulder_l: 'arm_l', arm_l: 'forearm_l', forearm_l: 'hand_l', shoulder_r: 'arm_r', arm_r: 'forearm_r', forearm_r: 'hand_r', thigh_l: 'calves_l', calves_l: 'foot_l', thigh_r: 'calves_r', calves_r: 'foot_r' };
const POINT_BONES = /^(eye|ear|nose|mouth|brow|pupil|lash)(_|$)/; // face features: zero-length points
const DEFAULT_LEN = { head: 24, hand: 24, foot: 24 };              // leaf bones without a tip point

const argv = process.argv.slice(2);
if (argv[0] === '--template') {
  console.log(JSON.stringify({ width: 1000, height: 1000, coords: 'normalized', points: TEMPLATE.map(([name, , x, y]) => ({ name, x, y })) }, null, 1));
  process.exit(0);
}
if (argv.length < 3) { console.error(fs.readFileSync(__filename, 'utf8').split('\n').slice(1, 38).filter(l => l.startsWith('//')).map(l => l.replace(/^\/\/ ?/, '')).join('\n')); process.exit(2); }
const [lmFile, layFile, outFile] = argv;
const opt = { spine: '3.8.99', images: './images/', mesh: 'all', weights: 'on' };
for (let i = 3; i < argv.length; i++) {
  if (argv[i] === '--spine' || argv[i] === '--spine-version') {
    opt.spine = argv[++i];
    if (!opt.spine || opt.spine.startsWith('--')) { console.error('--spine-version requires a version'); process.exit(2); }
  }
  else if (argv[i] === '--images') opt.images = argv[++i];
  else if (argv[i] === '--mesh') opt.mesh = argv[++i];
  else if (argv[i] === '--weights') opt.weights = argv[++i];
  else { console.error('unknown arg ' + argv[i]); process.exit(2); }
}
try { V.profileOf(opt.spine); } catch (err) { console.error(`Spine version: ${err.message}`); process.exit(3); }
const LM = JSON.parse(fs.readFileSync(lmFile, 'utf8'));
const W = LM.width, H = LM.height, norm = LM.coords === 'normalized';
const layerDir = path.dirname(path.resolve(layFile));
const LAYERS = JSON.parse(fs.readFileSync(layFile, 'utf8'));

// ---------------- points → bones ----------------
const pts = new Map();
for (const p of [...(LM.points || []), ...(LM.extra || [])]) pts.set(p.name, { name: p.name, x: norm ? p.x * W : p.x, y: norm ? p.y * H : p.y, parent: p.parent });
if (!pts.has('root')) { console.error('landmarks: "root" point is required (ground point between the feet)'); process.exit(3); }
const seqParent = name => { const m = /^(.*?)_?(\d+)$/.exec(name); if (!m) return null; const prev = `${m[1]}_${String(+m[2] - 1).padStart(m[2].length, '0')}`; return pts.has(prev) ? prev : null; };
for (const p of pts.values()) {
  if (p.name === 'root') { p.parent = null; continue; }
  p.parent = (PARENT[p.name] && pts.has(PARENT[p.name]) ? PARENT[p.name] : null) || (p.parent && pts.has(p.parent) ? p.parent : null) || seqParent(p.name) || (pts.has('head') && POINT_BONES.test(p.name) ? 'head' : 'root');
}
const root = pts.get('root');
const toSpine = p => ({ x: p.x - root.x, y: root.y - p.y });   // image (y down) → Spine world (y up), origin at root
const kids = n => [...pts.values()].filter(q => q.parent === n);
const side = n => (/(^|_)(l|L)$/.test(n) ? 'l' : /(^|_)(r|R)$/.test(n) ? 'r' : '');
function tipOf(p) {
  if (p.name === 'root' || p.name === 'head' || POINT_BONES.test(p.name)) return null;
  if (TIP[p.name] && pts.has(TIP[p.name]) && pts.get(TIP[p.name]).parent === p.name) return pts.get(TIP[p.name]);
  const ks = kids(p.name).filter(k => !POINT_BONES.test(k.name));
  return ks.find(k => side(k.name) && side(k.name) === side(p.name)) || ks.find(k => seqParent(k.name) === p.name) || null;
}
const order = [];
const placed = new Set();
const visit = p => { if (placed.has(p.name)) return; if (p.parent) visit(pts.get(p.parent)); placed.add(p.name); order.push(p); };
for (const p of pts.values()) visit(p);
const bones = [], B = new Map();
for (const p of order) {
  const s = toSpine(p);
  if (!p.parent) { const b = { name: 'root', parent: null, x: 0, y: 0, rotation: 0, length: 0, wx: 0, wy: 0, wr: 0 }; bones.push(b); B.set('root', b); continue; }
  const P = B.get(p.parent), tip = tipOf(p);
  const e = tip ? toSpine(tip) : null;
  const wr = e ? Math.atan2(e.y - s.y, e.x - s.x) * 180 / Math.PI : P.wr;
  const len = e ? Math.hypot(e.x - s.x, e.y - s.y) : (POINT_BONES.test(p.name) ? 0 : (DEFAULT_LEN[p.name.replace(/_[lr]$/, '')] || 0));
  const c = Math.cos(-P.wr * Math.PI / 180), sn = Math.sin(-P.wr * Math.PI / 180), dx = s.x - P.wx, dy = s.y - P.wy;
  let rot = wr - P.wr; while (rot > 180) rot -= 360; while (rot <= -180) rot += 360;
  const b = { name: p.name, parent: p.parent, x: dx * c - dy * sn, y: dx * sn + dy * c, rotation: rot, length: len, wx: s.x, wy: s.y, wr, tipX: e ? e.x : s.x, tipY: e ? e.y : s.y };
  bones.push(b); B.set(p.name, b);
}
const boneIndex = new Map(bones.map((b, i) => [b.name, i]));
// world → bone local (unit scale, rotation wr)
const toLocal = (b, x, y) => { const c = Math.cos(-b.wr * Math.PI / 180), s = Math.sin(-b.wr * Math.PI / 180), dx = x - b.wx, dy = y - b.wy; return [dx * c - dy * s, dx * s + dy * c]; };

// ---------------- layer → bone binding ----------------
const family = n => { n = String(n).toLowerCase(); if (/^(body|waist|neck|head)$/.test(n)) return 'axial'; if (/^(shoulder|arm|forearm|hand)(_|$)/.test(n)) return 'arm'; if (/^(thigh|calves|calf|foot|leg)(_|$)/.test(n)) return 'leg'; if (/(^|_)hair(_|$|\d)/.test(n)) return 'hair'; return n.replace(/_(l|r)(_\d+)?$/, '').replace(/_?\d+$/, ''); };
// returns { bone, weightable }: semantic name matches may be weighted along their chain; layers bound only by
// position (nearest torso/head bone) stay single-bone, like MintS binds unnamed layers without weights
function bindLayer(L) {
  if (L.bone && B.has(L.bone)) return { bone: L.bone, weightable: true };
  const n = String(L.name).toLowerCase().replace(/[\s-]+/g, '_'), sd = side(n) || (/(left|zuo)/.test(n) ? 'l' : /(right|you)/.test(n) ? 'r' : '');
  const pick = (...names) => names.find(x => B.has(x));
  const hit = (b, w = true) => (b ? { bone: b, weightable: w } : null);
  if (/(eye|pupil|iris|white|sclera|highlight|lash|lid|brow|mouth|lip|teeth|tongue|nose|cheek|face|hair|bang|fringe|ear(?!th)|head)/.test(n)) {
    const feat = /^(eye|ear|nose|mouth)/.exec(n);
    return hit((feat && pick(`${feat[1]}${feat[1] === 'nose' || feat[1] === 'mouth' ? '' : '_' + sd}`)) || pick('head'), false);
  }
  if (sd) {
    if (/(forearm|lower_?arm|arm_d)/.test(n)) return hit(pick(`forearm_${sd}`, `arm_${sd}`));
    if (/(hand|finger|thumb)/.test(n)) return hit(pick(`hand_${sd}`, `forearm_${sd}`));
    if (/(upper_?arm|arm)/.test(n)) return hit(pick(`arm_${sd}`));
    if (/(shoulder|kara)/.test(n)) return hit(pick(`shoulder_${sd}`));
    if (/(calf|calves|shin|lower_?leg)/.test(n)) return hit(pick(`calves_${sd}`, `thigh_${sd}`));
    if (/(foot|feet|shoe)/.test(n)) return hit(pick(`foot_${sd}`, `calves_${sd}`));
    if (/(thigh|upper_?leg|leg)/.test(n)) return hit(pick(`thigh_${sd}`));
  }
  if (/(neck)/.test(n)) return hit(pick('neck'));
  if (/(belt|waist)/.test(n)) return hit(pick('waist', 'body'));
  if (/(body|torso|chest)/.test(n)) return hit(pick('body'));
  if (/(pelvis|hip)/.test(n)) return hit(pick('body'), false);
  return null; // nearest torso/head bone below
}
const AXIAL = ['body', 'waist', 'neck', 'head'];
const segDist = (x, y, b) => { const dx = b.tipX - b.wx, dy = b.tipY - b.wy, L2 = dx * dx + dy * dy; const t = L2 ? Math.max(0, Math.min(1, ((x - b.wx) * dx + (y - b.wy) * dy) / L2)) : 0; return Math.hypot(x - (b.wx + t * dx), y - (b.wy + t * dy)); };
// downstream chain of the same family (MintS weight policy): start, then its only same-family child, … and it
// stops AFTER the first bone that has its own layer (that layer owns the next part: a sleeve bound to arm_l
// blends into forearm_l but not further when the forearm has its own drawing)
let imageBones = new Set();
function weightChain(start) {
  const out = [start];
  if (start === 'root') return out;
  let cur = start;
  for (let g = 0; g < 8; g++) {
    const ch = bones.filter(b => b.parent === cur && !POINT_BONES.test(b.name) && family(b.name) === family(cur) && (!side(b.name) || !side(cur) || side(b.name) === side(cur)));
    if (ch.length !== 1) break;
    cur = ch[0].name; out.push(cur);
    if (imageBones.has(cur)) break;
  }
  return out;
}

// ---------------- alpha mesh ----------------
function alphaMask(img) { const m = new Uint8Array(img.w * img.h); for (let i = 0; i < m.length; i++) m[i] = img.data[i * 4 + 3] > 0 ? 1 : 0; return m; }
// drop specks: components ≤ 128 px and ≤ 0.25% of the largest with max alpha ≤ 16 (MintS thresholds)
function cleanSpecks(img, m) {
  const w = img.w, h = img.h, lab = new Int32Array(w * h).fill(-1), comps = [];
  for (let s = 0; s < m.length; s++) {
    if (!m[s] || lab[s] >= 0) continue;
    const q = [s], c = { px: [], maxA: 0 }; lab[s] = comps.length;
    while (q.length) { const i = q.pop(); c.px.push(i); c.maxA = Math.max(c.maxA, img.data[i * 4 + 3]); const x = i % w, y = (i / w) | 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const X = x + dx, Y = y + dy; if (X < 0 || Y < 0 || X >= w || Y >= h) continue; const j = Y * w + X; if (m[j] && lab[j] < 0) { lab[j] = comps.length; q.push(j); } } }
    comps.push(c);
  }
  const big = Math.max(...comps.map(c => c.px.length));
  for (const c of comps) if (c.px.length <= 128 && c.px.length / big <= 0.0025 && c.maxA <= 16) for (const i of c.px) m[i] = 0;
  return comps.filter(c => c.px.length > 128 || c.px.length / big > 0.0025 || c.maxA > 16);
}
function dilate(m, w, h, r) { const o = new Uint8Array(w * h); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { if (!m[y * w + x]) continue; for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) { const X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < w && Y < h) o[Y * w + X] = 1; } } return o; }
// connect separate components with 1px bridges so one outline encloses everything (MintS connectAlphaComponents)
function bridge(m, w, h) {
  const lab = new Int32Array(w * h).fill(-1), comps = [];
  for (let s = 0; s < m.length; s++) { if (!m[s] || lab[s] >= 0) continue; const q = [s], px = []; lab[s] = comps.length; while (q.length) { const i = q.pop(); px.push(i); const x = i % w, y = (i / w) | 0; for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const X = x + dx, Y = y + dy; if (X < 0 || Y < 0 || X >= w || Y >= h) continue; const j = Y * w + X; if (m[j] && lab[j] < 0) { lab[j] = comps.length; q.push(j); } } } comps.push(px); }
  if (comps.length < 2) return m;
  comps.sort((a, b) => b.length - a.length);
  const joined = [comps[0]];
  const sample = px => px.filter((_, k) => k % Math.max(1, Math.floor(px.length / 300)) === 0);
  for (let c = 1; c < comps.length; c++) {
    let best = null;
    for (const a of sample(comps[c])) for (const g of joined) for (const b of sample(g)) { const d = Math.hypot(a % w - b % w, ((a / w) | 0) - ((b / w) | 0)); if (!best || d < best.d) best = { a, b, d }; }
    const ax = best.a % w, ay = (best.a / w) | 0, bx = best.b % w, by = (best.b / w) | 0, n = Math.ceil(best.d) + 1;
    for (let k = 0; k <= n; k++) { const x = Math.round(ax + (bx - ax) * k / n), y = Math.round(ay + (by - ay) * k / n); m[y * w + x] = 1; if (x + 1 < w) m[y * w + x + 1] = 1; }
    joined.push(comps[c]);
  }
  return m;
}
// outer boundary of a binary mask as a polygon of pixel-corner points (largest loop), y down
function traceOuter(m, w, h) {
  const at = (x, y) => (x >= 0 && y >= 0 && x < w && y < h ? m[y * w + x] : 0);
  // directed edges with the inside on the left; chain them
  const next = new Map(), key = (x, y) => y * (w + 1) + x;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    if (!at(x, y)) continue;
    if (!at(x, y - 1)) next.set(key(x, y), key(x + 1, y));
    if (!at(x + 1, y)) next.set(key(x + 1, y), key(x + 1, y + 1));
    if (!at(x, y + 1)) next.set(key(x + 1, y + 1), key(x, y + 1));
    if (!at(x - 1, y)) next.set(key(x, y + 1), key(x, y));
  }
  const used = new Set(), loops = [];
  for (const s of next.keys()) {
    if (used.has(s)) continue;
    const loop = []; let k = s, g = 0;
    while (!used.has(k) && next.has(k) && g++ < 4 * (w + 1) * (h + 1)) { used.add(k); loop.push([k % (w + 1), Math.floor(k / (w + 1))]); k = next.get(k); }
    if (loop.length >= 4) loops.push(loop);
  }
  const area = l => { let a = 0; for (let i = 0; i < l.length; i++) { const p = l[i], q = l[(i + 1) % l.length]; a += p[0] * q[1] - q[0] * p[1]; } return a / 2; };
  loops.sort((a, b) => Math.abs(area(b)) - Math.abs(area(a)));
  // drop collinear points
  const L = loops[0] || [];
  return L.filter((p, i) => { const a = L[(i - 1 + L.length) % L.length], b = L[(i + 1) % L.length]; return (p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0]) !== 0; });
}
// greedy chord sampling: longest chord ≤ maxChord whose skipped arc stays within `sag` px and that does not cut
// through an opaque pixel of the ORIGINAL mask (alpha-safe hull)
function simplify(loop, m, w, h, maxChord, sag) {
  const n = loop.length, out = [];
  const opaque = (x, y) => { const X = Math.floor(x), Y = Math.floor(y); return X >= 0 && Y >= 0 && X < w && Y < h && m[Y * w + X]; };
  const safe = (a, b) => { const steps = Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 0.4); for (let s = 1; s < steps; s++) { const t = s / steps, x = a[0] + (b[0] - a[0]) * t, y = a[1] + (b[1] - a[1]) * t; for (const [ox, oy] of [[-0.49, -0.49], [0.49, -0.49], [-0.49, 0.49], [0.49, 0.49]]) if (opaque(x + ox, y + oy)) return false; } return true; };
  const sagOf = (i, j) => { const a = loop[i], b = loop[j % n], L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1; let mx = 0; for (let k = i + 1; k < j; k++) { const p = loop[k % n]; mx = Math.max(mx, Math.abs((b[0] - a[0]) * (a[1] - p[1]) - (a[0] - p[0]) * (b[1] - a[1])) / L); } return mx; };
  let i = 0;
  while (i < n) {
    out.push(loop[i]);
    let best = i + 1;
    for (let j = Math.min(n, i + Math.ceil(maxChord * 2.5)); j > i + 1; j--) {
      if (j === n && out.length < 3) continue;
      const a = loop[i], b = loop[j % n];
      if (Math.hypot(b[0] - a[0], b[1] - a[1]) > maxChord) continue;
      if (sagOf(i, j) > sag) continue;
      if (!safe(a, b)) continue;
      best = j; break;
    }
    i = best;
  }
  return out;
}
const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
function earClip(poly) {
  const idx = poly.map((_, i) => i), tris = [];
  let area = 0; for (let i = 0; i < poly.length; i++) { const p = poly[i], q = poly[(i + 1) % poly.length]; area += p[0] * q[1] - q[0] * p[1]; }
  const ccw = area > 0;
  const inside = (p, a, b, c) => { const d1 = cross(a, b, p), d2 = cross(b, c, p), d3 = cross(c, a, p); return ccw ? d1 > 0 && d2 > 0 && d3 > 0 : d1 < 0 && d2 < 0 && d3 < 0; };
  let guard = 0;
  while (idx.length > 3 && guard++ < 10000) {
    let cut = false;
    for (let k = 0; k < idx.length; k++) {
      const i0 = idx[(k - 1 + idx.length) % idx.length], i1 = idx[k], i2 = idx[(k + 1) % idx.length];
      const c = cross(poly[i0], poly[i1], poly[i2]);
      if (ccw ? c <= 1e-9 : c >= -1e-9) continue;
      if (idx.some(j => j !== i0 && j !== i1 && j !== i2 && inside(poly[j], poly[i0], poly[i1], poly[i2]))) continue;
      tris.push(i0, i1, i2); idx.splice(k, 1); cut = true; break;
    }
    if (!cut) { const k = 1; tris.push(idx[0], idx[1], idx[2]); idx.splice(k, 1); }
  }
  if (idx.length === 3) tris.push(idx[0], idx[1], idx[2]);
  return tris;
}
function pointInPoly(p, poly) { let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const a = poly[i], b = poly[j]; if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c; } return c; }
function distToPoly(p, poly) { let d = Infinity; for (let i = 0; i < poly.length; i++) { const a = poly[i], b = poly[(i + 1) % poly.length], dx = b[0] - a[0], dy = b[1] - a[1], L2 = dx * dx + dy * dy, t = L2 ? Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2)) : 0; d = Math.min(d, Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)); } return d; }
function insertPoint(P, tris, p) {
  for (let t = 0; t < tris.length; t += 3) {
    const a = P[tris[t]], b = P[tris[t + 1]], c = P[tris[t + 2]];
    const d1 = cross(a, b, p), d2 = cross(b, c, p), d3 = cross(c, a, p);
    if ((d1 > 1e-6 && d2 > 1e-6 && d3 > 1e-6) || (d1 < -1e-6 && d2 < -1e-6 && d3 < -1e-6)) { const k = P.length; P.push(p); const [i, j, l] = [tris[t], tris[t + 1], tris[t + 2]]; tris.splice(t, 3, i, j, k, j, l, k, l, i, k); return true; }
  }
  return false;
}
const quality = (a, b, c) => { const ab = Math.hypot(b[0] - a[0], b[1] - a[1]), bc = Math.hypot(c[0] - b[0], c[1] - b[1]), ca = Math.hypot(a[0] - c[0], a[1] - c[1]), den = ab * ab + bc * bc + ca * ca; return den > 1e-9 ? 2 * Math.sqrt(3) * Math.abs(cross(a, b, c)) / den : 0; };
function flipEdges(P, tris) {
  for (let it = 0; it < P.length * 12; it++) {
    const em = new Map();
    for (let t = 0; t < tris.length; t += 3) for (let e = 0; e < 3; e++) { const a = tris[t + e], b = tris[t + (e + 1) % 3], o = tris[t + (e + 2) % 3], k = Math.min(a, b) + ':' + Math.max(a, b); (em.get(k) || em.set(k, []).get(k)).push({ t, o, a, b }); }
    let flipped = false;
    for (const [, refs] of em) {
      if (refs.length !== 2) continue;
      const { a, b } = refs[0], c = refs[0].o, d = refs[1].o;
      const segX = (p1, p2, p3, p4) => cross(p1, p2, p3) * cross(p1, p2, p4) < 0 && cross(p3, p4, p1) * cross(p3, p4, p2) < 0;
      if (!segX(P[a], P[b], P[c], P[d])) continue;
      if (em.has(Math.min(c, d) + ':' + Math.max(c, d))) continue;
      const oldQ = Math.min(quality(P[a], P[b], P[c]), quality(P[a], P[b], P[d])), newQ = Math.min(quality(P[c], P[d], P[a]), quality(P[c], P[d], P[b]));
      if (newQ <= oldQ + 0.0005) continue;
      tris.splice(refs[0].t, 3, c, d, a); tris.splice(refs[1].t, 3, d, c, b);
      flipped = true; break;
    }
    if (!flipped) break;
  }
  // consistent winding (same sign as the hull)
  return tris;
}
function buildMesh(img, Lname) {
  const w = img.w, h = img.h;
  const m = alphaMask(img);
  const comps = cleanSpecks(img, m);
  if (!comps.length) return null;
  let area = 0; for (let i = 0; i < m.length; i++) area += m[i];
  if (area < 24) return null;
  const d = bridge(dilate(m, w, h, 1), w, h);
  const loop = traceOuter(d, w, h);
  if (loop.length < 4) return null;
  // MintS fidelity policy: chord ≈ 1.8·√diagonal (14–64px), sagitta ≈ 0.11·√short side (2–4px)
  let x0 = w, y0 = h, x1 = 0, y1 = 0; for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (m[y * w + x]) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
  const vw = x1 - x0 + 1, vh = y1 - y0 + 1, diag = Math.hypot(vw, vh);
  const chord = Math.max(14, Math.min(64, Math.sqrt(diag) * 1.8)), sag = Math.max(2, Math.min(4, Math.sqrt(Math.min(vw, vh)) * 0.11));
  let hull = simplify(loop, m, w, h, chord, sag);
  if (hull.length < 3) return null;
  const P = hull.map(p => p.slice());
  const tris = earClip(P);
  // interior budget from visible area: 6 + √area/6, cap 34 (40 for limbs/torso/head/hair), small parts fewer
  const limbish = /(arm|hand|sleeve|thigh|calf|calves|shin|leg|foot|body|torso|neck|skirt|dress|cloth|cape|coat|face|head|hair|bang)/i.test(Lname);
  let target = Math.round(6 + Math.sqrt(area) / 6), cap = limbish ? 40 : 34;
  if (area < 120) cap = Math.min(cap, 6); else if (area < 320) cap = Math.min(cap, 9);
  target = Math.max(area >= 320 ? 8 : 3, Math.min(cap, target));
  // farthest-point sampling on a staggered lattice of opaque, interior candidates
  const spacing = Math.sqrt(area / Math.max(1, target * 0.866)), step = Math.max(1.25, Math.min(12, spacing / 4));
  const cand = [];
  for (let y = y0 + step * 0.37, r = 0; y <= y1 + 1; y += step, r++) for (let x = x0 + step * 0.29 + (r % 2 ? step / 2 : 0); x <= x1 + 1; x += step) {
    const X = Math.floor(x), Y = Math.floor(y);
    if (X < 0 || Y < 0 || X >= w || Y >= h || !m[Y * w + X] || !pointInPoly([x, y], hull)) continue;
    const bd = distToPoly([x, y], hull);
    if (bd < 0.75) continue;
    cand.push({ p: [x, y], bd, near: Infinity });
  }
  for (const c of cand) for (const q of P) c.near = Math.min(c.near, Math.hypot(c.p[0] - q[0], c.p[1] - q[1]));
  let added = 0;
  while (added < target) {
    let best = null, score = -Infinity;
    for (const c of cand) { if (c.used) continue; const s = Math.min(c.near, c.bd * 1.4); if (s > score) { score = s; best = c; } }
    if (!best || score <= 0.5) break;
    best.used = true;
    if (insertPoint(P, tris, best.p)) { added++; for (const c of cand) if (!c.used) c.near = Math.min(c.near, Math.hypot(c.p[0] - best.p[0], c.p[1] - best.p[1])); }
  }
  flipEdges(P, tris);
  // winding: make every triangle the same orientation as the hull
  let ha = 0; for (let i = 0; i < hull.length; i++) { const p = hull[i], q = hull[(i + 1) % hull.length]; ha += p[0] * q[1] - q[0] * p[1]; }
  for (let t = 0; t < tris.length; t += 3) if (Math.sign(cross(P[tris[t]], P[tris[t + 1]], P[tris[t + 2]])) !== Math.sign(ha)) { const k = tris[t + 1]; tris[t + 1] = tris[t + 2]; tris[t + 2] = k; }
  return { P, tris, hull: hull.length, area, interior: added };
}

// ---------------- weights (smoothstep across the joint) ----------------
const smooth = (e0, e1, v) => { const t = Math.max(0, Math.min(1, (v - e0) / (e1 - e0))); return t * t * (3 - 2 * t); };
function influences(x, y, chain) {
  const cands = chain.map(n => B.get(n)).filter(b => b && b.name !== 'root');
  if (cands.length <= 1) return [[cands[0] || B.get('root'), 1]];
  const ds = cands.map(b => ({ b, d: segDist(x, y, b) })).sort((p, q) => p.d - q.d);
  const prim = ds[0].b, sec = ds.slice(1).find(o => o.b.parent === prim.name || prim.parent === o.b.name);
  if (!sec) return [[prim, 1]];
  const parent = sec.b.parent === prim.name ? prim : sec.b, child = parent === prim ? sec.b : prim;
  const ax = child.tipX - parent.wx, ay = child.tipY - parent.wy, L = Math.hypot(ax, ay);
  if (L < 0.5) return [[prim, 1]];
  const signed = ((x - child.wx) * ax + (y - child.wy) * ay) / L;
  const radius = Math.max(6, Math.min(28, Math.min(Math.max(1, parent.length), child.length || parent.length) * 0.1));
  if (signed <= -radius) return [[parent, 1]];
  if (signed >= radius) return [[child, 1]];
  const wc = smooth(-radius, radius, signed);
  if (Math.min(wc, 1 - wc) < 0.035) return [[wc > 0.5 ? child : parent, 1]];
  return [[parent, 1 - wc], [child, wc]].sort((p, q) => boneIndex.get(p[0].name) - boneIndex.get(q[0].name));
}

// ---------------- assemble ----------------
const slots = [], atts = {}, report = [], atlasPages = [];
let meshCount = 0, weightedCount = 0, vertSum = 0;
const items = LAYERS.map(L => {
  const img = R.decodePNG(fs.readFileSync(path.resolve(layerDir, L.png)));
  const cs = toSpine({ x: L.left + img.w / 2, y: L.top + img.h / 2 });
  let bind = bindLayer(L);
  if (!bind) { // nearest torso / head bone segment, no weights
    let best = null;
    for (const n of AXIAL) { const b = B.get(n); if (!b) continue; const d = segDist(cs.x, cs.y, b); if (!best || d < best.d) best = { b, d }; }
    bind = { bone: best ? best.b.name : 'root', weightable: false, nearest: true };
  }
  return { L, img, cs, bind };
});
imageBones = new Set(items.filter(it => it.bind.weightable).map(it => it.bind.bone));
for (const { L, img, cs, bind } of items) {
  const name = L.name;
  const boneName = bind.bone;
  const bone = B.get(boneName);
  const attName = name, pathName = String(L.path || path.basename(L.png).replace(/\.png$/i, ''));
  slots.push({ name, bone: boneName, attachment: attName });
  atlasPages.push(`\n${path.relative(path.dirname(path.resolve(outFile)), path.resolve(layerDir, L.png)).replace(/\\/g, '/')}\nsize: ${img.w},${img.h}\nformat: RGBA8888\nfilter: Linear,Linear\nrepeat: none\n${pathName}\n  rotate: false\n  xy: 0, 0\n  size: ${img.w}, ${img.h}\n  orig: ${img.w}, ${img.h}\n  offset: 0, 0\n  index: -1\n`);
  const chain = opt.weights === 'on' && bind.weightable ? weightChain(boneName) : [boneName];
  const wantMesh = opt.mesh === 'all' || (opt.mesh === 'weighted' && chain.length > 1);
  const mesh = wantMesh ? buildMesh(img, name) : null;
  if (!mesh) {
    const [lx, ly] = toLocal(bone, cs.x, cs.y);
    atts[name] = { [attName]: { path: pathName, x: +lx.toFixed(2), y: +ly.toFixed(2), rotation: +(-bone.wr).toFixed(2), width: img.w, height: img.h } };
    report.push(`${name} → ${boneName}${bind.nearest ? ' (nearest)' : ''} region`);
    continue;
  }
  const uvs = [], verts = [];
  let weighted = false;
  for (const [px, py] of mesh.P) {
    uvs.push(+(px / img.w).toFixed(6), +(py / img.h).toFixed(6));
    const ws = toSpine({ x: L.left + px, y: L.top + py });
    const inf = chain.length > 1 ? influences(ws.x, ws.y, chain) : [[bone, 1]];
    if (chain.length > 1) { weighted = true; verts.push(inf.length); for (const [b, wgt] of inf) { const [lx, ly] = toLocal(b, ws.x, ws.y); verts.push(boneIndex.get(b.name), +lx.toFixed(3), +ly.toFixed(3), +wgt.toFixed(4)); } }
    else { const [lx, ly] = toLocal(bone, ws.x, ws.y); verts.push(+lx.toFixed(3), +ly.toFixed(3)); }
  }
  const edges = []; for (let i = 0; i < mesh.hull; i++) edges.push(i * 2, ((i + 1) % mesh.hull) * 2);
  atts[name] = { [attName]: { type: 'mesh', path: pathName, uvs, triangles: mesh.tris, vertices: verts, hull: mesh.hull, edges, width: img.w, height: img.h } };
  meshCount++; if (weighted) weightedCount++; vertSum += mesh.P.length;
  report.push(`${name} → ${boneName}${bind.nearest ? ' (nearest)' : ''} mesh ${mesh.P.length}v (${mesh.hull} hull + ${mesh.interior} interior) ${mesh.tris.length / 3} tris${weighted ? ' weights ' + chain.join('>') : ''}`);
}
// Build the common rig in 3.8, then serialize using the selected version profile. Changing the
// version tag alone would leave incompatible skins/constraint/attachment fields behind.
let out = {
  skeleton: { spine: '3.8.99', x: -root.x, y: root.y - H, width: W, height: H, images: opt.images },
  bones: bones.map(b => { const o = { name: b.name }; if (b.parent) o.parent = b.parent; if (b.length) o.length = +b.length.toFixed(2); if (b.parent) { o.x = +b.x.toFixed(2); o.y = +b.y.toFixed(2); } if (Math.abs(b.rotation) > 1e-6) o.rotation = +b.rotation.toFixed(3); return o; }),
  slots,
  skins: [{ name: 'default', attachments: atts }],
  animations: {},
};
try { out = V.convertVersion(out, opt.spine); } catch (err) { console.error(`Spine version: ${err.message}`); process.exit(3); }
// preview atlas: one page per layer PNG (for spine_render / lint; Spine's editor imports the images folder itself)
fs.mkdirSync(path.dirname(path.resolve(outFile)), { recursive: true });
fs.writeFileSync(outFile.replace(/\.json$/i, '') + '.atlas', atlasPages.join('').replace(/^\n/, ''));
fs.writeFileSync(outFile, JSON.stringify(out, null, 1));
const torso = ['body', 'waist', 'neck'].filter(n => B.has(n)).map(n => `${n} ${B.get(n).wr.toFixed(0)}°`).join(', ');
const points = bones.filter(b => POINT_BONES.test(b.name)).map(b => b.name);
console.log(`wrote ${outFile}: Spine ${out.skeleton.spine}, ${bones.length} bones, ${slots.length} slots, ${meshCount} meshes (${weightedCount} weighted, ${meshCount ? (vertSum / meshCount).toFixed(1) : 0} verts avg)`);
console.log(`torso bones point up the body (world angle, 90° = up): ${torso || '-'}; face feature points (length 0): ${points.join(', ') || '-'}`);
console.log(report.map(r => '- ' + r).join('\n'));
