// spine_core.js — shared, dependency-free helpers for Spine JSON (3.7–4.3).
// Normalises version differences so analysis / lint / generator scripts can share one model.
'use strict';
const fs = require('fs');
const path = require('path');

const FPS_DEFAULT = 30;

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^﻿/, ''));
}

// Accept a .json file or a directory containing one.
function resolveJson(p) {
  const st = fs.statSync(p);
  if (st.isFile()) return p;
  const f = fs.readdirSync(p).find(n => n.toLowerCase().endsWith('.json') && !n.toLowerCase().endsWith('.atlas.json'));
  if (!f) throw new Error(`no .json in ${p}`);
  return path.join(p, f);
}

function versionOf(j) {
  const v = String((j.skeleton && j.skeleton.spine) || '3.8');
  const m = /^(\d+)\.(\d+)(?:[.-]|$)/.exec(v);
  if (!m) throw new Error(`invalid skeleton.spine version: ${v}`);
  const major = +m[1], minor = +m[2];
  return { raw: v, major, minor, is4: major >= 4, is37: major === 3 && minor === 7,
    supported: major === 3 && (minor === 7 || minor === 8) || major === 4 && minor <= 3 };
}

// Legacy boolean callers remain accepted. An actual version is required to distinguish
// 3.7 normalised arrays from 4.x absolute arrays (the shapes overlap).
function curveVersion(v) {
  if (typeof v === 'boolean') return { is4: v, is37: false };
  if (typeof v === 'string') return versionOf({ skeleton: { spine: v } });
  if (v && v.major !== undefined && v.minor !== undefined) return Object.assign({}, v, { is4: v.major >= 4, is37: v.major === 3 && v.minor === 7 });
  return v || { is4: true, is37: false };
}

function constraintsOf(j, type) {
  if (Array.isArray(j.constraints)) return j.constraints.filter(c => c.type === type);
  return j[type] || [];
}

function skinsOf(j) {
  if (Array.isArray(j.skins)) return j.skins.map(s => ({ name: s.name, attachments: s.attachments || {} }));
  return Object.entries(j.skins || {}).map(([name, attachments]) => ({ name, attachments }));
}

// ---------- skeleton model ----------
function buildModel(j) {
  const version = versionOf(j);
  if (!version.supported) throw new Error(`unsupported Spine schema ${version.raw}; supported versions: 3.7, 3.8, 4.0–4.3`);
  const bones = j.bones || [];
  const byName = new Map(bones.map((b, i) => [b.name, Object.assign({ index: i }, b)]));
  const kids = new Map(bones.map(b => [b.name, []]));
  for (const b of bones) if (b.parent) kids.get(b.parent).push(b.name);
  const slots = j.slots || [];
  const slotByName = new Map(slots.map((s, i) => [s.name, Object.assign({ index: i }, s)]));
  const boneSlots = new Map(); // bone -> Set(slot | slot/attachment for weighted meshes)
  const add = (b, s) => { if (!boneSlots.has(b)) boneSlots.set(b, new Set()); boneSlots.get(b).add(s); };
  for (const s of slots) add(s.bone, s.name);
  const meshes = [];
  const skins = skinsOf(j);
  const sourceMesh = (a, slot, seen = new Set()) => {
    const name = a.source || a.parent;
    if (!name) return a;
    const key = `${a.skin || 'default'}/${a.slot || slot}/${name}`;
    if (seen.has(key)) throw new Error(`linked mesh cycle: ${key}`);
    seen.add(key);
    const sk = skins.find(s => s.name === (a.skin || 'default'));
    const src = sk && (sk.attachments[a.slot || slot] || {})[name];
    if (!src) throw new Error(`linked mesh source not found: ${key}`);
    return sourceMesh(src, a.slot || slot, seen);
  };
  for (const sk of skins) for (const [slot, atts] of Object.entries(sk.attachments)) for (const [an, a] of Object.entries(atts)) {
    if (a.type !== 'mesh' && a.type !== 'linkedmesh') continue;
    const geometry = sourceMesh(a, slot);
    const n = geometry.uvs ? geometry.uvs.length / 2 : 0;
    const weighted = geometry.vertices && geometry.uvs && geometry.vertices.length !== geometry.uvs.length;
    const infl = new Set();
    if (weighted) { const v = geometry.vertices; for (let i = 0; i < v.length;) { const c = v[i++]; for (let k = 0; k < c; k++, i += 4) infl.add(bones[v[i]].name); } }
    for (const b of infl) add(b, `${slot}/${an}`);
    meshes.push({ skin: sk.name, slot, name: an, verts: n, weighted, bones: [...infl] });
  }
  const depth = name => { let d = 0, b = byName.get(name); while (b && b.parent) { d++; b = byName.get(b.parent); } return d; };
  const ancestors = name => { const out = []; let b = byName.get(name); while (b && b.parent) { out.push(b.parent); b = byName.get(b.parent); } return out; };
  return { j, bones, byName, kids, slots, slotByName, boneSlots, meshes, depth, ancestors, version };
}

// Maximal single-child bone chains (>= minLen bones). Typical for hair / cloth / tails / smoke ribbons.
function chainsOf(m, minLen = 3) {
  const out = [];
  for (const b of m.bones) {
    const p = b.parent && m.byName.get(b.parent);
    if (p && m.kids.get(p.name).length === 1 && p.parent) continue;
    const c = [b.name];
    let cur = b.name;
    while (m.kids.get(cur).length === 1) { cur = m.kids.get(cur)[0]; c.push(cur); }
    if (c.length >= minLen) out.push(c);
  }
  return out;
}

// ---------- curves ----------
// Unified per-segment curve: {type:'linear'|'stepped'|'bezier', cx1,cy1,cx2,cy2 normalised 0..1}
// 3.8: key.curve = 'stepped' | number(c1) with c2,c3,c4 (normalised).
// 4.x: key.curve = 'stepped' | [cx1,cy1,cx2,cy2, ...per channel] in ABSOLUTE time/value units.
function segCurve(k0, k1, channel, v0, v1, version) {
  const c = k0.curve;
  if (c === undefined) return { type: 'linear' };
  if (c === 'stepped') return { type: 'stepped' };
  if (typeof c === 'number') return { type: 'bezier', cx1: c, cy1: k0.c2 === undefined ? 0 : k0.c2, cx2: k0.c3 === undefined ? 1 : k0.c3, cy2: k0.c4 === undefined ? 1 : k0.c4 };
  if (Array.isArray(c)) {
    const ver = curveVersion(version);
    if (ver.is37 || !ver.is4) return { type: 'bezier', cx1: c[0], cy1: c[1], cx2: c[2], cy2: c[3] };
    const o = (channel || 0) * 4;
    if (c.length < o + 4) return { type: 'linear' };
    const t0 = k0.time || 0, t1 = k1 ? (k1.time || 0) : t0;
    const dt = t1 - t0 || 1, dv = (v1 - v0) || 0;
    const nx = x => (x - t0) / dt;
    // Absolute handles may overshoot even when the endpoint values are identical.
    // Keep them in value units in that case rather than discarding the animation.
    if (Math.abs(dv) < 1e-9 && (Math.abs(c[o + 1] - v0) > 1e-9 || Math.abs(c[o + 3] - v0) > 1e-9))
      return { type: 'bezier', cx1: nx(c[o]), cy1: c[o + 1], cx2: nx(c[o + 2]), cy2: c[o + 3], absolute: true, v0, v1 };
    const ny = y => (Math.abs(dv) < 1e-9 ? 0 : (y - v0) / dv);
    return { type: 'bezier', cx1: nx(c[o]), cy1: ny(c[o + 1]), cx2: nx(c[o + 2]), cy2: ny(c[o + 3]) };
  }
  return { type: 'linear' };
}
function bezierY(cv, t) {
  if (cv.type === 'linear') return t;
  if (cv.type === 'stepped') return 0;
  const { cx1: x1, cy1: y1, cx2: x2, cy2: y2 } = cv;
  let lo = 0, hi = 1, s = t;
  for (let i = 0; i < 30; i++) {
    s = (lo + hi) / 2;
    const x = 3 * (1 - s) * (1 - s) * s * x1 + 3 * (1 - s) * s * s * x2 + s * s * s;
    if (x < t) lo = s; else hi = s;
  }
  return (cv.absolute ? (1 - s) ** 3 * cv.v0 : 0) + 3 * (1 - s) * (1 - s) * s * y1 + 3 * (1 - s) * s * s * y2 + s * s * s * (cv.absolute ? cv.v1 : 1);
}
function curveClass(cv) {
  if (cv.type !== 'bezier') return cv.type;
  const { cx1, cy1, cx2, cy2 } = cv;
  if (Math.abs(cx1 - cy1) < 0.03 && Math.abs(cx2 - cy2) < 0.03) return 'linear~';
  const easeIn = cx1 > 0.05 && cy1 < cx1 * 0.6, easeOut = cx2 < 0.95 && cy2 > cx2 + (1 - cx2) * 0.4;
  if (easeIn && easeOut) return 'easeInOut';
  if (easeIn) return 'easeIn';
  if (easeOut) return 'easeOut';
  return 'custom';
}
const curveLabel = cv => cv.type !== 'bezier' ? cv.type : `bz(${[cv.cx1, cv.cy1, cv.cx2, cv.cy2].map(x => Math.round(x * 100) / 100).join(',')})`;

// ---------- timelines → unified channel keys ----------
// Returns { kind:'rotate'|'translate'|'scale'|'shear', channels:{name:[{t,v,cv}]}}
const T = k => (typeof k.time === 'number' ? k.time : 0);
function channelsOfBoneTimeline(type, keys, version) {
  const ver = curveVersion(version), is4 = ver.is4;
  const def = type === 'scale' ? 1 : 0;
  const mk = (getter, channel) => keys.map((k, i) => {
    const v = getter(k), nk = keys[i + 1];
    return { t: T(k), v, cv: nk ? segCurve(k, nk, channel, v, getter(nk), ver) : { type: 'linear' } };
  });
  if (type === 'rotate') return { kind: 'rotate', channels: { r: mk(k => (k.value !== undefined ? k.value : (k.angle !== undefined ? k.angle : 0)), 0) } };
  // 4.x split timelines translatex/translatey/scalex/... use `value`
  if (/^(translate|scale|shear)[xy]$/i.test(type)) {
    const base = type.slice(0, -1).toLowerCase(), ax = type.slice(-1).toLowerCase();
    return { kind: base, channels: { [ax]: mk(k => (k.value !== undefined ? k.value : (base === 'scale' ? 1 : 0)), 0) } };
  }
  if (type === 'translate' || type === 'scale' || type === 'shear') {
    return { kind: type, channels: { x: mk(k => (k.x !== undefined ? k.x : def), 0), y: mk(k => (k.y !== undefined ? k.y : def), is4 ? 1 : 0) } };
  }
  return null;
}
function evalChannel(keys, time) {
  if (!keys.length) return 0;
  if (time <= keys[0].t) return keys[0].v;
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (time >= a.t && time <= b.t) {
      if (b.t - a.t < 1e-9) return b.v;
      const y = bezierY(a.cv, (time - a.t) / (b.t - a.t));
      return a.cv.absolute ? y : a.v + (b.v - a.v) * y;
    }
  }
  return keys[keys.length - 1].v;
}
function sampleChannel(keys, dur, fps = FPS_DEFAULT) {
  const n = Math.max(1, Math.round(dur * fps));
  const out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = evalChannel(keys, i / fps);
  return out;
}

// Deform timelines across versions: 3.8/4.0 anim.deform[skin][slot][att] = keys;
// 4.1+ anim.attachments[skin][slot][att].deform = keys. Returns [{skin, slot, att, keys}].
function deformTimelines(anim) {
  const out = [];
  for (const [skin, sl] of Object.entries(anim.deform || {})) for (const [slot, atts] of Object.entries(sl)) for (const [att, keys] of Object.entries(atts)) out.push({ skin, slot, att, keys });
  for (const [skin, sl] of Object.entries(anim.attachments || {})) for (const [slot, atts] of Object.entries(sl)) for (const [att, tls] of Object.entries(atts)) if (tls && tls.deform) out.push({ skin, slot, att, keys: tls.deform });
  return out;
}
// 4.x deform curves: [cx1(abs time), cy1(0..1), cx2(abs time), cy2(0..1)]
function deformCurve(k, nk, version) {
  const c = k.curve;
  if (c === undefined) return { type: 'linear' };
  if (c === 'stepped') return { type: 'stepped' };
  if (typeof c === 'number') return { type: 'bezier', cx1: c, cy1: k.c2 === undefined ? 0 : k.c2, cx2: k.c3 === undefined ? 1 : k.c3, cy2: k.c4 === undefined ? 1 : k.c4 };
  if (Array.isArray(c) && nk) { const ver = curveVersion(version); if (ver.is37 || !ver.is4) return { type: 'bezier', cx1: c[0], cy1: c[1], cx2: c[2], cy2: c[3] }; const t0 = T(k), dt = (T(nk) - t0) || 1; return { type: 'bezier', cx1: (c[0] - t0) / dt, cy1: c[1], cx2: (c[2] - t0) / dt, cy2: c[3] }; }
  return { type: 'linear' };
}

function animDuration(anim) {
  let max = 0;
  const walk = o => {
    if (Array.isArray(o)) { for (const k of o) if (k && typeof k === 'object') { if (typeof k.time === 'number' && k.time > max) max = k.time; walk(k); } }
    else if (o && typeof o === 'object') for (const v of Object.values(o)) walk(v);
  };
  walk(anim);
  return max;
}

// ---------- signal helpers ----------
const ptp = a => (a.length ? Math.max(...a) - Math.min(...a) : 0);
function bestLag(a, b, maxLag) {
  const n = a.length;
  const ma = a.reduce((s, x) => s + x, 0) / n, mb = b.reduce((s, x) => s + x, 0) / n;
  const A = a.map(x => x - ma), B = b.map(x => x - mb);
  const na = Math.sqrt(A.reduce((s, x) => s + x * x, 0)), nb = Math.sqrt(B.reduce((s, x) => s + x * x, 0));
  if (na < 1e-6 || nb < 1e-6) return null;
  let best = -2, lag = 0;
  for (let L = -maxLag; L <= maxLag; L++) {
    let s = 0;
    for (let i = 0; i < n; i++) s += A[i] * B[(i + L + n) % n];
    const c = s / (na * nb);
    if (c > best) { best = c; lag = L; }
  }
  return { lag, corr: best };
}
function period(a) {
  const n = a.length;
  const m = a.reduce((s, x) => s + x, 0) / n, A = a.map(x => x - m);
  const e = A.reduce((s, x) => s + x * x, 0);
  if (e < 1e-9) return null;
  for (let k = 8; k >= 1; k--) {
    if (n % k) continue;
    const p = n / k;
    let s = 0;
    for (let i = 0; i < n; i++) s += A[i] * A[(i + p) % n];
    if (s / e > 0.97) return p;
  }
  return n;
}
// Is anything drawn by `bone` (its slots, descendants' slots, meshes weighted to them) visible at
// the loop seam (t=0 or t=dur)? One-way particles that respawn while invisible are a valid pattern.
function visibleAtSeam(m, anim, bone, dur) {
  const desc = new Set([bone]);
  for (let grew = true; grew;) { grew = false; for (const b of m.bones) if (b.parent && desc.has(b.parent) && !desc.has(b.name)) { desc.add(b.name); grew = true; } }
  const slots = new Set();
  for (const b of desc) for (const s of m.boneSlots.get(b) || []) slots.add(s.split('/')[0]);
  if (!slots.size) return false;
  for (const sn of slots) {
    const tl = (anim.slots || {})[sn] || {};
    const setup = m.slotByName.get(sn) || {};
    const ctl = tl.color || tl.rgba;
    const A = c => parseInt((c || 'ffffffff').slice(6, 8) || 'ff', 16) / 255;
    const alphaAt = t => {
      if (tl.alpha && tl.alpha.length) {
        const v = k => (k.value === undefined ? 1 : k.value);
        const ks = tl.alpha.map((k, i) => ({ t: T(k), v: v(k), cv: tl.alpha[i + 1] ? segCurve(k, tl.alpha[i + 1], 0, v(k), v(tl.alpha[i + 1]), m.version) : { type: 'linear' } }));
        return evalChannel(ks, t);
      }
      if (ctl && ctl.length) {
        const ch = m.version.is4 ? 3 : 0; // 4.x rgba alpha is channel 3; 3.7 curves share channel 0.
        const ks = ctl.map((k, i) => ({ t: T(k), v: A(k.color), cv: ctl[i + 1] ? segCurve(k, ctl[i + 1], ch, A(k.color), A(ctl[i + 1].color), m.version) : { type: 'linear' } }));
        return evalChannel(ks, t);
      }
      return A(setup.color);
    };
    const attAt = t => {
      if (!tl.attachment || !tl.attachment.length) return setup.attachment || null;
      let cur = setup.attachment || null;
      for (const k of tl.attachment) if (T(k) <= t + 1e-6) cur = k.name;
      return cur;
    };
    for (const t of [0, dur]) if (alphaAt(t) > 0.05 && attAt(t)) return true;
  }
  return false;
}

const quantile = (arr, p) => { if (!arr.length) return null; const s = arr.slice().sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
const r2 = x => Math.round(x * 100) / 100;

module.exports = {
  FPS_DEFAULT, readJson, resolveJson, versionOf, skinsOf, constraintsOf, buildModel, chainsOf,
  segCurve, bezierY, curveClass, curveLabel, channelsOfBoneTimeline, evalChannel, sampleChannel,
  animDuration, ptp, bestLag, period, quantile, r2, T, visibleAtSeam, deformTimelines, deformCurve,
};
