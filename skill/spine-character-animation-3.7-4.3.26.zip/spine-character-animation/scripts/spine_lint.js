#!/usr/bin/env node
// spine_lint.js — check a Spine JSON (3.8 / 4.x) against the character-animation rules of this skill.
// Prints PASS / WARN / FAIL lines with fix hints; exit code 1 if any FAIL.
//
// Usage: node spine_lint.js <file.json|dir> [--anim NAME] [--fps 30] [--strict] [--kind auto|character|fx]
//   --kind fx (or auto-detected: effects / props / scenery with no body) skips the body rules
//   R04 A11 A12 A13 — a smoke puff or a sandcastle has no torso to breathe with.
'use strict';
const C = require('./spine_core');
const R = require('./spine_render');
const { analyseAnim, spinePath } = require('./spine_inspect');

const args = process.argv.slice(2);
const opt = { fps: 30, strict: false, kind: 'auto' };
const rest = [];
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--anim') opt.anim = args[++i];
  else if (args[i] === '--fps') opt.fps = +args[++i];
  else if (args[i] === '--strict') opt.strict = true;
  else if (args[i] === '--kind') opt.kind = args[++i];
  else rest.push(args[i]);
}
if (!rest[0]) { console.error('usage: node spine_lint.js <file.json|dir> [--anim NAME] [--fps 30] [--strict] [--kind auto|character|fx]'); process.exit(2); }

const file = C.resolveJson(rest[0]);
const j = C.readJson(file);
const m = C.buildModel(j);
const out = [];
let fails = 0, warns = 0;
const PASS = (id, msg) => out.push(`PASS  [${id}] ${msg}`);
const WARN = (id, msg, fix) => { warns++; out.push(`WARN  [${id}] ${msg}${fix ? '\n        fix: ' + fix : ''}`); };
const FAIL = (id, msg, fix) => { fails++; out.push(`FAIL  [${id}] ${msg}${fix ? '\n        fix: ' + fix : ''}`); };

// ---------------- rig rules ----------------
const root = m.bones.find(b => !b.parent);
const sp = spinePath(m);
const rootKids = m.kids.get(root.name);
// character vs effect/prop/scenery skeleton
const FX_NAME = /^(fx|vfx|scenery|scene|bg|prop|env|effect|particle)[_-]/i;
const BODY_NAME = /(head|tou|toubu|lian|face|neck|bozi|spine|yao|xiong|chest|torso|shenti|qugan|hip|kua|pelvis|arm|bi|leg|tui|hand|shou|foot|jiao|hair|toufa)/i;
const fxShare = m.bones.filter(b => FX_NAME.test(b.name)).length / Math.max(1, m.bones.length - 1);
const hasBodyName = m.bones.some(b => BODY_NAME.test(b.name));
// conservative: generic names (bone12…) are common in real characters, so "no body names" alone is not enough
const autoFx = fxShare > 0.5 || (m.bones.length <= 20 && !hasBodyName && sp.path.length < 3);
const kind = opt.kind !== 'auto' ? opt.kind : (autoFx ? 'fx' : 'character');
const isChar = kind === 'character';
if (!isChar) out.push(`INFO  skeleton treated as "${kind}" (effect / prop / scenery: ${Math.round(fxShare * 100)}% fx_/prop_/scenery_ named bones); body rules R04 A11 A12 A13 skipped — pass --kind character to force them, or name effect bones fx_* so groups are detected`);
if (m.bones.filter(b => !b.parent).length !== 1) FAIL('R01', 'skeleton must have exactly one root bone');
else PASS('R01', `single root "${root.name}"`);

const rootAnimated = Object.values(j.animations || {}).some(a => a.bones && a.bones[root.name]);
if (rootAnimated) WARN('R02', 'root bone is animated', 'keep root static (game code moves/flips the skeleton through root); animate a master/hip bone instead');
else PASS('R02', 'root is not animated');

if (!sp.path.length) WARN('R03', 'no clear body hierarchy under root');
else {
  const first = sp.path[0];
  const firstKids = m.kids.get(first).length;
  PASS('R03', `body path ${sp.path.join(' > ')}`);
  if (isChar && sp.path.length < 3) WARN('R04', `body path only ${sp.path.length} bones deep`, 'use root > master/hip > torso(2-3 segments) > neck > head so breathing can propagate');
  if (firstKids === 0) WARN('R05', `master bone "${first}" has no children`);
}

const generic = m.bones.filter(b => /^(bone|骨骼)?_?\d+$|_spine_?\d+[a-z]?$|^bone\d*$/i.test(b.name));
const gShare = generic.length / m.bones.length;
if (gShare > 0.5) WARN('R06', `${Math.round(gShare * 100)}% of bones have generic names (e.g. ${generic.slice(0, 3).map(b => b.name).join(', ')})`, 'rename by part + side + index, e.g. hair_back_L_01, arm_upper_R; see references/08-naming-glossary.md');
else PASS('R06', `semantic naming (${Math.round((1 - gShare) * 100)}% named)`);

const noLen = m.bones.filter(b => b.parent && !b.length && m.kids.get(b.name).length > 0 && !/(target|ik|ctrl|control|zong|all|root|master|center|zhixin)/i.test(b.name));
if (noLen.length > m.bones.length * 0.3) WARN('R07', `${noLen.length} parent bones have zero length`, 'give limb/chain bones a length pointing to the child joint; zero-length is fine only for controls/IK targets/pivots');

// IK: a foot/leg target must not inherit body motion. "Static" = no ancestor (except root) is animated.
const animatedBones = new Set(Object.values(j.animations || {}).flatMap(a => Object.keys(a.bones || {})));
for (const c of C.constraintsOf(j, 'ik')) {
  const t = m.byName.get(c.target);
  const bones = c.bones.map(n => m.byName.get(n));
  const isLeg = c.bones.some(n => /(tui|leg|thigh|shin|jiao|foot|calf)/i.test(n));
  const movingAncestor = m.ancestors(c.target).find(a => a !== root.name && animatedBones.has(a));
  if (isLeg && movingAncestor) WARN('R08', `leg IK "${c.name}" target "${c.target}" inherits motion from animated "${movingAncestor}"`, 'parent foot IK targets to root or a static ground bone so feet stay planted while the body bobs (78% of reference foot targets move <2px)');
  if (bones.some(b => b && m.ancestors(c.target).includes(b.name))) FAIL('R09', `IK "${c.name}" target is a descendant of its own constrained bones`, 'move the target out of the chain');
}
if (C.constraintsOf(j, 'ik').length) PASS('R08', `${C.constraintsOf(j, 'ik').length} IK constraints checked`);

// chain sanity: hair/cloth chains with >1 segment and non-zero lengths
const chains = C.chainsOf(m, 3);
const bad = chains.filter(c => c.some(n => !m.byName.get(n).length));
if (bad.length > chains.length * 0.5 && chains.length) WARN('R10', `${bad.length}/${chains.length} chains contain zero-length bones`, 'chain bones should have length ≈ segment length so rotation pivots sit at the joint');

// R14 torso built bottom-up: below the head, each torso bone with length whose next body-path bone sits above it
// must point at that bone (bone X axis within 30°). A torso bone pointing DOWN while its child is above means
// the chain was built top-down — rotation pivots sit at the wrong end and breathing bends the body backwards.
// Corpus: 209 skeletons with measurable torso segments, 0 with a majority pointing down, 5 with any.
// R15 face features as points: eye / brow / mouth / nose / pupil / lash leaf bones are pivots (zero length,
// parent head) — a length suggests a mis-built chain. Corpus: 83 of 119 such bones are points (70%). Info only.
if (isChar && sp.path.length >= 3) {
  const skR = R.buildSkeleton(JSON.parse(JSON.stringify(j))); R.pose(skR, null, 0, true);
  const pathN = [sp.root, ...sp.path];
  const headIdx = pathN.findIndex(x => /(head|tou(?!fa)|toubu|lian)/i.test(x));
  const end = headIdx > 0 ? headIdx : pathN.length - 1;
  const segs = [];
  for (let i = 1; i < end; i++) {
    const b = skR.boneByName.get(pathN[i]), nx = skR.boneByName.get(pathN[i + 1]);
    if (!(b.data.length > 0)) continue;
    const dx = nx.worldX - b.worldX, dy = nx.worldY - b.worldY;
    if (Math.hypot(dx, dy) < 3 || dy < Math.abs(dx) * 0.5) continue;
    const d = Math.abs(((Math.atan2(b.c, b.a) - Math.atan2(dy, dx)) * 180 / Math.PI % 360 + 540) % 360 - 180);
    // "down" = away from the child above AND the bone itself points down the body (world Y component < −0.5);
    // a sideways bone (footage/038 bone2: −1°) is an odd rig, not a top-down torso
    segs.push({ n: b.name, d, down: d >= 120 && b.c / Math.hypot(b.a, b.c) < -0.5 });
  }
  const down = segs.filter(s => s.down);
  if (down.length && down.length * 2 > segs.length) WARN('R14', `torso bones point DOWN the body: ${down.map(s => `${s.n} (${s.d.toFixed(0)}° from its child)`).join(', ')}`, 'build the torso from the pelvis UP: each torso bone starts at its own joint and points at the next one above (body → waist → neck → head), length = distance; see references/01-rigging.md §2.1');
  else if (segs.length) PASS('R14', `torso built bottom-up (${segs.filter(s => s.d <= 30).length}/${segs.length} segments point at the bone above)`);
  const faceRe = /(^|_)(eye|yan|brow|mei|mouth|zui|nose|bizi|pupil|tongkong|iris|lash|jiemao|lid|yanpi)(?!.*(hair|fa))/i;
  const faceLeaf = skR.bones.filter(b => faceRe.test(b.name) && !b.children.length);
  const withLen = faceLeaf.filter(b => (b.data.length || 0) > 0);
  if (faceLeaf.length && withLen.length) out.push(`INFO  [R15] ${withLen.length}/${faceLeaf.length} face-feature bones have a length (${withLen.slice(0, 3).map(b => `${b.name} ${(+b.data.length).toFixed(0)}px`).join(', ')}) — features are usually points (length 0) parented to head`);
  else if (faceLeaf.length) PASS('R15', `${faceLeaf.length} face-feature bones are points`);
}

// mesh weights
// reference corpus: bones per weighted mesh median 2, p95 7, p99 12
const heavy = m.meshes.filter(x => x.weighted && x.bones.length > 12);
if (heavy.length) WARN('R11', `${heavy.length} weighted meshes influenced by >12 bones (e.g. ${heavy.slice(0, 2).map(x => `${x.slot}/${x.name}:${x.bones.length}`).join(', ')})`, 'typical mesh uses 2–7 bones; >12 is costly and hard to weight — split long hair/cloth meshes per strand/panel');
let maxPerVertex = 0;
for (const sk of C.skinsOf(j)) for (const atts of Object.values(sk.attachments)) for (const a of Object.values(atts)) {
  if (a.type !== 'mesh' || !a.uvs || a.vertices.length === a.uvs.length) continue;
  for (let i = 0; i < a.vertices.length;) { const n = a.vertices[i]; if (n > maxPerVertex) maxPerVertex = n; i += 1 + n * 4; }
}
// Spine has no hard per-vertex limit; >4 is common in the reference set (96% of projects) — only flag extremes.
if (maxPerVertex > 8) WARN('R13', `some vertices are weighted to ${maxPerVertex} bones`, 'prune tiny weights (Weights view → Prune); 2–4 bones per vertex is usually enough');
const big = m.meshes.filter(x => x.verts > 300);
if (big.length) WARN('R12', `${big.length} meshes have >300 vertices`, 'reduce vertices; median in reference corpus is 18, p90 = 48');

// ---------------- animation rules ----------------
const fps = opt.fps;
const anims = Object.entries(j.animations || {}).filter(([n]) => !opt.anim || n === opt.anim);
if (!anims.length) FAIL('A00', 'no animations');
const BLINK_NAME = /(blink|zhayan|eye_?close|biyan)/i;
const hasBlinkAnim = Object.keys(j.animations || {}).some(n => BLINK_NAME.test(n));
for (const [name, a] of anims) {
  const r = analyseAnim(m, name, a, fps);
  const tag = `${name}`;
  if (BLINK_NAME.test(name)) {
    // overlay blink for track 1+: must start and end in the open/rest pose, because a finished
    // non-looping entry keeps applying its last frame (AnimationState), and track 0 cannot reset it.
    const dur = C.animDuration(a);
    const notRest = [];
    for (const [bn, tls] of Object.entries(a.bones || {})) for (const [type, keys] of Object.entries(tls)) {
      const ch = C.channelsOfBoneTimeline(type, keys, m.version);
      if (!ch) continue;
      const restV = ch.kind === 'scale' ? 1 : 0;
      for (const [cn, ks] of Object.entries(ch.channels)) for (const t of [0, dur]) {
        const v = C.evalChannel(ks, t);
        if (Math.abs(v - restV) > (ch.kind === 'scale' ? 0.01 : 0.1)) notRest.push(`${bn}.${type}.${cn}@${Math.round(t * fps)}f=${C.r2(v)}`);
      }
    }
    for (const [sn, tl] of Object.entries(a.slots || {})) if (tl.attachment && tl.attachment.length) {
      const setup = (m.slotByName.get(sn) || {}).attachment || null, last = tl.attachment[tl.attachment.length - 1].name;
      if (last !== setup) notRest.push(`${sn}.attachment ends on "${last}" (setup "${setup}")`);
    }
    if (notRest.length) FAIL('B01', `${tag}: overlay blink does not start/end in the rest (eyes-open) pose: ${notRest.slice(0, 3).join('; ')}`, 'key the open pose at frame 0 and at the last frame; a non-looping track holds its last frame');
    else PASS('B01', `${tag}: overlay blink starts and ends eyes-open (${r.frames}f)`);
    if (r.frames > 18) WARN('B02', `${tag}: blink animation is ${r.frames}f long`, 'overlay blinks are 6–12f; trigger it at random 2–5s intervals on track 1 instead of padding it');
    continue;
  }
  const isLoop = /(idle|stand|loop|wait|daiji|breath|standby|animation)/i.test(name) || anims.length === 1;
  if (isLoop) {
    if (r.loopBreaks.length) FAIL('A01', `${tag}: ${r.loopBreaks.length} visible timelines do not end where they start (${r.loopBreaks.slice(0, 3).join('; ')})`, 'copy the first key to the last frame (time = duration) for every looping timeline, or hide the part (alpha 0 / no attachment) at the seam if it is a one-way particle');
    else PASS('A01', `${tag}: seamless loop (${r.frames}f)${r.hiddenSeamBreaks.length ? `, ${r.hiddenSeamBreaks.length} one-way particle timelines hidden at seam` : ''}`);
    if (r.symmetricTurns) WARN('A10', `${tag}: ${r.symmetricTurns.length} rotations end on a 90°/180° multiple, not 360° (${r.symmetricTurns[0]})`, 'seamless only if the rotated shape is symmetric (gear teeth, ring); otherwise rotate a full 360° per loop');
    const unit = [40, 60, 80, 90, 100, 120];
    if (r.period && !unit.some(u => r.period % u === 0 || u % r.period === 0)) WARN('A02', `${tag}: body period ${r.period}f is not a multiple of 40/60/80/90/100/120f`, 'use 80f (2.67s) breaths at 30fps; loop length = 1, 2 or 3 breaths (80/160/240f)');
    else if (r.period) PASS('A02', `${tag}: body period ${r.period}f, ${C.r2(r.frames / r.period)} cycles`);
    if (r.frames < 40) WARN('A03', `${tag}: idle shorter than 40f`, 'idles shorter than ~1.3s read as jitter; reference median is 160f');
    const g10 = parseInt(r.grid['10f'] || '0', 10);
    if (g10 < 40) WARN('A04', `${tag}: only ${g10}% of keys on a 10f grid`, 'idle loops in the reference set keep ~77% of keys on a 10f grid; snap main keys to quarter-cycle marks, offset only secondary parts');
  }
  const tot = Object.values(r.curve).reduce((s, x) => s + x, 0);
  const lin = (r.curve.linear || 0) / Math.max(1, tot);
  if (!tot) PASS('A05', `${tag}: no moving key segments (static)`);
  else if (lin > 0.4) WARN('A05', `${tag}: ${Math.round(lin * 100)}% of key segments are linear`, 'use eased bezier (0.25,0,0.75,1) for organic motion; reserve linear for constant spin/scroll and stepped for blinks/swaps');
  else PASS('A05', `${tag}: easing ok (linear ${Math.round(lin * 100)}%)`);
  // amplitude floors (calibrated on 198 reference characters; thresholds ≈ corpus p5–p10).
  // Under-animation is the most common failure of generated idles: everything "correct" but invisible.
  if (isChar && isLoop && r.frames >= 40) {
    const H = R.boundsOf(j).height; // skeleton.height, or computed when the export omits it
    const dur = C.animDuration(a);
    let bodyTy = 0, bodyRot = 0;
    for (const bn of sp.path) {
      const tl = (a.bones || {})[bn];
      if (!tl) continue;
      for (const [type, keys] of Object.entries(tl)) {
        const ch = C.channelsOfBoneTimeline(type, keys, m.version);
        if (!ch) continue;
        for (const ks of Object.values(ch.channels)) {
          const s = C.ptp(C.sampleChannel(ks, dur, fps));
          if (ch.kind === 'translate' && H) bodyTy = Math.max(bodyTy, s / H * 1000);
          if (ch.kind === 'rotate') bodyRot = Math.max(bodyRot, s);
        }
      }
    }
    if (bodyTy < 2.5 && bodyRot < 1.5) WARN('A11', `${tag}: body barely moves (max bob ${bodyTy.toFixed(1)}‰ of height, max torso rotation ${bodyRot.toFixed(2)}°)`, `reference: bob median 8‰ (p10 2.6‰) ≈ ${Math.round(H * 0.008)}px for this skeleton, torso rotation median 3.7° (p10 1.6°)`);
    else PASS('A11', `${tag}: body motion bob ${bodyTy.toFixed(1)}‰ / rot ${bodyRot.toFixed(2)}°`);
    // head: only when a head bone can be identified by name (generic names make the body path unreliable)
    const headBone = m.bones.find(b => /^(head|tou|toubu|lian|face|naodai)(_?\d+)?$/i.test(b.name));
    if (headBone) {
      let hr = 0;
      for (const bn of [headBone.name, headBone.parent].filter(Boolean)) {
        const tl = ((a.bones || {})[bn] || {}).rotate;
        if (tl) hr = Math.max(hr, C.ptp(C.sampleChannel(C.channelsOfBoneTimeline('rotate', tl, m.version).channels.r, dur, fps)));
      }
      const turnRig = C.constraintsOf(j, 'transform').some(c => m.ancestors(c.source || c.target).includes(headBone.name) && (a.bones || {})[c.source || c.target]);
      if (hr < 1 && !turnRig) WARN('A13', `${tag}: head "${headBone.name}" rotates only ${hr.toFixed(2)}° and has no animated turn rig`, 'reference head/neck rotation median 3.4° (p25 1.9°); add a sway 15–20f after the chest, or animate a pseudo-3D head turn control');
    }
    if (r.chains.length && H) {
      // tip world travel vs reference median for the chain's length class (3787 reference chains,
      // ‰ of skeleton height): <5% H → 18‰, 5–12% → 23‰, 12–25% → 39‰, >25% → 65‰ (p10 ≈ 0.45× median)
      const REF = [[0.05, 18], [0.12, 23], [0.25, 39], [Infinity, 65]];
      const sk = R.buildSkeleton(JSON.parse(JSON.stringify(j)));
      const tipsW = r.chains.map(c => { const b = sk.boneByName.get(c.bones[c.bones.length - 1]); const len = c.bones.reduce((s, n) => s + (m.byName.get(n).length || 0), 0); return { c, b, len, xs: [], ys: [] }; }).filter(t => t.len > 0);
      for (let f = 0; f < r.frames; f += 2) { R.pose(sk, a, f / fps, true); for (const t of tipsW) { const Lb = t.b.data.length || 0; t.xs.push(t.b.worldX + t.b.a * Lb); t.ys.push(t.b.worldY + t.b.c * Lb); } }
      const rows = tipsW.map(t => {
        const travel = Math.hypot(Math.max(...t.xs) - Math.min(...t.xs), Math.max(...t.ys) - Math.min(...t.ys));
        const ref = REF.find(([lim]) => t.len / H < lim)[1];
        return { name: t.c.bones[0], travel, permille: travel / H * 1000, ref, ratio: travel / H * 1000 / ref };
      }).sort((x, y) => x.ratio - y.ratio);
      if (rows.length) {
        const med = rows[Math.floor(rows.length / 2)];
        const angMed = r.chains.map(c => c.ampDeg[c.ampDeg.length - 1]).sort((x, y) => x - y)[Math.floor(r.chains.length / 2)];
        if (med.ratio < 0.3) WARN('A12', `${tag}: chain tips barely move — median chain travels ${med.permille.toFixed(1)}‰ of height (${med.travel.toFixed(0)}px), ${Math.round(med.ratio * 100)}% of the reference for its length; median tip swing ${angMed.toFixed(1)}°. Smallest: ${rows.slice(0, 3).map(x => `${x.name} ${x.travel.toFixed(0)}px/ref ${(x.ref * H / 1000).toFixed(0)}px`).join(', ')}`, 'use --chain ... kind=<preset> or tip=<deg> (amp= is the ROOT segment; tip = amp × growth^(N-1)); reference tip swing median 17°, see references/03-chain-secondary.md §2');
        else PASS('A12', `${tag}: chain tips travel ${Math.round(med.ratio * 100)}% of reference (median ${med.permille.toFixed(1)}‰ of height, tip swing ${angMed.toFixed(1)}°)`);
        // over-animation: the whole set (not single chains — long tails are normal, p90 ≈ 2.3× median)
        if (med.ratio > 3) WARN('A14', `${tag}: chains travel ${med.ratio.toFixed(1)}× the reference on median (${med.permille.toFixed(0)}‰ of height)`, 'idle secondary motion this large reads as wind/action; check --trails for tangling, lower tip or cap with max=');
      }
    }
  }
  // A16 scaleY blink geometry: bones whose scale.y dips briefly below 0.6 (blink-like). The eye squashes
  // toward the bone origin along the bone's local Y — origin in the upper part of the eye = blink goes UP;
  // whole-eye drawings squashed below 0.25 = blank face (no closed-eye drawing / lid layer to show).
  for (const [bn, tl] of Object.entries(a.bones || {})) {
    if (!tl.scale && !tl.scaley) continue;
    const ch = C.channelsOfBoneTimeline(tl.scale ? 'scale' : 'scaley', tl.scale || tl.scaley, m.version);
    const ys = C.sampleChannel(ch.channels.y, C.animDuration(a), fps);
    const xs = ch.channels.x ? C.sampleChannel(ch.channels.x, C.animDuration(a), fps) : ys.map(() => 1);
    const minY = Math.min(...ys), low = ys.filter(v => v < 0.6).length;
    const restY = ys.slice().sort((p, q) => p - q)[Math.floor(ys.length / 2)];
    // a blink squashes Y only, briefly, from a rest scale of ~1 (particles/props scale X and Y together)
    const blinkLike = minY < 0.6 && low <= 24 && Math.abs(restY - 1) < 0.1 && C.ptp(xs) < 0.2 * C.ptp(ys);
    if (!blinkLike) continue;
    const geo = R.blinkGeometry(R.skeletonFor(JSON.parse(JSON.stringify(j)), file), bn);
    if (!geo) continue;
    const probs = [];
    if (Math.abs(geo.tilt) > 5) probs.push(`squash axis is ${geo.tilt.toFixed(1)}° off the normal of the face line (${geo.faceRef}) — the eye closes slanted (needs local Y perpendicular to the eye line, ±5°)`);
    if (geo.t > 0.6 || geo.t < -0.25) probs.push(`origin at ${(geo.t * 100).toFixed(0)}% of the eye height above the lower lid — the eye closes ${geo.t > 0.6 ? 'UPWARD' : 'toward a line below it'}`);
    if (!geo.lidLike && minY < 0.25) probs.push(`whole-eye drawings (${geo.slots.join(', ')}) squashed to ${minY.toFixed(2)} — the eye disappears and leaves a blank face`);
    if (probs.length) FAIL('A16', `${tag}: blink bone "${bn}": ${probs.join('; ')}`, `insert a blink bone between head and eye with its ORIGIN on the lower lid line and local Y perpendicular to the face line (rotation ${geo.fixRotation.toFixed(2)}° relative to ${bn}; counter-rotate the eye under it so the art stays put) — automatic: spine_gen_secondary.js --blinkrig ${bn} --blink ${bn}_blink mode=scaleY — and either show a closed-eye drawing or keep minScale ≥ 0.25 for whole-eye drawings; see references/04-blink-face.md §3.3`);
    else PASS('A16', `${tag}: blink bone "${bn}" closes toward the lower lid (origin at ${(geo.t * 100).toFixed(0)}% of eye height), axis ${geo.tilt.toFixed(1)}° from the face-line normal, min scale ${minY.toFixed(2)}`);
  }
  // A19 deform-blink texture smear: at the closed key, visible DETAILED pixels (lashes, lid line, outlines —
  // local contrast > 0.25) of the blink meshes that come from a triangle stretched > 1.8× in some direction, or
  // flipped. Lines then turn thick and blurry ("dirty pixels"). Needs the atlas. Corpus (279 deform blinks):
  // share p50 3%, p95 47%; smeared px p50 9, p95 184, p99 311, max 421. test_out/004_v4 warrior: 522px / 69%.
  // FAIL above the corpus maximum (> 450px and > 50%), WARN above its p99 (> 300px and > 50%).
  if (isLoop || BLINK_NAME.test(name)) {
    let skT = null;
    try { skT = R.loadProject(file); } catch (e) { /* no atlas: skip */ }
    const dts = skT ? C.deformTimelines(a) : [];
    const pul = [];
    for (const tl of dts) {
      const ks = tl.keys; if (ks.length < 3) continue;
      const mag = ks.map(k => (k.vertices || []).reduce((s, v) => Math.max(s, Math.abs(v)), 0)), mx = Math.max(...mag);
      if (mx < 2) continue;
      for (let i = 0; i < ks.length; i++) {
        if (mag[i] > 0.15 * mx) continue;
        let k = i + 1; while (k < ks.length && mag[k] > 0.15 * mx) k++;
        if (k >= ks.length || k === i + 1) continue;
        const t0 = C.T(ks[i]) * fps, t1 = C.T(ks[k]) * fps, pk = Math.max(...mag.slice(i + 1, k));
        if (t1 - t0 <= 30 && t1 - t0 >= 3 && pk >= 0.5 * mx) { const ic = mag.findIndex((q, qi) => qi > i && qi < k && q >= 0.95 * pk); pul.push({ slot: tl.slot, t0, tc: C.T(ks[ic]) }); }
        i = k - 1;
      }
    }
    pul.sort((p, q) => p.t0 - q.t0);
    const seen = new Set();
    for (const p0 of pul) {
      if ([...seen].some(t => Math.abs(t - p0.t0) <= 4)) continue;
      seen.add(p0.t0);
      const grp = pul.filter(p => Math.abs(p.t0 - p0.t0) <= 4), names = new Set(grp.map(p => p.slot));
      const f = Math.round(Math.min(...grp.map(p => p.tc)) * fps + 0.3);
      const smear = R.deformSmear(skT, a, f / fps, names);
      if (!smear || smear.detail < 30) continue;
      const share = smear.bad / smear.detail;
      const worst = smear.per.sort((x, y) => y.bad - x.bad)[0];
      const msg = `${tag}: deform blink @${f}f — ${smear.bad} of ${smear.detail} visible line/detail px (${Math.round(share * 100)}%) come from triangles stretched up to ×${smear.maxStretch.toFixed(1)} or flipped; worst ${worst.slot} ${worst.bad}px`;
      const fix = 'move the lid edge (lash line) as a RIGID band and slide it down, compress only the skin above it toward the lid top; collapse eye white / pupil instead of stretching the lid over them; add vertex rows along the lash line so it can bend without stretching triangles; see references/04-blink-face.md §3.1';
      if (share > 0.5 && smear.bad > 450) FAIL('A19', msg + ' (corpus max 421px)', fix);
      else if (share > 0.5 && smear.bad > 300) WARN('A19', msg + ' (corpus p99 311px)', fix);
      else PASS('A19', `${tag}: deform blink @${f}f keeps lines clean (${smear.bad}/${smear.detail} detail px stretched)`);
    }
  }
  // A18 pupil/highlight hidden out of sync with the eye: a normally visible slot that an attachment key hides
  // briefly (visible → none → visible, ≤24f) on top of an eye that closes (an overlapping visible slot whose
  // posed height drops below 60%). openness = (h - hmin) / (hopen - hmin). Hidden while the eye is already
  // ≥60% open = a white eye without pupil / pupil pops in late; shown while ≤10% open = pupil over a shut eye.
  {
    const skA = R.buildSkeleton(JSON.parse(JSON.stringify(j)));
    const boxOf = p => { if (!p.length) return null; const xs = p.map(q => q[0]), ys = p.map(q => q[1]); return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]; };
    const inter = (p, q) => Math.max(0, Math.min(p[2], q[2]) - Math.max(p[0], q[0])) * Math.max(0, Math.min(p[3], q[3]) - Math.max(p[1], q[1]));
    for (const [sn, stl] of Object.entries(a.slots || {})) {
      const ks = stl.attachment, s = skA.slotByName.get(sn);
      if (!ks || !s || !s.data.attachment) continue;
      for (let i = 1; i < ks.length; i++) {
        if (ks[i].name || !ks[i - 1].name) continue;
        let k = i; while (k < ks.length && !ks[k].name) k++;
        if (k >= ks.length) break;
        const h0 = Math.round((ks[i].time || 0) * fps), h1 = Math.round((ks[k].time || 0) * fps), shown = ks[i - 1].name;
        i = k;
        if (h1 - h0 > 24 || h1 <= h0) continue;
        R.pose(skA, a, (h0 - 1) / fps, false);
        if (!(skA.slotByName.get(sn).color[3] > 0.1)) continue;
        const hb = boxOf(R.slotPoints(skA, s, shown, true));
        if (!hb) continue;
        const area = Math.max(1e-6, (hb[2] - hb[0]) * (hb[3] - hb[1]));
        const F0 = Math.max(0, h0 - 10), F1 = h1 + 10;
        const cands = skA.slots.filter(o => o !== s && o.attName && o.color[3] > 0.1).filter(o => { const b = boxOf(R.slotPoints(skA, o, o.attName, true)); return b && inter(b, hb) > 0.3 * area; });
        if (!cands.length) continue;
        const Hs = new Map(cands.map(o => [o, []]));
        for (let f = F0; f <= F1; f++) {
          R.pose(skA, a, f / fps, false);
          for (const o of cands) { const b = o.color[3] > 0.1 && boxOf(R.slotPoints(skA, o, o.attName, true)); Hs.get(o).push(b ? b[3] - b[1] : NaN); }
        }
        let eye = null;
        for (const o of cands) {
          const hs = Hs.get(o);
          if (hs.some(isNaN)) continue;
          const hopen = Math.max(hs[0], hs[hs.length - 1]), hmin = Math.min(...hs), at = hs.indexOf(hmin) + F0;
          if (hmin < 0.6 * hopen && at >= h0 - 6 && at <= h1 + 2 && (!eye || hmin / hopen < eye.r)) eye = { o, hs, hopen, hmin, r: hmin / hopen };
        }
        if (!eye) continue;
        const open = f => (eye.hs[f - F0] - eye.hmin) / Math.max(1e-6, eye.hopen - eye.hmin);
        const lateHidden = [], shutShown = [];
        for (let f = h0; f < h1; f++) if (open(f) >= 0.6) lateHidden.push(`${f}f ${Math.round(open(f) * 100)}%`);
        for (const f of [h0 - 2, h0 - 1, h1, h1 + 1]) if (f >= F0 && f <= F1 && open(f) <= 0.1) shutShown.push(`${f}f ${Math.round(open(f) * 100)}%`);
        const closed = []; for (let f = F0; f <= F1; f++) if (open(f) < 0.5) closed.push(f);
        const span = closed.length ? `${closed[0]}–${closed[closed.length - 1]}f` : '-';
        if (lateHidden.length || shutShown.length) FAIL('A18', `${tag}: "${sn}" is hidden ${h0}–${h1 - 1}f but the eye "${eye.o.name}" is <50% open at ${span}` + (lateHidden.length ? `; hidden while the eye is already open (${lateHidden.join(', ')}) — a white eye without pupil, the pupil pops in late` : '') + (shutShown.length ? `; shown over the shut eye (${shutShown.join(', ')})` : ''),
          `hide it on the same frame the eye passes 50% closed and show it again on the first opening frame (${span}), or better keep it visible and squash/deform it with the SAME keys as the eye white (corpus 019/046/055/127) — spine_gen_secondary.js --blink LABEL mode=deform lid=... inner=white,pupil does this; see references/04-blink-face.md §3.1/§3.4`);
        else PASS('A18', `${tag}: "${sn}" hidden ${h0}–${h1 - 1}f matches eye "${eye.o.name}" closure (<50% open ${span})`);
      }
    }
  }
  // A15 IK knee/elbow pop: a 2-bone IK that is fully straight in part of the loop and bent in another
  // flips across the singular point (bend 0°) — with stretch on it snaps from "stretched" to "bent", read as a
  // twitch. Sample the bend angle per frame; flag touching 0° while also bending, or per-frame jumps.
  if (r.frames >= 20 && C.constraintsOf(j, 'ik').some(c => c.bones.length === 2)) {
    const sk2 = R.buildSkeleton(JSON.parse(JSON.stringify(j)));
    const dur2 = C.animDuration(a);
    for (const c of C.constraintsOf(j, 'ik').filter(q => q.bones.length === 2)) {
      const U = sk2.boneByName.get(c.bones[0]), Lw = sk2.boneByName.get(c.bones[1]), Tg = sk2.boneByName.get(c.target);
      R.pose(sk2, null, 0, true);
      let setupBend = (Math.atan2(Lw.c, Lw.a) - Math.atan2(U.c, U.a)) * 180 / Math.PI;
      while (setupBend > 180) setupBend -= 360; while (setupBend < -180) setupBend += 360;
      const bends = [], tgt = [];
      for (let f = 0; f <= r.frames; f++) {
        R.pose(sk2, a, Math.min(dur2, f / fps), true);
        let d = (Math.atan2(Lw.c, Lw.a) - Math.atan2(U.c, U.a)) * 180 / Math.PI;
        while (d > 180) d -= 360; while (d < -180) d += 360;
        bends.push(d);
        tgt.push([Tg.worldX, Tg.worldY, U.worldX, U.worldY]);
      }
      const straight = bends.filter(x => Math.abs(x) < 0.05).length, bent = bends.filter(x => Math.abs(x) > 0.3).length;
      // a jump only counts when the target-to-root distance barely changed that frame: a fast-moving
      // target (hand reaching, drumstick) legitimately swings the limb; a pop happens with a still target
      let jump = 0, at = 0;
      for (let k = 1; k < bends.length; k++) {
        const dd = Math.abs(bends[k] - bends[k - 1]);
        const dist = q => Math.hypot(q[0] - q[2], q[1] - q[3]);
        const dReach = Math.abs(dist(tgt[k]) - dist(tgt[k - 1]));
        if (dReach < 1 && dd > jump) { jump = dd; at = k; }
      }
      // Only the straight/bent alternation is reported as a defect (0 false positives on 218 reference
      // projects). Large per-frame changes alone also occur in legitimate fast moves, so they are info only.
      const flips = straight > 0 && bent > 0;
      // A17 knee over-reacts to the pelvis: a nearly straight planted leg (setup bend < 8°) is hyper-sensitive —
      // dθ/dD = 2/(L·sin(θ/2)) — so a few px of pelvis bob swings the knee 10°+, read as "knee and pelvis move
      // independently". Reference (150 planted IKs): setup bend median 18.7°, 0.97°/px; flag when the setup is
      // nearly straight, the response > 2°/px AND the knee actually swings > 8° (0 hits in the reference set).
      const reach = tgt.map(q => Math.hypot(q[0] - q[2], q[1] - q[3]));
      const tgtMove = Math.hypot(Math.max(...tgt.map(q => q[0])) - Math.min(...tgt.map(q => q[0])), Math.max(...tgt.map(q => q[1])) - Math.min(...tgt.map(q => q[1])));
      const bendRange = Math.max(...bends.map(Math.abs)) - Math.min(...bends.map(Math.abs));
      const ratio = bendRange / Math.max(1e-6, C.ptp(reach));
      if (tgtMove < 2 && C.ptp(reach) > 0.5 && Math.abs(setupBend) < 8 && ratio > 2 && bendRange > 8) {
        const L2 = (U.data.length || 0) + (Lw.data.length || 0);
        const per = th => (2 / (L2 * Math.sin(th / 2 * Math.PI / 180)) * 180 / Math.PI).toFixed(2); // °/px at bend th
        const lower = th => (L2 * (Math.cos(Math.abs(setupBend) / 2 * Math.PI / 180) - Math.cos(th / 2 * Math.PI / 180))).toFixed(1);
        WARN('A17', `${tag}: IK "${c.name}" knee swings ${bendRange.toFixed(1)}° for ${C.ptp(reach).toFixed(1)}px of hip travel (${ratio.toFixed(2)}°/px; setup bend only ${Math.abs(setupBend).toFixed(1)}°) — the knee over-reacts and looks disconnected from the pelvis`, `pre-bend the planted leg in the setup pose (reference median 18.7°, 0.97°/px). Legs ${L2.toFixed(0)}px: 20° → ${per(20)}°/px, 25° → ${per(25)}°/px. Easiest: keep the foot target and lower the pelvis/master setup by ${lower(20)}px (20°) or ${lower(25)}px (25°), let the IK bend the knee; or reduce the pelvis bob.`);
      }
      if (flips) WARN('A15', `${tag}: IK "${c.name}" (${c.bones.join('+')}) is fully straight in ${straight} frames and bent in ${bent} — it crosses the straight-limb point, the joint pops (worst ${jump.toFixed(2)}° in one frame at f${at})${c.stretch ? '; stretch on' : ''}`, 'bend the limb 3–8° in the setup pose so the body bob never fully straightens it (reference 001: knee stays 6.7–7.8° bent), or reduce the bob; avoid stretch on a limb that alternates straight/bent (4.x: use softness)');
      else PASS('A15', `${tag}: IK "${c.name}" bend ${Math.min(...bends).toFixed(1)}..${Math.max(...bends).toFixed(1)}°, never crosses straight${jump > 0.8 ? ` (info: max ${jump.toFixed(2)}°/frame at f${at})` : ''}`);
    }
  }
  // chains: lag and amplitude growth
  let sync = 0, shrink = 0;
  for (const c of r.chains) {
    const lags = c.lagFrames.filter(x => x !== null);
    if (lags.length && lags.every(x => x === 0)) sync++;
    if (c.ampDeg.length >= 3 && c.ampDeg[c.ampDeg.length - 1] < c.ampDeg[0] * 0.8) shrink++;
  }
  if (r.chains.length) {
    if (sync > r.chains.length * 0.3) WARN('A06', `${tag}: ${sync}/${r.chains.length} chains rotate in sync (lag 0)`, 'offset each child segment by ~1/8 of the cycle (10f for an 80f cycle) so motion travels from root to tip');
    else PASS('A06', `${tag}: ${r.chains.length} chains with travelling lag`);
    if (shrink > r.chains.length * 0.3) WARN('A07', `${tag}: ${shrink} chains get stiffer toward the tip`, 'tip segments should swing more: ≈1.5–2.5× the parent amplitude per segment');
  }
  // blink
  const eyeName = /(eye|yan|biyan|jiemao|lash|lid|pupil|white|iris|tongkong|yanzhu|yanbai|yanqiu)/i;
  const hasEyes = m.slots.some(s => eyeName.test(s.name)) || m.meshes.some(x => eyeName.test(x.slot)) || m.bones.some(b => eyeName.test(b.name));
  if (isLoop && hasEyes) {
    if (!r.blink.length && hasBlinkAnim) PASS('A08', `${tag}: no blink inside the loop; separate blink animation present (play it on track 1)`);
    else if (!r.blink.length) WARN('A08', `${tag}: character has eye parts but no blink detected`, 'add a 7–10f blink (close 2–3f, hold 2–3f, open 3–4f), 1–2 per 160f loop, or put it on a separate track');
    else {
      const long = r.blink.filter(b => b.frames > 18);
      if (long.length) WARN('A09', `${tag}: blink lasting ${long[0].frames}f`, 'a normal blink is 6–12f at 30fps; longer reads as a slow/sleepy close');
      else PASS('A08', `${tag}: ${r.blink.length} blink(s) ${r.blink.map(b => b.frames + 'f').join(', ')}`);
    }
  }
}

console.log(`# lint ${file}\n` + out.join('\n') + `\n\nsummary: ${fails} FAIL, ${warns} WARN`);
process.exit(fails || (opt.strict && warns) ? 1 : 0);
