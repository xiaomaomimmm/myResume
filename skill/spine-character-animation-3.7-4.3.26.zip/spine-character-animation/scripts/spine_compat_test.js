#!/usr/bin/env node
// Behavioral regression tests for the common-feature version converter. No npm dependencies.
'use strict';
const assert=require('assert'),V=require('./spine_compat'),C=require('./spine_core');
const ease={curve:.25,c3:.75}, key=(time,values,curve)=>Object.assign({time},values,curve||{});
function fixture(){return {
  skeleton:{spine:'3.8.99',fps:30,images:'./images/'},
  bones:[{name:'root'},{name:'body',parent:'root',transform:'noScale',length:40},{name:'target',parent:'root',x:12,y:30}],
  slots:[{name:'face',bone:'body',attachment:'mesh',dark:'000000'},{name:'route',bone:'root',attachment:'route'}],
  ik:[{name:'ik',order:0,bones:['body'],target:'target',mix:.7,uniform:true}],
  transform:[{name:'follow',order:1,bones:['body'],target:'target',rotateMix:.2,translateMix:.3,scaleMix:0,shearMix:0}],
  path:[{name:'path',order:2,bones:['body'],target:'route',rotateMix:.2,translateMix:.4}],
  skins:[{name:'default',attachments:{face:{mesh:{type:'mesh',uvs:[0,0,1,0,1,1,0,1],triangles:[0,1,2,2,3,0],vertices:[0,0,10,0,10,10,0,10],hull:4,width:10,height:10},linked:{type:'linkedmesh',parent:'mesh',deform:true}},route:{route:{type:'path',vertexCount:6,vertices:[0,0,10,0,20,0,30,0,40,0,50,0],lengths:[30,50],closed:false,constantSpeed:false}}}}],
  events:{hit:{int:2}},
  animations:{idle:{
    bones:{body:{rotate:[key(0,{angle:2},ease),key(1,{angle:14},ease),key(2,{angle:2})],translate:[key(0,{x:2,y:5},ease),key(1,{x:8,y:15},ease),key(2,{x:2,y:5})],scale:[key(0,{x:1,y:1},ease),key(1,{x:1.1,y:1.2},ease),key(2,{x:1,y:1})]}},
    slots:{face:{color:[key(0,{color:'ffffffff'},ease),key(1,{color:'80402080'},ease),key(2,{color:'ffffffff'})],twoColor:[key(0,{light:'ffffffff',dark:'000000'},ease),key(1,{light:'80808080',dark:'204060'},ease),key(2,{light:'ffffffff',dark:'000000'})],attachment:[key(0,{name:'mesh'}),key(2,{name:'mesh'})]}},
    ik:{ik:[key(0,{mix:.7,softness:0},ease),key(1,{mix:.8,softness:0},ease),key(2,{mix:.7,softness:0})]},
    transform:{follow:[key(0,{rotateMix:.2,translateMix:.3,scaleMix:0,shearMix:0},ease),key(1,{rotateMix:.4,translateMix:.7,scaleMix:0,shearMix:0},ease),key(2,{rotateMix:.2,translateMix:.3,scaleMix:0,shearMix:0})]},
    paths:{path:{position:[key(0,{position:0},ease),key(1,{position:.5},ease),key(2,{position:0})],mix:[key(0,{rotateMix:.2,translateMix:.4},ease),key(1,{rotateMix:.5,translateMix:.8},ease),key(2,{rotateMix:.2,translateMix:.4})]}},
    deform:{default:{face:{mesh:[key(0,{},ease),key(1,{offset:2,vertices:[1,2]},ease),key(2,{})]}}},
    drawOrder:[key(0,{}),key(1,{offsets:[{slot:'face',offset:1}]}),key(2,{})],events:[key(.5,{name:'hit'})]
  }}
};}
let checks=0;const check=(value,message)=>{assert(value,message);checks++;};
const original=fixture(),snapshot=JSON.stringify(original);
for(const version of V.SUPPORTED){
  const converted=V.convertVersion(original,version),validation=V.validateVersion(converted);
  check(validation.errors.length===0,version+': '+validation.errors.join(';'));
  const p=V.profileOf(converted);
  check(Array.isArray(converted.skins)===p.arraySkins,version+' skins layout');
  check(!!converted.animations.idle.attachments===p.attachmentTimelines,version+' deform location');
  const rotate=C.channelsOfBoneTimeline('rotate',converted.animations.idle.bones.body.rotate,p);
  const source=C.channelsOfBoneTimeline('rotate',original.animations.idle.bones.body.rotate,V.profileOf(original));
  for(const t of [.125,.25,.5,.75,1.25,1.875])check(Math.abs(C.evalChannel(rotate.channels.r,t)-C.evalChannel(source.channels.r,t))<1e-5,version+' rotation curve at '+t);
  const back=V.convertVersion(converted,'3.8.99');
  check(back.bones[1].transform==='noScale',version+' bone inheritance round trip');
  check(back.skins[0].attachments.face.linked.parent==='mesh',version+' linked mesh round trip');
  check(back.animations.idle.deform.default.face.mesh[1].vertices[1]===2,version+' deform values preserved');
  check(back.animations.idle.paths.path.position[1].position===.5,version+' path position values preserved');
  check(back.animations.idle.slots.face.twoColor[0].curve===.25,version+' two-color curve preserved');
  if(version==='3.7')check(converted.animations.idle.bones.body.rotate.every(k=>Number.isFinite(k.time)&&Number.isFinite(k.angle)), '3.7 required key fields');
  if(version==='4.3'){
    const tc=converted.constraints.find(c=>c.type==='transform');check(tc.source==='target' && tc.properties.x.to.x, '4.3 transform mapping');
    check(converted.constraints.find(c=>c.type==='path').slot==='route','4.3 path slot');
    check(converted.constraints.find(c=>c.type==='ik').scaleY==='uniform','4.3 IK scaleY');
  }
}
check(JSON.stringify(original)===snapshot,'conversion does not mutate input');
check(V.profileOf('latest').raw==='4.3.26','latest release profile');
assert.throws(()=>V.parseVersion('5.0'),/Unsupported/);checks++;
assert.throws(()=>V.parseVersion('4.9'),/Unsupported/);checks++;
const physics=V.convertVersion(original,'4.2');physics.physics=[{name:'wind',bone:'body'}];
assert.throws(()=>V.convertVersion(physics,'4.1'),/physics/);checks++;
const independent=V.convertVersion(original,'4.2');independent.transform[0].mixY=.91;
assert.throws(()=>V.convertVersion(independent,'3.8'),/independent mixX/);checks++;
const mismatched=V.convertVersion(original,'4.2');mismatched.animations.idle.bones.body.translate[0].curve[5]=100;
assert.throws(()=>V.convertVersion(mismatched,'3.8'),/independent channel/);checks++;
const sequence=V.convertVersion(original,'4.1');sequence.skins[0].attachments.face.mesh.sequence={count:2};
assert.throws(()=>V.convertVersion(sequence,'4.0'),/sequence/);checks++;
const fullTurn=V.convertVersion(original,'4.2');fullTurn.animations.idle.bones.body.rotate[1].value=400;
assert.throws(()=>V.convertVersion(fullTurn,'3.8'),/180 degrees/);checks++;
const legacy=V.convertVersion(original,'3.7');delete legacy.animations.idle.bones.body.rotate[0].time;
check(V.validateVersion(legacy).errors.some(e=>/explicit time/.test(e)), 'missing3.7 time fails validation');
check(V.convertVersion(legacy,'3.7').animations.idle.bones.body.rotate[0].time===0,'legacy omitted time repaired');
assert.throws(()=>V.parseVersion('4.3.26-beta'),/beta\/prerelease/);checks++;
const missingAngle=V.convertVersion(original,'3.7');delete missingAngle.animations.idle.bones.body.rotate[0].angle;
check(V.validateVersion(missingAngle).errors.some(e=>/explicit numeric angle/.test(e)),'3.7 angle required');
const badArray=V.convertVersion(original,'4.2');badArray.animations.idle.bones.body.translate[0].curve.length=4;
check(V.validateVersion(badArray).errors.some(e=>/expected 8/.test(e)),'two-axis Bezier count checked');
const missingName=fixture();delete missingName.animations.idle.slots.face.attachment[0].name;
check(V.validateVersion(missingName).errors.some(e=>/explicit name/.test(e)),'attachment key name required');
const missingColor=fixture();delete missingColor.animations.idle.slots.face.color[0].color;
check(V.validateVersion(missingColor).errors.some(e=>/missing color/.test(e)),'slot color required');
const requiredConstraint=V.convertVersion(original,'4.3');requiredConstraint.constraints[0].skin=true;
assert.throws(()=>V.convertVersion(requiredConstraint,'3.7'),/skin-required constraints/);checks++;
const alpha=V.convertVersion(original,'4.2');alpha.animations.idle.slots.face={alpha:[{value:.2,curve:[.25,.2,.75,.6]},{time:1,value:.6}]};
const alphaOld=V.convertVersion(alpha,'3.8');
check(alphaOld.animations.idle.slots.face.color[0].color==='ffffff33' && alphaOld.animations.idle.slots.face.color[1].color==='ffffff99','alpha-only downgrade preserves setup RGB and alpha endpoints');
check(alphaOld.animations.idle.slots.face.color[0].curve===.25,'alpha-only downgrade retains easing');
console.log(`PASS ${checks} compatibility checks across ${V.SUPPORTED.join(', ')}`);
module.exports={fixture};
