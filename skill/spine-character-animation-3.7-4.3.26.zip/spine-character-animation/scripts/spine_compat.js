// Explicit Spine JSON profiles. Conversion never edits the caller's object or silently drops features.
'use strict';
const SUPPORTED = ['3.7', '3.8', '4.0', '4.1', '4.2', '4.3'];
const LATEST_STABLE = '4.3.26'; // Official changelog checked 2026-10-27; unknown future profiles are rejected.
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const n = (v, d) => v === undefined ? d : v;
const time = k => n(k.time, 0);
const clone = j => JSON.parse(JSON.stringify(j));
function parseVersion(raw) {
  if (raw && typeof raw === 'object') raw = raw.skeleton && raw.skeleton.spine;
  if (raw === 'latest') raw = LATEST_STABLE;
  if (typeof raw !== 'string' || !/^(\d+)\.(\d+)(?:\.\d+)?$/.test(raw))
    throw new Error('skeleton.spine / target version must explicitly identify a supported stable Spine version; beta/prerelease schemas are not supported');
  const parts = raw.match(/^(\d+)\.(\d+)/), major = +parts[1], minor = +parts[2], key = major + '.' + minor;
  if (!SUPPORTED.includes(key)) throw new Error(`Unsupported Spine ${raw}; supported profiles: ${SUPPORTED.join(', ')}`);
  return { raw, major, minor, key, is4: major >= 4 };
}
function profileOf(raw) {
  const p = parseVersion(raw);
  return Object.assign(p, {
    arraySkins: p.key !== '3.7', curve: p.is4 ? 'absolute' : p.key === '3.7' ? 'normalized-array' : 'normalized-number',
    attachmentTimelines: p.is4 && p.minor >= 1, inherit: p.is4 && p.minor >= 2,
    unifiedConstraints: p.key === '4.3', physics: p.is4 && p.minor >= 2,
  });
}
function fail(where, message) { throw new Error(`${where}: ${message}`); }
function skinList(j) { return Array.isArray(j.skins) ? j.skins : Object.entries(j.skins || {}).map(([name, attachments]) => ({name, attachments})); }
function eachAttachment(j, fn) { for (const sk of skinList(j)) for (const [slot, atts] of Object.entries(sk.attachments || {})) for (const [name, att] of Object.entries(atts)) fn(att, `skins.${sk.name}.${slot}.${name}`); }
function walkKeys(j, fn) {
  function walk(o, where) {
    if (!o || typeof o !== 'object') return;
    if (Array.isArray(o)) {
      if (o.length && o.every(k => k && typeof k === 'object' && !Array.isArray(k))) { fn(o, where); }
      else for (let i = 0; i < o.length; i++) walk(o[i], where + '.' + i);
    } else for (const [k,v] of Object.entries(o)) walk(v, where + '.' + k);
  }
  walk(j.animations || {}, 'animations');
}
function validateVersion(j) {
  const errors = [], warnings = []; let p;
  try { p = profileOf(j); } catch (e) { return {version: j.skeleton && j.skeleton.spine, errors:[e.message], warnings}; }
  const err = (w,m) => errors.push(`${w}: ${m}`);
  if (j.skins !== undefined && Array.isArray(j.skins) !== p.arraySkins) err('skins', p.arraySkins ? 'must be an array in this profile' : 'must be a name-keyed object in Spine 3.7');
  for (const b of j.bones || []) {
    if (has(b, p.inherit ? 'transform' : 'inherit')) err(`bones.${b.name}`, `use ${p.inherit ? 'inherit' : 'transform'} in Spine ${p.key}`);
    if (!p.arraySkins && b.skin) err(`bones.${b.name}.skin`, 'skin-required bones need Spine 3.8+');
  }
  if (p.unifiedConstraints) {
    for (const k of ['ik','transform','path','physics']) if (j[k] && j[k].length) err(k, 'Spine 4.3 uses the unified constraints array');
    for (const c of j.constraints || []) {
      if(c.type==='transform' && (!c.source || !c.properties || c.target!==undefined)) err('constraints.'+c.name,'4.3 transform requires source and properties, replacing target');
      if(c.type==='path' && (!c.slot || c.target!==undefined))err('constraints.'+c.name,'4.3 path requires slot, replacing target');
      if(c.type==='ik' && c.uniform!==undefined)err('constraints.'+c.name,'4.3 IK uses scaleY instead of uniform');
    }
  }
  else if (j.constraints && j.constraints.length) err('constraints','unified constraints require Spine 4.3');
  if (!p.physics && j.physics && j.physics.length) err('physics','physics constraints require Spine 4.2+');
  for (const [name,a] of Object.entries(j.animations || {})) {
    if (p.attachmentTimelines ? a.deform : a.attachments) err(`animations.${name}`, `use ${p.attachmentTimelines ? 'attachments.<skin>.<slot>.<att>.deform' : 'deform.<skin>.<slot>.<att>'} in Spine ${p.key}`);
    for (const [bn, tls] of Object.entries(a.bones || {})) for (const [type, ks] of Object.entries(tls)) {
      const allowed=p.is4?['rotate','translate','scale','shear','translatex','translatey','scalex','scaley','shearx','sheary'].concat(p.inherit?['inherit']:[]):['rotate','translate','scale','shear'];
      if(!allowed.includes(type))err(`animations.${name}.bones.${bn}.${type}`,'unsupported bone timeline in this profile');
      if (!p.is4 && /^(translate|scale|shear)[xy]$/.test(type)) err(`animations.${name}.bones.${bn}.${type}`, 'split axis timelines require Spine 4.x');
      if (!p.inherit && type === 'inherit') err(`animations.${name}.bones.${bn}.inherit`, 'inherit timeline requires Spine 4.2+');
      if (type === 'rotate') for (const k of ks) if (has(k,p.is4?'angle':'value')) err(`animations.${name}.bones.${bn}.rotate`, `use ${p.is4?'value':'angle'} keys`);
      if (p.key==='3.7' && type==='rotate')for(const k of ks)if(!Number.isFinite(k.angle))err(`animations.${name}.bones.${bn}.rotate`,'Spine 3.7 requires explicit numeric angle');
    }
    for (const [sn,tls] of Object.entries(a.slots || {})) for (const type of Object.keys(tls)) {
      if(!(p.is4?['attachment','rgba','rgb','alpha','rgba2','rgb2']:['attachment','color','twoColor']).includes(type))err(`animations.${name}.slots.${sn}.${type}`,'unsupported slot timeline in this profile');
      if (p.is4 && ['color','twoColor'].includes(type)) err(`animations.${name}.slots.${sn}.${type}`, 'use rgba / rgba2 in Spine 4.x');
      if (!p.is4 && ['rgba','rgb','alpha','rgba2','rgb2'].includes(type)) err(`animations.${name}.slots.${sn}.${type}`, 'use color / twoColor in Spine 3.x');
      for(const k of tls[type]){
        if(type==='attachment'&&!has(k,'name'))err(`animations.${name}.slots.${sn}.attachment`,'attachment keys require explicit name (null detaches)');
        if(['color','rgba','rgb'].includes(type) && (typeof k.color!=='string'||!new RegExp('^[a-fA-F0-9]{'+(type==='rgb'?6:8)+'}$').test(k.color)))err(`animations.${name}.slots.${sn}.${type}`,'invalid or missing color');
        if(['twoColor','rgba2','rgb2'].includes(type) && (typeof k.light!=='string'||typeof k.dark!=='string'||!new RegExp('^[a-fA-F0-9]{'+(type==='rgb2'?6:8)+'}$').test(k.light)||!/^[a-fA-F0-9]{6}$/.test(k.dark)))err(`animations.${name}.slots.${sn}.${type}`,'invalid or missing light/dark color');
      }
    }
  }
  eachAttachment(j,(att,w)=>{
    if(p.unifiedConstraints && att.parent!==undefined)err(w,'4.3 linked meshes use source instead of parent');
    if(!p.unifiedConstraints && att.source!==undefined)err(w,'linked mesh source requires Spine 4.3');
  });
  walkKeys(j,(ks,w)=>ks.forEach((k,i)=>{
    if(w.endsWith('.offsets'))return;
    if(p.key==='3.7' && k.time===undefined)err(w+'.'+i,'Spine 3.7 requires explicit time, including time:0');
    if (k.time !== undefined && (!Number.isFinite(k.time) || k.time < 0)) err(w+'.'+i,'invalid timeline time');
    if (i && time(k) < time(ks[i-1])) err(w+'.'+i,'timeline keys must be in time order');
    if (k.curve === undefined || k.curve === 'stepped') return;
    if(p.is4 && ['c2','c3','c4'].some(f=>has(k,f)))err(w+'.'+i,'normalized c2/c3/c4 controls are invalid in Spine 4.x');
    if (p.curve === 'normalized-number' && typeof k.curve !== 'number') err(w+'.'+i,'Spine 3.8 Bezier curve must be numeric c1 plus c2/c3/c4');
    else if (p.curve !== 'normalized-number' && !Array.isArray(k.curve)) err(w+'.'+i,`${p.key} Bezier curve must be an array`);
    if (Array.isArray(k.curve) && (!k.curve.every(Number.isFinite) || (p.key==='3.7' ? k.curve.length!==4 : k.curve.length%4!==0))) err(w+'.'+i,'invalid Bezier control array');
    if(p.is4 && Array.isArray(k.curve)){
      const type=w.slice(w.lastIndexOf('.')+1);
      const count= /\.ik\./.test(w)?2:/\.transform\./.test(w)?6:/\.slots\./.test(w)?({rgba:4,rgb:3,alpha:1,rgba2:7,rgb2:6}[type]):/\.bones\./.test(w)?({rotate:1,translate:2,scale:2,shear:2,translatex:1,translatey:1,scalex:1,scaley:1,shearx:1,sheary:1}[type]):type==='mix'&&/\.(path|paths)\./.test(w)?3:(['position','spacing'].includes(type)&&/\.(path|paths)\./.test(w))||type==='deform'||/\.deform\./.test(w)||/\.(physics|slider)\./.test(w)?1:undefined;
      if(count && k.curve.length!==count*4)err(w+'.'+i,`expected ${count*4} absolute Bezier numbers`);
    }
  }));
  return {version:p.raw, profile:p, errors, warnings};
}
function assertValid(j) { const v=validateVersion(j); if(v.errors.length) throw new Error(v.errors.join('\n')); return v.profile; }
function normalizedCurve(k, nk, p, channels, where, deform) {
  if (k.curve === undefined || k.curve === 'stepped') return k.curve;
  if (!p.is4) return p.key==='3.7' ? k.curve.slice() : [k.curve,n(k.c2,0),n(k.c3,1),n(k.c4,1)];
  if (!nk) return undefined;
  const dt=time(nk)-time(k); if(!(dt>0)) fail(where,'Bezier segment needs increasing times');
  const curves=channels.map((get,ch)=>{
    const v0=deform?0:get(k), v1=deform?1:get(nk), dv=v1-v0, c=k.curve.slice(ch*4,ch*4+4);
    if(c.length!==4) fail(where,`missing Bezier controls for channel ${ch}`);
    if(Math.abs(dv)<1e-10) {
      if(Math.abs(c[1]-v0)>1e-7 || Math.abs(c[3]-v0)>1e-7) fail(where,'constant endpoint curve has overshoot that cannot be represented by Spine 3.x');
      return [(c[0]-time(k))/dt,0,(c[2]-time(k))/dt,1];
    }
    return [(c[0]-time(k))/dt,(c[1]-v0)/dv,(c[2]-time(k))/dt,(c[3]-v0)/dv];
  });
  const varying=curves.filter((c,ch)=>deform || Math.abs(channels[ch](nk)-channels[ch](k))>1e-10);
  const cv=varying[0] || curves[0];
  for(const c of varying) if(c.some((x,i)=>Math.abs(x-cv[i])>2e-5)) fail(where,'independent channel curves cannot be losslessly collapsed to the shared Spine 3.x curve');
  return cv;
}
function convertKeys(ks, channels, source, target, where, deform=false) {
  return ks.map((k,i)=>{
    const o=Object.assign({},k); delete o.curve; delete o.c2; delete o.c3; delete o.c4;
    if(k.curve===undefined) return o;
    if(k.curve==='stepped') {o.curve='stepped';return o;}
    const nk=ks[i+1]; if(!nk) return o;
    if(source.is4 && target.is4) {o.curve=k.curve.slice();return o;}
    const cv=normalizedCurve(k,nk,source,channels,where+'.'+i,deform);
    if(cv===undefined) return o;
    if(!target.is4) {
      if(target.key==='3.7') o.curve=cv;
      else {o.curve=cv[0];o.c2=cv[1];o.c3=cv[2];o.c4=cv[3];}
    } else {
      const dt=time(nk)-time(k);
      o.curve=channels.flatMap(get=>{
        const v0=deform?0:get(k),v1=deform?1:get(nk),dv=v1-v0;
        return [time(k)+cv[0]*dt,v0+cv[1]*dv,time(k)+cv[2]*dt,v0+cv[3]*dv];
      });
    }
    return o;
  });
}
function rename(o, from, to) { if(has(o,from)) { o[to]=o[from];delete o[from]; } }
function colorGetter(field,ch, fallback) { return k=>parseInt(n(k[field],fallback).slice(ch*2,ch*2+2),16)/255; }
const oldMix=['rotateMix','translateMix','scaleMix','shearMix'];
const newMix=['mixRotate','mixX','mixY','mixScaleX','mixScaleY','mixShearY'];
const mixGetter=f=>k=>n(k[f],f==='mixY'?n(k.mixX,1):1);
function mixRename(c,s,t,pathOnly,where) {
  if(s.is4===t.is4) return;
  if(t.is4) {
    rename(c,'rotateMix','mixRotate'); rename(c,'translateMix','mixX');
    if(has(c,'mixX')) c.mixY=c.mixX;
    if(!pathOnly){rename(c,'scaleMix','mixScaleX');if(has(c,'mixScaleX'))c.mixScaleY=c.mixScaleX;rename(c,'shearMix','mixShearY');}
  } else {
    if(n(c.mixX,1)!==n(c.mixY,n(c.mixX,1)))fail(where,'independent mixX/mixY cannot be downgraded');
    if(!pathOnly && n(c.mixScaleX,1)!==n(c.mixScaleY,n(c.mixScaleX,1)))fail(where,'independent scale mixes cannot be downgraded');
    rename(c,'mixRotate','rotateMix');rename(c,'mixX','translateMix');delete c.mixY;
    if(!pathOnly){rename(c,'mixScaleX','scaleMix');delete c.mixScaleY;rename(c,'mixShearY','shearMix');}
  }
}
const properties=['rotate','x','y','scaleX','scaleY','shearY'];
function constraint43(c,type,upgrade,where) {
  if(type==='ik') {
    if(upgrade){c.scaleY=c.uniform?'uniform':'none';delete c.uniform;}
    else {if(c.scaleY && !['none','uniform'].includes(c.scaleY))fail(where,'volume-preserving IK scaleY requires Spine 4.3');c.uniform=c.scaleY==='uniform';delete c.scaleY;}
  }
  if(type==='path')rename(c,upgrade?'target':'slot',upgrade?'slot':'target');
  if(type==='transform'){
    if(upgrade){
      rename(c,'target','source');c.localSource=c.localTarget=!!c.local;delete c.local;rename(c,'relative','additive');
      c.properties=Object.fromEntries(properties.map(prop=>[prop,{to:{[prop]:{}}}]));
    }else{
      if(c.clamp || !!c.localSource!==!!c.localTarget)fail(where,'clamped or mixed local/world transform mapping requires Spine 4.3');
      for(const [prop,from]of Object.entries(c.properties||{})){
        if(!properties.includes(prop) || n(from.offset,0)!==0 || Object.keys(from.to||{}).length!==1 || !has(from.to,prop))fail(where,'cross-property transform mapping requires Spine 4.3');
        const to=from.to[prop];if(n(to.offset,0)!==0 || n(to.scale,1)!==1)fail(where,'custom transform mapping requires Spine 4.3');
      }
      // Missing properties were disabled in 4.3. Keep their mixes disabled in older profiles.
      const names=['mixRotate','mixX','mixY','mixScaleX','mixScaleY','mixShearY'];
      properties.forEach((prop,i)=>{if(!has(c.properties||{},prop))c[names[i]]=0;});
      rename(c,'source','target');c.local=!!c.localSource;delete c.localSource;delete c.localTarget;rename(c,'additive','relative');delete c.clamp;delete c.properties;
    }
  }
  if(type==='physics'){
    if(!upgrade && c.scaleY && c.scaleY!=='none')fail(where,'physics scaleY requires Spine 4.3');
    if(!upgrade)delete c.scaleY;
    c.inertia=n(c.inertia,upgrade?1:.5);c.damping=n(c.damping,upgrade?1:.85);
  }
}
function required37(j, source) {
  walkKeys(j,(ks,w)=>{if(!w.endsWith('.offsets'))for(const k of ks)k.time=n(k.time,0);});
  for(const a of Object.values(j.animations||{})){
    for(const tls of Object.values(a.bones||{})){
      for(const k of tls.rotate||[])k.angle=n(k.angle,0);
      for(const k of tls.scale||[]){k.x=n(k.x,source?0:1);k.y=n(k.y,source?0:1);}
    }
    for(const tls of Object.values(a.slots||{})){
      for(const k of tls.attachment||[])if(!has(k,'name'))k.name=null;
      for(const k of tls.color||[])k.color=n(k.color,'ffffffff');
      for(const k of tls.twoColor||[]){k.light=n(k.light,'ffffffff');k.dark=n(k.dark,'000000');}
    }
  }
}
function convertVersion(input, rawTarget) {
  const sourceClone=clone(input);if(parseVersion(input).key==='3.7')required37(sourceClone,true);
  const s=assertValid(sourceClone),t=profileOf(rawTarget),j=sourceClone;
  if(s.key===t.key){ j.skeleton.spine=t.raw;return j; }
  // Version-only rewrites are unsafe for features whose solver or JSON changed.
  if(!t.physics && ((j.physics||[]).length || (j.constraints||[]).some(c=>c.type==='physics')))fail('physics','target lacks physics constraints');
  if(t.key==='3.7') {
    for(const sk of skinList(j)) for(const k of ['bones','ik','transform','path','physics','slider','constraints']) if(sk[k] && sk[k].length)fail('skins.'+sk.name,'skin-required bones/constraints require Spine 3.8+');
    for(const b of j.bones||[]) if(b.skin)fail('bones.'+b.name,'skin-required bones require Spine 3.8+');
    for(const c of [...(j.ik||[]),...(j.transform||[]),...(j.path||[])])if(c.skin)fail('constraints.'+c.name,'skin-required constraints require Spine 3.8+');
  }
  if(!t.attachmentTimelines)eachAttachment(j,(a,w)=>{if(a.sequence)fail(w+'.sequence','sequence attachments require Spine 4.1+');});
  for(const b of j.bones||[]) if(s.inherit!==t.inherit)rename(b,s.inherit?'inherit':'transform',t.inherit?'inherit':'transform');
  // Unified constraints are handled after timeline conversion, keeping arrays available below.
  if(s.unifiedConstraints) {
    for(const [constraintIndex,c] of (j.constraints||[]).entries()) {
      if(!['ik','transform','path','physics'].includes(c.type))fail('constraints.'+c.name,'this constraint type cannot be converted by the common-feature profile');
      const o=Object.assign({order:constraintIndex},c);delete o.type;constraint43(o,c.type,false,'constraints.'+c.name);(j[c.type]=j[c.type]||[]).push(o);
    }
    delete j.constraints;
  }
  if(t.key==='3.7')for(const c of [...(j.ik||[]),...(j.transform||[]),...(j.path||[])])if(c.skin)fail('constraints.'+c.name,'skin-required constraints require Spine 3.8+');
  for(const c of j.ik||[])if(t.key==='3.7' && n(c.softness,0)!==0)fail('ik.'+c.name+'.softness','IK softness requires Spine 3.8+');
  for(const c of j.transform||[])mixRename(c,s,t,false,'transform.'+c.name);
  for(const c of j.path||[])mixRename(c,s,t,true,'path.'+c.name);
  eachAttachment(j,(a,w)=>{
    if((a.type==='linkedmesh' || a.parent!==undefined || a.source!==undefined) && s.attachmentTimelines!==t.attachmentTimelines)rename(a,s.attachmentTimelines?'timelines':'deform',t.attachmentTimelines?'timelines':'deform');
    if(s.unifiedConstraints!==t.unifiedConstraints && (a.type==='mesh'||a.type==='linkedmesh')){
      if(!t.unifiedConstraints && a.slot)fail(w,'cross-slot linked meshes require Spine 4.3');
      rename(a,s.unifiedConstraints?'source':'parent',t.unifiedConstraints?'source':'parent');
    }
  });
  for(const [an,a]of Object.entries(j.animations||{})){
    const prefix='animations.'+an;
    if(!t.physics && a.physics && Object.keys(a.physics).length)fail(prefix+'.physics','target lacks physics timelines');
    if(!t.unifiedConstraints && (a.slider || a.drawOrderFolder))fail(prefix,'slider or draw-order-folder timelines require Spine 4.3');
    for(const [bn,tls]of Object.entries(a.bones||{})) for(const [type,ks]of Object.entries(tls)) {
      const w=prefix+'.bones.'+bn+'.'+type;
      if(type==='inherit'){if(!t.inherit)fail(w,'animated inheritance requires Spine 4.2+');continue;}
      if(!['rotate','translate','scale','shear'].includes(type)) {
        if(/^(translate|scale|shear)[xy]$/.test(type) && t.is4)continue;
        fail(w,'unsupported timeline conversion; preserve the source version');
      }
      const getters=type==='rotate'?[k=>n(k[s.is4?'value':'angle'],0)]:[k=>n(k.x,type==='scale'?1:0),k=>n(k.y,type==='scale'?1:0)];
      tls[type]=convertKeys(ks,getters,s,t,w);
      if(type==='rotate' && s.is4!==t.is4) {
        if(!t.is4){for(let i=1;i<ks.length;i++)if(Math.abs(getters[0](ks[i])-getters[0](ks[i-1]))>180+1e-6)fail(w,'rotation segment exceeds 180 degrees; split full turns before downgrading');}
        else {for(let i=1;i<ks.length;i++)if(Math.abs(getters[0](ks[i])-getters[0](ks[i-1]))>180+1e-6)fail(w,'Spine 3.x shortest-arc rotation needs an explicit unwrap before upgrade');}
        tls[type].forEach(k=>rename(k,s.is4?'value':'angle',t.is4?'value':'angle'));
      }
    }
    for(const [sn,tls]of Object.entries(a.slots||{}))for(const [type,ks]of Object.entries(tls)){
      const w=prefix+'.slots.'+sn+'.'+type;if(type==='attachment')continue;
      if(!t.is4 && ['alpha','rgb','rgb2'].includes(type)){
        const other=Object.keys(tls).filter(k=>k!=='attachment' && k!==type);
        if(other.length)fail(w,'overlapping split color/alpha timelines need baking before Spine 3.x conversion');
        const setup=(j.slots||[]).find(slot=>slot.name===sn)||{}, setupColor=n(setup.color,'ffffffff');
        if(type==='alpha'){
          const converted=convertKeys(ks,[k=>n(k.value,1)],s,t,w);
          tls.color=converted.map(k=>{const o=Object.assign({},k);o.color=setupColor.slice(0,6)+Math.round(Math.max(0,Math.min(1,n(k.value,1)))*255).toString(16).padStart(2,'0');delete o.value;return o;});
        }else{
          const getters=type==='rgb'?[0,1,2].map(ch=>colorGetter('color',ch,'ffffff')):[...[0,1,2].map(ch=>colorGetter('light',ch,'ffffff')),...[0,1,2].map(ch=>colorGetter('dark',ch,'000000'))];
          const converted=convertKeys(ks,getters,s,t,w);
          if(type==='rgb')tls.color=converted.map(k=>Object.assign({},k,{color:n(k.color,'ffffff').slice(0,6)+setupColor.slice(6,8)}));
          else tls.twoColor=converted.map(k=>Object.assign({},k,{light:n(k.light,'ffffff').slice(0,6)+setupColor.slice(6,8),dark:n(k.dark,'000000')}));
        }
        delete tls[type];continue;
      }
      let getters;
      if(type==='color'||type==='rgba')getters=[0,1,2,3].map(ch=>colorGetter('color',ch,'ffffffff'));
      else if(type==='twoColor'||type==='rgba2')getters=[...[0,1,2,3].map(ch=>colorGetter('light',ch,'ffffffff')),...[0,1,2].map(ch=>colorGetter('dark',ch,'000000'))];
      else if(t.is4 && ['rgb','rgb2','alpha'].includes(type))continue;
      else fail(w,'split color/alpha timelines cannot be downgraded without baking');
      const dest=t.is4?(type==='color'?'rgba':type==='twoColor'?'rgba2':type):(type==='rgba'?'color':type==='rgba2'?'twoColor':type);
      tls[dest]=convertKeys(ks,getters,s,t,w);if(dest!==type)delete tls[type];
    }
    for(const [name,ks]of Object.entries(a.ik||{})){
      const w=prefix+'.ik.'+name;if(t.key==='3.7' && ks.some(k=>n(k.softness,0)!==0))fail(w,'IK softness requires Spine 3.8+');
      a.ik[name]=convertKeys(ks,s.is4?[k=>n(k.mix,1),k=>n(k.softness,0)]:[k=>n(k.mix,1)],s,t,w);
      if(t.is4 && !s.is4) { // 3.8 curves drive both mix and softness.
        a.ik[name]=convertKeys(ks,[k=>n(k.mix,1),k=>n(k.softness,0)],s,t,w);
      }
    }
    for(const [name,ks]of Object.entries(a.transform||{})){
      const w=prefix+'.transform.'+name;
      const getters=(s.is4?newMix:oldMix).map(mixGetter);
      a.transform[name]=convertKeys(ks,getters,s,t,w);
      if(t.is4&&!s.is4) {
        const expanded=[oldMix[0],oldMix[1],oldMix[1],oldMix[2],oldMix[2],oldMix[3]].map(f=>k=>n(k[f],1));
        a.transform[name]=convertKeys(ks,expanded,s,t,w);
      }
      for(const k of a.transform[name])mixRename(k,s,t,false,w);
    }
    const paths=a.paths || a.path || {};
    for(const [name,tls]of Object.entries(paths))for(const [type,ks]of Object.entries(tls)){
      const w=prefix+'.paths.'+name+'.'+type;
      const getters=type==='mix'?(s.is4?['mixRotate','mixX','mixY']:['rotateMix','translateMix']).map(mixGetter):[k=>n(k[s.is4?'value':type],0)];
      tls[type]=convertKeys(ks,getters,s,t,w);
      if(type==='mix'){
        if(t.is4&&!s.is4)tls[type]=convertKeys(ks,['rotateMix','translateMix','translateMix'].map(f=>k=>n(k[f],1)),s,t,w);
        for(const k of tls[type])mixRename(k,s,t,true,w);
      }
      if(s.is4!==t.is4 && (type==='position'||type==='spacing'))for(const k of tls[type])rename(k,s.is4?'value':type,t.is4?'value':type);
    }
    if(Object.keys(paths).length){a[t.is4?'path':'paths']=paths;delete a[t.is4?'paths':'path'];}
    const deform={};
    if(s.attachmentTimelines){for(const [skin,slots]of Object.entries(a.attachments||{}))for(const [slot,atts]of Object.entries(slots))for(const [att,tls]of Object.entries(atts)){
      if(!t.attachmentTimelines && Object.keys(tls).some(k=>k!=='deform'))fail(prefix+'.attachments.'+skin+'.'+slot+'.'+att,'sequence or other attachment timelines require Spine 4.1+');
      if(tls.deform){((deform[skin]=deform[skin]||{})[slot]=deform[skin][slot]||{})[att]=tls.deform;}
    }}else Object.assign(deform,a.deform||{});
    for(const [skin,slots]of Object.entries(deform))for(const [slot,atts]of Object.entries(slots))for(const [att,ks]of Object.entries(atts)){
      const conv=convertKeys(ks,[()=>0],s,t,prefix+'.deform.'+skin+'.'+slot+'.'+att,true);
      if(t.attachmentTimelines){a.attachments=a.attachments||{};const dest=((a.attachments[skin]=a.attachments[skin]||{})[slot]=a.attachments[skin][slot]||{});dest[att]=dest[att]||{};dest[att].deform=conv;}
      else {a.deform=a.deform||{};((a.deform[skin]=a.deform[skin]||{})[slot]=a.deform[skin][slot]||{})[att]=conv;}
    }
    delete a[t.attachmentTimelines?'deform':'attachments'];
    if(a.draworder){if(a.drawOrder)fail(prefix,'both draworder and drawOrder present');a.drawOrder=a.draworder;delete a.draworder;}
  }
  if(s.arraySkins!==t.arraySkins)j.skins=t.arraySkins?skinList(j):Object.fromEntries(skinList(j).map(sk=>[sk.name,sk.attachments||{}]));
  if(t.unifiedConstraints){j.constraints=[];for(const type of ['ik','transform','path','physics']){for(const c of j[type]||[]){constraint43(c,type,true,type+'.'+c.name);j.constraints.push(Object.assign({type},c));}delete j[type];}j.constraints.sort((a,b)=>n(a.order,0)-n(b.order,0));}
  if(t.key==='3.7')required37(j,false);
  j.skeleton.spine=t.raw;
  assertValid(j);return j;
}
module.exports={SUPPORTED,LATEST_STABLE,parseVersion,profileOf,validateVersion,convertVersion};
