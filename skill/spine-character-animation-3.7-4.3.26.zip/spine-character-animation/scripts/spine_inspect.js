#!/usr/bin/env node
// spine_inspect.js — analyse a Spine JSON (3.8 / 4.x) and print a compact, agent-readable report:
// skeleton structure, spine path, constraints, pseudo-3D rigs, chains (lag / amplitude growth),
// blink events, loop rhythm (grid alignment, cycles), independent scene groups.
//
// Usage:
//   node spine_inspect.js <file.json|dir> [--anim NAME] [--fps 30] [--json] [--tree]
'use strict';
const C = require('./spine_core');
const R = require('./spine_render');

function parseArgs(argv) {
  const o = { fps: 30, json: false, tree: false };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--anim') o.anim = argv[++i];
    else if (a === '--fps') o.fps = +argv[++i];
    else if (a === '--json') o.json = true;
    else if (a === '--tree') o.tree = true;
    else rest.push(a);
  }
  o.input = rest[0];
  return o;
}

function spinePath(m) {
  const size = new Map();
  const sz = n => { if (size.has(n)) return size.get(n); const s = 1 + m.kids.get(n).reduce((a, k) => a + sz(k), 0); size.set(n, s); return s; };
  const root = m.bones.find(b => !b.parent);
  const out = [];
  let cur = root.name;
  for (let guard = 0; guard < 16; guard++) {
    const ks = m.kids.get(cur).slice().sort((a, b) => sz(b) - sz(a));
    if (!ks.length || sz(ks[0]) < m.bones.length * 0.15) break;
    cur = ks[0];
    out.push(cur);
  }
  return { root: root.name, path: out, size: sz };
}

function analyseAnim(m, name, anim, fps) {
  const dur = C.animDuration(anim), nf = Math.round(dur * fps);
  const version = m.version;
  const res = { name, durationSec: C.r2(dur), frames: nf, boneTimelines: 0, curve: {}, grid: {}, loopBreaks: [], hiddenSeamBreaks: [], blink: [], chains: [], slotTimelines: {}, deform: 0, drawOrderKeys: 0, events: (anim.events || []).length, period: null };
  const seamVis = new Map(); // bone -> visible at loop seam (cached)
  const isVisible = bn => { if (!seamVis.has(bn)) seamVis.set(bn, C.visibleAtSeam(m, anim, bn, dur)); return seamVis.get(bn); };
  const keyFrames = [];
  const sig = new Map(); // bone -> {rotate: samples}
  for (const [bn, tls] of Object.entries(anim.bones || {})) {
    for (const [type, keys] of Object.entries(tls)) {
      const ch = C.channelsOfBoneTimeline(type, keys, version);
      if (!ch) continue;
      res.boneTimelines++;
      for (const [cn, ks] of Object.entries(ch.channels)) {
        // curve stats only for segments that change value (a hold / placeholder key has no meaningful easing)
        ks.forEach((k, i) => { if (cn === Object.keys(ch.channels)[0]) keyFrames.push(Math.round(k.t * fps)); if (i < ks.length - 1 && Math.abs(ks[i + 1].v - k.v) > 1e-6) { const c = C.curveClass(k.cv); res.curve[c] = (res.curve[c] || 0) + 1; } });
        if (ks.length >= 2 && nf > 0) {
          const a = C.evalChannel(ks, 0), b = C.evalChannel(ks, dur);
          const tol = ch.kind === 'scale' ? 0.02 : 0.5; // below this the pop is not visible
          if (Math.abs(a - b) > tol) {
            const msg = `${bn}.${type}.${cn} start=${C.r2(a)} end=${C.r2(b)}`;
            const d = Math.abs(a - b) % 360;
            const symTurn = ch.kind === 'rotate' && (Math.min(d % 90, 90 - (d % 90)) < 0.5); // 90/180/270/360°: seamless only for symmetric shapes (gears, rings)
            // one-way particle respawning while invisible = valid; otherwise a visible pop
            if (!isVisible(bn)) res.hiddenSeamBreaks.push(msg);
            else if (symTurn) (res.symmetricTurns = res.symmetricTurns || []).push(msg);
            else res.loopBreaks.push(msg);
          }
        }
        if (ch.kind === 'rotate') { if (!sig.has(bn)) sig.set(bn, {}); sig.get(bn).rotate = C.sampleChannel(ks, dur, fps); }
        if (ch.kind === 'translate' || ch.kind === 'scale') { if (!sig.has(bn)) sig.set(bn, {}); sig.get(bn)[`${ch.kind}.${cn}`] = C.sampleChannel(ks, dur, fps); }
      }
    }
  }
  if (keyFrames.length) for (const g of [5, 10, 20]) res.grid[`${g}f`] = Math.round(keyFrames.filter(f => f % g === 0).length / keyFrames.length * 100) + '%';
  // dominant period of the most-moving body bone
  const sp = spinePath(m).path;
  for (const bn of sp) { const s = sig.get(bn); if (!s) continue; const any = s.rotate || s['translate.y'] || s['translate.x']; if (any && C.ptp(any) > 0.2) { res.period = C.period(any); res.periodBone = bn; break; } }
  // chains
  for (const c of C.chainsOf(m, 3)) {
    const rows = c.map(n => ({ n, s: sig.get(n) && sig.get(n).rotate })).filter(x => x.s);
    if (rows.length < 2) continue;
    const amps = rows.map(x => C.ptp(x.s));
    if (amps[0] < 0.2 && amps[amps.length - 1] < 0.5) continue;
    const per = C.period(rows[0].s) || nf;
    const lags = [];
    for (let i = 1; i < rows.length; i++) { const r = C.bestLag(rows[i - 1].s, rows[i].s, Math.floor(per / 2)); lags.push(r && r.corr > 0.6 ? r.lag : null); }
    const slots = [...new Set(c.flatMap(n => [...(m.boneSlots.get(n) || [])].map(s => s.split('/')[0])))].slice(0, 3);
    res.chains.push({ bones: rows.map(x => x.n), slots, period: per, ampDeg: amps.map(C.r2), lagFrames: lags, ampRatio: amps.slice(1).map((a, i) => C.r2(a / Math.max(1e-6, amps[i]))) });
  }
  // slot timelines
  for (const [sn, tl] of Object.entries(anim.slots || {})) for (const k of Object.keys(tl)) res.slotTimelines[k] = (res.slotTimelines[k] || 0) + 1;
  const deforms = C.deformTimelines(anim);
  res.deform = deforms.length;
  res.drawOrderKeys = (anim.drawOrder || anim.draworder || []).length;
  // blink candidates: short pulses (<= 20f) in deform / bone scale / translate / attachment that co-occur
  const pulses = [];
  const pulseOf = (s, label) => {
    const mx = Math.max(...s.map(Math.abs));
    if (mx < 1e-6) return;
    const on = s.map(v => Math.abs(v) > mx * 0.15);
    const segs = [];
    let st = -1;
    for (let i = 0; i <= on.length; i++) { const x = i < on.length && on[i]; if (x && st < 0) st = i; if (!x && st >= 0) { segs.push([st, i]); st = -1; } }
    const active = segs.reduce((a, [x, y]) => a + y - x, 0);
    // short standalone clips (e.g. an overlay "blink" of 6–20f) are one event by definition
    const shortClip = nf <= 24;
    if (segs.length && segs.every(([x, y]) => y - x <= 20) && (shortClip || active <= nf * 0.3)) segs.forEach(sg => pulses.push({ a: sg[0], b: sg[1], label }));
  };
  for (const [bn, s] of sig) {
    if (s['scale.x']) pulseOf(s['scale.x'].map(v => v - 1), `${bn}.scaleX`);
    if (s['scale.y']) pulseOf(s['scale.y'].map(v => v - 1), `${bn}.scaleY`);
    if (s['translate.y'] && C.ptp(s['translate.y']) > 1) pulseOf(s['translate.y'], `${bn}.translateY`);
  }
  for (const { slot: sn, keys } of deforms) {
    const ks = keys.map((k, i) => ({ t: C.T(k), v: (k.vertices || []).reduce((s, x) => s + Math.abs(x), 0), cv: C.deformCurve(k, keys[i + 1], version) }));
    pulseOf(C.sampleChannel(ks, dur, fps), `deform:${sn}`);
  }
  for (const [sn, tl] of Object.entries(anim.slots || {})) if (tl.attachment) {
    const setup = (m.slotByName.get(sn) || {}).attachment || null;
    let cur = setup, from = 0;
    const evs = tl.attachment.map(k => ({ f: Math.round(C.T(k) * fps), n: k.name }));
    for (const e of evs.concat([{ f: nf, n: '__end' }])) { if (cur !== setup && e.f - from <= 15 && e.f > from) pulses.push({ a: from, b: e.f, label: `attachment:${sn}=${cur}` }); cur = e.n; from = e.f; }
  }
  pulses.sort((x, y) => x.a - y.a);
  const groups = [];
  for (const p of pulses) { let g = groups.find(g => Math.abs(g.a - p.a) <= 4); if (!g) { g = { a: p.a, b: p.b, parts: [] }; groups.push(g); } g.b = Math.max(g.b, p.b); g.parts.push(p.label); }
  const eyeRe = /(biyan|zhayan|blink|yan|eye|lid|lash|jiemao|yanpi|yanbai|yanzhu|yanqiu|tongkong|white|pupil|iris|mei|brow|close)/i;
  res.blink = groups.filter(g => g.parts.length >= 2 || g.parts.some(x => eyeRe.test(x))).map(g => ({ startF: g.a, endF: g.b, frames: g.b - g.a, parts: [...new Set(g.parts)].slice(0, 6) }));
  return res;
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  if (!o.input) { console.error('usage: node spine_inspect.js <file.json|dir> [--anim NAME] [--fps 30] [--json] [--tree]'); process.exit(1); }
  const file = C.resolveJson(o.input);
  const j = C.readJson(file);
  const m = C.buildModel(j);
  const fps = o.fps || (j.skeleton && j.skeleton.fps) || 30;
  const sp = spinePath(m);
  const animated = new Set(Object.values(j.animations || {}).flatMap(a => Object.keys(a.bones || {})));
  const generic = m.bones.filter(b => /^(bone|骨骼)?_?\d+$|_spine_?\d+[a-z]?$|^bone\d*$/i.test(b.name)).length;
  const rootKids = m.kids.get(sp.root);
  const report = {
    file, spine: m.version.raw,
    size: (() => { const b = R.boundsOf(j); const given = j.skeleton && j.skeleton.height > 0; return { w: C.r2(b.width), h: C.r2(b.height), x: C.r2(b.x), y: C.r2(b.y), source: given ? 'skeleton' : 'computed (skeleton bounds missing in file)' }; })(),
    counts: { bones: m.bones.length, slots: m.slots.length, ik: C.constraintsOf(j, 'ik').length, transform: C.constraintsOf(j, 'transform').length, path: C.constraintsOf(j, 'path').length, physics: C.constraintsOf(j, 'physics').length, skins: C.skinsOf(j).length, meshes: m.meshes.length, weightedMeshes: m.meshes.filter(x => x.weighted).length, animations: Object.keys(j.animations || {}).length },
    naming: { genericBoneShare: C.r2(generic / Math.max(1, m.bones.length)), advice: generic / m.bones.length > 0.5 ? 'mostly generic names (bone12 / X_spine_34): rename to semantic names before editing' : 'semantic names' },
    hierarchy: {
      maxDepth: Math.max(...m.bones.map(b => m.depth(b.name))),
      spinePath: sp.path,
      rootChildren: rootKids.map(n => ({ bone: n, subtreeBones: sp.size(n), animatedInSubtree: [n, ...m.bones.filter(b => m.ancestors(b.name).includes(n)).map(b => b.name)].filter(x => animated.has(x)).length })),
      inheritModes: m.bones.filter(b => b.transform && b.transform !== 'normal' || b.inherit && b.inherit !== 'normal').reduce((acc, b) => { const k = b.transform || b.inherit; acc[k] = (acc[k] || 0) + 1; return acc; }, {}),
    },
    constraints: {
      ik: C.constraintsOf(j, 'ik').map(c => ({ name: c.name, bones: c.bones, target: c.target, targetParent: m.byName.get(c.target).parent, mix: c.mix === undefined ? 1 : c.mix, bendPositive: c.bendPositive !== false })),
      transform: C.constraintsOf(j, 'transform').map(c => ({ name: c.name, bones: c.bones, target: c.source || c.target, properties: c.properties, mix: { r: c.rotateMix ?? c.mixRotate ?? 1, x: c.translateMix ?? c.mixX ?? 1, y: c.translateMix ?? c.mixY ?? c.mixX ?? 1, s: c.scaleMix ?? c.mixScaleX ?? 1 } })),
      path: C.constraintsOf(j, 'path').map(c => ({ name: c.name, bones: c.bones, target: c.slot || c.target })),
      physics: C.constraintsOf(j, 'physics').map(c => ({ name: c.name, bone: c.bone, inertia: c.inertia, strength: c.strength, damping: c.damping })),
    },
    slots: { blend: m.slots.filter(s => s.blend && s.blend !== 'normal').map(s => `${s.name}:${s.blend}`), hiddenAtSetup: m.slots.filter(s => !s.attachment).map(s => s.name).slice(0, 40) },
    animations: [],
  };
  // pseudo-3D rigs: translate-only transform constraints, negative mix = mirrored
  report.constraints.pseudo3D = report.constraints.transform.filter(t => t.mix.r === 0 && t.mix.s === 0 && t.mix.x !== 0).map(t => `${t.target} -> ${t.bones.join(',')} @${t.mix.x}`);
  const anims = Object.entries(j.animations || {}).filter(([n]) => !o.anim || n === o.anim);
  for (const [n, a] of anims) report.animations.push(analyseAnim(m, n, a, fps));
  if (o.json) { console.log(JSON.stringify(report, null, 1)); return; }
  // ---------- text output ----------
  const L = [];
  L.push(`# ${report.file}`);
  L.push(`spine ${report.spine} | size ${report.size.w}x${report.size.h} @(${report.size.x},${report.size.y})${report.size.source === 'skeleton' ? '' : ' [' + report.size.source + ']'} | ${Object.entries(report.counts).map(([k, v]) => `${k}=${v}`).join(' ')}`);
  L.push(`naming: generic share ${report.naming.genericBoneShare} -> ${report.naming.advice}`);
  L.push(`hierarchy: maxDepth=${report.hierarchy.maxDepth} spinePath=${report.hierarchy.spinePath.join(' > ')}`);
  L.push(`root children: ${report.hierarchy.rootChildren.map(r => `${r.bone}(${r.subtreeBones}b,${r.animatedInSubtree}a)`).join(', ')}`);
  L.push(`inherit modes: ${JSON.stringify(report.hierarchy.inheritModes)}`);
  if (report.constraints.ik.length) L.push(`IK: ${report.constraints.ik.map(c => `${c.name}[${c.bones.join('+')}]->${c.target}(parent ${c.targetParent}) mix${c.mix}${c.bendPositive ? '' : ' bend-'}`).join(' | ')}`);
  if (report.constraints.pseudo3D.length) L.push(`pseudo-3D translate rigs: ${report.constraints.pseudo3D.join(' | ')}`);
  if (report.constraints.path.length) L.push(`path: ${report.constraints.path.map(p => `${p.name}[${p.bones.length}]->${p.target}`).join(' | ')}`);
  if (report.constraints.physics.length) L.push(`physics: ${report.constraints.physics.map(p => p.bone).join(', ')}`);
  if (report.slots.blend.length) L.push(`blend slots: ${report.slots.blend.join(', ')}`);
  for (const a of report.animations) {
    L.push(`\n## ${a.name}: ${a.durationSec}s = ${a.frames}f | period ${a.period ? a.period + 'f (' + C.r2(a.frames / a.period) + ' cycles, ref ' + a.periodBone + ')' : 'n/a'} | bone timelines ${a.boneTimelines} | deform ${a.deform} | drawOrder keys ${a.drawOrderKeys} | events ${a.events}`);
    L.push(`grid alignment ${JSON.stringify(a.grid)} | curves ${JSON.stringify(a.curve)} | slot timelines ${JSON.stringify(a.slotTimelines)}`);
    L.push(`loop breaks (start != end, visible at seam): ${a.loopBreaks.length}${a.loopBreaks.length ? ' e.g. ' + a.loopBreaks.slice(0, 5).join('; ') : ''}${a.hiddenSeamBreaks.length ? ` | ${a.hiddenSeamBreaks.length} more on parts hidden at the seam (one-way particles, OK)` : ''}${a.symmetricTurns ? ` | ${a.symmetricTurns.length} rotations end on a 90° multiple (OK only if the shape is rotationally symmetric): ${a.symmetricTurns.slice(0, 2).join('; ')}` : ''}`);
    L.push(`blinks: ${a.blink.length ? a.blink.map(b => `[${b.startF}-${b.endF}] ${b.frames}f {${b.parts.join(', ')}}`).join('  ') : 'none detected'}`);
    L.push(`chains (${a.chains.length}):`);
    for (const c of a.chains.slice(0, 40)) L.push(`  ${c.bones.join('>')} <${c.slots.join(',')}> period ${c.period}f amp° [${c.ampDeg}] ratio [${c.ampRatio}] lag f [${c.lagFrames}]`);
    if (a.chains.length > 40) L.push(`  ... ${a.chains.length - 40} more`);
  }
  if (o.tree) {
    L.push('\n## TREE');
    const walk = (n, d) => { const b = m.byName.get(n); L.push(`${'  '.repeat(d)}${n}${b.length ? ' L' + C.r2(b.length) : ''}${animated.has(n) ? ' *' : ''}${(m.boneSlots.get(n) || new Set()).size ? ' <' + [...m.boneSlots.get(n)].filter(s => !s.includes('/')).slice(0, 3).join(',') + '>' : ''}`); for (const k of m.kids.get(n)) walk(k, d + 1); };
    walk(sp.root, 0);
  }
  console.log(L.join('\n'));
}

if (require.main === module) main();
module.exports = { analyseAnim, spinePath };
