#!/usr/bin/env node
// psd_layers.js — dependency-free PSD/PSB layer reader for Spine rigging prep.
// Lists every layer (index, group path, name, bounds, size, opacity, visibility, blend) as TEXT and
// can render ONE numbered contact sheet of all layers, so an agent never needs to view layers one
// by one (agent platforms cap the number of images per conversation). Can also export layers as PNG.
//
// Usage:
//   node psd_layers.js <file.psd>                        # text table (default)
//   node psd_layers.js <file.psd> --json                 # JSON metadata
//   node psd_layers.js <file.psd> --sheet out/layers     # ONE contact sheet PNG (≤60 layers/page, --page N)
//   node psd_layers.js <file.psd> --composite out/comp   # flattened preview of visible layers (1 PNG)
//   node psd_layers.js <file.psd> --export out/images    # every pixel layer → <name>.png (for Spine import)
//   node psd_layers.js <file.psd> --select 9-30,32-108 --export out/warrior/images
//      Select original table indices; selected exports use <index>_<name>.png, including duplicates.
// Supports 8-bit RGB(A) and grayscale, raw and RLE channel compression. 16/32-bit and ZIP-compressed
// layers are listed but not decoded (marked "undecoded").
'use strict';
const fs = require('fs');
const path = require('path');
const R = require('./spine_render'); // PNG encoder, canvas + bitmap font

function readPSD(file) {
  const b = fs.readFileSync(file);
  let p = 0;
  const u8 = () => b[p++], u16 = () => { const v = b.readUInt16BE(p); p += 2; return v; }, i16 = () => { const v = b.readInt16BE(p); p += 2; return v; };
  const u32 = () => { const v = b.readUInt32BE(p); p += 4; return v; }, i32 = () => { const v = b.readInt32BE(p); p += 4; return v; };
  if (b.toString('ascii', 0, 4) !== '8BPS') throw new Error('not a PSD file');
  p = 4;
  const version = u16(); // 1 = PSD, 2 = PSB
  const len = () => (version === 2 ? Number(b.readBigUInt64BE((p += 8) - 8)) : u32());
  p += 6;
  const channels = u16(), height = u32(), width = u32(), depth = u16(), mode = u16();
  // NB: `p += u32()` would read p BEFORE u32() advances it — always read the length first.
  const cmLen = u32(); p += cmLen; // color mode data
  const irLen = u32(); p += irLen; // image resources
  const lmLen = len(), lmEnd = p + lmLen;
  const layers = [];
  if (lmLen > 0) {
    const liLen = len(), liEnd = p + liLen;
    if (liLen > 0) {
      let count = i16();
      const hasMergedAlpha = count < 0;
      count = Math.abs(count);
      for (let i = 0; i < count; i++) {
        const top = i32(), left = i32(), bottom = i32(), right = i32();
        const nch = u16();
        const chans = [];
        for (let c = 0; c < nch; c++) chans.push({ id: i16(), len: len() });
        p += 4; // blend signature
        const blend = b.toString('ascii', p, p + 4); p += 4;
        const opacity = u8(), clipping = u8(), flags = u8(); p += 1;
        const extraLen = u32(), extraEnd = p + extraLen;
        const maskLen = u32();
        p += maskLen;
        const brLen = u32();
        p += brLen;
        const nlen = u8();
        let name = b.toString('latin1', p, p + nlen);
        p += ((nlen + 1 + 3) & ~3) - 1; // pascal string padded to 4 incl. length byte
        let sectionType = 0;
        while (p + 12 <= extraEnd) { // tagged blocks
          const sig = b.toString('ascii', p, p + 4); if (sig !== '8BIM' && sig !== '8B64') break; p += 4;
          const key = b.toString('ascii', p, p + 4); p += 4;
          const big = version === 2 && ['LMsk', 'Lr16', 'Lr32', 'Layr', 'Mt16', 'Mt32', 'Mtrn', 'Alph', 'FMsk', 'lnk2', 'FEid', 'FXid', 'PxSD'].includes(key);
          const blen = big ? Number(b.readBigUInt64BE((p += 8) - 8)) : u32();
          const bstart = p;
          if (key === 'luni') { const n = b.readUInt32BE(p); name = ''; for (let k = 0; k < n; k++) name += String.fromCharCode(b.readUInt16BE(p + 4 + k * 2)); }
          if (key === 'lsct' || key === 'lsdk') sectionType = b.readUInt32BE(p);
          p = bstart + blen;
        }
        p = extraEnd;
        layers.push({ top, left, bottom, right, width: right - left, height: bottom - top, chans, blend, opacity, clipping, hidden: !!(flags & 2), name, sectionType, hasMergedAlpha });
      }
      // channel image data, in layer order
      for (const L of layers) {
        L.data = {};
        for (const ch of L.chans) {
          const start = p, comp = u16();
          const w = ch.id === -2 ? 0 : L.width, h = ch.id === -2 ? 0 : L.height;
          if (w > 0 && h > 0 && depth === 8) {
            if (comp === 0) L.data[ch.id] = b.subarray(p, p + w * h);
            else if (comp === 1) {
              const counts = [];
              for (let y = 0; y < h; y++) counts.push(version === 2 ? u32() : u16());
              const out = Buffer.alloc(w * h);
              let o = 0;
              for (let y = 0; y < h; y++) {
                const end = p + counts[y];
                let x = 0;
                while (p < end && x < w) {
                  const n = b.readInt8(p++);
                  if (n >= 0) { b.copy(out, o + x, p, p + n + 1); p += n + 1; x += n + 1; }
                  else if (n !== -128) { out.fill(b[p++], o + x, o + x + 1 - n); x += 1 - n; }
                }
                p = end; o += w;
              }
              L.data[ch.id] = out;
            } else L.undecoded = `compression ${comp}`;
          } else if (w > 0 && h > 0) L.undecoded = `${depth}-bit`;
          p = start + ch.len;
        }
      }
      p = liEnd;
    }
  }
  p = lmEnd;
  // group paths: PSD stores layers bottom→top; groups are closed by a "bounding section divider" (3)
  // that comes BEFORE (below) the group's layers, and opened by the folder record (1/2) above them.
  const stack = [];
  for (let i = layers.length - 1; i >= 0; i--) { // top → bottom
    const L = layers[i];
    if (L.sectionType === 1 || L.sectionType === 2) { L.group = stack.join('/'); stack.push(L.name); L.isGroup = true; continue; }
    if (L.sectionType === 3) { stack.pop(); L.isDivider = true; continue; }
    L.group = stack.join('/');
  }
  return { version, channels, width, height, depth, mode, layers };
}

// layer → RGBA Uint8Array (straight alpha), or null
function layerRGBA(L, mode) {
  if (!L.width || !L.height || L.undecoded) return null;
  const n = L.width * L.height, out = new Uint8Array(n * 4);
  const r = L.data[0], g = mode === 3 ? L.data[1] : L.data[0], bl = mode === 3 ? L.data[2] : L.data[0], a = L.data[-1];
  if (!r) return null;
  for (let i = 0; i < n; i++) { out[i * 4] = r[i]; out[i * 4 + 1] = g ? g[i] : r[i]; out[i * 4 + 2] = bl ? bl[i] : r[i]; out[i * 4 + 3] = a ? a[i] : 255; }
  return out;
}

const safe = s => s.replace(/[\\/:*?"<>|\s]+/g, '_').replace(/^_+|_+$/g, '') || 'layer';

function selectLayers(layers, selection) {
  if (selection === undefined) return layers;
  const indices = new Set();
  for (const token of selection.split(',')) {
    const m = /^(\d+)(?:-(\d+))?$/.exec(token.trim());
    if (!m) throw new Error(`invalid --select token: ${token}`);
    const a = Number(m[1]), b = m[2] === undefined ? a : Number(m[2]);
    if (b < a || b - a > layers.length) throw new Error(`invalid --select range: ${token}`);
    for (let i = a; i <= b; i++) indices.add(i);
  }
  const available = new Set(layers.map(L => L.index));
  for (const i of indices) if (!available.has(i)) throw new Error(`--select index ${i} is not a pixel layer`);
  return layers.filter(L => indices.has(L.index));
}

function main() {
  const args = process.argv.slice(2);
  if (!args[0]) { console.error(fs.readFileSync(__filename, 'utf8').split('\n').slice(1, 20).filter(l => l.startsWith('//')).map(l => l.replace(/^\/\/ ?/, '')).join('\n')); process.exit(2); }
  const opt = {};
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--json') opt.json = true;
    else if (args[i] === '--sheet') opt.sheet = args[++i];
    else if (args[i] === '--composite') opt.composite = args[++i];
    else if (args[i] === '--export') opt.export = args[++i];
    else if (args[i] === '--page') opt.page = +args[++i];
    else if (args[i] === '--select') { opt.select = args[++i]; if (!opt.select) throw new Error('--select requires an index list'); }
  }
  const psd = readPSD(args[0]);
  const pix = selectLayers(psd.layers.map((L, i) => Object.assign(L, { index: i })).filter(L => !L.isGroup && !L.isDivider), opt.select);
  if (opt.json) { console.log(JSON.stringify({ width: psd.width, height: psd.height, depth: psd.depth, mode: psd.mode, layers: pix.map(L => ({ index: L.index, group: L.group, name: L.name, left: L.left, top: L.top, width: L.width, height: L.height, opacity: L.opacity, hidden: L.hidden, blend: L.blend, clipping: L.clipping, undecoded: L.undecoded || undefined })) }, null, 1)); return; }
  console.log(`# ${path.basename(args[0])}  ${psd.width}x${psd.height}  ${psd.depth}-bit mode ${psd.mode}  ${pix.length} layers (${psd.layers.filter(L => L.isGroup).length} groups)  — index 0 = bottom`);
  console.log('index\tgroup/name\tx,y(top-left)\tw x h\topacity\tflags');
  for (const L of pix) console.log(`${L.index}\t${L.group ? L.group + '/' : ''}${L.name}\t${L.left},${L.top}\t${L.width}x${L.height}\t${Math.round(L.opacity / 2.55)}%\t${[L.hidden ? 'hidden' : '', L.clipping ? 'clip' : '', L.blend !== 'norm' ? L.blend : '', L.undecoded ? 'undecoded:' + L.undecoded : '', !L.width ? 'empty' : ''].filter(Boolean).join(',')}`);
  if (opt.export) {
    fs.mkdirSync(opt.export, { recursive: true });
    const used = new Map();
    let nOut = 0;
    for (const L of pix) {
      const rgba = layerRGBA(L, psd.mode);
      if (!rgba) continue;
      let base = safe(L.name);
      const k = (used.get(base) || 0) + 1; used.set(base, k);
      if (k > 1) base += `_${k}`;
      if (opt.select !== undefined) base = String(L.index).padStart(3, '0') + '_' + base;
      fs.writeFileSync(path.join(opt.export, base + '.png'), R.encodePNG(L.width, L.height, rgba));
      nOut++;
    }
    console.log(`exported ${nOut} layer PNGs to ${opt.export}`);
  }
  if (opt.composite) {
    const W = psd.width, H = psd.height, acc = new Float32Array(W * H * 4);
    for (const L of pix) { // bottom → top, normal blending, visible only
      if (L.hidden) continue;
      const rgba = layerRGBA(L, psd.mode);
      if (!rgba) continue;
      const op = L.opacity / 255;
      for (let y = 0; y < L.height; y++) { const Y = L.top + y; if (Y < 0 || Y >= H) continue; for (let x = 0; x < L.width; x++) { const X = L.left + x; if (X < 0 || X >= W) continue; const s = (y * L.width + x) * 4, d = (Y * W + X) * 4, a = rgba[s + 3] / 255 * op; if (a <= 0) continue; for (let c = 0; c < 3; c++) acc[d + c] = rgba[s + c] * a + acc[d + c] * (1 - a); acc[d + 3] = a + acc[d + 3] * (1 - a); } }
    }
    const scale = Math.min(1, 1200 / Math.max(W, H)), w = Math.max(1, Math.round(W * scale)), h = Math.max(1, Math.round(H * scale));
    const cv = R.makeCanvas(w, h, [0.47, 0.47, 0.5]);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const d = (Math.min(H - 1, Math.floor(y / scale)) * W + Math.min(W - 1, Math.floor(x / scale))) * 4, a = acc[d + 3], o = (y * w + x) * 3; for (let c = 0; c < 3; c++) cv.c[o + c] = (acc[d + c] / 255) + cv.c[o + c] * (1 - a); }
    fs.mkdirSync(path.dirname(path.resolve(opt.composite + '_composite.png')), { recursive: true });
    R.savePNG(cv, opt.composite + '_composite.png');
    console.log(`wrote ${opt.composite}_composite.png ${w}x${h}`);
  }
  if (opt.sheet) {
    const vis = pix.filter(L => L.width > 0 && !L.undecoded);
    const per = 60, page = Math.max(0, (opt.page || 1) - 1), pages = Math.ceil(vis.length / per), list = vis.slice(page * per, page * per + per);
    const cols = 10, cell = 120, head = 14, pad = 3;
    const rows = Math.max(1, Math.ceil(list.length / cols));
    const cv = R.makeCanvas(cols * (cell + pad) + pad, rows * (cell + head + pad) + pad, [0.28, 0.29, 0.32]);
    list.forEach((L, k) => {
      const x0 = pad + (k % cols) * (cell + pad), y0 = pad + Math.floor(k / cols) * (cell + head + pad);
      const W = cv.W;
      for (let y = 0; y < cell; y++) for (let x = 0; x < cell; x++) { const o = ((y0 + head + y) * W + x0 + x) * 3; const ck = ((x >> 3) + (y >> 3)) & 1 ? 0.52 : 0.44; cv.c[o] = cv.c[o + 1] = cv.c[o + 2] = ck; }
      R.text(cv, x0 + 1, y0 + 2, String(L.index), [1, 1, 0.3], 2);
      const rgba = layerRGBA(L, psd.mode);
      const s = Math.min(cell / L.width, cell / L.height), dw = L.width * s, dh = L.height * s, ox = x0 + (cell - dw) / 2, oy = y0 + head + (cell - dh) / 2;
      for (let y = 0; y < cell; y++) for (let x = 0; x < cell; x++) {
        const sx = Math.floor((x0 + x - ox) / s), sy = Math.floor((y0 + head + y - oy) / s);
        if (sx < 0 || sy < 0 || sx >= L.width || sy >= L.height) continue;
        const si = (sy * L.width + sx) * 4, a = rgba[si + 3] / 255;
        if (a <= 0) continue;
        const o = ((y0 + head + y) * W + x0 + x) * 3;
        for (let c = 0; c < 3; c++) cv.c[o + c] = rgba[si + c] / 255 * a + cv.c[o + c] * (1 - a);
      }
    });
    const file = `${opt.sheet}_layers${pages > 1 ? '_p' + (page + 1) : ''}.png`;
    fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
    R.savePNG(cv, file);
    console.log(`wrote ${file} — layers ${list.length ? list[0].index : '-'}..${list.length ? list[list.length - 1].index : '-'} (${list.length} of ${vis.length}, page ${page + 1}/${pages}${pages > 1 ? ', --page N for more' : ''}); tile number = index in the table above`);
  }
}

if (require.main === module) main();
module.exports = { readPSD, layerRGBA, selectLayers };
