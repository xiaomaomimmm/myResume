#!/usr/bin/env node
// Backward-compatible entry point. All format conversion lives in spine_compat.js.
'use strict';
const C=require('./spine_core'),V=require('./spine_compat'),CLI=require('./spine_convert');
const argv=process.argv.slice(2);
if(argv.length!==2){console.error('usage: node spine_convert_38_to_42.js <in.json> <out.json>');process.exitCode=2;}
else try{
  const version=V.parseVersion(C.readJson(C.resolveJson(argv[0])));
  if(version.key!=='3.7'&&version.key!=='3.8')throw new Error('Legacy wrapper accepts Spine 3.7/3.8; use spine_convert.js for other sources');
  process.exitCode=CLI.main([argv[0],argv[1],'--spine-version','4.2']);
}catch(e){console.error(e.message);process.exitCode=1;}
