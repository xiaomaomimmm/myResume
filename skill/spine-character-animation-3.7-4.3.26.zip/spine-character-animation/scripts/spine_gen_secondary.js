#!/usr/bin/env node
// spine_gen_secondary.js — write procedural keys into a Spine JSON animation using the
// timing rules distilled in this skill (Spine 3.7, 3.8 and 4.0–4.3 key formats).
//
// Usage:
//   node spine_gen_secondary.js <in.json> <out.json> --anim idle [--frames 160] [--fps 30]
//        [--spine-version 3.7|3.8|4.0|4.1|4.2|4.3|latest] <op> [<op> ...]
//   Omitting --spine-version preserves the input version. An explicit target converts the full JSON
//   before generation; unsupported or lossy conversions fail before any output is written.
//
// Ops (repeatable, applied in order):
//   --chain  bone1,bone2,bone3  [kind=back_hair] [tip=33 | amp=6] [growth=1.8] [lag=10] [max=°] [cycles=2] [phase=0] [bias=0]
//            rotate swing travelling root->tip: amp(seg i) = amp*growth^i, start offset = phase + i*lag
//            amp = ROOT segment peak-to-peak °, tip = LAST segment peak-to-peak ° (amp is derived from it).
//            kind = preset with corpus-median tip/growth/lag: bangs side_hair back_hair braid ahoge ear tail
//                   cape skirt sleeve ribbon pendant tassel wing plant  (explicit params override it)
//            max  = cap per-segment amplitude (growth stops there, avoids curling tips)
//   --breath bone              [ty=6] [sx=0] [sy=0] [rot=0] [cycles=2] [phase=0]
//            translate-y / scale / rotate ease-in-out loop (torso, chest, hip)
//   --sway   bone              [rot=2] [tx=0] [ty=0] [cycles=2] [phase=0]
//   --float  bone              [ty=10] [tx=0] [rot=0] [cycles=1] [phase=0]  (props / scene items)
//   --blink  slot|bone         [at=150] [close=3] [hold=2] [open=4] [mode=attachment|scaleY] [closed=NAME]
//            attachment mode switches slot to `closed` attachment (preferred: real closed-eye drawing).
//            scaleY mode squashes a lid/eye bone [minScale=0.1]. It is REFUSED when the bone's local Y is >5° off
//            the normal of the line through both eyes (slanted blink; forceAxis=1 skips) or its origin is in the
//            upper part of / above the eye (the eye would close upward); force=1 skips the origin check. If the eye slots are whole-eye drawings (no lid/lash/closed layer),
//            minScale is clamped to 0.25 (squint) because squashing to ~0 leaves a blank face; allowErase=1 overrides.
//   --blink  LABEL mode=deform lid=slotA,slotB inner=white,pupil,highlight [lower=..] [brow=..] [at=] [close=3] [hold=2]
//            [open=4] [line=0.1] [lidTop=0.4] [minScale=0.1] [lowerUp] [browPx] [axis=deg] [curve=ease|snap|linear]
//            MESH-DEFORM blink (corpus method, 120/128 projects): lash meshes (mostly dark pixels) slide down RIGIDLY to
//            the closing line along a smooth curve, lid skin compresses (its top drops lidTop×), so lines never stretch
//            (lint A19); eye white / iris / pupil collapse onto that line
//            with the SAME keys (no pupil hiding), lower lid rises, brow drops. One op per eye; give the L and R ops
//            one after the other so the face line runs through both eyes. Removes attachment keys that hid these parts.
//   --blinkrig eyeBone         [name=<eyeBone>_blink] [keep=0] [axis=deg]   (rig step, runs before all other ops)
//            axis = face-line direction to squash across (default: line through both eyes' DRAWN centres — keep it;
//            the corpus squashes even foreshortened 3/4 eyes along the face normal, median 6.9° off)
//            inserts a dedicated blink bone between eyeBone and its parent: origin on the lower lid, local Y
//            perpendicular to the line through both eyes; eyeBone is re-parented so the setup does not move.
//            Old scale keys on eyeBone are removed (keep=1 keeps them). Then: --blink <eyeBone>_blink mode=scaleY
//   --wave   bone1,bone2,...   [tx=20] [ty=15] [lag=10] [cycles=2]  (mesh control points: a bulge travels
//            along smoke/steam/water while the shape stays put — back-and-forth per point, see 03 §4.1)
//   --drift  bone1:slot1,bone2:slot2,...  [tx=20] [ty=120] [life=frames] [fade=0.25] [grow=1.4] [rot=0] [peak=1]
//            ONE-WAY particles (smoke puffs, steam, sparks, bubbles, petals): each moves start → start+(tx,ty)
//            linearly over `life` frames, scales 1 → grow, alpha 0 → peak → 0 (fade = fraction of life
//            for fade-in and fade-out), then jumps back while invisible. N particles are staggered by
//            life/N so something is always visible. life must divide the loop (frames % life == 0).
//   --alpha  slot              [min=0.25] [cycles=2] [phase=0]       (slot alpha pulse, e.g. glow/smoke)
//   --beat   bone1,bone2  at=F len=60 rot=deg [tx= ty=] [ant=0.33] [over=0.15] [lag=4] [kids=c1,c2] [follow=0.6]
//            ONLY WHEN THE USER ASKS FOR A PERFORMANCE BEAT (default idles are pure loops). One-shot gesture added
//            on top of the existing loop keys: anticipation (−ant × pose) → action (ease-in) → overshoot (+over) →
//            moving hold → settle back to the loop value, so the loop seam is untouched. Main bones offset by lag/2,
//            kids= by lag per level, ×1.3 larger, with 2 decaying follow-through swings. Run it AFTER the breath /
//            sway / chain ops of the same bones.
//
// All loops close exactly (last key == first key at frame `frames`). Existing timelines of the
// same type on the same bone are replaced. Prints WARNINGS when amplitudes are far below the
// reference corpus (a "barely moving" idle is the most common failure, not over-animation).
'use strict';
const fs = require('fs');
const C = require('./spine_core');
const V = require('./spine_compat');

const argv = process.argv.slice(2);
if (argv.length < 3) { console.error(fs.readFileSync(__filename, 'utf8').split('\n').slice(1, 60).filter(l => l.startsWith('//')).map(l => l.replace(/^\/\/ ?/, '')).join('\n')); process.exit(2); }
const inFile = C.resolveJson(argv[0]), outFile = argv[1];
let j = C.readJson(inFile);
let animName = 'idle', frames = 160, fps = 30, targetVersion;
const ops = [];
for (let i = 2; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--anim') animName = argv[++i];
  else if (a === '--frames') frames = +argv[++i];
  else if (a === '--fps') fps = +argv[++i];
  else if (a === '--spine-version') {
    targetVersion = argv[++i];
    if (!targetVersion || targetVersion.startsWith('--')) { console.error('--spine-version requires a version'); process.exit(2); }
  }
  else if (/^--(chain|breath|sway|float|blink|blinkrig|wave|drift|alpha|beat)$/.test(a)) {
    const op = { op: a.slice(2), target: argv[++i], p: {} };
    while (argv[i + 1] && /^[a-zA-Z]+=/.test(argv[i + 1])) { const [k, v] = argv[++i].split('='); op.p[k] = isNaN(+v) ? v : +v; }
    ops.push(op);
  } else { console.error('unknown arg ' + a); process.exit(2); }
}
try {
  const inputProfile = V.profileOf(j);
  j = V.convertVersion(j, targetVersion === undefined ? inputProfile.raw : targetVersion);
} catch (err) { console.error(`Spine version: ${err.message}`); process.exit(3); }
if (!Number.isFinite(fps) || fps <= 0 || !Number.isInteger(frames) || frames <= 0) {
  console.error('--fps must be positive and --frames must be a positive integer'); process.exit(2);
}
const ver = C.versionOf(j), is4 = ver.is4, is37 = ver.major === 3 && ver.minor === 7;
// 3.7 stores one normalised four-number array, 3.8 stores curve/c2/c3/c4.
function setLegacyCurve(key, curve) {
  delete key.c2; delete key.c3; delete key.c4;
  if (is37) key.curve = curve.slice();
  else { key.curve = curve[0]; key.c2 = curve[1]; key.c3 = curve[2]; key.c4 = curve[3]; }
}
// ---- rig pre-pass: --blinkrig eyeBone  inserts "<eyeBone>_blink" between the eye bone and its parent:
// origin on the eye's lower lid (along the face-line normal), local X parallel to the line through both eyes,
// so a scaleY on it closes the eye toward the lower lid, perpendicular to the face even on a tilted head.
// The eye bone is re-parented with a compensating local transform: the setup pose is unchanged.
for (const o of ops.filter(q => q.op === 'blinkrig')) {
  const Rr = require('./spine_render');
  const name = o.target, newName = o.p.name || `${name}_blink`;
  const sk = Rr.skeletonFor(JSON.parse(JSON.stringify(j)), inFile);
  const E = sk.boneByName.get(name);
  if (!E || !E.parent) { console.error(`--blinkrig: bone not found or has no parent: ${name}`); process.exit(3); }
  if (sk.boneByName.get(newName)) { console.error(`--blinkrig: ${newName} already exists`); process.exit(3); }
  const geo = Rr.blinkGeometry(sk, name); // poses setup
  if (!geo) { console.error(`--blinkrig: no eye geometry (slots) under ${name}`); process.exit(3); }
  const ed = j.bones.find(b => b.name === name);
  const inh = ed.inherit || ed.transform;
  if (inh && inh !== 'normal') { console.error(`--blinkrig: ${name} uses inherit "${inh}"; insert the blink bone manually`); process.exit(3); }
  const consOn = [...(j.ik || []), ...(j.transform || []), ...(j.path || []), ...(j.constraints || [])].filter(c => (c.bones || []).includes(name) || c.target === name);
  if (consOn.length) { console.error(`--blinkrig: ${name} is used by constraint(s) ${consOn.map(c => c.name).join(', ')}; insert the blink bone manually`); process.exit(3); }
  Rr.pose(sk, null, 0, false);
  const P = E.parent;
  const allPts = () => sk.slots.map(s => Rr.slotPoints(sk, s, s.data.attachment));
  const before = allPts();
  // face frame: x along the eye line, y = its normal pointing up (Spine world is y-up).
  // axis=deg overrides (e.g. a 3/4 view where one eye is foreshortened: use the reference's closed-line angle)
  let phi = o.p.axis !== undefined ? +o.p.axis : geo.faceLine;
  if (Math.cos(phi * Math.PI / 180) < 0) phi += 180;
  phi = ((phi + 180) % 360 + 360) % 360 - 180;
  const ux = Math.cos(phi * Math.PI / 180), uy = Math.sin(phi * Math.PI / 180), nx = -uy, ny = ux; // x axis, y axis (world)
  // lower lid = lowest DRAWN pixel along -normal (not the mesh rectangle, whose corners are often transparent)
  const pts = sk.slots.filter(s => { for (let x = s.bone; x; x = x.parent) if (x === E) return true; return false; }).flatMap(s => Rr.drawnPoints(sk, s, 1));
  const along = pts.map(([x, y]) => x * ux + y * uy), up = pts.map(([x, y]) => x * nx + y * ny);
  const cAlong = (Math.min(...along) + Math.max(...along)) / 2, lid = Math.min(...up);
  const O = [cAlong * ux + lid * nx, cAlong * uy + lid * ny];
  // B world matrix: rotation phi, unit scale, origin O.  Local to P: inverse(P) * world
  const pDet = P.a * P.d - P.b * P.c;
  const toLocalP = ([x, y]) => { const dx = x - P.worldX, dy = y - P.worldY; return [(P.d * dx - P.b * dy) / pDet, (-P.c * dx + P.a * dy) / pDet]; };
  const pRot = Math.atan2(P.c, P.a) * 180 / Math.PI, pScale = Math.hypot(P.a, P.c);
  const bLocal = toLocalP(O);
  const bRot = phi - pRot;                              // P assumed rotation + uniform scale (typical head bone)
  const bScale = 1 / pScale;                            // keep B at unit world scale
  // E local under B: inverse(B) * E_world
  const Bw = { a: ux, b: nx, c: uy, d: ny, x: O[0], y: O[1] };
  const eRel = [(E.worldX - Bw.x) * ux + (E.worldY - Bw.y) * uy, (E.worldX - Bw.x) * nx + (E.worldY - Bw.y) * ny];
  const eWorldRot = Math.atan2(E.c, E.a) * 180 / Math.PI, eWorldSx = Math.hypot(E.a, E.c), eWorldSy = Math.hypot(E.b, E.d);
  const idx = j.bones.indexOf(ed);
  const nb = { name: newName, parent: P.name, x: +bLocal[0].toFixed(4), y: +bLocal[1].toFixed(4), rotation: +bRot.toFixed(4) };
  if (Math.abs(bScale - 1) > 1e-6) { nb.scaleX = +bScale.toFixed(6); nb.scaleY = +bScale.toFixed(6); }
  ed.parent = newName; ed.x = +eRel[0].toFixed(4); ed.y = +eRel[1].toFixed(4); ed.rotation = +(eWorldRot - phi).toFixed(4);
  if (Math.abs(eWorldSx - 1) > 1e-6 || ed.scaleX !== undefined) ed.scaleX = +eWorldSx.toFixed(6);
  if (Math.abs(eWorldSy - 1) > 1e-6 || ed.scaleY !== undefined) ed.scaleY = +eWorldSy.toFixed(6);
  j.bones.splice(idx, 0, nb); // parent before child
  // weighted vertices reference bones BY INDEX: shift every index >= idx by one
  const skinList = Array.isArray(j.skins) ? j.skins.map(s => s.attachments || {}) : Object.values(j.skins || {});
  for (const slots of skinList) for (const atts of Object.values(slots)) for (const att of Object.values(atts)) {
    const v = att.vertices;
    if (!Array.isArray(v)) continue;
    const n = att.type === 'mesh' || !att.type ? (att.uvs || []).length / 2 : att.vertexCount;
    if (!(n > 0) || v.length === n * 2) continue; // unweighted
    for (let i = 0; i < v.length;) { const c = v[i++]; for (let k = 0; k < c; k++, i += 4) if (v[i] >= idx) v[i]++; }
  }
  // existing timelines of the eye bone: translate offsets were in P's frame → rotate into the blink bone's frame;
  // its scale keys (the old slanted blink) are removed unless keep=1 — blink the new bone instead
  const rr = -bRot * Math.PI / 180, removed = [];
  for (const [an, a] of Object.entries(j.animations || {})) {
    const tl = a.bones && a.bones[name];
    if (!tl) continue;
    const tk = tl.translate || [];
    // 4.x curves hold absolute value handles per channel: keep the eased shape (normalised handles of the
    // channel that actually moves) and re-express them for the rotated x/y values
    const norm = tk.map((k, i) => {
      const n = tk[i + 1];
      if (!is4 || !Array.isArray(k.curve) || !n) return null;
      const t0 = k.time || 0, dt = (n.time || 0) - t0 || 1, ch = Math.abs((n.y || 0) - (k.y || 0)) > Math.abs((n.x || 0) - (k.x || 0)) ? 1 : 0;
      const v0 = ch ? k.y || 0 : k.x || 0, dv = (ch ? n.y || 0 : n.x || 0) - v0, c = k.curve.slice(ch * 4, ch * 4 + 4);
      return c.length < 4 ? null : [(c[0] - t0) / dt, Math.abs(dv) < 1e-9 ? 0 : (c[1] - v0) / dv, (c[2] - t0) / dt, Math.abs(dv) < 1e-9 ? 1 : (c[3] - v0) / dv];
    });
    for (const k of tk) { const x = k.x || 0, y = k.y || 0; k.x = +((x * Math.cos(rr) - y * Math.sin(rr)) / bScale).toFixed(4); k.y = +((x * Math.sin(rr) + y * Math.cos(rr)) / bScale).toFixed(4); }
    tk.forEach((k, i) => {
      if (!norm[i]) return;
      const n = tk[i + 1], t0 = k.time || 0, dt = (n.time || 0) - t0, [a, b, c, d] = norm[i];
      k.curve = [];
      for (const ch of ['x', 'y']) { const v0 = k[ch], dv = n[ch] - v0; k.curve.push(+(t0 + a * dt).toFixed(4), +(v0 + b * dv).toFixed(4), +(t0 + c * dt).toFixed(4), +(v0 + d * dv).toFixed(4)); }
    });
    if (tl.scale && !o.p.keep) { delete tl.scale; removed.push(an); }
  }
  // verify nothing moved in the setup pose (every slot, not only the eye)
  const sk2 = Rr.skeletonFor(JSON.parse(JSON.stringify(j)), inFile);
  Rr.pose(sk2, null, 0, true);
  const after = sk2.slots.map(s => Rr.slotPoints(sk2, s, s.data.attachment));
  let err = 0;
  before.forEach((ps, si) => ps.forEach((q, i) => { const r = after[si][i]; err = Math.max(err, r ? Math.hypot(q[0] - r[0], q[1] - r[1]) : Infinity); }));
  if (!(err < 0.05)) { console.error(`--blinkrig ${name}: setup changed by ${err.toFixed(3)}px — parent "${P.name}" probably has shear / non-uniform scale; insert the blink bone manually`); process.exit(3); }
  o.report = `blinkrig ${name}: inserted ${newName} (parent ${P.name}) origin on the lower lid, local Y ⊥ face line (${geo.faceRef}, ${geo.faceLine.toFixed(1)}°, was ${geo.tilt.toFixed(1)}° off); setup moved ${err.toFixed(4)}px` +
    (removed.length ? `; removed old scale keys of ${name} in: ${removed.join(', ')}` : '') + `. Blink it with: --blink ${newName} mode=scaleY`;
}
const m = C.buildModel(j);
j.animations = j.animations || {};
const anim = j.animations[animName] = j.animations[animName] || {};
const D = frames / fps;
const sec = f => +(f / fps).toFixed(4);
const EASE = [0.25, 0, 0.75, 1];

// Build keys for a sine-like loop sampled at extremes: value(t) alternates lo/hi every half cycle,
// shifted by `offsetF` frames; wrap-around handled by splitting the segment at frame 0 / end.
function loopKeys(lo, hi, cycles, offsetF) {
  const half = frames / cycles / 2;
  const off = ((offsetF % (2 * half)) + 2 * half) % (2 * half);
  // extremes at off + k*half, alternating hi (even k) / lo (odd k) — first extreme is hi
  const ext = [];
  for (let k = -2; k <= cycles * 2 + 2; k++) { const f = off + k * half; ext.push({ f, v: k % 2 === 0 ? hi : lo }); }
  const inRange = ext.filter(e => e.f > 1e-6 && e.f < frames - 1e-6);
  // value at frame 0 by interpolating the bracketing extremes with the same ease
  const prev = ext.filter(e => e.f <= 0).pop(), next = ext.find(e => e.f > 0);
  const u = (0 - prev.f) / (next.f - prev.f);
  const v0 = prev.v + (next.v - prev.v) * C.bezierY({ type: 'bezier', cx1: EASE[0], cy1: EASE[1], cx2: EASE[2], cy2: EASE[3] }, u);
  const keys = [{ f: 0, v: v0, split: u > 1e-6 ? { from: u, a: prev.v, b: next.v } : null }];
  for (const e of inRange) keys.push({ f: e.f, v: e.v });
  keys.push({ f: frames, v: v0, splitEnd: u > 1e-6 ? { to: u, a: prev.v, b: next.v } : null });
  return keys;
}
// Sub-segment [u0,u1] of the ease curve, re-expressed as a bezier whose x-controls are 1/3, 2/3
// (x linear in t). y-controls solve B(1/3)=a, B(2/3)=b:
//   4/9*y1 + 2/9*y2 = a - 1/27 ;  2/9*y1 + 4/9*y2 = b - 8/27
function subCurve(u0, u1) {
  const cv = { type: 'bezier', cx1: EASE[0], cy1: EASE[1], cx2: EASE[2], cy2: EASE[3] };
  const y0 = C.bezierY(cv, u0), y1 = C.bezierY(cv, u1);
  const f = t => (C.bezierY(cv, u0 + (u1 - u0) * t) - y0) / Math.max(1e-9, y1 - y0);
  const A1 = f(1 / 3) - 1 / 27, A2 = f(2 / 3) - 8 / 27;
  const yc1 = 3 * A1 - 1.5 * A2, yc2 = 3 * A2 - 1.5 * A1;
  return [+(1 / 3).toFixed(4), +yc1.toFixed(4), +(2 / 3).toFixed(4), +yc2.toFixed(4)];
}
function curveFor(k, next) {
  if (!next) return null;
  if (k.split) return subCurve(k.split.from, 1);
  if (next.splitEnd) return subCurve(0, next.splitEnd.to);
  return EASE;
}
// write a single-channel or xy timeline
function writeBoneTimeline(bone, type, chans) {
  anim.bones = anim.bones || {};
  const tl = anim.bones[bone] = anim.bones[bone] || {};
  const base = chans[Object.keys(chans)[0]];
  const keys = base.map((k, i) => {
    const o = {};
    if (k.f !== 0 || is37) o.time = sec(k.f);
    if (type === 'rotate') { if (is4) o.value = +k.v.toFixed(3); else o.angle = +k.v.toFixed(3); }
    else { o.x = +chans.x[i].v.toFixed(3); o.y = +chans.y[i].v.toFixed(3); }
    const nxt = base[i + 1];
    if (nxt) {
      if (is4) {
        // 4.x: absolute-unit bezier per channel
        const t0 = k.f / fps, t1 = nxt.f / fps;
        const arr = [];
        for (const cn of Object.keys(chans)) {
          const c = curveFor(chans[cn][i], chans[cn][i + 1]);
          const v0 = chans[cn][i].v, v1 = chans[cn][i + 1].v;
          arr.push(+(t0 + c[0] * (t1 - t0)).toFixed(4), +(v0 + c[1] * (v1 - v0)).toFixed(4), +(t0 + c[2] * (t1 - t0)).toFixed(4), +(v0 + c[3] * (v1 - v0)).toFixed(4));
        }
        o.curve = arr;
      } else {
        const c = curveFor(k, nxt);
        if (!(c[0] === 0 && c[1] === 0 && c[2] === 1 && c[3] === 1)) setLegacyCurve(o, c);
      }
    }
    return o;
  });
  tl[type] = keys;
}
const need = b => { if (!m.byName.has(b)) { console.error(`bone not found: ${b}`); process.exit(3); } };
const skelParent = b => (m.byName.get(b) || {}).parent || 'root';
const report = ops.filter(o => o.report).map(o => o.report), warnings = [];
// Corpus medians (references/03-chain-secondary.md §2): tip = peak-to-peak swing of the LAST segment (°)
const CHAIN_PRESETS = {
  bangs: { tip: 20, growth: 1.8, lagFrac: 0.1 },      // 刘海/前发
  side_hair: { tip: 20, growth: 1.8 },                 // 侧发
  back_hair: { tip: 33, growth: 1.9 },                 // 后发/马尾
  braid: { tip: 40, growth: 1.8 },                     // 辫子
  ahoge: { tip: 25, growth: 1.5, lagFrac: 1 / 16 },    // 呆毛
  ear: { tip: 37, growth: 1.75 },                      // 兽耳
  tail: { tip: 47, growth: 1.7, lagFrac: 0.15 },       // 尾巴
  cape: { tip: 25, growth: 2.1, lagFrac: 0.15 },       // 披风
  skirt: { tip: 13, growth: 1.8 },                     // 裙摆（裙专项统计：末节中位 13°，末端位移中位 37‰ 身高）
  sleeve: { tip: 18, growth: 1.8 },                    // 袖口/衣角
  ribbon: { tip: 24, growth: 2.2, lagFrac: 0.15 },     // 飘带/腰带垂片
  pendant: { tip: 15, growth: 1.5 },                   // 吊坠/流苏
  tassel: { tip: 38, growth: 1.7, lagFrac: 0.15 },     // 灯笼穗
  wing: { tip: 22, growth: 1.7, lagFrac: 0.15 },       // 翅膀羽毛
  plant: { tip: 15, growth: 1.6, lagFrac: 1 / 32 },    // 植物/草
};
// ---- performance beat (--beat): one-shot gesture ADDED on top of whatever loop keys the bone already has.
// Five beats (references/06-timing-rhythm.md §4): anticipation (opposite, 1/3 of the pose, 12% of the beat) →
// action (ease-in, 20%) → overshoot (+15%, 8%) → moving hold (≤1.5° drift, 35%) → settle back (25%), so the last
// key equals the loop value and the loop seam is untouched. Children listed after `|` follow with `lag` frames
// delay and 1–2 decaying swings after the stop (follow-through, ×0.5 each).
// Values add to the existing timeline: the existing curve is sampled at every new key frame and the offset added.
function sampleExisting(bone, type, ch, f) {
  const tl = anim.bones && anim.bones[bone] && anim.bones[bone][type];
  if (!tl || !tl.length) return type === 'scale' ? 1 : 0;
  const chs = C.channelsOfBoneTimeline(type, tl, ver).channels;
  return C.evalChannel(chs[ch] || chs[Object.keys(chs)[0]], f / fps);
}
// Sparse keys only at the beat frames (value = loop value there + offset), each segment with its own curve:
// in = accelerate (0.5,0,1,1), out = decelerate (0,0,0.5,1), ease = default (0.25,0,0.75,1). The loop between
// two beat keys is approximated by the curve (≤ ~0.2° for an 80f breath under 20f segments), so the loop keeps
// its shape and the key count stays low (performance segments in the corpus: 12–47% on the 10f grid).
function addBeat(bone, type, offsets) { // offsets: [[frame, {r} | {x,y}, curveToNext]], sorted, first/last = 0 offset
  anim.bones = anim.bones || {};
  const tl = anim.bones[bone] = anim.bones[bone] || {};
  const old = tl[type] ? JSON.parse(JSON.stringify(tl[type])) : null;
  const oldChs = old ? C.channelsOfBoneTimeline(type, old, ver).channels : null;
  const chNames = type === 'rotate' ? ['r'] : ['x', 'y'];
  const base = (ch, f) => (oldChs ? C.evalChannel(oldChs[ch] || oldChs[Object.keys(oldChs)[0]], f / fps) : (type === 'scale' ? 1 : 0));
  const f0 = offsets[0][0], f1 = offsets[offsets.length - 1][0];
  const val = (k, ch) => (ch === 'r' ? (k.value !== undefined ? k.value : k.angle || 0) : (k[ch] !== undefined ? k[ch] : (type === 'scale' ? 1 : 0)));
  const mk = (f, vals) => { const k = {}; if (f || is37) k.time = sec(f); if (type === 'rotate') { if (is4) k.value = +vals.r.toFixed(3); else k.angle = +vals.r.toFixed(3); } else { k.x = +vals.x.toFixed(3); k.y = +vals.y.toFixed(3); } return k; };
  const CURVES = { in: [0.5, 0, 1, 1], out: [0, 0, 0.5, 1], ease: EASE, linear: null };
  const setCurve = (k, nk, kind) => {
    delete k.curve; delete k.c2; delete k.c3; delete k.c4;
    const c = CURVES[kind]; if (!c || !nk) return;
    if (!is4) { setLegacyCurve(k, c); return; }
    const t0 = k.time || 0, t1 = nk.time || 0, arr = [];
    for (const ch of chNames) { const v0 = val(k, ch), v1 = val(nk, ch); arr.push(+(t0 + c[0] * (t1 - t0)).toFixed(4), +(v0 + c[1] * (v1 - v0)).toFixed(4), +(t0 + c[2] * (t1 - t0)).toFixed(4), +(v0 + c[3] * (v1 - v0)).toFixed(4)); }
    k.curve = arr;
  };
  let keys = old ? old.filter(k => { const f = (k.time || 0) * fps; return f < f0 - 1e-6 || f > f1 + 1e-6; }) : [];
  if (!old) { const z = Object.fromEntries(chNames.map(ch => [ch, type === 'scale' ? 1 : 0])); keys = [mk(0, z), mk(frames, z)]; }
  const beatKeys = offsets.map(([f, o]) => mk(f, Object.fromEntries(chNames.map(ch => [ch, base(ch, f) + (o[ch] || 0)]))));
  keys = [...keys, ...beatKeys].sort((a, b) => (a.time || 0) - (b.time || 0)).filter((k, i, a) => i === 0 || Math.abs((k.time || 0) - (a[i - 1].time || 0)) > 1e-6);
  // curves: inside the beat from the plan ('linear' plan steps become ease too: corpus performance segments are
  // mostly eased); the two edge segments (old key → beat start, beat end → old key) ease. On a bone without loop
  // keys the zero keys before / after the beat stay flat (no curve needed).
  keys.forEach((k, i) => {
    const f = (k.time || 0) * fps, nk = keys[i + 1];
    if (!nk) return;
    const bi = offsets.findIndex(([of]) => Math.abs(of - f) < 1e-6);
    const flat = chNames.every(ch => Math.abs(val(k, ch) - val(nk, ch)) < 1e-6);
    if (flat) { setCurve(k, nk, 'linear'); return; }
    if (bi >= 0 && bi < offsets.length - 1) setCurve(k, nk, offsets[bi][2] === 'linear' ? 'ease' : offsets[bi][2]);
    else if (Math.abs((nk.time || 0) * fps - f0) < 1e-6 || bi === offsets.length - 1) setCurve(k, nk, 'ease');
  });
  tl[type] = keys;
}
for (const o of ops) {
  const p = o.p;
  if (o.op === 'beat') {
    // --beat bone1,bone2 at=F len=L rot=deg [tx= ty=] [ant=0.33] [over=0.15] [lag=4] [kids=c1,c2] [follow=0.6]
    const mains = o.target.split(',').filter(Boolean), kids = String(p.kids || '').split(',').filter(Boolean);
    [...mains, ...kids].forEach(need);
    const at = p.at ?? Math.round(frames * 0.4), len = p.len ?? 60, rot = p.rot ?? 0, tx = p.tx ?? 0, ty = p.ty ?? 0;
    const ant = p.ant ?? 0.33, over = p.over ?? 0.15, lag = p.lag ?? 4, follow = p.follow ?? 0.6;
    if (at < 1 || at + len + (kids.length ? lag * kids.length + 10 : 0) > frames - 1) { console.error(`--beat ${o.target}: ${at}..${at + len}f (+ follow-through) must fit inside the ${frames}f loop`); process.exit(2); }
    // beat frames, snapped to the 5f grid when that keeps every segment ≥ 3f
    const fr = fracs => { const raw = fracs.map(x => at + x * len), snap = raw.map(v => Math.round(v / 5) * 5); const ok = [at, ...snap].every((v, i, a) => i === 0 || v - a[i - 1] >= 3); return (ok ? snap : raw.map(Math.round)); };
    const [fA, fB, fC, fD, fE] = fr([0.12, 0.32, 0.40, 0.75, 1.0]);
    const pose = s => ({ r: rot * s, x: tx * s, y: ty * s });
    const drift = 0.06; // moving hold: slow drift of 6% of the pose (≈ 0.5–1.5° for 10–25° gestures)
    const plan = scale => [[at, pose(0), 'ease'], [fA, pose(-ant * scale), 'in'], [fB, pose((1 + over) * scale), 'out'], [fC, pose(1 * scale), 'ease'], [fD, pose((1 - drift) * scale), 'ease'], [fE, pose(0), 'linear']];
    const write = (b, off) => {
      if (rot) addBeat(b, 'rotate', off.map(([f, v, c]) => [f, { r: v.r }, c]));
      if (tx || ty) addBeat(b, 'translate', off.map(([f, v, c]) => [f, { x: v.x, y: v.y }, c]));
    };
    mains.forEach((b, i) => write(b, plan(1).map(([f, v, c]) => [f + i * Math.round(lag / 2 / 5) * 5, v, c])));
    // children: delayed, larger (×1.3 per level), then 2 decaying swings after the main settles
    kids.forEach((b, i) => {
      const d = lag * (i + 1), sc = Math.pow(1.3, i + 1);
      const base = plan(sc).map(([f, v, c]) => [f + d, v, c]);
      const end = base[base.length - 1][0], amp = rot * sc * follow * 0.25;
      base.splice(base.length - 1, 1, [end, { r: -amp, x: 0, y: 0 }, 'ease'], [end + 5, { r: amp * 0.5, x: 0, y: 0 }, 'ease'], [end + 10, { r: 0, x: 0, y: 0 }, 'linear']);
      if (rot) addBeat(b, 'rotate', base.map(([f, v, c]) => [f, { r: v.r }, c]));
    });
    report.push(`beat ${mains.join(',')}${kids.length ? ' kids ' + kids.join(',') : ''}:${at}–${fE}f (anticipation ${at}–${fA}, action –${fB}, overshoot –${fC}, moving hold –${fD}, settle –${fE}); pose rot ${rot}° t(${tx},${ty}); children lag ${lag}f ×1.3/level + follow-through; added on top of the loop, loop seam unchanged`);
    continue;
  }
  if (o.op === 'chain') {
    const bones = o.target.split(',');
    bones.forEach(need);
    const pre = p.kind ? CHAIN_PRESETS[p.kind] : null;
    if (p.kind && !pre) { console.error(`unknown chain kind "${p.kind}"; use one of ${Object.keys(CHAIN_PRESETS).join(', ')}`); process.exit(2); }
    const growth = p.growth ?? (pre ? pre.growth : 1.8), cycles = p.cycles ?? 2, phase = p.phase ?? 0, bias = p.bias ?? 0;
    const lag = p.lag ?? (pre && pre.lagFrac ? Math.round(frames / cycles * pre.lagFrac) : Math.round(frames / cycles / 8));
    // amplitude: amp = root segment (peak-to-peak °); tip = last segment (what the reference tables list)
    const tip = p.tip ?? (p.amp === undefined && pre ? pre.tip : undefined);
    const amp = p.amp ?? (tip !== undefined ? tip / Math.pow(growth, bones.length - 1) : 6);
    const cap = p.max ?? Infinity; // cap per-segment amplitude (curl limit), growth stops there
    const amps = bones.map((b, i) => Math.min(cap, amp * Math.pow(growth, i)));
    bones.forEach((b, i) => writeBoneTimeline(b, 'rotate', { r: loopKeys(bias - amps[i] / 2, bias + amps[i] / 2, cycles, phase + i * lag) }));
    report.push(`chain ${bones.join('>')}${p.kind ? ` [${p.kind}]` : ''} amp° [${amps.map(a => +a.toFixed(2)).join(', ')}] (x${growth}/seg) lag ${lag}f cycles ${cycles}`);
    const ref = pre ? pre.tip : null;
    if (ref && amps[amps.length - 1] < ref * 0.4) warnings.push(`chain ${bones[0]}: tip ${amps[amps.length - 1].toFixed(1)}° is < 40% of the reference ${ref}° for "${p.kind}" — motion will read as almost static`);
  } else if (o.op === 'breath' || o.op === 'sway' || o.op === 'float') {
    need(o.target);
    const cycles = p.cycles ?? (o.op === 'float' ? 1 : 2), phase = p.phase ?? 0;
    const explicit = ['tx', 'ty', 'rot', 'sx', 'sy'].some(k => p[k] !== undefined);
    const ty = p.ty ?? (explicit ? 0 : o.op === 'breath' ? 6 : o.op === 'float' ? 10 : 0), tx = p.tx ?? 0, rot = p.rot ?? (o.op === 'sway' && !explicit ? 2 : 0), sx = p.sx ?? 0, sy = p.sy ?? 0;
    if (tx || ty) { const kx = loopKeys(0, tx, cycles, phase), ky = loopKeys(0, ty, cycles, phase); writeBoneTimeline(o.target, 'translate', { x: kx, y: ky }); }
    if (rot) writeBoneTimeline(o.target, 'rotate', { r: loopKeys(-rot / 2, rot / 2, cycles, phase + (p.rotLag ?? 0)) });
    if (sx || sy) { const kx = loopKeys(1, 1 + sx, cycles, phase), ky = loopKeys(1, 1 + sy, cycles, phase); writeBoneTimeline(o.target, 'scale', { x: kx, y: ky }); }
    report.push(`${o.op} ${o.target} t(${tx},${ty}) rot ${rot} s(${sx},${sy}) cycles ${cycles} phase ${phase}`);
  } else if (o.op === 'wave') {
    const bones = o.target.split(',');
    bones.forEach(need);
    const cycles = p.cycles ?? 2, lag = p.lag ?? Math.round(frames / cycles / 8);
    bones.forEach((b, i) => writeBoneTimeline(b, 'translate', { x: loopKeys(0, p.tx ?? 20, cycles, i * lag), y: loopKeys(0, p.ty ?? 15, cycles, i * lag) }));
    report.push(`wave ${bones.length} control points lag ${lag}f`);
  } else if (o.op === 'drift') {
    const pairs = o.target.split(',').map(s => s.split(':'));
    const life = p.life ?? frames, fade = Math.min(0.45, Math.max(0.05, p.fade ?? 0.25));
    if (frames % life) { console.error(`--drift life=${life} must divide the loop length ${frames}`); process.exit(2); }
    const tx = p.tx ?? 20, ty = p.ty ?? 120, grow = p.grow ?? 1.4, rot = p.rot ?? 0, peak = p.peak ?? 1;
    pairs.forEach(([bone, slotName], i) => {
      need(bone);
      const slot = slotName ? m.slotByName.get(slotName) : null;
      if (slotName && !slot) { console.error(`slot not found: ${slotName}`); process.exit(3); }
      const off = Math.round(i * life / pairs.length) % life; // particle i is `off` frames into its life at frame 0
      // phase u(f) = ((f + off) mod life) / life. Inside a life the value is linear a0 → a1; at each wrap
      // frame w (u returns to 0, alpha is 0 there) hold a1 until just before w (stepped), then restart at a0.
      // Because life divides `frames`, u(frames) == u(0): the loop closes.
      const lerpKeys = (a0, a1) => {
        const val = f => a0 + (a1 - a0) * (((f + off) % life) / life);
        const keys = [{ f: 0, v: val(0), cv: 'linear' }];
        for (let w = 1; w <= frames; w++) if ((w + off) % life === 0) {
          keys.push({ f: w - 0.03, v: a1, cv: 'stepped' }); // ~0.001 s before the wrap: end of this life
          if (w < frames) keys.push({ f: w, v: a0, cv: 'linear' });
        }
        // the loop end restarts the cycle: value at `frames` equals the value at 0 (a0 when off == 0)
        keys.push({ f: frames, v: val(0), cv: null });
        return keys;
      };
      const writeLin = (type, chans) => {
        anim.bones = anim.bones || {};
        const tl = anim.bones[bone] = anim.bones[bone] || {};
        const base = chans[Object.keys(chans)[0]];
        tl[type] = base.map((k, idx) => {
          const o2 = {};
          if (k.f || is37) o2.time = +(k.f / fps).toFixed(4);
          if (type === 'rotate') o2[is4 ? 'value' : 'angle'] = +k.v.toFixed(3);
          else { o2.x = +chans.x[idx].v.toFixed(3); o2.y = +chans.y[idx].v.toFixed(3); }
          if (k.cv === 'stepped') o2.curve = 'stepped';
          return o2;
        });
      };
      writeLin('translate', { x: lerpKeys(0, tx), y: lerpKeys(0, ty) });
      if (grow !== 1) writeLin('scale', { x: lerpKeys(1, grow), y: lerpKeys(1, grow) });
      if (rot) writeLin('rotate', { r: lerpKeys(0, rot) });
      if (slot) {
        // alpha over one life: 0 → peak (fade) → peak → 0 (fade), eased; repeated, staggered by off
        const base6 = (slot.color || 'ffffffff').slice(0, 6), hex = v => base6 + Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0');
        const baseRGB = [0, 2, 4].map(q => parseInt(base6.slice(q, q + 2), 16) / 255);
        const shape = [[0, 0], [fade, peak], [1 - fade, peak], [1, 0]];
        const pts = [];
        for (let start = -off; start < frames; start += life) for (const [u, v] of shape) { const f = start + u * life; if (f >= 0 && f <= frames) pts.push([f, v]); }
        const valAt = f => { const u = ((f + off) % life + life) % life / life; for (let s = 0; s < 3; s++) { const [u0, v0] = shape[s], [u1, v1] = shape[s + 1]; if (u >= u0 && u <= u1) return v0 + (v1 - v0) * C.bezierY({ type: 'bezier', cx1: 0.25, cy1: 0, cx2: 0.75, cy2: 1 }, (u - u0) / Math.max(1e-9, u1 - u0)); } return 0; };
        if (!pts.length || pts[0][0] > 0) pts.unshift([0, valAt(0)]);
        if (pts[pts.length - 1][0] < frames) pts.push([frames, valAt(frames)]);
        const uniq = pts.filter((q, k) => k === 0 || Math.abs(q[0] - pts[k - 1][0]) > 1e-6);
        anim.slots = anim.slots || {};
        const st = anim.slots[slotName] = anim.slots[slotName] || {};
        const keys = uniq.map(([f, v], k) => {
          const o2 = {};
          if (f || is37) o2.time = +(f / fps).toFixed(4);
          o2.color = hex(v);
          const nk = uniq[k + 1];
          if (nk && Math.abs(nk[1] - v) > 1e-6) {
            if (is4) { const t0 = f / fps, t1 = nk[0] / fps; o2.curve = [0, 1, 2, 3].flatMap(c => c < 3 ? [t0 + 0.25 * (t1 - t0), baseRGB[c], t0 + 0.75 * (t1 - t0), baseRGB[c]] : [t0 + 0.25 * (t1 - t0), v, t0 + 0.75 * (t1 - t0), nk[1]]).map(x => +x.toFixed(4)); }
            else setLegacyCurve(o2, EASE);
          }
          return o2;
        });
        if (is4) st.rgba = keys; else st.color = keys;
      }
    });
    report.push(`drift ${pairs.length} particles: move (${tx},${ty}) over ${life}f, scale 1→${grow}, fade ${fade}, staggered every ${Math.round(life / pairs.length)}f; reset while invisible`);
  } else if (o.op === 'blink') {
    const at = p.at ?? Math.round(frames * 0.6), close = p.close ?? 3, hold = p.hold ?? 2, open = p.open ?? 4;
    const mode = p.mode ?? 'attachment';
    if (mode === 'attachment') {
      const slot = m.slotByName.get(o.target);
      if (!slot) { console.error(`slot not found: ${o.target}`); process.exit(3); }
      const closed = p.closed;
      if (!closed) { console.error('blink attachment mode needs closed=<attachmentName>'); process.exit(3); }
      anim.slots = anim.slots || {};
      const st = anim.slots[o.target] = anim.slots[o.target] || {};
      // swap mode has no in-betweens: show the closed drawing for `close+hold+open` frames total
      // (reference set: 6–8f), optionally with a half-closed drawing (half=NAME) on the edges.
      const openName = slot.attachment || null;
      const total = p.total ?? Math.max(6, close + hold + open);
      const k = [is37 ? { time: 0, name: openName } : { name: openName }];
      if (p.half) {
        k.push({ time: sec(at), name: p.half });
        k.push({ time: sec(at + 2), name: closed });
        k.push({ time: sec(at + total - 2), name: p.half });
      } else k.push({ time: sec(at), name: closed });
      k.push({ time: sec(at + total), name: openName });
      st.attachment = k;
      report.push(`blink(attachment) ${o.target}: ${at}-${at + total}f (${total}f${p.half ? ', with half-closed frames' : ''})`);
    } else if (mode === 'deform') {
      // Mesh-deform blink (the corpus method: 120 of 128 blinking projects). One op = one eye; o.target is a label.
      //   lid=   upper lid / lash meshes: move DOWN along the face normal until their lower edge (= top of the
      //          eye opening) reaches the closing line; middle moves more than the corners (arc) → closed line bows
      //   inner= eye white, iris, pupil, highlight meshes: squash toward the closing line (minScale), same keys,
      //          so they stay under the lid edge — never hide the pupil with attachment keys
      //   lower= lower lid / lash meshes: move UP to the closing line; brow= brow meshes: move down browPx
      // Face frame: line through this eye and the paired deform-blink op (1st↔2nd, 3rd↔4th), or axis=deg,
      // or the long axis of the lid. line = closing line height in the opening (0 = lower lid, corpus ≈ 0–0.15).
      const Rr = require('./spine_render');
      const die = msg => { console.error(`--blink ${o.target} mode=deform: ${msg}`); process.exit(3); };
      const list = s => (s === undefined ? [] : String(s).split(',').filter(Boolean));
      const roles = { lid: list(p.lid), inner: list(p.inner), lower: list(p.lower), brow: list(p.brow) };
      if (!roles.lid.length && !roles.inner.length) die('needs lid=<upper lid/lash mesh slots> and/or inner=<eye white, iris, pupil mesh slots>');
      const sk = Rr.skeletonFor(JSON.parse(JSON.stringify(j)), inFile);
      Rr.pose(sk, null, 0, false);
      const skinsL = Array.isArray(j.skins) ? j.skins.map(s => [s.name, s.attachments || {}]) : Object.entries(j.skins || {});
      const meshOf = sn => {
        const s = sk.slotByName.get(sn);
        if (!s) die(`slot not found: ${sn}`);
        const an = s.data.attachment;
        if (!an) die(`slot ${sn} has no setup attachment`);
        for (const [skn, atts] of skinsL) {
          const a = (atts[sn] || {})[an];
          if (!a) continue;
          if ((a.type || 'region') !== 'mesh') die(`slot ${sn} attachment "${an}" is a ${a.type || 'region'}, not a mesh — convert it to a mesh (or use mode=attachment / bone keys)`);
          return { sn, s, an, skn, a, pts: Rr.slotPoints(sk, s, an), drawn: sk.atlas ? Rr.opaqueTexels(sk, s, 1) : null };
        }
        return die(`attachment "${an}" of slot ${sn} not found in any skin`);
      };
      const parts = Object.fromEntries(Object.entries(roles).map(([r, ss]) => [r, ss.map(meshOf)]));
      const opening = (parts.inner.length ? parts.inner : parts.lid).flatMap(q => q.pts);
      // eye centre = drawn centre of the first inner slot (the eye white), else the first lid slot
      const centreOf = op => { const ss = list(op.p.inner).length ? list(op.p.inner) : list(op.p.lid); const sl = ss.map(sn => sk.slotByName.get(sn)).filter(Boolean); return sl.length ? Rr.drawnCentre(sk, sl.slice(0, 1)) : null; };
      const dOps = ops.filter(q => q.op === 'blink' && q.p.mode === 'deform'), di = dOps.indexOf(o), mate = dOps[di ^ 1];
      let phi, axisRef;
      if (p.axis !== undefined) { phi = +p.axis; axisRef = 'axis='; }
      else if (mate && mate !== o && centreOf(mate) && centreOf(o)) { const c0 = centreOf(o), c1 = centreOf(mate); phi = Math.atan2(c1[1] - c0[1], c1[0] - c0[0]) * 180 / Math.PI; axisRef = `line to ${mate.target}`; }
      else { // long axis of the lid (or opening) vertices
        const ps = (parts.lid.length ? parts.lid : parts.inner).flatMap(q => q.pts), mx = ps.reduce((t, q) => t + q[0], 0) / ps.length, my = ps.reduce((t, q) => t + q[1], 0) / ps.length;
        let sxx = 0, syy = 0, sxy = 0; for (const [x, y] of ps) { sxx += (x - mx) ** 2; syy += (y - my) ** 2; sxy += (x - mx) * (y - my); }
        phi = 0.5 * Math.atan2(2 * sxy, sxx - syy) * 180 / Math.PI; axisRef = 'lid long axis';
      }
      if (Math.cos(phi * Math.PI / 180) < 0) phi += 180;
      phi = ((phi + 180) % 360 + 360) % 360 - 180;
      const ux = Math.cos(phi * Math.PI / 180), uy = Math.sin(phi * Math.PI / 180), nx = -uy, ny = ux; // u along the eye, v = face normal (up)
      const U = ([x, y]) => x * ux + y * uy, V = ([x, y]) => x * nx + y * ny;
      const ou = opening.map(U), u0 = Math.min(...ou), u1 = Math.max(...ou), wU = Math.max(1e-6, u1 - u0);
      const mid = opening.filter(q => Math.abs((U(q) - u0) / wU - 0.5) <= 1 / 6);
      const ref = mid.length >= 2 ? mid : opening;
      const T = Math.max(...ref.map(V)), Bt = Math.min(...ref.map(V)), h = T - Bt;
      if (!(h > 1)) die(`eye opening is only ${h.toFixed(1)}px tall along the face normal (axis ${phi.toFixed(1)}°) — check lid=/inner= or pass axis=`);
      // Contours along the eye (u) in the face frame, from the vertices themselves:
      //   opening bottom Bo(u) / top To(u) = lowest / highest inner vertex near u (no inner: the lid's own band)
      //   lid edge E(u) = lowest lid-group vertex near u (lash line), lid top Lt(u) = highest
      //   closing line C(u) = Bo(u) + line·(To(u) − Bo(u))  — follows the lower-lid curve, as in the corpus
      // Lid: STRETCH like the reference rigs (footage 007: lash line drops 11–14px, lid top stays): vertex offset =
      //   (C − E)(u) · w,  w = 1 on the lash line → lidTop at the lid's top edge (the skin fill covers the eye).
      // Inner: collapse onto C(u) to minScale (stays under the lash line even if the lid has no skin fill).
      const near = (ps, u, f) => { const r = ps.filter(q => Math.abs(U(q) - u) <= wU / 8); const use = r.length ? r : ps.slice().sort((a, b) => Math.abs(U(a) - u) - Math.abs(U(b) - u)).slice(0, 2); return f(...use.map(V)); };
      // contours from DRAWN pixels when the atlas is available (grid meshes have transparent margins)
      const drawnOf = q => (q.drawn && q.drawn.length ? q.drawn.map(t => [t.x, t.y]) : q.pts);
      const lidPts = parts.lid.flatMap(drawnOf), innerPts = parts.inner.flatMap(drawnOf);
      const cu = u => Math.min(u1, Math.max(u0, u));
      const Bo = u => near(innerPts.length ? innerPts : lidPts, cu(u), Math.min), To = u => near(innerPts.length ? innerPts : lidPts, cu(u), Math.max);
      const line = p.line ?? 0.1, s = p.minScale ?? 0.1, lidTop = p.lidTop ?? 0.4, lowerUp = p.lowerUp ?? line, browPx = p.browPx ?? +(0.15 * h).toFixed(1);
      const Cl = u => Bo(u) + line * (To(u) - Bo(u));
      const fall = u => { const d = Math.max(u0 - u, u - u1, 0) / (0.15 * wU); return Math.max(0, 1 - d); }; // lid corners beyond the eye ease out
      // lash line = top of the eye white (lid meshes are often grids whose lowest vertices are transparent image
      // corners, not the lash line); without inner= the lid's own lowest vertices are used
      const E = u => (innerPts.length ? To(cu(u)) : near(lidPts, u, Math.min)), Lt = u => near(lidPts, u, Math.max);
      // SMOOTH drop profile: per-column pixel extremes are noisy (anti-aliasing, highlights); neighbouring vertices
      // that drop by different amounts shear the triangles between them and smear lashes / painted marks (004 V4).
      // Least-squares quadratic through 9 columns of (closing line − lash line), clamped ≤ 0.
      const fitQ = (us, ys) => { // y = a + b·t + c·t², t = (u − um)/wU
        const um = (u0 + u1) / 2, S = [0, 0, 0, 0, 0], Y = [0, 0, 0];
        us.forEach((u, i) => { const t = (u - um) / wU; for (let k = 0; k < 5; k++) S[k] += t ** k; for (let k = 0; k < 3; k++) Y[k] += ys[i] * t ** k; });
        const M = [[S[0], S[1], S[2]], [S[1], S[2], S[3]], [S[2], S[3], S[4]]];
        const det3 = m => m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
        const D = det3(M); if (Math.abs(D) < 1e-12) { const mean = ys.reduce((s, y) => s + y, 0) / ys.length; return () => mean; }
        const co = [0, 1, 2].map(c => det3(M.map((row, r) => row.map((v, k) => (k === c ? Y[r] : v)))) / D);
        return u => { const t = (u - um) / wU; return co[0] + co[1] * t + co[2] * t * t; };
      };
      const cols = Array.from({ length: 9 }, (_, i) => u0 + wU * (0.05 + 0.9 * i / 8));
      const dropFit = fitQ(cols, cols.map(u => Cl(u) - E(u)));
      const dropAt = u => Math.min(0, dropFit(cu(u))) * fall(u);
      // Lid motion, as in footage/004 (the same art, 0 smeared lash pixels):
      //  - lash-like lid meshes (≥ 50% dark pixels): the WHOLE mesh drops rigidly per column → the lash keeps its
      //    thickness and only bends along the smooth profile;
      //  - lid skin meshes: the lash-line edge drops fully, the skin top drops lidTop × as much → vertical stretch
      //    stays ≤ 1 + (1 − lidTop)·drop/height (the reference slides its lid skin, it does not pin its top).
      const lashLike = new Set(parts.lid.filter(q => q.drawn && q.drawn.length && q.drawn.filter(t => t.lum < 0.3).length / q.drawn.length >= 0.5).map(q => q.sn));
      const lidOffFor = q => pt => {
        const u = U(pt), drop = dropAt(u);
        if (lashLike.has(q.sn)) return drop;
        const e = E(u), top = Math.max(e + 1, Lt(u));
        const k = Math.min(1, Math.max(0, (V(pt) - e) / (top - e)));        // 0 at/below the lash line → 1 at the lid top
        return drop * (1 - (1 - lidTop) * k);
      };
      const dLid = dropAt((u0 + u1) / 2);
      const offsets = {
        lid: null, // per mesh: lidOffFor(q)
        // keep the relative layout, squashed to s, sitting ON the closing line (just above the landed lash line → covered)
        inner: q => { const u = cu(U(q)); return Cl(u) + s * (V(q) - Bo(u)) - V(q); },
        lower: q => lowerUp * (To(cu(U(q))) - Bo(cu(U(q)))),
        brow: () => -browPx,
      };
      const curveKey = (k, f, nf, cv) => {
        if (cv === 'stepped') { k.curve = 'stepped'; return; }
        if (cv === 'linear') return;
        // default = the corpus majority: standard ease on close and open (linear is the other half); curve=snap → accelerate in, decelerate out
        const c = p.curve === 'snap' ? (cv === 'in' ? [0.5, 0, 1, 1] : [0, 0, 0.5, 1]) : p.curve === 'linear' ? null : EASE;
        if (!c) return;
        if (is4) { const t0 = f / fps, t1 = nf / fps; k.curve = [+(t0 + c[0] * (t1 - t0)).toFixed(4), c[1], +(t0 + c[2] * (t1 - t0)).toFixed(4), c[3]]; }
        else setLegacyCurve(k, c);
      };
      const attachmentsLayout = ver.major === 4 && ver.minor >= 1;
      const f0 = at, f1 = at + close, f2 = f1 + hold, f3 = f2 + open;
      if (f0 < 1 || f3 > frames - 1) die(`blink ${f0}-${f3}f does not fit inside the ${frames}f loop`);
      const done = [], unhidden = [];
      for (const [role, list2] of Object.entries(parts)) for (const q of list2) {
        // world offset along the face normal → local offsets (per weighted influence for weighted meshes)
        const offFn = role === 'lid' ? lidOffFor(q) : offsets[role];
        const v = q.a.vertices, nV = q.a.uvs.length / 2, dv = q.pts.map(pt => offFn(pt));
        const inv = (b, wx, wy) => { const det = b.a * b.d - b.b * b.c; return [(b.d * wx - b.b * wy) / det, (-b.c * wx + b.a * wy) / det]; };
        const out = [];
        if (v.length === nV * 2) { for (let i = 0; i < nV; i++) out.push(...inv(q.s.bone, dv[i] * nx, dv[i] * ny)); }
        else for (let i = 0, vi = 0; i < v.length; vi++) { const n = v[i++]; for (let k = 0; k < n; k++, i += 4) out.push(...inv(sk.bones[v[i]], dv[vi] * nx, dv[vi] * ny)); }
        const verts = out.map(x => +x.toFixed(3));
        const pts = [[0, null, 'linear'], [f0, null, 'in'], [f1, verts, 'stepped'], [f2, verts, 'out'], [f3, null, 'linear'], [frames, null, null]];
        const keys = pts.map(([f, vv, cv], i) => { const k = {}; if (f || is37) k.time = sec(f); if (vv) k.vertices = vv; if (pts[i + 1]) curveKey(k, f, pts[i + 1][0], cv); return k; });
        if (attachmentsLayout) { anim.attachments = anim.attachments || {}; const a1 = anim.attachments[q.skn] = anim.attachments[q.skn] || {}; const a2 = a1[q.sn] = a1[q.sn] || {}; const a3 = a2[q.an] = a2[q.an] || {}; a3.deform = keys; }
        else { anim.deform = anim.deform || {}; const d1 = anim.deform[q.skn] = anim.deform[q.skn] || {}; const d2 = d1[q.sn] = d1[q.sn] || {}; d2[q.an] = keys; }
        done.push(`${role}:${q.sn}`);
        // attachment keys that hide this part around the blink are what makes "a white eye, pupil pops in late" — remove them
        const st = anim.slots && anim.slots[q.sn];
        if (st && st.attachment) {
          const before = st.attachment.length;
          st.attachment = st.attachment.filter(k => { const f = (k.time || 0) * fps; return f < f0 - 3 || f > f3 + 3; });
          if (st.attachment.length !== before) unhidden.push(q.sn);
          if (!st.attachment.length || st.attachment.every(k => k.name === q.an)) delete st.attachment;
        }
      }
      report.push(`blink(deform) ${o.target}: ${f0}-${f3}f (close ${close}, hold ${hold}, open ${open}); face axis ${phi.toFixed(1)}° (${axisRef}); opening ${h.toFixed(1)}px → lash line down ${(-dLid).toFixed(1)}px in the middle (lash meshes rigid${lashLike.size ? ': ' + [...lashLike].join(',') : ' — none detected'}, lid skin top follows ${lidTop}); inner squashed to ${s} on the closing line${parts.lower.length ? `; lower up ${(lowerUp * h).toFixed(1)}px` : ''}${parts.brow.length ? `; brow down ${browPx}px` : ''} — ${done.join(', ')}` + (unhidden.length ? `; removed attachment hide keys of ${unhidden.join(', ')} (parts now close with the same deform keys)` : ''));
      // texture check on the written keys (needs the atlas): lash / line pixels must not be stretched (lint A19)
      if (sk.atlas) {
        const sk3 = Rr.skeletonFor(JSON.parse(JSON.stringify(j)), inFile);
        const sm = Rr.deformSmear(sk3, anim, (f1 + 0.3) / fps, new Set(done.map(x => x.split(':')[1])));
        if (sm && sm.detail >= 30) {
          const share = sm.bad / sm.detail;
          report.push(`  texture @${f1}f: ${sm.bad}/${sm.detail} visible line px stretched >1.8× (${Math.round(share * 100)}%, max ×${sm.maxStretch.toFixed(1)})`);
          if (share > 0.35 && sm.bad > 150) warnings.push(`blink ${o.target}: ${Math.round(share * 100)}% of the visible lash/line pixels are stretched at the closed frame (lint A19) — the lid mesh needs more vertex rows along the lash line, or a smaller drop (line= higher, e.g. 0.3) / lidTop closer to 1`);
        }
      }
      if (!parts.inner.length) warnings.push(`blink ${o.target}: no inner= (eye white / pupil) given — the lid meshes are squashed as a whole-eye drawing would be; a separate upper-lid layer over the eye white looks better`);
    } else {
      // lid bone squash: rest -> (ease-in, fast) closed -> hold (stepped) -> (ease-out, slower) open
      need(o.target);
      // Safety checks (a scaleY blink scales around the BONE ORIGIN along the bone's LOCAL Y axis):
      //  1. the origin must sit on the eye's lower lid line, otherwise the eye collapses upward / sideways;
      //  2. the local Y axis must point roughly to world up/down, otherwise the squash is sideways;
      //  3. if the slots are whole-eye drawings (no separate lid / closed drawing), squashing to ~0 erases the
      //     eye and leaves a blank face — clamp to a squint (≥0.25) and say so.
      const Rr = require('./spine_render');
      const geo = Rr.blinkGeometry(Rr.skeletonFor(JSON.parse(JSON.stringify(j)), inFile), o.target);
      if (geo) {
        // t = height of the origin inside the eye, from the lower lid (0) to the upper lid (1). The eye closes
        // toward the origin: t≈0 lower lid (best), t≈0.5 middle (ok with a separate lash/lid layer),
        // t>0.6 or above the eye = closes UPWARD (wrong), t<-0.25 far below the eye = slides down.
        const { t, tilt } = geo;
        const problems = [];
        // the squash axis must be perpendicular to the FACE line (through both eyes), ±5°
        if (Math.abs(tilt) > 5 && !p.forceAxis) problems.push(`squash axis is ${tilt.toFixed(1)}° off the normal of the face line (${geo.faceRef}, ${geo.faceLine.toFixed(1)}°) — the eye would squash slanted`);
        if ((t > 0.6 || t < -0.25) && !p.force) problems.push(`bone origin sits at ${(t * 100).toFixed(0)}% of the eye height above the lower lid (0% = lower lid, 100% = upper lid) — the eye would close toward ${t > 0.6 ? 'the TOP (blink goes upward)' : 'a line below the eye'}`);
        if (problems.length) {
          console.error(`--blink ${o.target} mode=scaleY refused:\n  - ${problems.join('\n  - ')}\n  fix: insert a blink bone between the head and the eye: parent = ${skelParent(o.target)}, ORIGIN on the lower lid line, world rotation so its local Y is perpendicular to the face line (set its rotation to ${geo.fixRotation.toFixed(2)}° relative to the current ${o.target}); re-parent ${o.target} under it with the opposite rotation so the eye art stays put; then blink the new bone. Or use mode=attachment with a closed-eye drawing. force=1 skips the origin check, forceAxis=1 the axis check.`);
          process.exit(3);
        }
        // whole-eye drawings only? (no slot named like a lid / lash / closed eye under this bone)
        if (!geo.lidLike && (p.minScale ?? 0.1) < 0.25 && !p.allowErase) {
          warnings.push(`blink ${o.target}: slots under it look like whole-eye drawings (${geo.slots.join(', ')}); squashing below 0.25 erases the eye and leaves a blank face — clamped to minScale=0.25 (a squint). Add a closed-eye drawing (mode=attachment) or a separate upper-lid layer for a full blink.`);
          p.minScale = 0.25;
        }
      }
      const lo = p.minScale ?? 0.1;
      const f0 = at, f1 = at + close, f2 = f1 + hold, f3 = f2 + open;
      const pts = [[0, 1, 'linear'], [f0, 1, 'in'], [f1, lo, 'stepped'], [f2, lo, 'out'], [f3, 1, 'linear'], [frames, 1, null]];
      anim.bones = anim.bones || {};
      const tl = anim.bones[o.target] = anim.bones[o.target] || {};
      tl.scale = pts.map(([f, v, cv], i) => {
        const k = {};
        if (f || is37) k.time = sec(f);
        k.x = 1; k.y = v;
        const nx = pts[i + 1];
        if (!nx || cv === 'linear') return k;
        if (cv === 'stepped') { k.curve = 'stepped'; return k; }
        const c = cv === 'in' ? [0.5, 0, 1, 1] : [0, 0, 0.5, 1]; // accelerate into close, decelerate out of open
        if (is4) {
          const t0 = f / fps, t1 = nx[0] / fps, v1 = nx[1];
          const xs = [t0 + c[0] * (t1 - t0), t0 + c[2] * (t1 - t0)];
          k.curve = [+xs[0].toFixed(4), 1, +xs[1].toFixed(4), 1, +xs[0].toFixed(4), +(v + c[1] * (v1 - v)).toFixed(4), +xs[1].toFixed(4), +(v + c[3] * (v1 - v)).toFixed(4)];
        } else setLegacyCurve(k, c);
        return k;
      });
      report.push(`blink(scaleY) ${o.target}: ${f0}-${f3}f (close ${close}, hold ${hold}, open ${open})`);
    }
  } else if (o.op === 'alpha') {
    const slot = m.slotByName.get(o.target);
    if (!slot) { console.error(`slot not found: ${o.target}`); process.exit(3); }
    const base = (slot.color || 'ffffffff').slice(0, 6);
    const cycles = p.cycles ?? 2, minA = p.min ?? 0.25;
    const ks = loopKeys(minA, 1, cycles, p.phase ?? 0);
    anim.slots = anim.slots || {};
    const st = anim.slots[o.target] = anim.slots[o.target] || {};
    const hex = v => base + Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, '0');
    const rgb = [0, 2, 4].map(q => parseInt(base.substr(q, 2), 16) / 255);
    const keys = ks.map((k, i) => {
      const o2 = {};
      if (k.f || is37) o2.time = sec(k.f);
      o2.color = hex(k.v);
      const nk = ks[i + 1];
      if (!nk) return o2;
      const c = curveFor(k, nk);
      if (!is4) { setLegacyCurve(o2, c); return o2; }
      // 4.x rgba: 4 channels × [cx1, cy1, cx2, cy2] in absolute time / channel value (0..1)
      const t0 = k.f / fps, t1 = nk.f / fps, x1 = +(t0 + c[0] * (t1 - t0)).toFixed(4), x2 = +(t0 + c[2] * (t1 - t0)).toFixed(4);
      const chans = [...rgb.map(v => [v, v]), [k.v, nk.v]];
      o2.curve = chans.flatMap(([a, b]) => [x1, +(a + c[1] * (b - a)).toFixed(4), x2, +(a + c[3] * (b - a)).toFixed(4)]);
      return o2;
    });
    if (is4) st.rgba = keys; else st.color = keys;
    report.push(`alpha ${o.target} ${minA}..1 cycles ${cycles}`);
  }
}
// body-level sanity: breathing translate relative to skeleton height (reference median 7.4‰, p25 2.7‰)
const H = require('./spine_render').boundsOf(j).height; // skeleton.height, or computed when omitted
for (const o of ops) if (o.op === 'breath' && o.p.ty !== undefined && H > 0 && Math.abs(o.p.ty) / H < 0.0025 && !o.p.sx && !o.p.sy && !o.p.rot)
  warnings.push(`breath ${o.target}: ty=${o.p.ty}px is ${(Math.abs(o.p.ty) / H * 1000).toFixed(1)}‰ of height ${Math.round(H)}px (reference 3–12‰, i.e. ${Math.round(H * 0.003)}–${Math.round(H * 0.012)}px)`);
// Validate the completed output using its own schema without upgrading the input version.
// This also supplies 3.7's required time/angle/scale fields on untouched timelines.
try { j = V.convertVersion(j, ver.raw); } catch (err) { console.error(`Spine version: ${err.message}`); process.exit(3); }
fs.mkdirSync(require('path').dirname(require('path').resolve(outFile)), { recursive: true });
fs.writeFileSync(outFile, JSON.stringify(j, null, 1), 'utf8');
console.log(`wrote ${outFile} anim "${animName}" ${frames}f @${fps}fps (Spine ${ver.raw} format)\n- ` + report.join('\n- '));
if (warnings.length) console.log('WARNINGS (amplitude far below the reference corpus; intentional only for very subtle/stiff characters):\n! ' + warnings.join('\n! '));
