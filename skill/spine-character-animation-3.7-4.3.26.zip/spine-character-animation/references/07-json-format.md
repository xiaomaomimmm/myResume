# 07 · Spine JSON 版本兼容（3.7–4.3）

> 依据：spine-runtimes 各分支 `SkeletonJson.java` / `Animation.java` / `AnimationState.java`，以及官方文档（链接见文末）。
> 语料文件全部是 3.8.84 / 3.8.99。**写文件前先读 `skeleton.spine` 判断版本**，不同版本字段不兼容。

## 0. 选择目标与转换边界

2026-10-27 核对官方仓库默认稳定分支与发布记录：最新正式版 **4.3.26**（2026-09-07）；4.3.27 标记为 Unreleased，5.0 是开发分支。本技能的 `latest` 是已验证的 4.3.26，不会自动映射到未来未知格式。目标支持 3.7、3.8、4.0、4.1、4.2、4.3；编辑器与运行时必须匹配 major.minor。

```bash
node scripts/spine_gen_secondary.js in.json out/idle.json --spine-version 3.7 --breath hip ty=-8
node scripts/spine_rig_from_layers.js landmarks.json layers.json out/rig.json --spine-version latest
node scripts/spine_convert.js in.json out/rig-4.1.json --spine-version 4.1
node scripts/spine_convert.js in.json --check
node scripts/spine_compat_test.js
```

修改已有动画默认保留输入版本；新建 rig 默认 3.8.99。版本转换写入新文件，并改写 skins、曲线、约束、附件和时间轴的实际格式。旧命令 `spine_convert_38_to_42.js` 调用同一转换库。

转换器支持该技能生成的常见骨骼、region/mesh/linkedmesh、呼吸/链条/眨眼/粒子时间轴，以及可等价表示的 IK、transform、path 数据。降级遇到缺乏等价表示的特性时抛错，不写出输出：physics 到 4.1 以下、sequence 到 4.0 以下、skin-required 数据到 3.7、非零 IK softness 到 3.7、动态 inherit 到 4.1 以下、slider/跨插槽 linkedmesh/高级 transform mapping 到 4.2 以下。4.x 的 split axis 和重叠 split color/alpha 不会自动烘焙为 3.x；独立 alpha/rgb/rgb2 可以在保留 setup 其余通道的前提下转换，颜色量化为 3.x 的 8 位精度（误差最多半个 1/255）；独立 XY mix/贝塞尔曲线和超过 180° 的旋转段会拒绝有损转换。

`--check` 检查工具支持的版本格式，不能替代完整官方导入验证。软件渲染器对 path、physics、slider、clipping、sequence、drawOrderFolder、非同属性映射及 local/additive transform 等未实现行为会明确警告。需要这些功能时，用对应官方运行时或编辑器检查。

---

## 1. 顶层结构

```jsonc
{
  "skeleton": { "hash": "...", "spine": "3.8.99", "x": -438.5, "y": -79.6, "width": 1005, "height": 1319,
                "images": "./images/", "audio": "", "fps": 30 },   // fps 只有勾选 nonessential 才导出，缺省=30
  "bones":     [ { "name": "root" }, { "name": "hip", "parent": "root", "length": 0, "x": 0, "y": 735, "rotation": 0 } ],
  "slots":     [ { "name": "hair_back", "bone": "head", "attachment": "hair_back", "blend": "normal", "color": "ffffffff" } ],
  "ik":        [ { "name": "ik_leg_L", "order": 0, "bones": ["thigh_L","shin_L"], "target": "ik_foot_L", "bendPositive": false, "mix": 1 } ],
  "transform": [ { "name": "head_turn", "order": 2, "bones": ["head_turn_mirror"], "target": "head_turn_ctrl",
                   "rotateMix": 0, "translateMix": -1, "scaleMix": 0, "shearMix": 0, "x": 0, "y": 0 } ],
  "path":      [ ],
  "skins":     [ { "name": "default", "attachments": { "<slot>": { "<attachment>": { /* region/mesh/... */ } } } } ],
  "events":    { "hit": { "int": 0, "float": 0, "string": "" } },
  "animations": { "idle": { "bones": {}, "slots": {}, "ik": {}, "transform": {}, "deform": {}, "drawOrder": [], "events": [] } }
}
```

- 骨骼数组必须**父在前、子在后**；`order` 决定约束执行顺序，缺省为 0。
- 坐标系：y 向上；`rotation` 单位为度，逆时针为正；骨骼 `x,y` 是相对父骨的局部坐标。
- 3.8 起 `skins` 是数组（3.7 及以前是以皮肤名为 key 的对象）。

## 2. 附件类型（skins 内）

| type | 关键字段 |
|---|---|
| region（缺省） | `x,y,rotation,scaleX,scaleY,width,height,path,color` |
| mesh | `uvs`（0–1，按顶点 2 个数）、`triangles`、`vertices`、`hull`、`edges`*、`width`*、`height`* |
| linkedmesh | 3.7–4.2：`parent`、`skin`；3.7–4.0：`deform`；4.1+：`timelines`；4.3：`source` 代替 `parent`，可有来源插槽 `slot` |
| clipping | `end`（结束插槽）、`vertexCount`、`vertices` |
| path / point / boundingbox | 略 |

**网格权重编码**：`vertices.length == uvs.length` 表示无权重（局部坐标 x,y）。否则每个顶点写成
`[boneCount, boneIndex, x, y, weight, boneIndex, x, y, weight, ...]`，x,y 是相对该骨骼的局部坐标，同一顶点的权重和为 1。

## 3. 动画时间轴：3.8 写法

**3.7 例外**：皮肤是对象；贝塞尔使用 `"curve": [0.25, 0, 0.75, 1]`（共享的归一化控制点），不是 4.x 的绝对数组。每个 key 明确写 `time`，第 0 帧写 `time: 0`；rotate 明确写 `angle: 0`；scale 明确写 `x: 1, y: 1`。官方 3.7 解析器对 scale 缺失轴默认 0，会把轴压扁；3.8+ 缺失轴默认 1。不要复用 3.8 的省略字段写法。

```jsonc
"animations": { "idle": {
  "bones": {
    "hip": {
      "translate": [ { "y": 0, "curve": 0.25, "c3": 0.75 },        // time 缺省=0；c2 缺省 0、c4 缺省 1
                     { "time": 1.3333, "y": -8, "curve": 0.25, "c3": 0.75 },
                     { "time": 2.6667, "y": 0 } ],
      "rotate":    [ { "angle": 0 }, { "time": 1.3333, "angle": 2 }, { "time": 2.6667, "angle": 0 } ],
      "scale":     [ { "x": 1, "y": 1 } ],
      "shear":     [ { "x": 0, "y": 0 } ]
    }
  },
  "slots": {
    "eye_L": { "attachment": [ { "time": 3.3333, "name": "eye_L_close" }, { "time": 3.5333, "name": "eye_L" } ],
               "color":      [ { "color": "ffffffff" }, { "time": 1.3333, "color": "ffffff3f" } ],
               "twoColor":   [ { "light": "ffffffff", "dark": "000000" } ] }
  },
  "deform": { "default": { "eye_L": { "eye_L": [ { "time": 3.33 }, { "time": 3.43, "offset": 12, "vertices": [0, -3.2, 0, -4.1], "curve": "stepped" }, { "time": 3.6 } ] } } },
  "ik":        { "ik_leg_L": [ { "mix": 1, "bendPositive": false } ] },
  "transform": { "head_turn": [ { "rotateMix": 0, "translateMix": -1 } ] },
  "drawOrder": [ { "time": 1, "offsets": [ { "slot": "arm_R", "offset": 5 } ] }, { "time": 2 } ],   // 无 offsets = 恢复 setup 顺序
  "events":    [ { "time": 0.6667, "name": "hit" } ]
} }
```

**3.8 曲线**：`"curve"` 为数字时就是贝塞尔的 cx1，同一个 key 上的 `c2`(cy1，缺省 0)、`c3`(cx2，缺省 1)、`c4`(cy2，缺省 1) 是另外三个分量，全部归一化到 0–1（x 表示两 key 间的时间比例，y 表示数值变化比例）。`"curve": "stepped"` 表示阶梯。不写 curve 表示线性。曲线作用于**本 key 到下一 key**这一段。
- 默认 ease-in-out：`"curve": 0.25, "c3": 0.75`（c2=0、c4=1 可省略）。
- 旋转：3.x 在相邻 key 之间沿最短弧插值（差值会先 wrap 到 ±180°），**要转一整圈必须拆成多个 key**。

## 4. 4.x 差异（必须遵守）

| 项 | 3.8 | 4.0 | 4.1 | 4.2 | 4.3 |
|---|---|---|---|---|---|
| rotate key | `angle` | **`value`** | 同 | 同 | 同 |
| 曲线 | `curve`+`c2..c4`（0–1 归一化） | **`curve: [cx1,cy1,cx2,cy2, …]` 每通道 4 个数，绝对单位**（cx=秒，cy=该通道数值） | 同 | 同 | 同 |
| translate/scale/shear | `x,y` | `x,y`（curve 8 个数：x 通道 4 个，y 通道 4 个）；新增 `translatex/translatey/scalex/scaley/shearx/sheary`（字段 `value`） | 同 | 同 | 同 |
| 插槽颜色 | `color` / `twoColor` | **`rgba`**（`color` 8 位）、`rgb`（6 位）、`alpha`（`value`）、`rgba2`（`light` 8 位 + `dark` 6 位）、`rgb2` | 同 | 同 | 同 |
| transform 约束 mix | `rotateMix/translateMix/scaleMix/shearMix` | **`mixRotate/mixX/mixY/mixScaleX/mixScaleY/mixShearY`** | 同 | 同 | 同 |
| path 约束 mix | `rotateMix/translateMix` | `mixRotate/mixX/mixY` | 同 | 同 | 同 |
| deform 位置 | `deform.<skin>.<slot>.<att>` | 同 | **`attachments.<skin>.<slot>.<att>.deform`**，并新增 `sequence` 时间轴 | 同 | 同 |
| 继承模式 | 骨骼 `transform` | 同 | 同 | **`inherit`**（另有 inherit 时间轴） | 同 |
| 物理 | — | — | — | 顶层 `physics:[…]` + 动画 `physics` | 见下 |
| 约束列表 | `ik/transform/path` 分开 | 同 | 同 | 同 + `physics` | **统一的 `constraints:[{type:…}]`**（ik/transform/path/physics/slider） |
| drawOrder 键名 | `drawOrder`（也接受 `draworder`） | 只认 `drawOrder` | 同 | 同 | 同 |

**4.x 曲线数组长度**（每通道 4 个数）：rotate、translatex/y、scalex/y、shearx/y、alpha、physics = 4；translate、scale、shear、ik（mix+softness）= 8；rgb、path mix = 12；rgba = 16；transform = 24；rgb2 = 24；rgba2 = 28；deform = 4（cy 为 0–1 归一化）。

4.x key 示例（rotate，t=0 → t=0.0667）：
```json
{ "value": -2.83, "curve": [0.015, -2.83, 0.036, 12.72] }, { "time": 0.0667, "value": 12.72 }
```
3.8 归一化 ease (0.25,0,0.75,1) 转成 4.x：`cx1 = t0 + 0.25·Δt, cy1 = v0, cx2 = t0 + 0.75·Δt, cy2 = v1`。
4.x 的 rotate 直接按数值插值，不再走最短弧。

**4.3 不是只合并约束数组**：transform 的 `target` 改为 `source`，`local` 改为 `localSource/localTarget`，`relative` 改为 `additive`；用 `properties` 指定来源属性与目标属性，例如 `"properties": {"x":{"to":{"x":{}}},"y":{"to":{"y":{}}}}`。path 的 `target` 改为 `slot`；IK 的 `uniform` 改为 `scaleY`（`none/uniform` 等）；linkedmesh 的 `parent` 改为 `source`。转换器建立同属性映射并保留约束顺序；复杂跨属性映射不能简单降级。

4.2 → 4.3 physics 转换还需显式保留默认值：4.2 inertia/damping 缺省 1/1，4.3 为 0.5/0.85。仅改版本号会改变运动效果。

**4.2 physics 约束字段**（缺省值）：`name, order, skin, bone, x, y, rotate, scaleX, shearX`（0），`limit 5000, fps 60, inertia 1, strength 100, damping 1, mass 1, wind 0, gravity 0, mix 1`，以及 `inertiaGlobal…mixGlobal`（false）。动画中写成 `physics: { "<name>" | "": { "inertia":[…], …, "reset":[{time}] } }`。

## 5. AnimationState 行为（多 track 叠加）

- 低 track 先应用、高 track 后应用；高 track **只覆盖它 key 了的属性**。
- track 0 使用 `MixBlend.first`：在 attachment / drawOrder 时间轴的第一个 key 之前，显示 setup 值。其他 track 默认 `replace`：在第一个 key 之前不改动。
- **非循环动画播完会保持最后一帧** → blink 动画的最后一个 key 必须是睁眼。
- 循环时只是 `time %= duration`，**不会**恢复 setup 姿态 → idle 每条时间轴首尾必须相同；attachment/drawOrder 要在第 0 帧 key。
- 动画淡出（mix out）时，只有它 key 过的属性回到 setup；drawOrder 会立即恢复，除非设置了 `mixDrawOrderThreshold`。
- `clearTrack` 保持当前姿态；要平滑回到 setup，用 `setEmptyAnimation` / `addEmptyAnimation`。

## 6. 导出建议

- 运行时用 **binary（.skel）**：JSON 文件更大，加载更慢。JSON 用于工具链、版本管理和本技能的脚本。
- 需要回导编辑器时勾选 **Nonessential data**（会导出 fps、骨骼颜色、网格 edges/width/height、images 路径等）。
- 导出时的 **Animation clean up** 会删除与 setup 相同的 key。叠加层动画（blink、表情层）在 4.1+ 勾选 **Layered**，防止必要的覆盖 key 被删。
- 编辑器的 major.minor 必须与运行时一致；升级版本后要重新导出。

## 7. 写 JSON 的安全守则（agent）

1. 先备份；同版本动画修改只改目标动画，新增 blinkrig 时同时调整相关骨骼/蒙皮。用户要求跨版本时按转换器改写结构，保留源文件；不要把只改版本字符串当作转换。
2. 骨骼/插槽名区分大小写，必须已存在；新增骨骼要插在其父骨**之后**。
3. 每条循环时间轴：首 key `time = 0`，末 key `time = duration`，首尾值相同。3.8+ 可省略第 0 帧的 `time`，3.7 必须明确写 `time: 0`。
4. `time` 用秒，保留 4 位小数（帧/30）。
5. 改完跑 `spine_lint.js`；再用 `spine_render.js --sheet` 看一张审查板。

## 参考
- JSON 格式：https://esotericsoftware.com/spine-json-format （以目标分支解析器为准）
- 发布记录：https://esotericsoftware.com/spine-changelog
- 运行时源码：https://github.com/EsotericSoftware/spine-runtimes （3.7 / 3.8 / 4.0 / 4.1 / 4.2 / 4.3 分支 `spine-libgdx/.../SkeletonJson.java`、`Animation.java`、`AnimationState.java`）
- 叠加动画：https://esotericsoftware.com/spine-applying-animations
- 物理约束：https://esotericsoftware.com/spine-physics-constraints
- 导出：https://esotericsoftware.com/spine-export
- 骨骼与继承：https://esotericsoftware.com/spine-bones
- 眨眼示例：spine-unity `SpineBlinkPlayer.cs`（4.2 分支 Examples）
