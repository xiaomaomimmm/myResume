# 08 · 命名规范与部位词典

> 语料现状：218 个工程里，**172 个（79%）几乎全是无意义名**（`bone12`、`H5SkinOnsen_spine118`、`_34`）；40 个是语义名（拼音为主，少量英文）。
> 结论：拼音/英文都可以，但**必须语义化、带侧别和序号**。agent 读到无意义名时，先用 `spine_inspect.js --tree` 结合插槽/附件名推断部位，再建议重命名。

---

## 1. 命名格式

```
<部位>[_<子部位>][_<侧别>][_<序号>]
```
- 侧别：`L` / `R`（角色自身的左右，不是画面左右），拼音工程用 `zuo` / `you` 前缀亦可（语料：`zuodabi`、`youxiaotui`）。
- 序号：两位数，从根到梢递增：`hair_back_01 → _02 → _03`。
- 前缀约定：`ik_`（IK 目标）、`ctrl_`（控制骨）、`turn_`（伪3D）、`prop_`（道具）、`fx_`（特效）、`pet_` / `float_`（伴随物）、`bg_`（背景）。
- 骨骼、插槽、附件**三者同名**（或插槽 = 附件名），便于查找。

## 2. 部位词典（英文 / 拼音 / 语料中出现的写法）

### 躯干
| 部位 | 英文 | 拼音 | 语料出现 |
|---|---|---|---|
| 根 | root | root | root |
| 总控 / 重心 | master, hip, cog | zong, zhixin | zong, zhixin, bone, all |
| 髋/胯 | hip, pelvis | kua | kua |
| 臀 | butt | tun, pigu | dun, pigu |
| 腰 | spine_01, waist | yao | yao, yao2 |
| 胸/躯干 | chest, spine_02, torso | xiong, shenti, qugan | xiong, shenti, qugan, body |
| 胸部（左右） | breast_L/R | zuoxiong / youxiong | zuoxiong, youxiong |
| 脖子 | neck | bozi | bozi, neck |
| 头 | head | tou | tou, head, toubu |
| 脸 | face | lian | lian, face |

### 头部 / 面部
| 部位 | 英文 | 拼音 | 语料出现 |
|---|---|---|---|
| 前发/刘海 | hair_front, bangs | liuhai, qianfa | liuhai, qianfa |
| 侧发 | hair_side_L/R | cefa, binfa | erfa, youbiantoufa |
| 后发 | hair_back | houfa, toufahou | houfa, toufahou |
| 头发（通用） | hair | toufa | toufa, hair, fa |
| 辫子/马尾 | braid, ponytail | bianzi, mawei | bianzi |
| 呆毛 | ahoge | daimao | daimao |
| 眼睛 | eye_L/R | yanjing, zuoyan/youyan | yanjing, yan, eye |
| 眼白 | eye_white | yanbai | yanbai, whites |
| 瞳孔/眼珠 | pupil, iris | tongkong, yanzhu, yanqiu | yanzhu, yanqiu, pupil, eyeball |
| 高光 | highlight | gaoguang | highlight |
| 上眼皮 | lid_upper | shangyanpi | shangyanpi, yp |
| 睫毛 | lash | jiemao | jiemao, eyelash |
| 闭眼 | eye_close | biyan | **biyan**（闭眼图通用名） |
| 眉毛 | brow | meimao | meimao, mei, eyebrow |
| 嘴 | mouth | zui, zuiba | zui, zuiba, mouth |
| 舌头 | tongue | shetou | shetou |
| 鼻子 | nose | bizi | bizi, nose |
| 下巴 | jaw | xiaba | xiaba |
| 耳朵 | ear | erduo, er | erduo, youer, zuoer, ear |
| 头饰/帽子 | hat, accessory | maozi, toushi, fashi | maozi, toushi, fashi |
| 耳环 | earring | erhuan | erhuan |

### 四肢
| 部位 | 英文 | 拼音 | 语料出现 |
|---|---|---|---|
| 肩 | shoulder | jian, jianbang | zuojian, jianbang |
| 上臂 | arm_upper | dabi | zuodabi, youdabi |
| 前臂 | arm_lower, forearm | xiaobi | zuoxiaobi, youxiaobi |
| 手 | hand | shou, shouzhang | zuoshou, youshou, shouzhang |
| 手指 | finger_* | shouzhi | damuzhi(拇) shizhi(食) zhongzhi(中) wumingzhi(无名) xiaozhi/xiaomuzhi(小) |
| 大腿 | leg_upper, thigh | datui | zuodatui, youdatui |
| 小腿 | leg_lower, shin | xiaotui | zuoxiaotui, youxiaotui |
| 脚 | foot | jiao | zuojiao, youjiao, foot |
| 膝甲/护具 | knee_pad | xijia, tuijia | youxijia, zuotuijia |

### 衣物 / 饰品
| 部位 | 英文 | 拼音 | 语料出现 |
|---|---|---|---|
| 披风 | cape | pifeng | pifeng |
| 裙子/裙摆 | skirt | qunzi, qunbai | qun, qunzi, qunbai, skirt |
| 袖子 | sleeve | xiuzi, xiukou | xiuzi, xiukou, xiu, sleeves |
| 外套 | coat | waitao | waitao, coat |
| 衣领 | collar | lingzi | lingzi |
| 飘带 | ribbon | piaodai | piaodai |
| 腰带 | belt | yaodai | yaodai |
| 斜挎带/肩带 | strap | xiedai | xiedai, strap |
| 绳子 | rope | shengzi | shengzi, rope |
| 项链/锁链 | necklace, chain | xianglian, suolian | xianglian, suolian |
| 蝴蝶结 | bow | hudiejie | hudiejie |
| 围巾 | scarf | weijin | weijin, scarf |
| 铃铛 | bell | lingdang | lingdang |

### 身体附属 / 道具 / 场景 / 特效
| 部位 | 英文 | 拼音 | 语料出现 |
|---|---|---|---|
| 尾巴 | tail | weiba | weiba, tail |
| 翅膀 | wing | chibang | chibang |
| 触手 | tentacle | chushou | chushou |
| 武器 | weapon | wuqi | wuqi, baojian(宝剑), dun(盾) |
| 篮子 | basket | lanzi | lanzi |
| 灯笼/灯 | lantern | denglong, deng | deng |
| 背景 | background | beijing | beijing, bj |
| 植物/草/树 | plant/grass/tree | zhiwu/cao/shu | cao, shu |
| 特效 | fx | texiao | texiao, tx |
| 光效/散光 | glow, light | guangxiao, sanguang | guangxiao, sanguang, light, faguang |
| 碎石 | debris | suishi | suishi |
| 烟/蒸汽 | smoke/steam | yan/zhengqi | zhengqi |
| 阴影 | shadow | yingzi, yinying | yingzi, yingying |

## 3. 推断无意义名的方法（agent）

1. 看插槽名/附件名：骨骼名无意义时，插槽/附件常常有意义（如 `biyan`、`toufa3`）。
2. 看层级位置：`root` 的最大子树是身体；身体路径的第 5–6 节是头；头的子链是头发/耳朵。
3. 看几何：setup 姿态世界坐标的最高处是头，最低处是脚；链长 15–30px 的细链在头部 = 头发。
4. 看动画：短脉冲（≤20f）多部件同步 = 眨眼；360° linear = 光环/齿轮；只有 translate 的零长度骨 + 平移约束 = 伪3D 控制。
5. 用 `spine_render.js --parts` 一次输出全部部件的索引板（48 个/页，控制台打印编号 → 插槽/骨骼），对照着改名。不要对每根骨骼单独用 `--isolate` 出图。
