# ArrowsGo Animation 工程约定

核对快照：2026-11-12，Unity 6000.3.16f1。以下源码路径相对 `arrowgo-unity/`；执行时以目标资产和当前源码为准，不把快照数量作为验收条件。

## 目录与制作入口

| 项目 | 规则及性质 |
|---|---|
| 正式 Clip | `Assets/AssetBundle/Animation/<功能>/`；784 个现有 .anim 均在此，是工程惯例。已有功能目录复用；没有时建立对应功能目录，页面专用 Clip 不因参考 Dialog 就塞进 Dialog 目录 |
| 模块 UI Prefab | `Assets/AssetBundle/Prefab/UI/<功能>/`，沿用目标页面目录 |
| 玩法/场景 Prefab | `Assets/AssetBundle/Prefab/GamePlay/` 下既有模块目录，先查同类对象 |
| Timeline 与预演场景 | 新增建议 `Assets/Art/Preview/<功能>/`；已有模块预演目录可沿用。已有参考 `Assets/Art/Preview/Uiv2.playable` |
| Legacy | 正式 Legacy 交付需要 `AnimationClip.legacy=true` 和 `Animation`。`Assets/Editor/Animation/LegacyAnimImporter.cs` 对所有 `Assets/AssetBundle/` 下 .anim 导入自动设置 Legacy，并不设置其它字段 |
| 采样率 | 新增通常 60；现有 782 个为 60、2 个为 30。不是设备帧率要求，不统一改现有 Clip |
| 新 UI | `Assets/Editor/UI/UIGenerateEditor.cs` 的 `Assets/Create Template UI` 建根 Animation/Canvas/GraphicRaycaster；确需导出引用时用 `Assets/Generate Base UI`，不手改生成类 |
| 转换入口 | `Assets/Editor/Animation/AnimatorToLegacyAnimationTool.cs` 整个工具类当前被注释，没有可用转换菜单。不要建议点击它 |
| 打包 | 正式目录和 Prefab 引用仍需程序确认加载/打包。`Assets/Editor/Resource/ResEditor.cs` 排除 Animation 常量生成，不承诺新 Clip 自动产生资源常量，也不强制逐 Clip 手填包名 |

新资源命名建议 `<用途/对象>_<阶段>`，文件名、内部名和实际注册名一致。现有工程有 `ea_`、UI 名等多种命名，没有统一强制前缀。固定播放名、别名和共享资源必须先查消费者。

按入场、退场、按钮反馈、强调、循环选取 [用途制作规则](animation-purposes.md)；新增阶段命名是建议，实际播放状态由消费者决定。Show/Click/Idle/Loop 的命名或 LoopTime 字段不单独构成用途分类或播放规范。

## Clip、组件与曲线

- 每条曲线相对 **Animation 所在对象** 解析节点路径；移动挂点或重命名节点后重查组件与属性。通用 `ea_CommonDialog_show` 涉及 `Content` 缩放/CanvasGroup Alpha 和 `Bg/CloseBg` 的 Image Alpha，结构不同不能直接认定通用曲线适用。
- 对本段控制的属性给出明确初终态；沿用布局与视觉节点分工，排查 LayoutGroup、适配、按钮反馈、程序换图/文本和其它动画是否同时写同一属性。
- Animations 列表需要正式播放的 Clip，或有可核验的正式 `AddClip` 注册逻辑；记录实际播放名。默认 Clip 对无参 Play/自动播放有影响，SlideInPage 等还读它做姿态接管，不能因按名播放就随意清空。
- 新程序触发对象建议 `playAutomatically=false`；启用即播的装饰可以开。现有 811 个实际序列化组件中 522 开、289 关，没有统一默认；另 114 条 stripped 引用不能作为完整组件统计。
- 现有完整组件均为 AlwaysAnimate，可沿用。普通 UI 不随意开启物理更新。时间缩放/暂停期间要否继续播放写给程序，Legacy 默认行为不能代替时间源合同。
- 事件应保留原时间、函数名、参数；新增仅采用双方已约定的事件。核对同对象的接收脚本及签名；Sample 预演不能证明业务事件已接收到。`AnimatorDisableEvent` 是 Animator 路线，不是 Legacy 通用结束回调。

| 结束需求 | 设置/接收合同 |
|---|---|
| 播完停止 | Once；停止/重置时间不保证保持最终姿态 |
| 停留末帧 | ClampForever，或程序采样终态后处理；ClampForever 仍在播放，不能等 `!isPlaying` 自然结束 |
| 循环 | Loop，明确停止时机与停止后的姿态 |
| 往返 | PingPong，确认回程节奏 |

AnimationState 初始继承 Clip，程序可覆盖 state；state 为 Default 才用组件 Wrap Mode。`Loop Time`、Clip wrapMode、组件 wrapMode 与运行时 state 分别记录。重播/打断/结束复原是不同操作：同一正在播放动画再次 Play 不自动回到起点；Stop 不保证回到设计初态。

官方核对入口：[WrapMode](https://docs.unity3d.com/6000.3/Documentation/ScriptReference/WrapMode.html)、[Animation.Play](https://docs.unity3d.com/6000.3/Documentation/ScriptReference/Animation.Play.html)。

## 程序播放入口路由

| 目标 | 当前入口 | 交付时要核对 |
|---|---|---|
| 普通 BasePage | `Assets/Scripts/Game/Framework/UI/BasePage.cs`：`ea_CommonDialog_show` / `ea_CommonDialog_close`；默认 InDuration=0.3、OutDuration=0.2 | WaitForSeconds 使用字段，不自动按 clip.length；专用名或时长需要本页程序接入。IsShowInAnim=false 会绕过进场回调路径，涉及自动关闭时需核对生命周期 |
| 根挂点 | `Assets/Scripts/Game/Framework/UI/BaseUI.cs`：Create 中 GetComponent<Animation>() | 默认页面主动画与 BaseUI 同根；子动画需要正确的子组件引用 |
| Style3 | `Assets/Scripts/Game/Framework/UI/Style/GameUIStyle/BaseStyle3Page.cs`：`ea_CommonDialogStyle3_show/close` | 找到 Clip 时按其 length，缺失回退 BasePage；检查子类覆写 |
| 滑动页 | `Assets/Scripts/Game/Framework/UI/SlideInPage.cs`、`PageSlideAnim.cs` | 已有 DOTween/曲线入口，先查现有组件，不盲建整页滑动 .anim；默认 Clip 参与姿态接管 |
| 猫逃开局 | `Assets/Scripts/Game/Module/Gameplay/CatEscape/View/CatEscapeOpeningPage.cs` | 播 `CatEscapeOpeningUI_appear`，按 Clip length；整段已有淡出，IsShowOutAnim=false 防止再叠退场 |
| Gallery 成功 | `Assets/Scripts/Game/Module/Gallery/View/GallerySuccessResultAnimationController.cs` | 存在固定 2.7166667 秒与 `CollageResultSuccessUI` 名称；实际 Gallery Clip 内名可能不同，先查目标，不擅自改此处 |
| 按钮反馈 | `Assets/Scripts/Game/Utils/UI/ButtonPressEffectAnimation.cs` | 配 m_Animation、m_PressClip、可选 m_HoldClip、m_ReleaseClip。已有自动注册、Hold 排队、Release 停旧队列、OnEnable 采样 Release 末帧复原；程序确认播放器已接按钮 |
| Toast Style3 | `Assets/Scripts/Game/Module/ThemeEvent/View/ThemeEventToastStyle3Page.cs` | 运行时 state.wrapMode=ClampForever 并采样首帧，说明文件 Loop 字段不代表最终行为 |

普通通用 show/close 实际约 0.233333/0.316667 秒，与 BasePage 默认等待不同。该差异用于提醒交付核对，不在本 Skill 的普通制作任务中批量修复旧页面。
