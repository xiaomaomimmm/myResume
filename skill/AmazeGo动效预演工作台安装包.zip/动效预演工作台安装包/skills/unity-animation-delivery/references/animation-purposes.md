# 按用途制作 Animation

面向设计师的用途规则；供 harness 选方案、建资源和验交付。核对日期：2026-11-12。源码与资产路径相对 `arrowgo-unity/`。**已有约束**来自当前播放器；**新建建议**用于没有现成方案时；示例的幅度、秒数和节点名不推广成全项目默认。

## 先判断用途，再判断阶段和重复方式

用途说明“为什么动”，阶段说明“何时动”，重复方式说明“怎样持续”。它们不是同一个字段。

| purpose | 用途 | phase | 常见 repeat_mode |
|---|---|---|---|
| entrance | 页面/对象从准备态进入展示态 | enter | once |
| exit | 从当前展示状态收起、离开 | exit | once |
| button_feedback | 用户操作反馈 | press / hold / release；确认点击后反馈用 click | press/release/click 为 once；hold 为 continuous 或 static_hold |
| emphasis | 奖励、错误、提示、强调某个信息 | cue | once；隔一段时间提醒为 periodic |
| loop | 等待、呼吸、闪光、常驻装饰等持续表现 | cycle | continuous；只有姿态维持时用 static_hold |

文件名只能帮助查找。例如 `ea_RateDialog_click` 是未选星时的内容反馈，不是按钮 PointerDown 的按下动画；`ea_BackBtnStyle3_Loop` 则只有零时刻姿态键。不能由 Click/Idle/Loop 后缀自动决定绑定和播放模式。

将每段写成：`触发 → 初态 → 过程 → 终态 → 完成条件/后继`，另记 `谁停止、停止后怎样复位、再触发怎样处理`。一个对象可以同时有页面入场、局部强调与常驻循环；按 Animation 组件和实际曲线属性区分它们。

只整理需求已涉及或现有播放器真正需要的阶段。页面入场回调直接启动角标循环时，不为了 Show→Loop 模板再建角标 Appear；已有完整演出不为凑阶段数量拆 Clip。没有后继/业务等待的 Release 或一次强调可以自带归位末帧，不为了填写 completion 字段增加新协程/回调：采用可自然结束的 Once，或按实际持帧策略标 none/external_signal。需要回调的消费者才记录它的已有入口或程序接收合同。

## 五类用途的制作规则

### 入场 entrance

- **初态与终态**：初态必须在首次可见前建立，避免先闪一下落位再回动画首帧；终态是该对象真实展示姿态，不默认 scale=1 或 alpha=1。只写本段负责的视觉属性。
- **挂点**：默认 BasePage 主进场使用页面根 Animation；子部件入场按它的实际播放组件。布局节点与视觉动画节点分工，不能为了入场曲线移动程序排布节点。
- **完成与交互**：先查消费者。BasePage 按 InDuration 计时，Style3/专用页可能按 Clip length；交互放开可能被页面覆写。不能通用地承诺“入场播完就可点击”。
- **末帧与后继**：没有需要自然排队的后继时，可以 ClampForever 保持落位，完成由计时/明确回调负责；采用 PlayQueued(CompleteOthers) 接后续时，前段需要有效 Once，落位由后继首帧或明确姿态接管。ClampForever 不会自然释放队列。
- **中途关闭/重开**：关闭优先取消入场和迟到回调；固定退场首帧未必匹配中途姿态。实际衔接、重新显示前复位需测试，不能只在 Timeline 拖首尾检查。

### 退场 exit

- 初态是退场触发时的可见状态；终态是收起/离开的视觉状态。退场不必是入场曲线倒放，倒放不能代替设计确认。
- 开始退场时按目标生命周期阻止新的交互，清理会重新启动循环/提示的旧回调；对象保留到退场完成。页面隐藏、释放资源和业务跳转由已有程序入口负责，不靠新建一个 Animation Event 名字完成。
- 一般为有限单段。Once 适合自然完成；若要在收起姿态等程序隐藏，可用 ClampForever + 有限完成回调。不能依据 `!isPlaying` 等 ClampForever 结束。
- 自带完整进/停/退演出的 Clip 不再自动叠通用退场。例如 CatEscapeOpeningPage 已设 IsShowOutAnim=false。需求要求专用退场时，交付对应播放名、OutDuration/实际等待及事件时机。
- 退场中重开、重复关闭、入场中关闭都要有明确策略；不要让旧 HideDone 把新一轮页面隐藏。只列接收合同，不借此自动改业务代码。

### 按钮反馈 button_feedback

先区分 **按下/按住/松手反馈** 与 **确认点击后的反馈**。前者有交互状态，后者通常是一次 click 动画；只有一次点击需求时不强行制作三段。

已有 ButtonPressEffectAnimation 的接入合同：

| 阶段 | 制作要求 | 当前播放器行为/限制 |
|---|---|---|
| press | 常态 → 按下态；要自动接 Hold 时为可自然结束的有限段 | Play 前 Stop；播 m_PressClip，Hold 存在时用 CompleteOthers 排队。播放器不主动设置 WrapMode，必须核对有效状态为 Once |
| hold | 首帧接住 Press 末态；保持缩放、持续光效等。动态光效需要时间变化，静态按住姿态可以零跨度 | m_HoldClip 可选；动态重复用有效 Loop，单纯维持姿态可由 ClampForever/明确采样维持。零时长采样的实际行为需在目标播放器验证 |
| release | 当前按下/按住态 → 常态，所有被反馈改变的属性都要收回 | 先 Stop 清旧队列再 Play m_ReleaseClip，不能让旧 Hold 在释放后重新出现；快速松手可能尚未到 Press 末帧，检查衔接 |
| re-enable | 重新启用时直接处于正常可操作姿态 | OnEnable Stop 并采样 Release 末帧。这里的 Release 是复位来源，不能当可随意省略的装饰；有已确认的替代复位机制时另记合同 |

效果脚本挂在 ButtonScaleStyle3 / Button2DStyle3 宿主同一节点上，m_Animation 可指向正确的视觉子对象。ButtonPressEffectPlayer 只收集宿主同节点效果，重复按下有去重；挂在任意子节点的效果不会自动被宿主发现。

**属性竞争必须明确处理**：ButtonScale 的 enableScale=true 会立即改宿主缩放；Animation 也写同一宿主 localScale 时有两个写入者。可选择将动画放视觉子节点并校准叠乘，或在本次目标上用已确认的单一缩放机制。移到子节点仍保留宿主即时缩放，不能承诺整个按钮已变成平滑动画；不批量关其它按钮的 enableScale。

验收至少覆盖短按（Press 未结束即松手）、长按、释放中再按、按住时禁用/关页、重新启用。效果的 Release 末帧复位不证明宿主的点击状态、输入机制、其它叠加效果也已复位，分别核对；确认点击后的业务反馈不能改成 PointerDown 就触发。

### 强调 emphasis

- 常态 → 峰值/反馈 → 常态；有意保留新状态时另写终态，不能把残留缩放/旋转当作完成。
- 默认一次有限演出，新建通常采用 Once 并给出明确恢复方式。幅度、次数和时长由参考/设计确定，不将 ChestItem 的 scale=1 和 rotation=identity 当所有对象的基准。
- 再次触发选择重启、合并/忽略或排队，沿用消费者；每次触发会 Stop/重播的 ChestItem 是一个工程例子，不是所有强调必须重启的规则。
- 每隔几秒提醒仍可属于 emphasis，repeat_mode=periodic。记录间隔是起点到起点还是完成后等待、首次何时触发、重叠怎样处理和点击/关闭的终止条件。可以用一次 Clip + 现有调度器，也可把强调与静止间隔制作成完整循环段；选择已有入口或明确接收合同，不假设现成通用调度器存在。
- 强调与按钮反馈、页面入退场、常驻循环写同一属性时，要分视觉节点，或明确停旧动作/复位/恢复旧循环的流程。不能只放多个 Animation 就认为不会竞争。

### 循环 loop

- 默认是持续表现的一个可重复周期。循环启动点、周期长度、时间源与停止者都要明确；循环 length 是单周期长度，不是业务等待多久。
- 动态周期要有真实时间变化，首尾值、速度/切线和离散状态切换要检查接缝；有意闪断/逐帧换图可按设计保留。自定义 effectFactor 首0尾1不能直接判接缝失败或成功，需结合对应组件/材质观察。
- 持续表现采用有效 Loop 或按需求 PingPong；静态维持采用 static_hold，并与“动态循环”区分。已有零跨度、有非空姿态键的 Clip 不自动判坏、不统一加尾帧；如果需求确实要呼吸，它也不能冒充动态周期。
- 关闭、禁用、被点击、业务结束或资源复用时由明确对象停循环；同时取消待启动的延迟/队列。停止后是保当前帧、恢复基准还是播放收尾，写明策略并验证。
- Loop 内事件每周期可能重触发，Battle_idle 的滚动音效就是例子。按事件用途确认重复次数/去重，不一律删循环事件，也不把一次奖励事件无说明地放进循环。

## 组合衔接与新建命名

| 组合 | 衔接规范 |
|---|---|
| 页面入场 → 展示循环 → 退场 | 入场自然结束或有效完成回调启动循环；关页取消旧完成回调、停止循环，再按退出合同收起；重开先恢复初态 |
| Show → PlayQueued Loop | Show 实际为 Once，不能 ClampForever；Loop 首帧接管本段要维持的属性；被禁用时连待播放队列一起停止 |
| Press → Hold → Release | Press 有限完成才自动到 Hold；松手可在 Press 或 Hold 阶段抢占，清队列后 Release；隐藏时依明确复位机制收回全部反馈属性 |
| 强调插入常驻循环 | 分节点/属性，或明确中断→强调→复位/恢复循环；恢复是从头还是继续需有合同，不靠两个 Clip 自行混合 |

相邻段只对共同负责的属性核对前段终值与后段起值。后段不写某个属性时，明确由谁保持/复位；不要为“接住末帧”把布局、动态文本、换图和业务状态无意录入。不同对象之间可通过已有完成回调衔接，next_id 表示已有后继而不是必须增加一段新资源。

新建建议命名：`<对象>_Appear`、`_Disappear`、`_Press/_Hold/_Release`、`_Click`、`_Emphasis`、`_Loop`。放 `Assets/AssetBundle/Animation/<功能>/`；旧固定播放名、共享资源和专用脚本入口优先，不按后缀批量重命名。新建通常 Legacy、60 Samples；没有统一用途秒数/缩放比，也没有一律开启自动播放的规范。

## harness 的用途合同

读取 [用途配置](../assets/purpose-profiles.json) 中本次 purpose；它给出阶段、推荐新建设置和必需检查，**不能拿推荐值覆盖既有资产**。新建、修改或交付具体动效时，在 report.json 的 `motion_contracts` 中按实际阶段记录：

`id/target/purpose/phase`、`settings_origin`（proposed/observed/unresolved）、Clip/挂点、首终态、实际或待定时长、repeat_mode、有效 WrapMode、完成条件、后继、停止者、复位/重播、负责属性与竞争、周期调度（适用时）。参考值和计划与观察分开；未知字段为 null/unresolved，并在 checks 给出 next_action。

检查 ID 可用 `purpose.<id>.classification/completion/continuity/ownership/reset/stop/cadence/events`，只选择用途涉及的项。约定已写成 JSON 不等于效果通过；曲线/挂点/初终态、有效播放模式、队列、快速打断、循环接缝和真实输入仍分别需要实际证据。只查用途规范时，不强制生成制作合同或验收材料。

## 工程举证

| 依据 | 已观察到的事实；不扩大为通用默认 |
|---|---|
| `Assets/Scripts/Game/Framework/UI/BasePage.cs` + `Assets/AssetBundle/Animation/Dialog/ea_CommonDialog_show.anim` / `ea_CommonDialog_close.anim` | 页面固定选名/字段计时；通用 Clip 有缩放与 Alpha 曲线。原始序列化末帧约0.233333/0.316667秒，不等于默认等待0.3/0.2 |
| `Assets/Scripts/Game/Module/Gameplay/Battle/UI/BattleMatchPage.cs` + `Assets/AssetBundle/Animation/Battle/Battle_start.anim` / `Battle_idle.anim` / `Battle_disappear.anim` | Start/Disappear 在 runtime state 用 ClampForever，Idle 用 Loop；按 length 计时、清理协程、重设 time 并 Sample。三个资产 LoopTime 都是1，不能据此把进退场判为持续循环；本页始终屏蔽输入 |
| `Assets/Scripts/Game/Module/RankList/View/DoubleBtnItem.cs` + `Assets/AssetBundle/Animation/FullLivesComplete/DoubleBtnItem.anim` / `DoubleBtnItem_Loop.anim` | show 文件 LoopTime=1，但程序 state 强制 Once 后排队 Loop；禁用会取消延迟并 Stop。show 约0.35秒和周期约4.233333秒只是该样例 |
| `Assets/Scripts/Game/Utils/UI/ButtonPressEffectAnimation.cs`、`ButtonPressEffect.cs`、`ButtonPressEffectPlayer.cs`、`ButtonScaleStyle3.cs`、`ButtonScale.cs` | Press/Hold/Release 字段、Hold 可选、清队列、Release 末帧复位、同节点效果收集、宿主即时缩放；不能泛化为全按钮生命周期已验证 |
| `Assets/AssetBundle/Prefab/UI/Home/CircleBtnStyle3.prefab` + `Assets/AssetBundle/Animation/View/Style3/ea_BackBtnStyle3_Click.anim` / `_Loop.anim` / `_End.anim` | GUID 引用对应 Press/Hold/Release；Loop 有根缩放、BgExpand 缩放/激活键，所有键在0时刻。是非空零跨度姿态资产，实际维持行为仍需 Unity 验证 |
| `Assets/Scripts/Game/Module/RankList/View/ChestItem.cs` + `Assets/AssetBundle/Animation/Rank/ChestItem_Shake.anim` | 点击 Stop 后 Play；SetData 明确复位缩放/旋转；Clip 晃动后回到原态，约0.7秒已回稳，序列化末帧约1.166667秒，视觉运动结束不等于 Clip length |
| `Assets/Scripts/Game/Module/RateUs/View/RateUsWithStarsStyle3Page.cs` + `Assets/AssetBundle/Animation/Dialog/ea_RateDialog_click.anim` | 未选星点击确认时播放内容反馈、暂时禁用星按钮并0.42秒后恢复；是该页反馈合同，不是所有 click 的按下/松手接口 |
| `Assets/Scripts/Game/Module/Gameplay/GameView/View/GridHintViewStyle3.cs` + `Assets/AssetBundle/Animation/Home/Style3/ea_GridHintViewStyle3_Show.anim` | 排布只动 Root，出现曲线写 BG；播放后立即 Sample 避免闪落位。证明布局位置与视觉动画节点需要分工 |

以上是源码与磁盘取证，未逐项做 live Unity 播放或视觉验收。
