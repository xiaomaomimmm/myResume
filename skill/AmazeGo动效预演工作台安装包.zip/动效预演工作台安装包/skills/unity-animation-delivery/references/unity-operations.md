# Unity 自动化执行方法

按任务选择操作；这些是 harness 使用的 Unity API 配方，不是设计师要手写的程序。不要把此处方法名直接当作 MCP action；先读取当前工具 schema，再映射调用。

## 能力发现与环境

1. 有 Unity MCP 时读取 `mcpforunity://custom-tools`、`mcpforunity://instances`、`mcpforunity://editor/state` 和 `mcpforunity://project/info`，确认项目根和版本。多实例时锁定真实目标实例；不使用本资料的旧实例 ID。
2. 按当前 schema 使用 `manage_asset`、`manage_animation`、`manage_components`、`manage_prefabs`、`manage_scene` 等。`manage_animation` 可能主要支持 Animator，不能默认它产出 Legacy 对象。工具动作覆盖不足时，可用工程 `script-execute` 桥调用 Unity API。
3. 桥来源 `Assets/Editor/MCP/ScriptExecuteTool.cs`：通过 `execute_custom_tool`，`tool_name="script-execute"`，parameters 含 `code`、`class_name`、`method_name`。代码定义 public class 和 public static 无参方法。先确认自定义工具存在；涉及 API 用当前反射/源码核对。临时桥代码在内存编译，不必写临时 Editor 文件进工程。
4. 桥返回明确 success/data envelope，或写出指定报告后回读。裸集合曾出现 success=true/data=null；空数据不能算检查通过。检查 Console、编译与导入状态，再读取具体结果。
5. 无 Unity 时执行静态预检、整理参数/变更计划/交付草稿。Unity 才能验证的项标 pending，说明缺能力；不手改 .anim、Prefab、Timeline YAML 来伪造已制作结果。

维护用户的未保存场景和修改。Prefab 修改优先隔离 `LoadPrefabContents`；预演使用专用场景/临时实例。不要默认保存当前打开的全部场景，或退出 Play Mode 丢弃用户工作；确需切换而影响工作时再确认。

## 创建或更新 Clip

- 先完成本次 [用途合同](animation-purposes.md)：入退场、按下/按住/释放、确认点击、强调或持续周期分别处理。推荐 WrapMode 取决于实际完成/后继条件；不能统一按文件名设 Loop，也不能把所有入场设 ClampForever 后仍用 CompleteOthers 等它结束。
- 用 `AssetDatabase.LoadAssetAtPath<AnimationClip>(path)` / 查 GUID 找已有 Clip。已有资源原位修改；移动用 `AssetDatabase.MoveAsset` 保留 GUID，避免删除重建。
- 新建功能目录用 `AssetDatabase.IsValidFolder` / `CreateFolder`；新 Clip 使用 `new AnimationClip`，设置 name、legacy=true、按需求/惯例 frameRate、wrapMode，再 `AssetDatabase.CreateAsset`。仅在路径无既有资源时 CreateAsset。
- 复用通用曲线制作页面专用变体：先查目标相对路径，复制到专用功能目录（CopyAsset 或 Instantiate 后 CreateAsset）；新变体有新 GUID，原共享资源保持原样。用户确要全局修改时再检查消费者范围。
- 浮点曲线用 `AnimationUtility.GetCurveBindings/GetEditorCurve/SetEditorCurve`；对象引用曲线用 `GetObjectReferenceCurveBindings/GetObjectReferenceCurve/SetObjectReferenceCurve`；事件用 `GetAnimationEvents/SetAnimationEvents`。调整既有数据只改涉及的曲线、时间和字段，保留其它切线、权重、事件和引用。
- 时间改动要同时核对各条曲线、事件和 Clip 设置。通过 `AnimationUtility.GetAnimationClipSettings/SetAnimationClipSettings` 调整所需 loopTime 等。最终 `clip.length` 与首尾帧由 Unity 回读，不能只写 stopTime 或拉长 Timeline 段就宣称正式动画为指定时长。
- 新曲线以实际组件序列化属性为依据，确认 binding.path、binding.type、propertyName。对需要的属性显式设置初终帧；有已确认参考则按参考制作，缺关键视觉值保留草稿并说明。不要用默认缩放淡入替换已有设计方案。
- 段间衔接比较共同负责属性的前段终帧/后段首帧；动态循环检查周期变化、首尾值/切线和离散切换。静态 Hold 可有零时刻姿态键，不为通过“时长检查”给既有资源补任意1秒尾帧。快速 Release 和退场中途打断要用实际触发时姿态验证，不能假定都从前段末帧开始。
- `EditorUtility.SetDirty` 后保存相关资产。`AssetDatabase.SaveAssets` 可能保存其它脏资产，优先使用当前版本支持的定向保存方法；确需全局保存时先检查脏资产范围。

## 正式 Prefab 挂载与回读

- `PrefabUtility.LoadPrefabContents(path)`，按目标相对节点路径定位 GameObject，取/添加 Animation；`finally` 中 `UnloadPrefabContents`。变体和嵌套 Prefab 保持层级与连接，只应用到需求指定层，不能通过展开 YAML 猜引用。
- 检查 `animation.GetClip(playName)`。无注册时 `AddClip(clip, playName)`；已有同名同 Clip 则复用；同名不同 Clip 时先查消费者和请求，不静默覆盖。保留其它注册及默认 Clip；只有任务明确要求才改默认 Clip、autoplay 和更新模式。
- 解析所有 float/object-reference bindings，确认节点、组件和属性存在；检查 missing script、丢失对象引用、动态布局/文本/换图冲突。运行时程序注册可作为接收合同，但必须定位真实代码和名称，不能拿 Timeline AddClip 作证明。
- `SaveAsPrefabAsset` 保存目标，卸载后再次加载，记录 Animation 节点、实际状态名、各 Clip GUID、默认 Clip、autoplay、设置和曲线；读到已保存数据才算 `unity_load`。在重新加载前不运行 Timeline。
- 真正播放验证使用新实例、实际播放器或明确的临时验证入口。Sample 只能证明采样；实际 Play/事件/页面回调需要对应播放证据。检查首次、播放中重触发、停止/隐藏后重开、完整结束后重播；结束时记录视觉姿态和 state。

## Timeline 预演

源码位于 `Assets/Addons/TimelineExtension/Runtime/`：LegacyAnimationTrack、LegacyAnimationClip、LegacyAnimationBehaviour、LegacyAnimationMixerBehaviour；Editor 下 ClipEditor 用于编辑检查。先查既有 Timeline/Director 并复用。

| 工作 | Unity 操作及需记录数据 |
|---|---|
| 新 Timeline | `ScriptableObject.CreateInstance<TimelineAsset>()` 并 CreateAsset；在独立预演场景放演出实例和 PlayableDirector |
| 轨道 | `timeline.CreateTrack<TimelineExtension.LegacyAnimationTrack>(null, trackName)`；Director 用 SetGenericBinding(track, animation) 绑定 **Animation** |
| 片段 | `track.CreateClip<TimelineExtension.LegacyAnimationClip>()`；asset 的 Clip 引正式 .anim，Speed、Loop 按需求设置；记录 TimelineClip.start、duration、clipIn、timeScale 及 ease/blend 参数 |
| 保存 | 保存 Timeline 和指定预演场景，重开/回读 Director 的 GetGenericBinding 及每段引用。Timeline 文件本身不能替代场景中的对象绑定 |
| 观察 | 独立预演实例下用 Director.time/Evaluate 按起点、变化关键点、末帧采样，或实际播放观察整段；检查适配、遮罩、排序和演出衔接；停止后恢复临时实例，不把采样姿态存回正式 Prefab |
| 更新 | 保留未涉及轨道、片段、曲线、绑定、Clip In、Speed、timeScale 和循环；同请求重跑复用资源，不追加重复轨道/片段 |

扩展的实际限制：自动 AddClip；Loop=true 时 state.wrapMode=Loop，否则 ClampForever；输入时间乘 asset.Speed，TimelineClip.timeScale 还影响输入时间。只采样最高权重输入，不是多段完整交叉混合。`LegacyAnimationClip.duration` 返回 clip.length，但段裁切/时间缩放可能不同，更新时不能把已有编排全重置为 clip.length。

预演成功后，必须另查正式保存的 Prefab 注册与独立播放；它们是不同 checks。Spine、Game/UI 粒子只在组合演出需要时保留/设置对应衔接，不在这个 Skill 内重做素材或转换粒子。

## 失败与重入

能定位的错误只修本次目标。相同操作失败且没有新依据时停止重复写入，保留可回读草稿、错误和 next_action。清理仅限本次临时实例/文件，不删除共享资源。恢复本次改动也需先核对用户是否期间修改，不能用整个目录回滚覆盖用户工作。
