#!/usr/bin/env python3
"""Read-only, conservative Unity text-asset inspection; never certifies playback."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re

GUID = re.compile(r'\bguid:\s*([0-9a-fA-F]{32})\b')
BLOCK = re.compile(r'^--- !u!(\d+) &(-?\d+)([^\n]*)\n(.*?)(?=^--- !u!|\Z)', re.M | re.S)

def field(text, key):
    match = re.search(r'^\s*' + re.escape(key) + r':\s*([^\n]*)$', text, re.M)
    return match.group(1).strip() if match else None

def number(text, key):
    raw = field(text, key)
    try:
        value = float(raw) if raw is not None else None
        return value if value is not None and math.isfinite(value) else None
    except ValueError:
        return None

def asset_path(root, value):
    rel = Path(value)
    if rel.is_absolute() or '..' in rel.parts or not rel.parts or rel.parts[0] != 'Assets':
        raise ValueError('Expected an Assets-relative path: ' + value)
    path = (root / rel).resolve()
    if not path.is_relative_to(root):
        raise ValueError('Asset path escapes project: ' + value)
    return path

def inspect(project_root, clips, prefabs):
    root = Path(project_root).resolve()
    for value in clips + prefabs:
        asset_path(root, value)
    report = {
        'schema_version': '1.0', 'skill': 'unity-animation-delivery',
        'mode': 'inspect', 'project_root': str(root),
        'created_at': datetime.now(timezone.utc).isoformat(),
        'request': {'clips': clips, 'prefabs': prefabs, 'source': 'static_audit'},
        'observations': [], 'checks': [], 'changes': [], 'artifacts': [],
        'programmer_handoff': [], 'handoff_status': 'not_requested',
    }
    def check(target, code, status, detail, action='', required=True, level='static'):
        report['checks'].append({'id': target + ':' + code, 'target': target,
            'status': status, 'level': level, 'required': required, 'scope': 'resource_delivery',
            'detail': detail, 'evidence': [target] if level != 'none' else [],
            'next_action': action})
    for rel in dict.fromkeys(clips + prefabs):
        path = asset_path(root, rel)
        if not path.is_file():
            check(rel, 'exists', 'failed', 'Asset file missing', 'Resolve the target path or create the requested asset in Unity')
            continue
        data = path.read_bytes()
        text = data.decode('utf8', errors='replace')
        meta = Path(str(path) + '.meta')
        found = GUID.search(meta.read_text('utf8', errors='replace')) if meta.is_file() else None
        obs = {'path': rel, 'sha256': hashlib.sha256(data).hexdigest(),
            'guid': found.group(1).lower() if found else None}
        report['observations'].append(obs)
        check(rel, 'exists', 'passed', 'File exists')
        check(rel, 'guid', 'passed' if found else 'failed',
            'Asset GUID present' if found else 'Missing or unreadable meta GUID',
            '' if found else 'Check import/meta in Unity; preserve existing identity, do not invent a replacement GUID')
        if rel in clips:
            is_text_clip = any(m.group(1) == '74' and re.match(r'AnimationClip:\s*\n', m.group(4)) for m in BLOCK.finditer(text))
            obs.update({'name': field(text, 'm_Name'), 'legacy': number(text, 'm_Legacy') if is_text_clip else None,
                'sample_rate': number(text, 'm_SampleRate') if is_text_clip else None,
                'wrap_mode_serialized': number(text, 'm_WrapMode') if is_text_clip else None,
                'stop_time_serialized': number(text, 'm_StopTime') if is_text_clip else None,
                'loop_time_serialized': number(text, 'm_LoopTime') if is_text_clip else None})
            legacy = obs['legacy']
            check(rel, 'legacy', 'pending' if legacy is None else ('passed' if legacy == 1 else 'failed'),
                'Serialized Legacy=' + str(legacy), 'Load AnimationClip in Unity to confirm Legacy' if legacy is None else ('' if legacy == 1 else 'Set legacy=true through Unity asset APIs'))
            conventional = rel.startswith('Assets/AssetBundle/Animation/')
            check(rel, 'location', 'passed' if conventional else 'pending',
                'Uses current formal Animation directory' if conventional else 'Outside current Animation directory convention; not an automatic defect',
                '' if conventional else 'Confirm intended use/loading before proposing a Unity move')
            check(rel, 'runtime', 'pending', 'Disk settings cannot establish effective state, curves, timing or replay',
                'Load the saved prefab in Unity, resolve curve bindings and test independent playback', level='none')
            check(rel, 'visual', 'needs_design', 'No visual approval collected by this static inspector',
                'Only when delivering an effect: review the actual target view with the designer', required=False, level='none')
        if rel in prefabs:
            components = []
            for match in BLOCK.finditer(text):
                if match.group(1) != '111':
                    continue
                body = match.group(4)
                registration = re.search(r'^  m_Animations:(.*?)(?=^  \w|\Z)', body, re.M | re.S)
                components.append({'file_id': match.group(2), 'stripped': 'stripped' in match.group(3),
                    'game_object': field(body, 'm_GameObject'),
                    'default_clip': field(body, 'm_Animation'),
                    'registered_guids': [g.lower() for g in GUID.findall(registration.group(1))] if registration else [],
                    'autoplay': number(body, 'm_PlayAutomatically'),
                    'culling_type': number(body, 'm_CullingType')})
            obs['components'] = components
            check(rel, 'registration', 'pending',
                'Serialized Animation references observed; node identity, nested/variant overrides, aliases and explicit runtime registration remain unresolved',
                'Use PrefabUtility.LoadPrefabContents; locate the intended Animation and resolve each playback name/clip; inspect explicit runtime AddClip if used', level='static')
    return report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', required=True, type=Path)
    parser.add_argument('--clip', action='append', default=[])
    parser.add_argument('--prefab', action='append', default=[])
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if not args.clip and not args.prefab:
        parser.error('Specify at least one --clip or --prefab')
    if any(not c.endswith('.anim') for c in args.clip) or any(not p.endswith('.prefab') for p in args.prefab):
        parser.error('Use .anim for --clip and .prefab for --prefab')
    if not args.project_root.is_dir():
        parser.error('Project root does not exist')
    if args.out and args.out.resolve().is_relative_to((args.project_root / 'Assets').resolve()):
        parser.error('Write reports outside Assets')
    try:
        report = inspect(args.project_root, args.clip, args.prefab)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    payload = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload, encoding='utf8')
        print(str(args.out))
    else:
        print(payload, end='')
    return 1 if any(c['status'] == 'failed' for c in report['checks']) else 0

if __name__ == '__main__':
    raise SystemExit(main())
