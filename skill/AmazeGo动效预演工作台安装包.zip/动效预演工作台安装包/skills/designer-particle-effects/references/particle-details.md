# 粒子规范与转换细则

整理日期：2026-11-11。`Assets/...` 相对 `arrowgo-unity/`。本文件按任务读取，执行顺序、失败兜底和最终状态统一见 [Skill入口](../SKILL.md)。

## 资源规范

### 目录与命名

| 资源 | 新建落点 | 命名 |
|---|---|---|
| 通用粒子贴图 | `Assets/Art/Texture/` | `et_<用途>_<序号>.png` |
| 特效材质 | `Assets/AssetBundle/Material/` | `em_<用途>_<序号>.mat` |
| Game 特效 Prefab | `Assets/AssetBundle/Prefab/GamePlay/Effect/` | `ep_<用途>_<序号>.prefab` |
| 共用 UI 特效 Prefab | `Assets/AssetBundle/Prefab/UI/Effect/` | `ep_<用途>_<序号>.prefab` |
| 单模块 UI 特效 Prefab | `Assets/AssetBundle/Prefab/UI/<模块>/Effect/` | 跟随模块命名 |
| UI 独立图片 | `Assets/AssetBundle/Sprite/<模块>/` | 跟随模块命名 |
| 独立 Texture 资源 | `Assets/AssetBundle/Texture/` | 跟随同类资源命名 |
| 新独立预演 | `Assets/Art/Preview/<效果名>/` | 场景、Timeline及预演专用资源集中放置 |

资源目录沿用工程既有落点；命名形式与新预演子目录是本 Skill 的组织建议。用户指定位置优先。缺少目标子目录时创建，不覆盖同名资源；旧资源不为整理而搬迁，保留 GUID 和现有引用。

文件路径不决定 Game/UI 类型，以组件、目标层级和实际使用环境为准。转换后按目标类型保存，并放入目标场景父节点。材质、贴图及必要依赖保持有效引用；位于 Art 下的图片被正式 Prefab 引用时仍属于交付依赖。

### 材质标准

| 表现要求 | 材质要求 |
|---|---|
| 普通透明粒子 | `Knight/SFX/Simple`，透明混合，按实际贴图与顶点颜色确认轮廓 |
| 叠加发光粒子 | 使用适合的叠加混合，确认亮暗背景下的颜色与透明表现 |
| UI 粒子参与 uGUI Mask | `Knight/SFX/SimpleUIStencil` 或具备对应 Stencil 支持的材质 |
| UV流动、扭曲、溶解 | 保留相应贴图槽、UV参数、时间来源、Custom Data和Vertex Streams |

Simple 的主贴图为 `_MainTex`，材质色调为 `_TintColor_MainTex`，颜色还受粒子顶点颜色影响；实际行为为 ZWrite Off。SimpleUIStencil 的 Stencil 支持不等于 RectMask2D 或其他裁剪兼容，按实际目标容器核验。

查资源时从 Prefab 的 Renderer Material、Trail Material 和序列帧 Sprite 引用追到当前 Shader 的有效槽与贴图，不能从名称编号推导对应关系。材质中残留的旧属性不作为当前功能依据。

只改粒子颜色、大小、寿命和发射参数时优先复用材质；修改贴图、混合、色调或材质动画时建立专用副本，保护共享材质。跨 Shader 转换核对贴图、UV、HDR颜色、混合、剔除、深度和透明度，复杂表现需实际对照。

### 贴图标准

- 普通 `Art/Texture`、`AssetBundle/Texture`、`Resources` 贴图：Android ASTC 6×6，iOS ASTC 4×4，默认及平台 Max Size不超过2048；Normal Map不套此普通格式标准。
- Sprite、Spine、BigSprite按各自资源类型的导入约定处理，不混用普通粒子规则。
- Texture Type、Alpha、Mipmaps、sRGB、Read/Write、Wrap和Filter按实际用途与同类素材确认，不统一重置。
- 颜色图与数据图按Shader采样语义设置sRGB；流动纹理确认重复方式，独立图案确认透明边与边缘采样。
- 序列帧确认分格、帧数、UV、播放顺序和Sprite/图集引用；导入压缩后在实际显示尺寸检查清晰度。
- 保留设计师提供的原素材与已调导入设置；只调整本次资源。

## Game与UI粒子标准

Game使用ParticleSystem；新建通常采用Scaling Mode=Hierarchy，Simulation Space按跟随或世界残留要求选择。保留明确的世界尺度、挂点、朝向、图层与遮挡，旧效果保留设计意图。

UI标准依据：[AmazeGo!——UIParticle 使用指南](https://learnings.feishu.cn/wiki/Dov0wNhwrickk5kZk7QciJdVnUf)。

### 容器与参数

一套完整效果由一个独立 UIParticle 容器承载多个 ParticleSystem，内部相对位置、动画和子发射关系保持完整。目标层级为 Canvas下的指定UI父节点、UIParticle容器及其粒子内容。核对实际收集列表与Rendering Order，避免嵌套容器导致粒子归属遗漏。

| 参数 | 新建标准 | 转换与旧效果要求 |
|---|---|---|
| RectTransform Scale | (1,1,1) | 记录原缩放和动画贡献，补偿后再规范化 |
| UIParticle Scale | 1，作为整体尺寸调整入口 | 已匹配表现的显示倍率保留；固化需完整换算所有长度及运动参数 |
| Position Mode | Absolute | Relative的发射偏移也参与显示缩放，转换需单独处理 |
| Auto Scaling | None | UIParticle模式用于明确的分辨率补偿；Transform模式会改根Scale，记录已有行为，不批量重置 |
| PS Scaling Mode | Local | Hierarchy含父级缩放，Shape主要缩放发射几何；切换需补偿有效尺寸与位置 |
| Simulation Space | 按运动需求选择 | 与Scaling Mode分别处理，保留跟随或世界残留语义 |
| Renderer Min Particle Size | 0 | 已有尺寸限制可能参与原表现，转换按源与目标视野匹配 |
| Custom View | 出现尺寸封顶或视野差异时确定 | 固定烘焙视野，不代替Canvas、相机和宽高比适配 |

### 尺寸与目标环境

- UI整体大小使用UIParticle Scale；RectTransform及父级Scale会参与位置和适配换算，避免重复倍率。
- Canvas坐标单位与UIParticle模拟参数单位分开计算；节点位置映射不能直接套给粒子Size。按 [位置映射与粒子尺寸映射](#参数转换) 记录各自依据并对照。
- Hierarchy下过小先核对Canvas及父级有效缩放，再处理Local转换补偿，不能只切模式。
- Max Particle Size与烘焙视野共同限制大粒子。正交Billboard的起点估算为 `尺寸上限 ≈ Max Particle Size × 2 × Custom View Size`；视野为正交半高，尺寸按烘焙坐标衡量，不能直接代入UI像素或未经缩放的Start Size。
- 增大Custom View前检查Min Particle Size；非零最小限制可能同时放大小粒子。大小两类粒子都要核对，Trails及其他渲染模式另按实际表现确认。
- Prefab预览与实际场景可能有不同相机、Canvas和视野。最终在真实目标Canvas/Play Mode确认，不能只凭隔离预览定稿。

### 透明度、播放和材质动画

继承CanvasGroup alpha低于0.01时，UI粒子的内部模拟可能暂停；跨过阈值即可恢复，不必等透明度为1。核对Start Delay与实际开始播放的时刻，区分淡入过程中的暂停与淡入结束才触发播放。

| 播放意图 | 表现要求 |
|---|---|
| 隐藏整组 | 根关闭后不显示；确认重新显示的播放起点，关闭根会截断可见尾粒子 |
| 暂停与继续 | 保留当前进度，恢复后接着播放 |
| 从头重播 | 重置进度及必要发射状态，Start Delay重新参与，不能沿用上次停发状态 |
| 停发并收尾 | 保持根激活与模拟推进，已有粒子按寿命消失 |
| 立即清空 | 停止并清除已有粒子，单纯暂停或停止发射不等于清空 |
| 随UI淡入淡出 | 保留面板节奏，考虑低透明度时暂停对粒子时间的影响 |

材质动画须登记Animatable Properties中的真实Shader属性名和类型，核对AnimationClip绑定及实际渲染材质。粒子Start Color与材质属性动画分开处理。Mask、RectMask2D及其他裁剪分别确认兼容性。

### 多粒子与重复效果

一个容器承载多个PS仍有逐PS烘焙及额外Trails开销，不以容器数量代替性能依据。Mesh Sharing仅用于结构、材质、尺度兼容且允许共享同一模拟进度的效果；Group ID一致，明确模拟源与副本关系。独立触发、独立随机或独立暂停的效果保留独立模拟，确认模拟源显隐对副本的影响。

## 参数转换

### 建立对照基准

记录源资源身份、可见场景、参考相机/Canvas和分辨率、目标父节点、单次/循环及本次要求的大小和节奏。原资源、共享材质和已调动画绑定保持不变，在新副本处理。

从每个PS分别记录Scaling Mode、Simulation Space、各级Scale、UIParticle Scale/Position Mode/Auto Scaling、粒子尺寸、Shape几何、节点位移及运动参数。父级缩放、旋转、UI透明度、遮罩和动画是源表现的一部分；按交付范围保留或补偿，不静默忽略。只交付粒子本体时，明确与外部演出分离后的比较基准。

以当前UI参数做UI→Game转换；恢复原始表现和转换当前表现分别处理。记录基准和已应用倍率，修正从同一基准生成，防止在输出上反复叠乘。

### UI单位映射：位置与粒子尺寸分别处理

Canvas的坐标单位与UIParticle的模拟参数单位分别计算。位置映射决定根和子节点放在哪里，粒子尺寸映射决定粒子实际显示多大；不得把Canvas坐标倍率直接乘到Start Size、Shape或速度上。

#### 共同基准

记录实际源/目标相机、Canvas Render Mode、相机视口、Canvas实际Rect尺寸和scaleFactor、CanvasScaler模式及参考分辨率、根与父级有效缩放、UIParticle Scale/Position Mode/Auto Scaling，以及各PS的Scaling Mode和Simulation Space。

以真实目标场景的当前值为准。参考分辨率用于屏幕适配，不等于实际Canvas尺寸；Expand下实际Rect可以改变。Canvas自身为适配生成的小Scale保留，外部父级缩放另行计入，不把两者一并归1。相机、Canvas、分辨率或目标父级改变后重新计算。

#### 位置映射

1. 取得源效果的发射中心及相关节点世界位置，在源参考相机下投影为屏幕位置；确认可见、未被相机近远裁剪面排除。
2. Game→UI时，将这些屏幕位置转换到目标UI父节点所在平面，再换成该父节点的本地位置。Screen Space Overlay按无UI相机的屏幕映射处理，Screen Space Camera使用Canvas实际相机，World Space使用观察该Canvas的相机。
3. UI→Game时，先取得源UI的屏幕位置，再落到指定Game挂点平面。反向没有天然Game深度，使用明确目标平面；未指定且场景无法确定时先确认，不自行猜深度。
4. 保留根和内部节点的相对关系，在各自父节点坐标系中写入结果。RectTransform的锚点、Pivot和父节点变换需参与换算，不能直接把屏幕位置写成anchoredPosition，也不能把世界坐标整体乘倍率。
5. 新建按Absolute处理节点偏移。旧Relative效果需先求其显示缩放后的实际发射位置，再映射到目标，避免遗漏或再次缩放偏移。旋转按两端坐标轴转换；规范化节点Scale前先补偿受影响的位置与参数。

正交、屏幕平面平行且正均匀缩放时，可用以下比例核对节点间距：

`Game世界单位像素长度 = 相机视口像素高度 ÷ (2 × 正交半高)`

`Canvas单位像素长度 = Canvas当前scaleFactor`（Screen Space模式）

`Game世界长度对应的Canvas长度 = Game世界长度 × Game单位像素长度 ÷ Canvas单位像素长度`

目标父节点相对Canvas有均匀缩放时，Canvas长度再除以该相对缩放得到父节点本地长度。已经通过屏幕投影和父节点逆变换得到位置时，不再乘这些比例。World Space或其他投影按实际单位位移在屏幕上的长度校准，不套Screen Space公式。

#### 粒子尺寸映射

1. 按每个PS记录源与目标的Start Size/三轴Size、Scaling Mode、节点有效缩放、UIParticle显示设置、渲染模式与Min/Max Particle Size。尺寸基准包含这些设置的实际贡献，与位置倍率分开记录。
2. 在对照副本的相同时刻校准两端单位尺寸参数的屏幕宽高。保持贴图轮廓、相对Size曲线、朝向和随机条件可比；测量时确认未受尺寸封顶或最小尺寸钳制，不能用被钳制的显示尺寸反推线性倍率。
3. 分别求倍率并换算参数：

`尺寸倍率 = 源端单位Size参数的像素长度 ÷ 目标端单位Size参数的像素长度`

`目标Size参数 = 源Size参数 × 尺寸倍率`

4. 常量、随机范围及三轴尺寸按相应倍率处理，相对Size曲线保留。X/Y映射不一致或受深度变化影响时，不强行取单一倍率；明确该投影的限制，保留待处理差异。
5. UIParticle会对Canvas缩放进行补偿。在相同正交相机、新建None/Local、UIParticle Scale=1、根及子PS自身Scale=1、无额外父级缩放且未触发尺寸钳制的条件下，粒子模拟长度可接近Game世界长度；这与Canvas坐标长度不同。仍按两端实际显示校准，不把这一条件结论固化成所有效果倍率为1。
6. 旧效果已有显示倍率或尺寸限制时先保留。需要把显示倍率固化到参数时，尺寸、Shape、内部位移与运动分别补偿；完成相关对照后再归一化，不重复补偿Canvas缩放。

Shape发射几何、模拟中的位置与速度不属于RectTransform节点位置，也不能直接沿用Size倍率。按后续参数类别分别换算。重力、透视深度运动、非均匀缩放等特殊处理仍按各自分支核验。

#### 本项验收与交付记录

| 项目 | 完成条件与记录 |
|---|---|
| 参考环境 | 相机/Canvas、实际视口、Canvas Rect与scaleFactor、目标父节点及缩放明确；未重复补偿 |
| 位置映射 | 实际目标中发射中心、内部节点偏移及朝向符合源基准或指定位置；锚点/Pivot正确 |
| 尺寸映射 | 相同对照时刻的粒子宽高与整体尺寸符合源基准或明确的设计倍率；未混用Canvas坐标倍率 |
| 适配核验 | 在本次要求的目标屏幕比例下检查；环境变化后重新计算，有意随UI缩放的行为符合设计要求 |
| 交付状态 | 记录位置换算依据、每PS尺寸倍率及限制、实际放置节点和核验结果；未完成画面对照时标明待确认 |

单次映射完成以实际目标场景中的位置与尺寸对照为依据，并保留上述计算与交付记录；文档中的方法和公式不代替具体资源的画面核验。

### 按参数性质换算

以下倍率均为该参数所在空间的实际换算倍率；时间基准保持不变。

| 参数类型 | 换算方法 |
|---|---|
| Start Size及三轴尺寸 | 按粒子有效长度换算，各轴保留比例 |
| Shape位置与发射几何 | 按发射长度换算；通过Shape整体Scale或具体尺寸表达完整几何，二者不要重复乘同一倍率 |
| 子节点位移与发射中心 | 按位置空间映射，保留节点关系、旋转及相对轨迹 |
| Start Speed、Velocity XYZ/Radial、限速 | 按有效线速度换算，并保持方向与坐标空间 |
| Orbital中心和偏移 | 按长度换算；Orbital角速度保持原值 |
| Force XYZ与加速度 | 保持同一时间内的目标轨迹，按运动空间映射加速度 |
| Gravity Modifier | 从实际重力轨迹单独求补偿；重力未必继承尺寸倍率，标量不能表达重力方向旋转 |
| Rate over Distance | 按发射器有效行程倍率的倒数换算，保持同一路径的粒子密度 |
| Size/Color/Rotation by Speed及Emitter Speed范围 | 阈值随对应粒子速度或发射器速度换算，曲线输出保持语义 |
| Drag与Dampen | 依响应语义处理；尺寸加权Drag按尺寸倍率平方的倒数补偿，速度加权Drag按速度倍率倒数补偿，同时启用时合并补偿；其余响应系数保留并核验 |
| Noise位移及空间频率 | 位移按有效长度换算，空间频率按其采样空间长度倍率的倒数处理；持续播放对照，不能只换一个Strength保证等效 |
| 时间与数量 | Duration、Lifetime、Start Delay、Burst、Rate over Time及数量保持，用户要求改节奏时单独设计 |
| 颜色、角度及相对曲线 | 保留颜色、透明度、旋转角/角速度、相对Size/Color/Rotation曲线及无量纲倍率 |

常量按相应倍率换算；随机两常量同时换上下界；曲线或双曲线只改需要的数值幅度，保留关键帧时间、曲线形状和随机模式。不同物理量分别处理，不能将整条动画或全部参数统一乘倍率。

#### 拖尾与子发射器

- Trails最小顶点间距按长度换算。宽度已继承粒子Size时不重复缩放；不继承时单独换算宽度。
- 保持尾迹持续时间。开启Size Affects Lifetime时补偿粒子尺寸变化对尾迹寿命的贡献，避免长度换算改变收尾节奏。
- 保留Trail Material、纹理模式、世界/本地行为及停发后的收尾；沿完整运动路径对照。
- 子发射器保留引用、触发条件、继承关系及自身参数。父子各自计算，避免漏转、重复转换或引用源资源中的旧节点。

#### 动画与外部依赖

已由Animation/Animator/Timeline驱动的参数须同步处理相关值与绑定，否则播放时会覆写静态转换结果。保留时间和曲线节奏，仅换算其中有物理单位的值。外部演出控制不属于粒子本体时，在预演中保留依赖和播放说明，不把它静默丢弃。

World粒子检查移动根后是否仍按源要求留在世界；Custom Simulation Space、碰撞、触发、力场和灯光依赖需对应目标环境。无法保持时指出具体节点与差异，不删除模块后宣称保持原效果。

### 材质、排序与UI设置

材质按目标Game/UI显示要求匹配，保留贴图槽、UV、HDR颜色、Blend、Cull、ZTest、顶点数据及材质动画。UI需要遮罩时核验对应材质，UI→Game时处理原CanvasGroup颜色/透明度与遮罩依赖，不默认丢失。

排序保留本次需要的遮挡关系：核对Sorting Layer、Sorting Order、UI兄弟顺序和Rendering Order。动态深度排序与固定UI顺序不能直接等同；发生差异时以指定目标表现调整并对照。

旧效果转换后的有效显示倍率、Min/Max Particle Size及Custom View按源与目标视野换算；规范化需先完成补偿，不机械覆盖已匹配的显示设置。

## Timeline预演与表现核验

### Timeline预演

- 游戏内效果创建或调整预演环境前，读取 [场景基准](../../designer-motion-workflow/references/scene-baseline.md)，先继承真实 Camera/Canvas、挂点及必要显示参数，再放粒子；独立场景也须有主线来源与回读对照。
- 复用指定Timeline、场景和已有Animation/Spine绑定；需要独立预演时按资源标准保存。
- Game粒子可由Control Track推进模拟，覆盖完整粒子内容及尾段；UI粒子由UIParticle推进，Activation Track编排显示，避免同一PS被重复模拟。
- 位移、尺寸和其他动效按对应Animation表达，保持既有动画系统及绑定。Timeline拖轴不等于UI粒子连续模拟；连续播放或Play Mode确认，倒拖、跳时刻与回零按本次实际需要核验。
- 关闭整组会截断尾粒子。需要停发后自然收尾时，保持对象可见与模拟继续，区分暂停、停发、清空和重播。
- 预演随机效果需可对照时，只在预演副本固定相应种子，原资源随机设置保留。

### 画面对照

同一参考环境及对应时刻检查发射中心、整体范围、粒子尺寸、颜色/透明度、速度与路径、展开峰值、延迟、寿命、尾迹及循环/重播。再在实际目标Canvas或Game相机下确认可见性、排序、遮罩、父级透明度与本次目标分辨率。

参数变化时检查播放过程中动画是否覆写、引用是否仍指向正确节点；材质和贴图无缺失、粉色或关联报错。静态引用检查不能代替播放与观感核验。
