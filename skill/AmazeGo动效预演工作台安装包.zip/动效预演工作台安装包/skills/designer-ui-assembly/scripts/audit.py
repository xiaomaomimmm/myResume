#!/usr/bin/env python3
"""Read-only Prefab/FUI preflight; does not import, build, render, or modify Unity assets."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys


def inside(path, root):
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def check(rule, target, status, detail, evidence=None, level='static', required=True, next_action=None):
    return {'id': rule, 'target': target, 'scope': 'resource_delivery', 'required': required,
            'status': status, 'level': level, 'detail': detail, 'evidence': evidence or [], 'next_action': next_action}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def capabilities(project):
    candidates = list((project / 'Packages').glob('com.learnings.unity.art2prefabtool'))
    candidates += sorted((project / 'Library/PackageCache').glob('com.learnings.unity.art2prefabtool@*'))
    result = {'package_path': None, 'package_version': None,
              'incremental_import_enabled': None, 'fui_preview_write_enabled': None,
              'live_tools_verified': False, 'evidence': []}
    # Multiple caches without a unique package cannot establish the active version.
    if len(candidates) != 1:
        result['candidate_paths'] = [str(p) for p in candidates]
        return result
    package = candidates[0]
    result['package_path'] = str(package)
    info = package / 'package.json'
    if info.is_file():
        result['package_version'] = json.loads(info.read_text()).get('version')
        result['evidence'].append(str(info))
    flags = package / 'Editor/UnstableFeatureFlags.cs'
    if flags.is_file():
        text = flags.read_text()
        text = re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S)
        for flag, key in [('IncrementalImportEnabled', 'incremental_import_enabled'),
                          ('FuiPreviewWriteEnabled', 'fui_preview_write_enabled')]:
            match = re.search(r'\bbool\s+' + flag + r'\s*=\s*(true|false)\s*;', text)
            if match:
                result[key] = match.group(1) == 'true'
        result['evidence'].append(str(flags))
    return result


def fui_errors(data):
    errors = []
    elements = data.get('elements')
    if not isinstance(elements, list) or not elements:
        return ['elements must be a nonempty list'], []
    ids = []
    for element in elements:
        if not isinstance(element, dict) or not isinstance(element.get('id'), str) or not element['id']:
            errors.append('Every element requires a nonempty string id.')
        else:
            ids.append(element['id'])
    if len(ids) != len(set(ids)):
        errors.append('Duplicate element id.')
    known = set(ids)
    parents = {}
    for element in elements:
        if not isinstance(element, dict):
            continue
        node, parent = element.get('id'), element.get('parentId')
        if parent and (not isinstance(parent, str) or parent not in known):
            errors.append(f'Unknown parent for {node}.')
        if isinstance(node, str):
            parents[node] = parent if isinstance(parent, str) else None
        children = element.get('children')
        if children is not None:
            if not isinstance(children, list) or any(not isinstance(c, str) or c not in known for c in children):
                errors.append(f'Invalid children for {node}.')
    for node in parents:
        seen, current = set(), node
        while current in parents:
            if current in seen:
                errors.append(f'Parent cycle involving {node}.')
                break
            seen.add(current)
            current = parents[current]
    return sorted(set(errors)), ids


def mapping_errors(data, ids):
    mapping = data.get('nodeFileIdMappings')
    if not mapping:
        return None
    if not isinstance(mapping, list):
        return ['nodeFileIdMappings must be a list.']
    seen, errors = set(), []
    for row in mapping:
        if not isinstance(row, dict):
            errors.append('Invalid mapping row.')
            continue
        node, fileid = row.get('nodeId'), row.get('fileId')
        if not isinstance(node, str) or node not in ids or node in seen:
            errors.append('Unknown or duplicate mapping nodeId.')
        if not isinstance(fileid, int) or isinstance(fileid, bool) or fileid == 0:
            errors.append('Mapping fileId must be a nonzero integer.')
        if isinstance(node, str):
            seen.add(node)
    return errors


def audit(project, prefabs, manifests):
    observations, checks = [], []
    for prefab in prefabs:
        target = prefab.relative_to(project).as_posix()
        if not prefab.is_file():
            checks.append(check('prefab.file', target, 'failed', 'Prefab does not exist.', [str(prefab)]))
            continue
        text = prefab.read_text(errors='replace')
        is_yaml = bool(re.search(r'^--- !u!\d+ &', text, re.M))
        meta = Path(str(prefab) + '.meta')
        match = re.search(r'^guid:\s*([0-9a-fA-F]{32})\s*$', meta.read_text(errors='replace'), re.M) if meta.is_file() else None
        observations.append({'kind': 'prefab', 'path': target, 'sha256': sha(prefab),
                             'guid': match.group(1).lower() if match else None,
                             'yaml_class_ids': sorted(set(re.findall(r'^--- !u!(\d+) &', text, re.M))),
                             'external_guids': sorted(set(re.findall(r'\bguid:\s*([0-9a-fA-F]{32})', text))),
                             'observation_level': 'static'})
        checks.append(check('prefab.file', target, 'passed' if is_yaml else 'pending',
                            'Read serialized YAML blocks only.' if is_yaml else 'Not recognized as text Unity YAML; load in Unity.', [str(prefab), sha(prefab)]))
        for rule, detail in [('prefab.dependencies', 'Nested/variant references, scripts, images and fonts need Unity dependency verification.'),
                             ('ui.bindings', 'Animation paths, localFileIDs and Timeline bindings have not been verified.'),
                             ('ui.visual', 'Layout, masking, adaptation and appearance have not been rendered.')]:
            checks.append(check(rule, target, 'pending', detail, level='none', next_action='Load the saved target in Unity and check only the requested changes.'))
    for manifest in manifests:
        target = str(manifest)
        if not manifest.is_file():
            checks.append(check('fui.file', target, 'failed', 'FUI/manifest does not exist.', [target]))
            continue
        try:
            data = json.loads(manifest.read_text(encoding='utf-8-sig'))
            if not isinstance(data, dict):
                raise ValueError('Manifest root must be an object.')
            errors, ids = fui_errors(data)
            mapping = mapping_errors(data, ids)
        except (ValueError, TypeError) as error:
            checks.append(check('fui.structure', target, 'failed', str(error), [target]))
            continue
        observations.append({'kind': 'fui', 'path': target, 'sha256': sha(manifest),
                             'source': data.get('source'), 'element_count': len(ids),
                             'sprite_folder': data.get('spriteFolder'), 'prefab_save_dir': data.get('prefabSaveDir'),
                             'observation_level': 'static'})
        checks.append(check('fui.structure', target, 'failed' if errors else 'passed',
                            '; '.join(errors) if errors else 'Element ids and parent graph are structurally consistent.', [target, sha(manifest)]))
        checks.append(check('fui.mapping', target, 'pending' if mapping is None else ('failed' if mapping else 'passed'),
                            'No nodeFileIdMappings; incremental identity is unverified.' if mapping is None else
                            ('; '.join(mapping) if mapping else 'Mapping rows are structurally valid; not resolved against Prefab.'),
                            [target], required=False, next_action='Read old Prefab and resolve mapped RectTransform localFileIDs in Unity.'))
        checks.append(check('fui.import', target, 'pending', 'Manifest structure does not prove image/font availability, import or appearance.',
                            level='none', next_action='Use the discovered Art2Prefab tool and verify its output.'))
    caps = capabilities(project)
    checks.append(check('tool.live_capability', None, 'pending', 'Package source is inspected; live Unity tools and gates are unverified.',
                        caps['evidence'], required=False, next_action='Discover active Unity instance and custom-tools.'))
    return {'schema_version': 1, 'skill': 'designer-ui-assembly', 'mode': 'inspect',
            'created_at': datetime.now(timezone.utc).isoformat(), 'project_root': str(project),
            'capabilities': caps, 'observations': observations, 'changes': [], 'checks': checks,
            'handoff_status': 'not_requested', 'designer_approval': None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', required=True)
    parser.add_argument('--prefab', action='append', default=[], help='Assets-relative saved Prefab; repeatable.')
    parser.add_argument('--figma-manifest', action='append', default=[], help='Explicit .fui/manifest.json; repeatable.')
    parser.add_argument('--out', help='Optional report outside source files, Assets and Skill package.')
    args = parser.parse_args()
    try:
        project = Path(args.project_root).resolve()
        if not (project / 'Assets').is_dir() or not (args.prefab or args.figma_manifest):
            raise ValueError('Provide a project containing Assets and at least one prefab or manifest.')
        prefabs = [(project / p).resolve() if not Path(p).is_absolute() else Path(p).resolve() for p in args.prefab]
        manifests = [Path(p).resolve() for p in args.figma_manifest]
        if any(not inside(p, project / 'Assets') for p in prefabs):
            raise ValueError('prefab must resolve inside project Assets')
        output = Path(args.out).resolve() if args.out else None
        if output and (output in prefabs + manifests or inside(output, project / 'Assets') or inside(output, Path(__file__).resolve().parent.parent)):
            raise ValueError('out must not overwrite source, Assets, or Skill files')
        report = audit(project, prefabs, manifests)
        rendered = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
        if output:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(rendered, encoding='utf-8')
        else:
            print(rendered, end='')
        return 1 if any(c['status'] == 'failed' for c in report['checks']) else 0
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
