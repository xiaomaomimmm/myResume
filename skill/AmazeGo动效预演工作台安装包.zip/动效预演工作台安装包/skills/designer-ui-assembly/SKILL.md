---
name: designer-ui-assembly
description: Use when ArrowsGo 设计师需要用已切图、设计参考、Figma/FUI 或既有 Unity UI 搭建、导入、调整和交付 uGUI Prefab，包括布局适配和动效节点准备；纯图片整理用 designer-image-assets，Animation、Spine、粒子和程序业务各自处理。
---

# 设计师 UI 界面搭建与交付

把设计参考和可用素材变成可编辑、可做动效、可交给程序的 UI Prefab。设计师用自然语言，harness 整理输入并调用工程工具，不要求设计师写 JSON/C#。`Assets/` 均相对 `arrowgo-unity/`。

## 独立动作与入口

| mode | 本次目标 | 结果 |
|---|---|---|
| `inspect` | 查界面/导入工具/布局和绑定 | 检查记录，不改资源 |
| `assemble` | 新搭或按明确范围调整 | 保存 UI Prefab、依赖和实际变更 |
| `handoff` | 给动效设计师或程序 | 当前 UI 资源及布局/节点/接收说明 |

入口：`cut_images`（切图+参考）、`figma_channel`（当前工具 Channel/Frame）、`fui`（已有 .fui/manifest+图片）、`existing_prefab`（原位调整）。同一请求可有多个模式，记录实际主目标。已有素材或清单可直接使用；缺素材问题只记录/处理本次所需项，**不自动执行完整图片整理 Skill**。不强制 PSD 或 PRD。

读 [UI 工程约定](references/project-conventions.md)；实际搭建/导入读 [Unity 工具执行](references/unity-operations.md)；自动化/交付读 [harness 合同](references/harness.md)。

## 执行

1. **定位输入与目标**：找到参考画幅、素材、模块风格、已有 Prefab/Canvas/图集和本次修改范围。切图本身没有层级/坐标；有截图可按参考搭建，记录推断和关键未明项，不虚构 Figma Frame/id/manifest。Figma 链路需实际 Channel/Frame 或 .fui 结构数据；缺结构时仍能盘点素材和目标，只有依赖它的导入动作待补。
2. **选择工具与形成计划**：发现当前 Unity 实例/custom-tools，核对 Art2PrefabTool 版本及功能门禁；源码有接口不代表现场可用。记录目标路径、GUID、节点身份、参考布局、拟改属性和资源引用。既有界面先检查 Animation 曲线路径、Timeline/Director 绑定、生成字段及其它共享引用。计划中明确原位 patch 或独立候选；不把重建器当保留绑定的更新器。
3. **搭建与保存**：新界面优先工程模板/公共组件或可用 Figma 工具，设置目标模块目录和当前字体/材质。既有界面按明确节点原位修改，保留 GUID、fileID、路径和已有组件。涉及动画控制的属性时说明影响、保留初态与播放挂点。需要重构/重导入且无法保留引用时先输出独立候选和迁移清单，继续完成可独立做的部分；不覆盖原目标后再验证“有没有丢”。
4. **回读与实际检查**：保存后重载正式 Prefab，检查图片/字体/材质/Missing Script、遮罩、层级、Raycast、布局控制器、锚点、CanvasScaler/安全区，以及变更涉及的绑定。对参考画幅和本次相关适配场景看实际画面。设计预演用轻量视觉验收；有已绑定动效的更新检查相关播放与回零，不扩大到全玩法回归。
5. **交付**：给可点击 Prefab/依赖路径、布局与动效节点、修改点、截图或现场视觉记录、待程序接收项。批量操作/正式交付保存 `report.json` 和 `handoff.md`，默认 `.local/reports/designer-ui-assembly/<任务名>/`。资源/视觉就绪与正式业务接入分别判定。只查规范不强制造场景、录屏或交付单。

## 当前工程的关键限制

- `PrefabBuilder.Build` 清空 Top/Middle/Bottom 和额外根节点；完整 `psd-ui-builder` 还生成 UI/Logic/Page。只可在明确的全新/重建任务中采用构建部分，不能自动用于保留旧动效的 UI 更新；本 Skill 不运行业务代码生成。
- 当前缓存 Art2PrefabTool 1.5.0 的 `IncrementalImportEnabled=false`、`FuiPreviewWriteEnabled=false`。FUI 可查和预览；增量接口和预览编辑落盘不可用。执行时重查实际版本/门禁；失败保留真实错误码，不改包开关、不用内部函数绕门禁。
- Figma 导出默认会清理散图，导入默认会覆盖散图；本次普通 UI 搭建显式关闭无关清理/覆盖。更新、删除或共享图替换只有已明确的范围才能执行。
- Figma `Top/Mid/Bottom` 来自有效 `Split:` 标签，PSD 模板用 `Top/Middle/Bottom`；不批量统一命名。正式动效挂点以实际 Prefab 为准，路径变更需同步迁移。
- UI 用 uGUI/TMP 和现有组件；`FigmaComponentMap.asset` 当前 entries 为空且 autoComponentEnabled=0，不能承诺已自动复用全套业务组件。

## 可运行的磁盘预检

```sh
python3 .ai/skills/designer-ui-assembly/scripts/audit.py --project-root arrowgo-unity --prefab Assets/AssetBundle/Prefab/UI/Gallery/GallerySuccessResultUI.prefab --out .local/reports/designer-ui-assembly/gallery/static-audit.json
```

也可重复传 `--figma-manifest /实际文件.fui`。脚本检查保存 Prefab 的局部 YAML、FUI ids/父关系/映射结构和本地包门禁；不导入、不渲染、不解析完整 Unity 引用，不证明映射已解析或动效可播。退出码 0 为无确定静态失败（仍可能 pending），1 为发现失败，2 为调用错误。只有磁盘检查时结果不能自动升级为完成交付。

示例：`$designer-ui-assembly 用这批已切图和效果图搭奖励弹窗，保留已有动画挂点，交付 UI Prefab。`
