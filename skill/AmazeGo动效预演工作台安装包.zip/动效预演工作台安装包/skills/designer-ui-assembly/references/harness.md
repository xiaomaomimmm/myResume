# UI 搭建 harness 输入与结果合同

合同定义任务数据和结果，不表示新建了监听器、MCP 或后台自动导入器。实际动作由已发现的工程工具承担；不能让设计师写 JSON 或编程参数。

## 输入与模式

`request`：mode（inspect/assemble/handoff）、source_type（cut_images/figma_channel/fui/existing_prefab）、module/style、reference（效果图/画幅/明确布局）、images/asset_manifest、prefab_path、canvas/scene、figma（Frame/Channel 或 FUI 路径）、update_scope、preserve_bindings、report_dir。

输入按模式取用：切图不要求 PSD/PRD/Frame；Figma 只接受实际连接/结构数据；既有 UI 使用具体节点/属性范围。未提供值为 null/缺项，影响执行的项列 checks 和下一步，其余检查继续。素材清单可由前一独立 Skill 提供，正确资源可直接引用，不强制串联。

## 输出

[report.schema.json](../assets/report.schema.json) 固定：schema_version=1、skill、mode、created_at、project_root、observations、changes、checks、handoff_status、designer_approval。可附 request、capabilities、ui_manifest、protected_bindings、programmer_handoff。

`ui_manifest`：正式 prefab_path/guid、参考画幅、实际 Canvas/适配参数、依赖（图片/字体/材质/嵌套Prefab）、节点清单（path/localFileID/component/layout）、动效挂点、图与节点映射。`protected_bindings`：更新前后的 Animation/Timeline/生成字段定位与差异，区分保存盘观察和 live Unity 数据，缺证据为未验证。`changes` 只写本次真正修改，方案单独记录，重复运行不新增无意义变体或重复节点。

## checks

各项有 `id,target,scope,required,status,level,detail,evidence,next_action`。唯一身份为 `(id,target)`。scope=resource_delivery/programmer_integration；status=passed/failed/pending/needs_design/needs_programmer/not_applicable。passed 附当前版本真实证据；未执行不能改 passed；not_applicable 写适用性依据。level=none/static/data_load/unity_load/visual/device，仅说明证据来源。

按本次请求取检查：输入和工具、资源/依赖、布局/适配、遮罩/排序/Raycast、保存回读、受影响动效/生成绑定、视觉确认、程序接收。查询不要求全部检查；新静态 UI 不要求已有动画播放验证；只是设计预演不强制正式业务回归。设备验证仅在目标或实际问题需要时必需。

磁盘 audit 输出 Prefab class ids/external_guids 是全文局部观察，不能判它们属于根组件或引用有效；FUI graph 检查只判 ids/父关系，不判断画面、完整工具 schema、字体/图片是否加载；mapping 结构有效不代表 fileID 在目标 Prefab 真存在。capabilities 的本地包/开关不代表现场已编译或工具已注册。

## 交付判定

- not_requested：仅检查/搭建，没有正式交付请求。
- draft：已有可用方案/资源，必需保存、绑定或视觉确认有缺项；给出实际草稿与下一步。
- ready_for_programmer：本次必需资源交付项通过，依赖/接收单完整，需要视觉确认的任务有当前版本设计师或请求约定的验收证据；程序接入项可留 needs_programmer。
- integrated：仅明确要求程序集成时使用，并要求接收方及真实页面的本次必要验证实际通过。

designer_approval 未发生为 null；发生时有 reviewer/time/evidence，关联当前 Prefab/资源版本。用户已确认本轮设计预演观感后完成必要底线检查即可收尾，不追加无关正式测试。磁盘退出码 0、FUI 能打开、JSON 格式正确都不能替代视觉确认或自动提升交付状态。

报告默认 `.local/reports/designer-ui-assembly/<任务名>/report.json`；交付单 handoff.md 同目录。交付单面向程序列根 Prefab、重要节点/类型、动态图文、点击/显示需求、布局适配、动效挂点/保留绑定、资源依赖和待接入项；不要把实现细节塞给设计师选择。
