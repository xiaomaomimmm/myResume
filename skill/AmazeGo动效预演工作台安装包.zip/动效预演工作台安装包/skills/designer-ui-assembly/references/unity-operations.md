# Unity 与 Art2Prefab 的可执行路径

先发现实例与 `mcpforunity://custom-tools`（若连接支持），确认工具参数与目标实例。未知工具名称/参数先查能力，不用旧 Skill 的 `script-execute`/`assets-refresh` 字符串冒充已注册 action。内部 C# 源码用于核对工具行为；源码存在不等于可直接调用。插件 UI 的入口是 `Tools/ArtToPrefab 导入工具`。

## 当前包与门禁

本次蒸馏实读 `Packages/manifest.json` 和缓存包 package.json 为 Art2PrefabTool 1.5.0。缓存 `Editor/UnstableFeatureFlags.cs` 关闭：

- IncrementalImportEnabled：增量导入（含 MCP）不可执行，错误 `INCREMENTAL_DISABLED`。
- FuiPreviewWriteEnabled：FUI 编辑保存/回写不可执行，错误 `PREVIEW_WRITE_DISABLED`。

执行时重新读取当前包/现场错误；新导入不受这两个门禁限制，但仍需验证 Channel、输入和现场依赖，旧 UI 不能承诺自动增量保留绑定。FUI 只读查看可用；编辑器中看见变化不证明已保存。不能改开关、调用内部方法或另写文件绕过门禁。

## 已切图 / 原位 patch

用当前发现的 Unity Editor 脚本/Prefab 工具加载目标（`PrefabUtility.LoadPrefabContents`），以明确路径/localFileID 定位；逐项改 Image.sprite、TMP 文本/字体、RectTransform 属性，保存并 unload。资源查找用完整路径，不模糊匹配后选第一张同名图。目标是嵌套 Prefab/Variant 时先看 override 和共享影响，保存到请求要求的资产而非误 Apply 到公共源。

新 UI 可用 `UIGenerateEditor.CreateTemplateUI(targetFolder)`，核对实际模板内容并另存目标；不调用 Generate Base UI、RunCodegen 或完整 psd-ui-builder。只有明确要求按 PSD plan 全新重建且输入齐全，才使用 PrefabBuilder 的构建部分；它不是局部修改器。

## Figma Channel 新导入

缓存 `Editor/Mcp/McpForUnity/Art2PrefabImportTool.cs` 定义 `art2prefab_import`，action 只有 `psd` / `figma_channel`。没有通用 `action=figma_file`。它通过运行中的 Figma 插件 Channel 拉 Frame，需实际 Frame id；Figma 官方 MCP 的截图/设计上下文不等于 Art2Prefab Channel。

工具可用时先查 Frame（以下为该自定义工具的 params，外层封装以现场协议为准）：

```json
{"action":"figma_channel","list_frames":true,"port":3055,"channel":"art2prefab"}
```

工具注册不证明 Channel 已连接。若返回 `Channel not ready`，保留原错误，将通道检查记为 pending，按现场提示诊断插件连接、中继 Node.js 和端口；这不影响已有素材/Prefab 的检查。只有恢复通道或取得真实 FUI 后才继续依赖它的导入；按截图搭的候选需标注推断，不能称为 Figma 原样导入。

新导入提供实际 `frame_id`、`sprite_output_path`、`fui_save_dir`、`prefab_save_dir`、`font_search_path`、`direct_mode`、`overwrite_sprites`。Frame/端口/Channel 按现场结果；默认名称/路径可能覆盖旧资源。新建独立候选使用专用目录与明确名称，显式 `overwrite_sprites=false`；确实要求更新的图片才允许覆盖指定范围。`direct_mode=true` 保存新 Prefab；false 创建 .fui 并打开预览，返回成功不证明正式 Prefab 已生成。

所有 Assets 路径以实际模块为准，不能照搬插件默认目录；返回 `rendered/skipped` 时检查跳过节点日志。自动导入可产生图片是 UI 导入的附属操作；不因此调用独立素材整理的去重/迁移流程。

## 已有 FUI / manifest

缓存 `Intermediate/FuiManifestData.cs` 定义 JSON FigmaManifest：elements、screen、assets、fonts、spriteFolder 等。`FigmaManifestImporter.ReadManifest(folder)` 会优先目录第一份 .fui 再 legacy manifest.json，多份文件必须先确定真实目标，不依赖目录顺序。

工具 `art2prefab_preview` 支持 open/status/close/save；当前 save 门禁关闭。已有 `.fui` 用 open（`fui_path`）和 status 核对 stage/文件；跨 Stage 打开可能有延迟，要查 status 确认目标，不把瞬时返回当目标就绪。

`art2prefab_nodes` 可 list/get 查 nodeId、名称/类型/父级/导出状态。写 action 可能修改预览内存并返回成功；当前门禁阻止的是 FUI 持久化，不代表预览编辑一定被拒绝。不能把内存成功当落盘成功，也不能把这些未持久化修改作为交付；本流程优先只读查询。

`art2prefab_export` 消费当前 stage，参数 `prefab_output_path`、`delete_after_export`、`cleanup_unused_sprites`。新输出专用目录，显式 false 关闭删除 FUI 和默认的散图清理。门禁关闭时只导出已加载的有效原始状态，不依赖尚未保存的编辑。输出路径参数是目录，文件名由 root 决定；核对真实返回 prefabPath，防止覆盖既有文件。

## 既有 UI 重导入

`art2prefab_incremental_prepare` 需 old_prefab_path、old_fui_path、new_frame_id、work_dir，且旧 FUI 要有 nodeFileIdMappings；当前 gate 关闭。仅有映射或源码接口也不能宣称增量可用。`Prepare` 还可能同步图片/创建候选，不当成纯只读检查。

保留动效的更新选择明确原位 patch；整段布局变更先新建独立候选，再核对可迁入差异与受影响引用。旧资源的 nodeId/fileID/路径变化需要真实迁移清单；不要因为 Prefab GUID 没变就判 Animation/Timeline 绑定保留。

## 保存与验证

保存输出后重新 Load 正式 Prefab，查 dependencies、节点/组件/字体/图片；对比前后受影响引用。显示到请求场景/画幅，核对截图或实际视觉证据。工具报错留错误码与可用草稿，继续不依赖故障入口的工作；重复同一错误不靠全量重导入或改包绕过。

工具源码详细参数按需查 `Editor/Mcp/McpForUnity/Art2Prefab{Import,Preview,Nodes,Export,IncrementalPrepare}Tool.cs` 和对应 Handlers；不在 Skill 复制完整 API。
