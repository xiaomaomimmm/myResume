# UI 工程约定与素材衔接

## 源码入口

| 主题 | 文件/入口 | 使用要点 |
|---|---|---|
| 新 UI 模板 | `Assets/Editor/UI/UIGenerateEditor.cs: CreateTemplateUI(targetFolder)` | 生成 `ZTemplateUI.prefab`，根 Canvas/GraphicRaycaster/Legacy Animation，Content 有 UINotchAdapter 和 Top/Middle/Bottom；只用于新目标 |
| 旧 PSD 计划构建 | `Assets/Editor/UGUIMCP/PrefabBuilder.cs: Build(workDir)` | 消费 session.json/build_plan.json；建模板并清旧内容、重建节点；可能删除按钮子 Prefab，禁止当原位 patch 工具 |
| 组件与布局规则 | `.ai/skills/psd-ui-builder/knowledge/{components,layout,naming,image,text,dialog}.md` | 只读取目标相关部分；阈值和像素分区是 PSD 工具的推断规则，不能强加 Figma 或设计师明确布局 |
| UI 运行与生成 | `Assets/Scripts/Game/Framework/UI/{BasePage,UIManager}.cs`，`Assets/Editor/UGUIMCP/CodegenWindow.cs` | 本 Skill 准备 Prefab 和接收说明；正式注册/生成代码交程序执行 |
| Figma 包 | `Packages/manifest.json`，`Library/PackageCache/com.learnings.unity.art2prefabtool@*/Editor/` | 按实际解析包定位，不固定缓存 hash；查询不到时记录缺口 |
| 业务扩展 | `Assets/Editor/Art2PrefabExt/*` | 颜色/描边/分区规则见下文 |

正式 UI 通常在 `Assets/AssetBundle/Prefab/UI/<功能>/`；图片在 `Sprite/<功能>/` 或明确的 BigSprite 专项目录；字体查 `Assets/Art/Font/TMP/`，程序生成类在 `Assets/Scripts/Game/Gen/UI/`。参考当前同模块同风格 UI，不默认使用插件的 Assets/Art/Prefabs、Assets/UI/Sprites 输出目录。草稿需独立位置、明确性质；不自动把预览资源迁为正式资源。

## 已切图与参考布局

素材清单可以来自 designer-image-assets，也可以直接查现有资源；最终需要准确 image→Sprite、文本→TMP 字体、节点→父级/布局关系。只有图片时可完成资源引用和候选节点；完整摆放需设计参考或明确布局。截图能提供视觉位置关系，不能恢复隐藏节点、变量、交互、AutoLayout 或稳定 Figma id；推断项在报告注明。

对缺图、文字不完整和布局关键歧义，只阻塞对应节点/动作。设计师明确要求近似搭建时可生成标注推断的草稿；不把截图“转成”伪造原生 FUI 数据再声称 Figma 原样导入。

## 实际布局/组件检查

- 同模块模板与公共组件优先，既有 Prefab 保留组件类型和引用。普通装饰 Image/Text 不抢 Raycast；实际按钮/遮罩阻挡范围按用途设置，不能全局一律开或关。
- 在目标 Canvas 记录 referenceResolution、scale mode、match、render mode/camera；坐标转换依据当前父 rect 和 pivot，不硬编码 1080×1920 或通用 PPU。
- LayoutGroup/ContentSizeFitter 会重写尺寸/位置；需要动效时明确控制节点，按现有结构区分布局容器与视觉运动子节点。不能给已有动画强行加 wrapper 后不迁移路径。
- 记录锚点、offset、pivot、比例与安全区；按用户目标画幅及相关长屏/横屏/安全区查看，单画幅截图不证明全部适配。
- 检查实际 Mask/RectMask2D、嵌套 Canvas、兄弟排序、透明边和效果外扩；不把静态图还原当所有遮罩/交互都正确。

## Figma 业务扩展

- `FigmaFrameSplitApplier`：根 `pluginTags` 的 `Split:r1,r2`，恰好两条有效比例触发 Top/Mid/Bottom 分层；会重父化并处理跨带背景遮挡。不要用 PSD 的固定 200 px 分区代替。
- `FigmaSkinBinderApplier`：只有 `colorBindingMode=TintMask` 才用 Graphic.color 乘色，彩色 PNG 保持设计 RGB。颜色变量按 `/` 分段去 Color，需匹配真实 SkinColorKeys；不匹配会跳过告警，不能填成换肤成功。
- `FigmaTmpStyleApplier`：字体就绪后应用 TMP 描边/投影；系数为标定，坐标 Y 转换和真实字体材质影响观感，需看实际输出。
- `FigmaComponentMap.asset`：当前 autoComponentEnabled=0、entries=[]。工具能导入节点不意味着业务 Button/Toggle/皮肤组件都自动正确。

## 动效与程序集成边界

更新前后比较 Prefab GUID、对象/组件 localFileID、节点路径、AnimationClip 绑定属性和相对路径、Animator Controller、PlayableDirector 的资产/轨道绑定、exposed references，以及现有 UI 字段。需要新增动效时另用 unity-animation-delivery、spine-unity-design 或 designer-particle-effects；本次 UI 搭建只准备稳定挂点和初始视觉状态。

程序接收单列 UI 根、需要访问的节点/类型、哪些显示文本/图片需动态赋值、交互和适配约定、依赖、动画预留/保留节点及待接入项。缺 UIType 注册、资源加载、页面业务不妨碍设计资源交付，但不能写“正式页面已经打开验证”。
