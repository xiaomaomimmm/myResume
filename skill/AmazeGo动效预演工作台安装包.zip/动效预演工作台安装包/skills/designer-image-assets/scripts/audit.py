#!/usr/bin/env python3
"""Read-only image inventory. PNG headers and byte hashes are not pixel validation."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import struct
import sys

EXTENSIONS = {'.png', '.jpg', '.jpeg', '.tga', '.webp', '.bmp', '.tif', '.tiff'}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest() if hasattr(hashlib, 'file_digest') else hashlib.sha256(stream.read()).hexdigest()


def guid(path):
    if not path.is_file():
        return None
    match = re.search(r'^guid:\s*([0-9a-fA-F]{32})\s*$', path.read_text(errors='replace'), re.M)
    return match.group(1).lower() if match else None


def fields(path):
    if not path.is_file():
        return {}
    text = path.read_text(errors='replace')
    return {key: match.group(1).strip() for key in
            ('textureType', 'spriteMode', 'spritePixelsToUnits', 'spriteBorder', 'spritePivot',
             'enableMipMap', 'alphaIsTransparency', 'maxTextureSize')
            for match in [re.search(r'^  ' + key + r':\s*(.+)$', text, re.M)] if match}


def header(path):
    if path.suffix.lower() != '.png':
        return None, None, 'format_requires_decoder'
    with path.open('rb') as stream:
        data = stream.read(33)
    if len(data) < 33 or data[:8] != b'\x89PNG\r\n\x1a\n' or data[12:16] != b'IHDR':
        return None, None, 'invalid_png_header'
    width, height = struct.unpack('>II', data[16:24])
    if width <= 0 or height <= 0:
        return None, None, 'invalid_png_size'
    return [width, height], data[25] in (4, 6), None


def check(rule, target, status, detail, evidence, required=True, level='static', next_action=None):
    return {'id': rule, 'target': target, 'scope': 'resource_delivery', 'required': required,
            'status': status, 'level': level, 'detail': detail, 'evidence': evidence,
            'next_action': next_action}


def inside(path, root):
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def asset_directory(project, value):
    path = (project / value).resolve() if not Path(value).is_absolute() else Path(value).resolve()
    if not inside(path, project / 'Assets'):
        raise ValueError('target-dir must resolve inside project Assets')
    return path


def audit(source, project, target):
    images = sorted(p for p in source.rglob('*') if p.is_file() and p.suffix.lower() in EXTENSIONS)
    observations, checks = [], []
    checks.append(check('batch.images', str(source), 'passed' if images else 'pending',
                        f'Found {len(images)} image files.', [str(source)],
                        next_action=None if images else 'Provide an image directory.'))
    for image in images:
        if not inside(image.resolve(), source):
            checks.append(check('asset.path', str(image), 'failed', 'Source symlink escapes source directory.', [str(image)]))
            continue
        destination = target / image.relative_to(source)
        if not inside(destination.resolve(), project / 'Assets'):
            checks.append(check('asset.path', str(image), 'failed', 'Target symlink escapes Assets.', [str(destination)]))
            continue
        size, alpha_channels, error = header(image)
        source_hash = digest(image)
        exists = destination.is_file()
        target_hash = digest(destination) if exists else None
        decision = 'new_candidate' if not exists else ('same_bytes_candidate' if source_hash == target_hash else 'content_conflict')
        meta = Path(str(destination) + '.meta')
        observations.append({'source_path': str(image), 'target_path': destination.relative_to(project).as_posix(),
                             'source_sha256': source_hash, 'target_sha256': target_hash,
                             'source_size': size, 'png_has_alpha_channels': alpha_channels,
                             'pixel_hash': None, 'color_role': 'unknown', 'decision': decision,
                             'target_guid': guid(meta), 'serialized_fields': fields(meta),
                             'observation_level': 'static'})
        target_id = destination.relative_to(project).as_posix()
        valid = error not in ('invalid_png_header', 'invalid_png_size')
        checks.append(check('asset.header', target_id, 'passed' if valid and size else ('failed' if not valid else 'pending'),
                            error or 'Read PNG IHDR dimensions only.', [str(image), source_hash],
                            next_action=None if size else 'Decode the source with an image decoder.'))
        checks.append(check('asset.decode', target_id, 'pending', 'No image decode or visible alpha/pixel inspection performed.',
                            [], level='none', next_action='Decode pixels; inspect appearance if needed.'))
        if decision == 'content_conflict':
            checks.append(check('asset.collision', target_id, 'pending', 'Same target path contains different bytes; no reuse/update decision executed.',
                                [source_hash, target_hash], next_action='Confirm target/version and reference impact; update in place only within requested scope.'))
        checks.append(check('asset.importer', target_id, 'pending', 'Serialized fields are partial observations, not Unity importer verification.',
                            [str(meta)] if meta.exists() else [], level='static' if meta.exists() else 'none',
                            next_action='Load source and target in Unity; verify importer and dependencies.'))
    return {'schema_version': 1, 'skill': 'designer-image-assets', 'mode': 'inspect',
            'created_at': datetime.now(timezone.utc).isoformat(), 'project_root': str(project),
            'observations': observations, 'changes': [], 'checks': checks,
            'handoff_status': 'not_requested', 'designer_approval': None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', required=True)
    parser.add_argument('--source-dir', required=True)
    parser.add_argument('--target-dir', required=True, help='Assets-relative target directory; only inspected, never created.')
    parser.add_argument('--out', help='Optional report outside source directory and project Assets.')
    args = parser.parse_args()
    try:
        project, source = Path(args.project_root).resolve(), Path(args.source_dir).resolve()
        if not (project / 'Assets').is_dir() or not source.is_dir():
            raise ValueError('project-root must contain Assets; source-dir must exist')
        target = asset_directory(project, args.target_dir)
        output = Path(args.out).resolve() if args.out else None
        if output and (inside(output, source) or inside(output, project / 'Assets') or inside(output, Path(__file__).resolve().parent.parent)):
            raise ValueError('out must not overwrite source, Assets, or Skill files')
        report = audit(source, project, target)
        rendered = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
        if output:
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(rendered, encoding='utf-8')
        else:
            print(rendered, end='')
        return 1 if any(c['status'] == 'failed' for c in report['checks']) else 0
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
