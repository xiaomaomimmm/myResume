# 图片资源的工程事实与执行方法

以下结论来自本工程源码；执行前核对当前文件，常量和目录不能靠旧文档推断。未要求本次修改这些工具。

## 用途决定落点和导入设置

| 用途 | 现有落点/规则 | 源码依据 |
|---|---|---|
| 普通 UI/图集散图 | `Assets/AssetBundle/Sprite/<功能>/`；平台格式由图集决定；尺寸不能被平台 override 偷偷放大 | `Assets/Editor/Resource/TextureFormatConventionPostprocessor.cs` 的 `InAtlasFolder`、`CapInAtlasFolder` |
| 图集外大图 | `Assets/AssetBundle/BigSprite/<功能>/`；不被 Sprite 树自动重新打图集；源图集迁移要复制真实平台设置 | `Assets/Editor/Resource/BigSpriteTextureImportPostprocessor.cs`、`SpriteMigration`、`AtlasUtilizationWindow.cs` |
| 一般 Texture/Resources | `Assets/Art/Texture/`、`Assets/AssetBundle/Texture/`、`Assets/Resources/`；当前 Android ASTC_6x6 / iOS ASTC_4x4、max≤2048；NormalMap 跳过；不顺带改色彩空间、mipmap/readable/type/filter | `TextureFormatConventionPostprocessor.IsGated/ApplyConvention` |
| Spine 或粒子专用贴图 | 保留各模块专用导入契约；不批量转 Sprite 或裁掉有效边距 | `Assets/Editor/Spine/SpineTextureImportPostprocessor.cs`；相关资源所在模块 |

目录只是条件之一：先查用途、现有引用/图集 packable 和目标模块，不能只因“大图”或超过某个文件体积就自动迁移。

## BigSprite / SDF

当前 `BigSpriteTextureImportPostprocessor`：base 与 `_sdf` 成组取**源长边最大值**，≤768 用 512 上限，其余 2048。只降不升；已有 overridden 格式保留源图集格式。无源图集才用 Android ASTC_6x6 / iOS ASTC_4x4 的默认值。`ApplyFromAtlas` 保存重导入后重新读 Importer，返回逐项差异。

`UISdfOutline` 使用导入后两张 Sprite rect 差计算描边范围；裁边、改 PPU 或单图降尺寸会改变效果。普通素材整理保留该对及目录关系，需要迁移时共同处理和核验。

## 查重复与版本

`Assets/Editor/Resource/SpriteCleanupWindow.cs` 为 PNG/JPG/JPEG 解码 RGBA，加宽高后做像素 hash；仅 Single 进入去重候选，并检查 border、引用数及字符串路径引用。像素相同不代表可删除：Importer、图集/用途、Sprite fileID 与字符串路径仍可能不同。

建议清单项：源路径/哈希、目标路径/GUID、解码宽高、源透明区、用途与颜色角色、Sprite 子资源名/fileID、PPU/border/pivot、图集、Importer 漂移、引用影响和计划动作。`byte_hash` 与 `pixel_hash` 分开；未解码的 pixel_hash 为 null。

源图 RGB 已烘色时保持原色；白色 mask 的颜色使用方式由设计/材质或 Figma 的 `colorBindingMode=TintMask` 决定。不能从有 alpha、名称含 glow、文件格式等推断成可乘色白图。

## Unity 实际执行

先发现 Unity 实例和 `mcpforunity://custom-tools`，按当前能力调用，不硬编码旧 MCP 参数。已有作用域清晰的导入工具优先；否则用已发现的 Editor 脚本桥逐文件执行 AssetDatabase/TextureImporter 公共 API。确认工具真实可用，不能因为源码中有函数就声称已经调用。

- `Assets/Editor/UGUIMCP/UICreateUtils.cs: SetSpriteFormat(spriteDir)` 扫整个目录，只将类型改 Sprite、关闭 mipmap；不会设置 Single、PPU、border、平台格式或保证图集成员资格。只在清单等于完整专用目录、范围明确时使用；共享目录改逐路径。
- 新图按指定目标复制/导入；同名更新保留原 `.meta`；变名/移目录用 AssetDatabase 并检查字符串路径。对原位更新，还需查看 Multiple 子 Sprite 的 fileID 是否变化。
- `AssetDatabase.SaveAssets` / `ImportAsset` 或 `SaveAndReimport` 后重新获得对象并读字段，记录实际结果。头部 IHDR 是源尺寸，不能替代 Unity 导入尺寸。
- 缺 Unity 时先交磁盘清单，不伪造 `.meta`、Importer 回读或完整画面验收。

## 与现有 PSD 流程的边界

`.ai/skills/psd-ui-builder/scripts/assets_processor.py` 依赖 `session.json + psd_tree.json`，按模块文件名复用；`.ai/skills/psd-ui-builder/stages/review.md` 会清理本次 plan 未引用的模块图片。它们服务完整 PSD 重建，不能原样用于已切图增量整理。

源码路径供检索，不复制整套实现到 Skill；变更工具后重新核对相关规则和实际资源。
