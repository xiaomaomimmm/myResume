# 图片素材 harness 合同

这是任务/结果合同，不是后台监听或某个 harness API 的实现。设计师说自然语言，harness 负责整理请求、发现可用工具、执行并记录结果。

## 输入

`request` 建议字段：`mode`（inspect/prepare/handoff）、`module`、`source_dirs`、`target_dir`、`usage`、`targets`、`update_scope`、`report_dir`。targets 可包含明确源→目标映射和已知图集/Prefab。尚未知为 null/缺项；只缺布局不妨碍图片盘点，只有目标/共享更新范围歧义才阻塞对应写入。

任务目录隔离，沿用指定报告目录或 `.local/reports/designer-image-assets/<任务名>/`。报告不写进 Skill 包、源图目录或 Assets。两 Skill 的连续执行须来自用户请求或 harness 已获授权的任务范围；图片整理完成不隐含搭 UI。

## 输出

按 [report.schema.json](../assets/report.schema.json)：`schema_version=1`、`skill`、`mode`、`created_at`、`project_root`、`observations`、`changes`、`checks`、`handoff_status`、`designer_approval`；可附 `request` 与 `asset_manifest`。

`asset_manifest` 每张图含 source_path/target_path、source_sha256/target_guid、source_size/imported_size、pixel_hash、color_role、decision、dependencies、importer、evidence。色彩角色为 `baked/tint_mask/unknown`；决定为 `reuse/import_new/update/conflict/pending`；建议动作与已执行动作分开，实际执行在 changes。缺值填 null；不让设计师填写技术对象。

磁盘 audit 的 observations 为 source_path/target_path、哈希、source_size、png_has_alpha_channels、target_guid、serialized_fields、color_role=unknown、pixel_hash=null、decision=new_candidate/same_bytes_candidate/content_conflict。这些是候选与局部字段，不直接填成已导入资产。检查者可以在实际 Unity/解码后输出更完整的同一合同。

## checks 与证据

每项包含 `id/target/scope/required/status/level/detail/evidence/next_action`。scope 为 resource_delivery 或 programmer_integration；检查唯一身份是 `(id,target)`。

| status | 判断 |
|---|---|
| passed | 本项实际检查符合要求，evidence 非空 |
| failed | 实查发现不符合 |
| pending | 尚未执行、材料/工具不足或无法确定 |
| needs_design | 关键设计决定或必要观感确认缺失 |
| needs_programmer | 正式加载/使用方接入待程序处理 |
| not_applicable | 本次确实不涉及，detail 写原因 |

level 为 none/static/data_load/unity_load/visual/device，仅标证据来源。PNG 有 alpha 通道不证明有可见透明像素；SHA256 判字节不判解码像素；磁盘 `.meta` 不证明 Unity 当前 importer/图集正确。检查范围不扩大成全仓优化；按本次动作设置 required。

## 完成状态

- `not_requested`：仅查询/准备，没有正式交付请求。
- `draft`：可用清单/草稿可交，必需导入或视觉证据尚缺。
- `ready_for_programmer`：本次必需资源交付 checks 均 passed/有依据的 not_applicable，依赖和使用说明完整；要求视觉确认时已有对应当前版本的设计记录。接收方未接入可保留 needs_programmer。
- `integrated`：明确要求程序集成时，接收方必需检查也实际通过。

纯素材盘点不强制预演/录屏/设计师逐项审批；若已切图只做无视觉改动的原位导入，按实际必要检查决定是否要求新的观感确认。designer_approval 没有时为 null，不能因工具完成自动生成“已批准”。

给后续 UI Skill 的素材清单是数据输入，可在用户明确要求搭建时直接使用；接收方需对当前版本和目标用途重新核对，旧 passed 不跨版本自动复用。
