---
name: designer-image-assets
description: Use when ArrowsGo 设计师需要盘点、检查、导入、更新或交付 PS/Figma 已切好的图片素材，包括 Sprite、贴图、同名冲突、复用、图集与大图落点；仅处理图片资源，UI 搭建、Spine 和粒子制作使用各自 Skill。
---

# 设计师图片素材整理与交付

把已切图整理成 Unity 可引用的素材和清单。设计师提供自然语言、图片目录和用途，harness 整理技术字段，不要求设计师写 JSON/C#。工程为 `arrowgo-unity/`，下文 `Assets/` 相对 Unity 工程。

## 本次动作

| mode | 使用场景 | 结果 |
|---|---|---|
| `inspect` | 找图、查规范、盘点、查重复/同名冲突 | 素材观察与待处理项，不改图片 |
| `prepare` | 导入、原位更新、调整明确的导入设置 | 保存资源及 `.meta`，回读后记录实际变更 |
| `handoff` | 给 UI/动效设计师或程序交素材 | 素材清单、依赖、版本和实际验收状态 |

一个请求可含多个动作，记录实际范围。**本 Skill 不自动继续搭 UI。**已有清单可供 `designer-ui-assembly` 单独使用；UI 已有正确资源引用时也不强制先运行本 Skill。

读取 [图片工程约定](references/project-conventions.md) 与本次用途对应的部分。自动化或批量交付读取 [harness 合同](references/harness.md)。

## 执行步骤

1. **定位与盘点**：查源目录、目标模块/用途、已有目标及引用。默认输入为已切图，PSD 非必需。保留原始文件、透明边、尺寸和 RGB；裁图、重切、合并图集或转换白色蒙版仅在本次明确需要时执行。缺少源目录/更新目标时仅询问影响操作的项，已有目录和约定仍可检查。
2. **形成素材计划**：对每张图记录源/目标路径、SHA256、解码尺寸、alpha 与颜色用途、已有 GUID、Importer 和引用影响。文件名只定位候选；同名异内容记冲突，不能当复用。同字节也只算复用候选，需核对用途与 border/pivot/PPU、Single/Multiple、平台/图集设置。无法解码时保留未验证状态。彩色透明 PNG 不因“透明”就变成 TintMask。
3. **按范围导入或更新**：复用工程目录和现有 importer。用已发现的 Unity 工具/API 导入指定文件；更新目标和意图已明确时原路径替换图片、保留 `.meta`/GUID。更改共享素材前查本次目标之外的引用；有未明确的共享影响时留下候选，继续处理无冲突图片。迁移/重命名用 `AssetDatabase.MoveAsset/RenameAsset`，同步字符串路径影响；不把仅改 GUID 当完整路径迁移。新资源由 Unity 生成 `.meta`。
4. **保存回读**：保存、重导入后重新取 Importer 和 Sprite；核对源像素与导入尺寸、Sprite 名/fileID、PPU、border、pivot、平台上限、图集与依赖，按变化核对实际画面。只处理本次清单，`SetSpriteFormat` 的目录全扫不是逐文件导入器。去重删除、图集迁移和全仓格式修正属于单独动作，不由一次普通导入推导。
5. **交付**：普通查询简短回答；批量操作/交付保存 `report.json` 和素材清单到指定目录，默认 `.local/reports/designer-image-assets/<任务名>/`。清单分开列复用、新增、更新、冲突和未验证项，附真实路径、GUID、版本及可继续处理的动作。草稿可以交出；Unity 读回、观感与程序接入分别记录。

## 工程中特别容易混淆的地方

- 普通 UI 图片沿用 `Assets/AssetBundle/Sprite/<功能>/`，图集决定平台压缩；不套用所有散图统一 ASTC 的规则。
- `BigSprite` 是避开自动入图集的大图目录；按源图集参数、长边和 base/`_sdf` 成组处理。尺寸上限不能按面积判，也不能两张分别定档。
- `assets_processor.py` 以同名判 `exists`，依赖 PSD tree；本 Skill 的已切图入口不能原样调用它来完成内容复用判定。
- 图片清理工具会改引用并删除文件；`psd-ui-builder` 的 review 还会清掉本次 plan 未用图，均不作为素材盘点的收尾。

## 可运行的磁盘预检

```sh
python3 .ai/skills/designer-image-assets/scripts/audit.py --project-root arrowgo-unity --source-dir /实际切图目录 --target-dir Assets/AssetBundle/Sprite/Gallery --out .local/reports/designer-image-assets/gallery/static-audit.json
```

脚本仅写报告：读 PNG 头尺寸、文件 SHA256、已有目标 GUID 和部分序列化字段；不解码像素，不判视觉通过，不执行复用/复制/删除/导入。退出码 `0` 为无确定静态失败（仍可能有 pending/内容冲突），`1` 为静态发现失败，`2` 为调用错误。harness 必须读取 checks，不把退出码 0 当导入完成。

设计师示例：`$designer-image-assets 整理这批已切图到 Gallery，比较已有同名资源，输出素材清单。`
