# Timeline 预演编排与验证

仅在明确要求编排或本次资源影响已有预演时读取。不作为资源交付的前置；Game/UI 正式播放仍由程序控制。对象选择见 [Game/UI](game-ui.md#objects)，资源准备与动作引用见 [资源主流程](resources.md)。

按需定位：[片段融合](#mix) · [动作编排](#sequence)；其后为多轨叠加、时间源、结束与翻转专项。

<a id="mix"></a>
## 片段融合

SkeletonDataAsset 的默认与有方向配对沿用 [资源融合规则](resources.md#mix)，本页只规定 Timeline 沿用/覆盖方式。

| Timeline 设计意图 | 片段设置 |
|---|---|
| 与 Game/UI 沿用资源融合 | **Default Mix Duration 开** |
| 拖动重叠区决定过渡 | Default Mix Duration 关；Use Blend Duration 开 |
| 明确指定片段秒数 | Default Mix Duration 关；Use Blend Duration 关；填写 Mix Duration |

默认模式下后两项不参与切换，即使序列化保存旧值。4.1 显示 Default Mix Duration，内部反向字段为 `customDuration`：勾选对应 false；旧教程 Custom Duration 先核对反向关系。

**哪些曲线真正生效：**Spine Animation State Clip 的 **Ease Out Duration、Blend Curves 不参与动作融合**。关 Default Mix Duration、开 Use Blend Duration 时，4.1 读取 `max(blendInDuration, easeInDuration)` 作为自定义过渡时长，不读取曲线形状。调缓入/缓出曲线不会得到相应的骨骼融合曲线；若需要不同动作节奏，先比较可用融合时长与动作源曲线，再确定是否需要设计师回 Spine 调整。不为“曲线没生效”删除已有曲线；其他 Animation Track 上的 Transform/CanvasGroup 曲线仍有各自作用。

<a id="sequence"></a>
## Timeline 预演操作

用户明确给出“idle → play → perf”等顺序时，先完成 [资源准备与引用校验](resources.md)，再把相应真实动作引用按顺序放入目标轨道。若这些是用途别名，需要已有明确映射；不能从名字近似或其他动作猜代替。没有指定循环次数/时长时，已有编排沿用；新建基础查看序列可先按各动作原始时长各播一次、速度 1 排列并报告该假设，保留已确定的例外。片段顺序不代表正式业务触发。

1. 已有预演局部调整；新预演放独立场景，用 Game/UI 实例、正确相机/Canvas/材质，避免自动启动正式玩法的脚本。
2. 创建预演专用 PlayableDirector 与 Timeline。正式 Prefab 保持程序播放用途，Director/Handle 放预演实例或预演 Prefab。
3. 新增资源准备已有动作引用时直接复用；缺失时按 [动作引用生成与同目录隔离](resources.md#references) 选择入口，并核对真实骨骼与动画绑定。同目录多骨骼不逐份点击官方共享目录按钮。4.1 通常生成单独 ReferenceAssets，4.3 单容器方式不直接套用。
4. 按组件选择 Handle 和菜单：

   | 对象 | Handle | Timeline 菜单 |
   |---|---|---|
   | SkeletonAnimation | SkeletonAnimationPlayableHandle | Spine → SkeletonAnimation Track |
   | SkeletonGraphic | SkeletonGraphicPlayableHandle | Spine → SkeletonGraphic Track |

   将对应 Handle 所在 GameObject 拖到轨道绑定栏。内部类名 SpineAnimationStateTrack / SpineAnimationStateGraphicTrack 不等于菜单名。SkeletonMecanim 不是这两类轨道的对象。

5. 拖实际 AnimationReferenceAsset 到片段区。核对真实引用，不用显示标题代替；记录开始、片段长、Loop、Speed Multiplier、Clip In 和融合。
6. 单套动作一般 Track Index 0。需叠加才按下节添加其他索引；索引不等于轨道行号。编辑态要求基础轨道在上、叠加轨道在下。
7. 按结束画面选择尾部行为，核对空白间隙与总长。

## 按需：多轨动作叠加

例如身体待机同时挥手，先核对上层动作实际给哪些骨骼/Slot 打了关键帧；上层有全身关键帧时可能覆盖整个待机，不能只靠拆成两行解决。

1. 同一对象绑定各 Spine 轨道；基础动作 **Track Index 0**，叠加动作使用不同的实际索引，如 1。同索引仍会相互切换；把基础行放上方、叠加行放下方，保留原有索引与顺序。
2. 片段 **Alpha 是动画权重，不是 UI 透明度**。按要求调整叠加程度，UI 淡出另用已确认的透明度控制源。
3. **Hold Previous 不表示保持末帧**。它可减少上层动作切换时对下层姿态的权重回落；前后动作关键帧集合不同也可能突跳。仅出现对应症状时比较开关效果，不统一勾选。
4. Event / Attachment / Draw Order Threshold 控制混出动作在过渡到什么程度后停止贡献事件、附件或绘制顺序；工程 4.1 字段与新版命名可能不同。保留已调值，只针对本次事件重复、换图或层序症状核对。
5. 叠加结束需要渐退时核对片段末尾的空动画融合与基底恢复。`ClearTrack` 本身不会把骨骼重置到 setup pose；不把清轨当作渐退或复位。区分回基础动作、回 setup pose 与保持当前姿态，按实际预演验证后交付程序。
6. 普通上层覆盖与程序的 `MixBlend.Add` 是不同动画混合方式，也不同于 Slot 的 Additive 光效。4.1 本 Skill 使用的 Timeline 轨道未提供直接选择 `MixBlend.Add` 的入口；真加法动作叠加需另做预演方案并交程序接入，不能把加一行报告成已实现。

## 两个时间源与暂停

先定位是游戏 `Time.timeScale=0`、Director 被 Pause、片段/组件速度为 0，还是 SkeletonGraphic Freeze/对象禁用。不要只勾 Don't Pause with Director 就报告解决所有暂停问题。

| 来源 | 控制内容 |
|---|---|
| PlayableDirector 的 Update Method / `timeUpdateMode` | Timeline 自身时间是否前进；Unscaled Game Time 对应 `DirectorUpdateMode.UnscaledGameTime` |
| Spine 动画轨道的 **Unscaled Time** | 在有效动作片段开始时写入 SkeletonAnimation / SkeletonGraphic 的 UnscaledTime，决定组件动画更新是否受 Time.timeScale 影响 |
| Don't Pause with Director | Director 暂停时是否暂停当前动画；不负责让 Director 时间继续前进 |

1. 若游戏时间暂停时整段预演仍需继续：预演 Director 用 **Unscaled Game Time**，相关 Spine 动画轨道开启 **Unscaled Time**，同时核对对象/组件启用、Freeze、组件与动作速度。仅切 Director 时间源，不能保证 UI Spine 动画同步继续。
2. 同一个 Spine 对象的多轨共用组件 UnscaledTime；统一本次时间意图，避免各轨片段开始时互相覆盖。普通使用沿用已有值，不强制全部预演忽略游戏暂停。
3. 如果调用了 **Director.Pause()**，序列时间会停止。Don't Pause with Director 可让当前动作继续，但不会推进后续片段或其他 Timeline 曲线；逐帧检视通常关闭。需要整段继续时在预演入口区分暂停来源，正式游戏暂停逻辑交程序处理。
4. 按实际需求对比正常播放、游戏时间暂停、Director 暂停/恢复和停止重播，确认动作与其他效果同步。UnscaledTime 是组件状态；若预演结束后对象还会复用，检查恢复要求，不假定停止自动恢复所有设置。

## 暂停与结束

| 选项 | 结果 |
|---|---|
| Don't Pause with Director | 开时 Director 暂停后动作可能继续；暂停逐帧检查通常关闭 |
| Don't End with Clip | 开时末尾不主动清空动作；不等于保持末帧，循环可能继续 |
| Clip End Mix Out Duration | 上项关时，空白/停止混到空动画的秒数；负值表示暂停 |
| Loop / Speed Multiplier / Clip In | 循环、倍速、动画内偏移，与片段长度分别记录 |

保持姿态、继续循环、回待机、隐藏是不同要求，按实际设置验证，不能只勾 Don't End with Clip 就宣称保持末帧。长片段可能裁剪、循环或保持，不一定减速。预演结尾隐藏 UI 是演示安排，不等于正式页面自动关闭。

## 按需：翻转预演

1. 在预演 Timeline 添加 **Spine → Skeleton Flip Track**，绑定目标的实际 **SpinePlayableHandleBase** 组件，即本对象的 SkeletonAnimationPlayableHandle 或 SkeletonGraphicPlayableHandle。轨道绑定类型不是 SkeletonDataAsset 或裸 SkeletonGraphic。
2. 添加 **Spine Skeleton Flip Clip**，设开始/结束和 **Flip X / Flip Y**。此轨道翻转整个 Skeleton，不能只翻某根骨骼。4.1 修改 Skeleton.ScaleX/ScaleY 的符号、保留原缩放绝对值，停止时恢复捕获的原缩放；Flip X 关代表 X 正向，不是相对当前朝向再次翻转，也不代表恢复全部骨骼姿态。
3. 查看正播、倒拖、跳帧、离开片段、停止和重播，确认朝向、初态与 [骨骼挂件](game-ui.md#attachments)。只在预演实例操作，不用负 Transform 缩放替代此轨道；正式朝向控制及复用恢复要求交程序。

## 一轮集中验证

- 编辑态正播/拖动、倒拖、跳到中段、回 0；同一时间点应恢复一致的本次姿态、显隐和位置，停止后恢复必要初态。
- Play Mode 从过渡前正播，观看实际配对融合、单次/循环、暂停和结束。官方明确编辑态融合为近似，不以倒拖代替正播。
- 涉及 UI 同时看本次材质、皮肤、CanvasGroup 和遮罩，普通调整不全查无关资源。
- 已有绝对时间预演重建不能照搬正式播放；每次清轨重放会破坏运行时融合。暂停修改动作/曲线后重新取样，确认变化可见。
- 记录已观看效果与未验证项。助手处理技术问题，设计师确认画面，表现通过后结束。
