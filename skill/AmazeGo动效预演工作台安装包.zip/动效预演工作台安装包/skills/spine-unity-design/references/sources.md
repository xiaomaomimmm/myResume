# 官方依据与工程版本

核对日期：2026-11-09。方法来源与查证入口不等于当前资源播放验收。

## 官方文档

| 内容 | 页面 |
|---|---|
| 二进制、导入、SkeletonDataAsset、Mix、Preview | [Assets](https://esotericsoftware.com/spine-unity-assets) |
| Game/UI 组件、皮肤、UI 材质、多贴图 | [Main Components](https://esotericsoftware.com/spine-unity-main-components) |
| 材质、混合、透明 | [Rendering](https://esotericsoftware.com/spine-unity-rendering) |
| Handle、轨道、默认融合、编辑态近似与结束 | [Timeline Extension](https://esotericsoftware.com/spine-unity-timeline) |
| RectTransform 边界、可见性、Match 与布局模式 | [Bounds and Correct Visibility](https://esotericsoftware.com/spine-unity-main-components#Bounds-and-Correct-Visibility)，落实为 [UI 边界流程](game-ui.md#bounds) |
| 实例材质覆盖与全角色透明合成 | [Changing Materials Per Instance](https://esotericsoftware.com/spine-unity-rendering#Changing-Materials-Per-Instance)、[Fading a Skeleton In or Out](https://esotericsoftware.com/spine-unity-rendering#Fading-a-Skeleton-In-or-Out)，落实为 [材质与颜色流程](rendering.md#materials) |
| Gamma/Linear、PMA/Straight、sRGB | [Atlas Texture Workflows](https://esotericsoftware.com/spine-unity-assets#Atlas-Texture-Workflows) |
| Timeline 有效参数与翻转 | [Spine Animation State Clip](https://esotericsoftware.com/spine-unity-timeline#Spine-Animation-State-Clip)、[Skeleton Flip Track](https://esotericsoftware.com/spine-unity-timeline#Skeleton-Flip-Track)，落实为 [预演流程](timeline.md) |
| 骨骼挂点与外部对象穿插 | [Manually Accessing Bone Transforms](https://esotericsoftware.com/spine-unity-main-components#Manually-Accessing-Bone-Transforms)、[Objects Between Skeleton Parts](https://esotericsoftware.com/spine-unity-rendering#Objects-Between-Skeleton-Parts)，落实为 [挂点与分层流程](game-ui.md#attachments) |

按任务读取对应部分。官方页面持续更新，含 4.3 内容；工程为 4.1。用当前 Inspector 与实现核对名称和支持项，不自行迁移。

## 工程入口

路径相对仓库根目录，按需读取，不把程序检查交给设计师。

| 问题 | 文件 / 依据 |
|---|---|
| 运行库 | `arrowgo-unity/Assets/Addons/Spine/version.txt`：4.1-2023-11-28，接受 4.1.xx |
| Timeline 版本 | `arrowgo-unity/Assets/Addons/com.esotericsoftware.spine.timeline-4.1/package.json`：4.1.7 |
| 默认/配对 Mix | `arrowgo-unity/Assets/Addons/Spine/Runtime/spine-unity/Asset Types/SkeletonDataAsset.cs`：FillStateData |
| Preview 和引用按钮 | `arrowgo-unity/Assets/Addons/Spine/Editor/spine-unity/Editor/Asset Types/SkeletonDataAssetInspector.cs`：CreateAnimationReferenceAssets 在数据资产同目录的 ReferenceAssets 中按安全化动作名生成，已有同路径 AnimationReferenceAsset 就跳过且不核对归属。同目录多骨骼会碰撞，按 [引用隔离流程](resources.md#references) 处理 |
| 独立动作引用创建与校验 | `arrowgo-unity/Assets/Addons/Spine/Runtime/spine-unity/Asset Types/AnimationReferenceAsset.cs`：Create 菜单、skeletonDataAsset/animationName、Clear/Initialize；`arrowgo-unity/Assets/Addons/Spine/Editor/spine-unity/Editor/Asset Types/AnimationReferenceAssetEditor.cs`：Inspector 编辑及按实际骨骼查动作。2026-11-10 核对源文件，未执行生成或迁移 |
| 轨道显示名/绑定 | `arrowgo-unity/Assets/Addons/com.esotericsoftware.spine.timeline-4.1/Runtime/SpineAnimationState/SpineAnimationStateTrack.cs` 与同目录 `SpineAnimationStateGraphicTrack.cs` |
| 默认勾选反向字段 | `arrowgo-unity/Assets/Addons/com.esotericsoftware.spine.timeline-4.1/Editor/SpineAnimationStateDrawer.cs`：Default Mix Duration = !customDuration |
| 正播/编辑态混合、有效时长与时间源 | `arrowgo-unity/Assets/Addons/com.esotericsoftware.spine.timeline-4.1/Runtime/SpineAnimationState/SpineAnimationStateMixerBehaviour.cs`：GetCustomMixDuration 读取 blendIn/easeIn 最大值；有效片段开始时写入组件 UnscaledTime，不修改 Director 时间源 |
| 多轨权重/混合/清轨 | `arrowgo-unity/Assets/Addons/com.esotericsoftware.spine.timeline-4.1/Runtime/SpineAnimationState/SpineAnimationStateBehaviour.cs`、MixerBehaviour；`arrowgo-unity/Assets/Addons/Spine/Runtime/spine-csharp/AnimationState.cs`：Alpha、HoldPrevious、各 Threshold、ClearTrack 与 SetEmptyAnimation |
| 翻转轨道和恢复 | `arrowgo-unity/Assets/Addons/com.esotericsoftware.spine.timeline-4.1/Runtime/SpineSkeletonFlip/SpineSkeletonFlipTrack.cs` 与同目录 MixerBehaviour：绑定 SpinePlayableHandleBase、修改 Skeleton.ScaleX/Y 并停止恢复 |
| UI 边界/布局/多贴图/材质 | `arrowgo-unity/Assets/Addons/Spine/Runtime/spine-unity/Components/SkeletonGraphic.cs` 与对应 Inspector：MatchRectTransformWithBounds、GetLayoutScale、Edit Layout Bounds；UpdateMaterialsMultipleCanvasRenderers 中材质或贴图覆盖支路绕过普通混合材质选择 |
| 持久实例材质入口 | `arrowgo-unity/Assets/Addons/Spine/Runtime/spine-unity/Components/SkeletonRendererCustomMaterials/SkeletonRendererCustomMaterials.cs` 与同目录 SkeletonGraphicCustomMaterials.cs：Game 原材质键、UI 原贴图键、启用/重用与清除映射 |
| 骨骼跟随与渲染分离 | `arrowgo-unity/Assets/Addons/Spine/Runtime/spine-unity/Components/Following/BoneFollower.cs`、BoneFollowerGraphic.cs；`arrowgo-unity/Assets/Addons/Spine/Runtime/spine-unity/Components/SkeletonRenderSeparator/SkeletonRenderSeparator.cs` 及 SkeletonGraphicInspector 的分离配置 |
| 颜色空间与渲染管线 | `arrowgo-unity/ProjectSettings/ProjectSettings.asset`：m_ActiveColorSpace=0（Gamma）；GraphicsSettings.asset：m_CustomRenderPipeline 无引用（Built-in），后续使用仍读取现状 |
| 4.1 CanvasGroup / Tint Black 组合 | `arrowgo-unity/Assets/Addons/Spine/Runtime/spine-unity/Utility/MaterialChecks.cs`：顶点与材质配套、Canvas uv1/uv2；同级 `Materials/SkeletonGraphicDefaultCanvasGroup.mat` 为普通淡出参考 |
| 程序皮肤/首帧注意项 | `.ai/wiki/concepts/runtime-spine.md` 与 `arrowgo-unity/Assets/Scripts/Game/Utils/Anim/SkeletonAnimationUtils.cs` |

## 设计师提供的 UI 卡点

[Spine 动画在 UI 上显示 + CanvasGroup 淡入淡出问题说明](https://learnings.feishu.cn/wiki/P4bBw4o1MiMqCFksHhzcNbspnPg)，2026-11-09 读取正文及嵌入设置表。沉淀为 [UI Add 光效与打包卡点](rendering.md#ui)，保留原问题来源，区分普通淡出、Additive 材质路径和包体变体验证。

表格明确 Straight Alpha Texture 依图集类型选择，因此不把原文“三处统一成直通”改写为“必须重导 Straight Alpha 图集”。文档中的变体剔除是既往案例，新增任务仍需程序核对真实包体。

Additive 操作核对了 SkeletonGraphic/Inspector、BlendModeMaterials、Spine-SkeletonGraphic-Additive shader 与现有材质。工程现有 CustomSVC、ResDefine/ResManager 资源预热及 BundleMainEditorSetting 的另一份 SVC 配置也已静态核对；未修改或验证构建。

## 版本适用与验收范围

当前官方含 4.3 贴图流程按钮及新版字段；本 Skill 按工程 4.1 的实际入口落实。整体合成文档提到 SkeletonRenderTexture/SkeletonRenderTextureFadeout，2026-11-09 编写时在 Assets 未检索到对应组件，作为方案参考。后续执行重新核对可用性，不把该历史结果当作本次检查或现成实现。

2026-11-09 初次蒸馏据官方页面和工程资源/实现完成，后续查证日期按上述记录保留。2026-11-11 文档组织调整仅合并流程与更新链接，未增加 Unity 生成、播放或构建验证证据。

## UI Add 实现核对细节

- [官方 SkeletonGraphic 组件与材质说明](https://esotericsoftware.com/spine-unity-main-components#SkeletonGraphic-Component)：CanvasGroup/PMA、UI 材质、关闭顶点 PMA 后的 Additive 材质要求。新版 Tint Black 支持项按工程 4.1 实现核对。
- `SkeletonGraphic.cs` 的 UpdateMaterialsMultipleCanvasRenderers：选择 Additive 材质需独立混合信息、顶点 PMA 关闭及有效 additiveMaterial。
- `SkeletonGraphicInspector.cs`：上述 UI 开关、Additive Material 槽及提示。
- `BlendModeMaterials.cs`：Apply Additive Material 决定 Additive 附件是否参与专用混合材质分配。
- `Spine-SkeletonGraphic-Additive.shader`：Blend One One、CanvasGroup 与 Straight Alpha 关键字；`Spine-SkeletonGraphic-NormalPass.cginc` 处理 CanvasGroup 修改后的顶点 Alpha。
