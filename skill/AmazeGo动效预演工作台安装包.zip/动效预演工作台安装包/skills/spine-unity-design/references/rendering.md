# 材质、UI Add 与透明效果

用于材质被更新恢复、颜色/透明边缘、SkeletonGraphic Additive 光效和 CanvasGroup 淡出。只处理本次明确用途，保留原 Shader 效果与共享资产；画面与真机结果分开交付。

按需定位：[材质绑定](#materials) · [颜色/贴图](#color) · [普通 UI/Tint Black](#ui) · [Additive](#additive) · [整体淡出](#fade) · [包体交付](#build)。

Game 使用对应世界空间/渲染管线的 Spine 材质，UI 使用 CanvasRenderer 兼容的 `Spine/SkeletonGraphic*`；世界空间 `Spine/Skeleton` 即使编辑器偶然显示也不能当 UI 验收通过。先确认 PMA 或 Straight Alpha 的实际导出方式、导入与材质配套，贴图 PMA 和组件 PMA Vertex Colors 是不同设置。

<a id="materials"></a>
## 持久材质绑定

Spine 会根据当前附件与混合方式重建 MeshRenderer 材质数组。直接改数组可能在下一次 LateUpdate 被覆盖；不加每帧强制换材质脚本补救。

| 目标 | 4.1 入口与范围 |
|---|---|
| 所有引用同一 Atlas 的世界空间对象一起改 | SpineAtlasAsset 的 Materials；这是共享变更，先核对全部使用者，修改后让相关对象 Reload 并验证 |
| 仅一个 Game 实例替换原图集材质 | **SkeletonRendererCustomMaterials**；Original Material 为该 Atlas 的真实材质，Replacement Material 为本次副本；`overrideDisabled=false` 才启用 |
| 仅一个 Game 实例的指定 Slot | 同组件的 Custom Slot Materials；真实 Slot Name + Material，`overrideDisabled=false`；保留其他 Slot 与混合模式 |
| 普通 UI 主材质与特殊混合材质 | SkeletonGraphic 的主 Material，以及条件满足时的 Additive/Multiply/Screen Material；使用相应 `Spine/SkeletonGraphic*` Shader，沿用 [UI Add](rendering.md#ui) 的配套设置 |
| UI 确需按图集页贴图做实例覆盖 | **SkeletonGraphicCustomMaterials**；Original Texture 为原 Atlas 材质的真实 mainTexture，Replacement Material/Texture；`overrideEnabled=true` 才启用 |

实例替换步骤：

1. 核对是全角色、指定原材质还是指定 Slot，以及是否已有覆盖组件/程序设置。读取原 Atlas 绑定，复制本次需要的材质，保留贴图、PMA/Straight、关键字及自定义效果。
2. Game：复用或通过 SkeletonRenderer 组件菜单 **Add Basic Serialized Custom Materials** 添加 SkeletonRendererCustomMaterials，绑定目标 renderer、原材质和替换材质。不要把复制后的材质作为 Original Material。
3. UI：普通改色/淡出优先使用主材质及混合材质槽；确需覆盖时通过 SkeletonGraphic 同名菜单添加 SkeletonGraphicCustomMaterials，按 **原贴图**填映射。Game 的原材质键和 UI 的原贴图键不能互换。
4. 保存本次组件/材质和 `.meta`。让对象更新、切动作/皮肤并重新启用，核对多个子网格及遮罩；仅 Inspector 一帧显示正确不算通过。若程序后来替换同一映射，给程序交接，不新增互相抢写的逻辑。

4.1 特别注意：在 Multiple CanvasRenderers 下，**存在任意 CustomMaterialOverride 或 CustomTextureOverride** 时会进入按原贴图覆盖的支路，绕过通常的 Add/Multiply/Screen 材质选择；未映射页也可能落到主材质。Normal/Add 共用一页贴图时，不把同一个普通材质映射整页当作修复。先核对现有覆盖用途；能保留效果时回到主/混合材质槽，否则需要程序提供支持不同混合方式的覆盖方案。仅按页换贴图也要检查 Add，没有材质映射不代表未受影响。

`Clear and Reapply Changes` 会清除目标上未序列化的覆盖；不作为默认按钮。有其他程序/组件映射时先查归属，保留已正确设置。

<a id="color"></a>
## 颜色与贴图透明方式

1. 读工程当前 Color Space、渲染管线、贴图导出声明/记录和实际 Shader；不要根据黑边猜 PMA。当前工程为 Gamma、内置渲染管线，仅是基线，后续任务仍核对现状。
2. 官方普通贴图工作流：

   | 项目 | PMA | Straight Alpha |
   |---|---|---|
   | 适用颜色空间 | Gamma | Gamma 或 Linear |
   | 导出 Premultiply alpha | 开 | 关，通常开启 Bleed |
   | 贴图 sRGB (Color Texture) | 当前官方建议关 | 常规颜色贴图开 |
   | 贴图 Alpha Is Transparency | 关 | 常规直通流程开 |
   | 材质 Straight Alpha Texture | 关 | 开 |

3. 当前官方对 PMA 的 sRGB 建议与部分旧教程不同，尤其关系到 Mip Maps 白色接缝。工程 4.1 先核对既有预设和目标资源，再做有症状的局部调整；4.3 的 Switch Texture Workflow 按钮不作为本工程操作步骤。
4. 标准 Gamma 预乘贴图不直接配 Linear 项目。若当前组合不兼容，说明需要匹配方式的贴图重导/材质配套，沿用项目颜色空间；不为一个资源切换全项目 Gamma/Linear。
5. 在同背景、同动作时刻对比原图/Spine 参考与 Unity，分别看普通色、半透明边缘及实际 Add。后处理、曝光、受光材质、Tint Black 和自定义 Shader 另核对，不把“关/开 sRGB”当所有颜色问题的统一修复。法线等数据贴图不套常规颜色贴图规则。

颜色属于效果验收；有确切导出方式和兼容路径时修正本次配置，期望观感不明确时展示对照再由设计师确定。

<a id="ui"></a>
## UI 混合与 CanvasGroup 淡出

Add 指真实 Slot 的 Additive 混合；烘焙在普通贴图中的亮光不自动等于 Add。以下普通淡出组合来自设计师飞书经验并已对照工程 4.1；不要求把正确 PMA 图集重导成 Straight Alpha，贴图类型与顶点处理分开判断。来源与查证日期见 [依据](sources.md)。

先核对本次透明度来源：CanvasGroup、Graphic Color、骨骼 Alpha 以及已有曲线是否同时参与。自定义 Shader 先确认支持项；有材质/贴图覆盖时先查 [持久绑定](#materials)，不能只看 Additive 槽已填就认为最终生效。

| 现象 | 下一步 |
|---|---|
| 普通部分淡出发白、发亮 | 对照下述普通/Tint Black 配套设置 |
| 普通部分正常，Add 不亮、变黑或不随淡出 | 核对 [Additive 独立路径](#additive) |
| 配置正确但半透明透出后部 | 判断 [整体淡出](#fade) 的透明混合限制 |
| 编辑器正常，手机异常 | 查依赖、Shader/关键字与平台贴图，交 [包体验证](#build) |

Add 本来会提亮背景；比较同动作、背景、时间点的原有效果，不把预期加色误判为发白。

### 普通 UI 淡出

1. 复用 SkeletonGraphic 和已绑定资源。复制需要调整的共享 UI 材质，给目标对象用，避免改全项目的 SkeletonGraphicDefault。
2. 普通 UI 材质开启 CanvasGroup Compatible；SkeletonGraphic Advanced 关闭 PMA Vertex Colors。
3. 材质 Straight Alpha Texture 按实际贴图选择：PMA 不勾，Straight Alpha 勾。不要因为关顶点 PMA 而改图集。
4. 在 CanvasGroup Alpha 1、0.5、0 查看普通部分和 Add 光效。正确淡出应连同光效逐步消失，0 时无残光；有设计上独立不淡出的光效时，按明确的层级设计验收。

### Tint Black 与自定义材质

普通组合不直接代替 Tint Black/custom shader。4.1 使用 Tint Black 时，在组件开启 **Tint Black** 与 **Canvas Group Tint Black**，采用相应 SkeletonGraphic Tint Black 材质，并在父 Canvas 的 **Additional Shader Channels** 开 **TexCoord1 / TexCoord2**（源码 uv1/uv2）。先确认现有组合再局部修正；Straight Alpha Texture 仍按贴图实际导出设置。普通淡出可参考已有 `SkeletonGraphicDefaultCanvasGroup`，新版 Detect 按钮不是工程 4.1 的前提。

<a id="additive"></a>
## Add Slot：关闭顶点 PMA 后补齐混合路径

PMA Vertex Colors 开启时，Spine 可以把 Additive 编码进顶点色，与 Normal 合在一次渲染中。关闭后不能继续依赖这种方式；需要独立的 Additive 混合材质/子网格渲染。即使图集只有一页，也可能因为两种混合材质需要多个 UI Renderer。

对本工程 4.1 的普通 SkeletonGraphic 路径：

1. 选目标 SkeletonDataAsset，检查 **Blend Modes / Blend Mode Materials → Apply Additive Material**，用于让 Additive Slot 分配专用混合材质。仅目标资源需要时开启，保留 Normal/Multiply/Screen 和原有融合设置。此资产可能同时被 Game 对象引用，核对受影响用途后再改，不另造整套重复骨骼资源。
2. 选 SkeletonGraphic，开启 **Advanced → Multiple CanvasRenderers**。在 **Blend Mode Materials → Additive Material** 绑定 UI 用的 Additive 材质。
3. 用 `Spine/SkeletonGraphic Additive` shader 的材质，例如复制 `SkeletonGraphicAdditive` 后调整。它与 SkeletonDataAsset 图集混合材质是不同的绑定位置，不能拿世界空间 Additive 材质直接填 UI 槽。
4. 这份 UI Additive 材质同样要按需求开启 **CanvasGroup Compatible**，Straight Alpha Texture 按图集类型设置。工程现有 SkeletonGraphicAdditive 材质序列化的 CanvasGroup Compatible 为 0；不能仅凭名字或 shader 默认值认定已正确。
5. 再看 Alpha 1、0.5、0、Slot 穿插顺序和遮罩。Normal 主材质、Additive 材质及子 Renderer 全部纳入检查，不能只改主材质。

找不到 Additive Material 槽时先看 Apply Additive Material 与 Multiple CanvasRenderers；看到 “Additive Material - Unused with PMA Vertex Colors” 时说明仍是顶点 PMA 路径；看到 “No Additive Mat - 'Apply Additive Material' disabled” 时先补目标资源设置。使用自定义材质覆盖组件/映射时，由助手核对是否绕过默认混合选择，不盲目反复换材质。

关闭合批路径可能增加 draw call。这里先交付正确画面，具体性能和打包接入由程序在目标设备评估，不要求设计师改渲染代码。

<a id="fade"></a>
## 整体淡出时背后部件透出来

先按 [UI Add 与淡出](rendering.md#ui) 验证 Alpha 与混合配置。设置正确后，在 Alpha 0.5 仍看见原本遮住的躯干/手臂，可能是透明三角形逐次混合的结果；CanvasGroup Compatible 不会把全角色先合成一张图片。

1. 比较 Alpha 1/0.5/0，分清 Add 发白/残光、附件穿帮与正确透明混合造成的背部显露；核对 CanvasGroup、Graphic Color、骨骼 Alpha 是否重复参与。
2. 普通淡出观感可接受时沿用现有方案；若必须像整体图片一样淡出，明确记录这个视觉要求，不继续反复换 PMA/材质开关试错。
3. 可按设计比较减少重叠部件、显隐安排、缩放/染色等替代表现；这些会改效果，需要按已确定设计执行，不能自动修改 Spine 源动作或覆盖绘制顺序。
4. 需要先合成再淡出时，用独立预演评估 RenderTexture/合成方案，交给程序确认实际实现、分辨率、显存、背景透明、UI 遮罩与包体。官方 SkeletonRenderTexture/SkeletonRenderTextureFadeout 是示例入口；编写时（2026-11-09）在工程 Assets 未检索到对应组件。实际执行先查当前工程可用性；未查证时只引用这条历史记录，不报告已完成本次检索。不承诺直接添加即用，也不自动安装或升级插件。

交付注明淡出控制源、整体/逐部件的预期、参考画面与未验收项。RenderTexture 的成本与移动设备结果由程序核对。

<a id="build"></a>
## 编辑器正常、手机异常：程序交付

原文记录了 `_CANVAS_GROUP_COMPATIBLE` Shader 变体在 AssetBundle 使用中被剔除的案例。这是重要排查方向，但手机不显示也可能是资源依赖、平台贴图或材质不兼容；只凭现象不能确认根因。

设计师交付：

- 目标 Prefab、SkeletonDataAsset、Atlas/贴图、Normal 与 Additive UI 材质及 `.meta`。
- 实际 Shader 名、CanvasGroup Compatible、Straight Alpha Texture、UI Alpha Clip/Tint Black 等实际使用选项。
- 异常动作、皮肤、Slot 和对应 Alpha/遮罩场景，以及编辑器效果参考；已实测的手机型号/包版本与异常画面。
- 明确标注“编辑器已验收；包体/AssetBundle/真机变体待程序验证”，除非本次已有真实验证证据。

程序需要核对最终构建是否保留**实际 Shader + Pass + 关键字组合**，不仅是收录了一个同名 Shader。Normal 与 Additive、PMA 与 Straight、Alpha Clip 等组合分别核对。

原文推荐 ShaderVariantCollection（SVC）并预加载；也提出 Shader 随 AssetBundle 构建。按项目现有资源和 Shader 构建管线选择保留/预热方案，再验证最终包体。收录、预热和通过最终剔除规则是不同环节，不能仅创建一个 SVC 就承诺真机正确。不默认把所有 Spine Shader 塞入 Always Included Shaders。

2026-11-09 已静态核对的工程入口（执行时重读现状，不表示本次包体已通过）：

- `Assets/Scripts/Game/Framework/Resource/ResDefine.cs` 的 WarmUpSVCResPath 指向 `Shader/CustomSVC.shadervariants`。
- `Assets/Scripts/Game/Framework/Resource/ResManager.cs` 加载该集合并 WarmUp。
- `Assets/AssetBundle/Shader/CustomSVC.shadervariants` 已包含普通 `Spine/SkeletonGraphic` 的 `_CANVAS_GROUP_COMPATIBLE` 及其与 UNITY_UI_ALPHACLIP 的组合。这不证明 Additive/Tint Black/Straight Alpha 的所有组合已覆盖。
- `Assets/Editor/BundleEditorSettings/BundleMainEditorSetting.asset` 另有 `Local/Shader/svc.shadervariants` 配置。程序核对实际构建和加载流程，不能把两份集合当作同一份。

上述路径相对 arrowgo-unity。Graphics Settings 的 Preloaded Shaders 为空，不足以说明项目完全没有 SVC 预热，因为存在资源加载预热入口。设计师 Skill 只整理交付与待核对项，不擅自修改打包、Shader 剔除或资源预热代码。

技术依据见 [来源](sources.md)，包括 SkeletonGraphic 材质覆盖支路、BlendModeMaterials、Additive shader 与 CanvasGroup 顶点处理。助手承担技术核对，设计师看设置与画面对照。
