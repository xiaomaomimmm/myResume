# Game/UI 对象、布局与挂点

按本次用途准备或调整对象，正式播放交程序。不为普通资源检查额外创建对象；仅修改已有目标或本次明确要求制作的对象。

按需定位：[对象准备](#objects) · [UI 边界](#bounds) · [容器适配](#layout) · [骨骼挂点](#attachments) · [部件分层](#layering)。材质和透明问题见 [渲染](rendering.md)，资源默认融合见 [资源主流程](resources.md#mix)。

<a id="objects"></a>
## Game/UI 对象准备

Game 选 SkeletonAnimation，Canvas UI 选 SkeletonGraphic。复用正确对象；新建时用当前插件创建入口，绑定 SkeletonDataAsset，设置 Initial Skin、初始 Animation 与 Loop，再调整所需位置、尺寸和排序。

Inspector 初始动画/Loop 只用于初始展示；程序后续播放可指定其他动作与循环。交付明确每个业务动作单次/循环，不把初始值当全部播放契约。

Game 关注相机、Sorting Layer/Order 和父级；UI 关注 RectTransform、锚点、尺寸、Canvas 与遮罩。沿用已有逻辑根与视觉子节点，不为美术偏移重建对象。

Game/UI 正式播放由程序控制。资源准备和预演不新增每帧强制播放、自动循环脚本或业务状态机，避免抢同一 AnimationState。

UI 默认单 CanvasRenderer 有单贴图限制；确为多页图集时检查 **Advanced → Multiple CanvasRenderers**，验证全身附件、遮罩与层级，不为检查重排图集。单页有 Add 时也可能需要多个 Renderer，见 [UI 混合路径](rendering.md#ui)。在本次 Mask/RectMask2D、CanvasGroup 与兄弟层级中实际观看，仅展示对象按需关闭 Raycast Target，避免挡点击。

<a id="bounds"></a>
## UI 边界与尺寸适配

用于 SkeletonGraphic 在滚动/遮罩中提前消失、RectTransform 不覆盖动作，或需要随容器等比适配。工程 4.1 的按钮和 Layout Scale Mode 已核对；不依赖新版 Detect。

### 可见范围检查

SkeletonGraphic 的 UI 可见性判断依赖 RectTransform 边界。网格还在遮罩内、矩形已完全离开时，RectMask2D 可能提前裁掉整个对象。扩大动画图集或关闭遮罩不是这个问题的默认处理。

1. 定位目标 SkeletonGraphic、实际 RectMask2D/Mask、父布局和受影响动作/皮肤。用 RectTransform 工具观察矩形与网格，比较刚进入、边缘和刚离开的滚动位置。
2. 记录当前位置、锚点、pivot、尺寸、Layout Scale Mode、referenceSize/referenceScale 与布局组件/曲线驱动的属性。保留已确认的画面大小与对齐。
3. 在可见且网格已更新的姿态，使用 Inspector **Match RectTransform with Mesh → Match**。4.1 方法是 `MatchRectTransformWithBounds()`，多 CanvasRenderer 时合并当前有效子网格的边界。该操作只匹配**当前姿态**，会修改尺寸、pivot 和参考边界，并可能更新分离子节点；不能当作全动画最大边界。
4. 观看动作中伸展最大的位置、相关皮肤和挂件。按实际网格范围调整包含这些姿态的稳定边界，检查偏移与枢轴；不要每帧重复 Match 或凭文件尺寸猜动画边界。
5. 重看原位置、大小与对齐，验证滚动两端、不同容器尺寸和遮罩穿越。仅边界修复仍可能改变布局占位/点击范围，确认相邻元素及 Raycast Target 的实际用途。已有曲线驱动同一属性时调整相应设计源，避免互相覆盖。

空网格时 Match 会返回失败，并可能设回小矩形默认值；先恢复可见姿态和有效网格，不把按钮调用完成视为修复通过。需要视觉比较才能确定的边界先在预演实例调整，验收后保存本次目标。

<a id="layout"></a>
## 容器变化时等比缩放

该功能以 SkeletonGraphic **自身 RectTransform 的当前尺寸**与参考边界计算比例；先让锚点/父布局正确传递容器尺寸。它不会自动把父容器尺寸拷到对象上。

| Layout Scale Mode | 适用目标 |
|---|---|
| None | 保持已有手工大小与缩放，不启用自动适配 |
| Width Controls Height | 以当前矩形宽度决定等比缩放 |
| Height Controls Width | 以当前矩形高度决定等比缩放 |
| Fit In Parent | 按参考边界等比完整放进当前矩形，可能留白 |
| Envelope Parent | 按参考边界等比覆盖当前矩形，可能超出/被遮罩裁切 |

1. 明确完整显示还是铺满、对齐点及参考画面；保持已确定模式，有新需求时选对应模式。
2. 模式非 None 时开启 **Edit Layout Bounds**，调整参考矩形与偏移；此模式下可用 Match，但仍仅匹配当前姿态。结合完整动作设定稳定参考边界，完成后关闭 Edit Layout Bounds。
3. 比较长宽不同的本次容器和动作最大伸展。匹配边界后 referenceSize/pivot 会改变，重新确认画面大小，不同时用整体 Transform 非等比缩放补偿。
4. 若离开 RectMask2D 后不更新，核对 **Update When Invisible**；若一直不播放，检查 **Freeze**、对象启用和时间源。按当前需求调整，普通 Mask/Canvas 本身不等同于 RectMask2D 的可见性检测。

交付记录目标对象、边界/参考尺寸、模式、对齐、实测容器和受影响布局/曲线。技术参数由助手整理，设计师确认大小与裁切观感。

仅在本次要求骨骼跟随或部件穿插时处理下节。这里准备挂点与显示顺序，粒子制作及正式业务触发交各自流程/程序，不为普通 Spine 生成整套骨骼层级。

<a id="attachments"></a>
## 骨骼挂点

1. 用实际 SkeletonData 的骨骼名定位挂点，记录期望位置、朝向、偏移、是否跟随骨骼缩放/角色翻转和参考动作。缺少骨骼需设计师补源工程，不凭命名猜手/头挂点。
2. Game 用 **BoneFollower**，绑定目标 SkeletonRenderer；UI 用 **BoneFollowerGraphic**，绑定 SkeletonGraphic。二者配置真实 Bone Name，不直接互换。
3. 优先用目标 Spine 对象下的独立跟随节点，效果放在其子节点上调美术偏移；Follower 自身的位置/旋转会被更新，偏移放子节点。已有跟随对象正确时复用，不重建业务根。
4. 按效果选择 Follow XY/Z Position、Follow Bone Rotation、Follow Skeleton Flip、Follow Local Scale/Parent World Scale。不要全部开启；Unity Transform 无法完整表达骨骼的错切/非均匀旋转缩放，出现变形时说明限制。
5. UI Follower 会使用 SkeletonGraphic.MeshScale，核对目标 Canvas、布局缩放和 pivot；跟随位置不保证粒子能在 Canvas 内正确渲染，UI 粒子仍需工程已有 UI Particle 路径。跨 Canvas/相机用途按实际空间核对。
6. 集中查看受影响动作、翻转、皮肤和本次 UI 尺寸，确认挂件位置、旋转、遮罩、绘制顺序和停止/重开。交付节点、骨骼名、跟随选项、子节点偏移及程序显隐/事件触发要求。

<a id="layering"></a>
## 外部对象插在骨骼部件之间

先看真实 Slot Draw Order 与外部对象的 Sorting/Canvas 顺序。Spine 内部 Slot 顺序与 Unity 外部对象排序是两层；修改整个角色的 Order 不能把物件插进一个未分离的网格。

| 位置 | 工程 4.1 做法 |
|---|---|
| Game | 设置 SkeletonRenderer 的 Separator Slot Names，并使用 **SkeletonRenderSeparator + SkeletonPartsRenderer** 拆分显示部分。组件 Inspector 可补缺失 Parts Renderer；有效分离点数通常需要至少点数+1 个 Renderer，保留已有部分。 |
| UI | SkeletonGraphic 开 **Multiple CanvasRenderers**，设置 **Separator Slot Names + Enable Separation**；会生成分离部分，不额外套 Game 的 SkeletonRenderSeparator。按实际 Canvas 层级把外部对象安排在部分之间。 |

1. 明确在哪个实际 Slot 边界插入，保留已调绘制顺序。需要改 Spine 内部层序时记录设计要求，不自动改全部动作的 Draw Order。
2. Game 在各 Parts Renderer 与外部对象上安排实际 Sorting Layer/Order；相同排序条件下还需核对相机透明排序。多页/多材质的错误穿插可评估 SortingGroup，但它会让子 Renderer 成组排序，有意让外部对象插入时不盲目添加。
3. UI 优先沿用本次 Canvas 与分离部分；调整层级时核对 Mask/RectMask2D、CanvasGroup、点击和布局继承。移动分离部分涉及 Update Part Location/Scale 时按所需空间设置，不把移出原父级当作无影响操作。
4. 看本次动画的 Draw Order 变化、附件显隐、皮肤、翻转及 Add，确认所有部分都渲染且外部对象始终处于正确位置。Renderer 不足先补必要部分，不用 Clear Parts Renderers 重建整套。
5. 交付真实分离 Slot、Parts 对象/顺序、外部对象位置及共享影响。拆分会增加 Renderer/批次，程序在目标设备验证；设计师验收穿插观感。

实现与官方依据见 [来源](sources.md)：SkeletonGraphic 的边界/布局、BoneFollower/BoneFollowerGraphic、SkeletonRenderSeparator 及 UI 分离配置。
