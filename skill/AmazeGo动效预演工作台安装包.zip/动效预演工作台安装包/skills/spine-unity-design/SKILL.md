---
name: spine-unity-design
description: >
  Use when 美术设计师在 ArrowsGo 中新增、导入或重导 Spine，检查资源、动画、皮肤、贴图、材质、引用，
  准备 Game/UI 资源与程序交付，或明确要求 Spine Timeline 编排。适用于 .skel.bytes 与既有 Spine JSON；
  纯 Unity Animation、粒子制作及正式业务播放接入另行处理。
---

# Spine 资源检查与交付

帮助设计师整理可交付的 Spine 资源。助手完成技术检查与可确定的局部修复，设计师确认画面；Game/UI 正式播放交程序。

## 默认流程

1. **准备资源**：按本次指定目录或工程现有约定归档/复用，检查后按每份骨骼身份生成/复用全部真实动画的 AnimationReferenceAssets。新增、重导与检查统一读取 [资源主流程](references/resources.md)，按扫描 → 计划 → 执行 → 验证处理。
2. **检查与修复**：核对文件/版本、动画/皮肤/事件、贴图/材质、融合和受影响引用。只读请求保持只读；处理资源的任务直接修复证据充分的本次问题，待定项继续记录。下表专项仅在涉及对应问题时读取。
3. **验收与交付**：按 [交付模板](assets/handoff-template.md) 给出实际资源、依赖、播放要求、更新差异与待验项；harness/批处理另按 [执行与结果约定](references/resources.md#execution) 输出结构化记录。资源查看可用 SkeletonDataAsset Preview，不要求先制作 Timeline 或录屏。

明确说“按 idle → play → perf 排到 Timeline”时，完成资源准备后再按真实动作引用编排，读取下表的 Timeline 流程。未要求编排时不自动创建 Timeline；没有真实动作或明确映射时不猜替代。

## 按问题读取参考

只加载本次需要的专项，已确认且未受影响的内容不反复检查。

| 本次问题 | 参考 |
|---|---|
| 材质替换、颜色/透明边缘、UI Add、淡出或真机异常交接 | [渲染与透明](references/rendering.md) |
| Game/UI 对象准备、UI 裁切/适配、挂点与部件穿插 | [Game/UI 对象与布局](references/game-ui.md) |
| 明确的 Timeline 编排，或本次资源影响已有预演 | [Timeline 预演](references/timeline.md) |

## 共同规则

- 复用正确的资产与对象；保护 `.meta`、引用、材质、大小、曲线及有方向的融合配对，保留有意的 0 秒覆盖。修改只限本次资源与已证明受其影响的使用者。
- 动画与身份以实际数据和可核实记录为准；修复条件见资源准备参考。仅举例或询问能力时不写入资源，未知映射与设计要求列待定，不阻塞独立工作。
- 区分“文件/引用检查通过”“画面已验收”“待程序验证”。无法 Unity 导入、生成或播放时说明未执行项；静态检查不等于画面或真机通过。

工程基线为 Spine **4.1**，官方方法与已核实实现见 [依据与版本](references/sources.md)，不自行升级插件。此 Skill 在助手接到任务时执行；自动匹配需安装到可发现目录，后台监听需另行配置。
