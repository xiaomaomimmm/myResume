# Spine 资源交付

复制到本次交付目录按实际资源范围填写，无关字段删去。以文件、数据、材质、更新与验收结果为主；没有预演时删除末尾预演节。未验证项明确标注，不写成默认通过。harness/批处理的固定字段见 [资源执行约定](../references/resources.md#execution)，本说明与 JSON 记录来自同一次结果，无需让设计师填写技术字段。

## 资源与对象

- SkeletonDataAsset：
- 实际导出文件组；源工程 / 导出预设位置（有则填写）：
- Atlas 全部页贴图、生成资产、材质及 Unity `.meta` 依赖清单：
- 每份 SkeletonDataAsset GUID 对应的 AnimationReferenceAssets 目录/清单与真实动画绑定；同目录同名隔离、全部动作是否齐全：
- 导出 / 运行库版本：
- Game Prefab / SkeletonAnimation 对象：
- UI Prefab / SkeletonGraphic 对象：
- 初始皮肤、显示状态、位置/尺寸与排序：
- 位置/位移由骨骼动画或程序对象控制；参考画面：
- 材质 / PMA 或 Straight Alpha / UI 特殊设置：

本次涉及尺寸、换材质或颜色问题时补充，无关项删去：

- UI RectTransform / 稳定边界与参考尺寸 / Layout Scale Mode / pivot 与对齐 / 已验容器尺寸：
- 材质绑定入口；原材质或原贴图 → 替换材质；指定 Slot / 页覆盖（有则列出）：
- 工程 Color Space / 贴图 sRGB、Alpha Is Transparency / 材质 Straight Alpha Texture；颜色与透明边缘对照：

包含 UI Add 光效时补充：

- Additive Slot、Normal / Additive UI 材质及实际 Shader：
- Apply Additive Material / Multiple CanvasRenderers / PMA Vertex Colors：
- 每份材质的 CanvasGroup Compatible / Straight Alpha Texture / Alpha Clip：
- 实际透明度控制：CanvasGroup / Graphic Color / 骨骼 Alpha；叠加控制说明：
- Alpha 1 / 0.5 / 0、遮罩与光效顺序的画面对照：
- 逐部件透明或整张图片式淡出的预期；合成方案、成本与程序待验项（需要时）：
- SVC / AssetBundle 变体和资源依赖的程序待核对项：

## 动作播放

| 实际动画名 | 画面用途 / 程序触发条件 | 原始时长 | 单次 / 循环 | 倍速 / 动画内偏移 | 播完后状态 | 重复触发 / 被打断的表现 |
|---|---|---|---|---|---|---|
| | | | | | | |

业务触发未确定时写“由程序确认”，不把 Timeline 秒数当作正式业务触发条件。

- 需要的皮肤与初始皮肤；界面关闭再打开或对象复用的初态：

## 事件与关键时刻

有事件或需要程序同步的时刻才填写，无关时删除本节。时间为动画内时间，另有 Timeline 编排时分别标注。

| 所属动画 | 事件名 / 关键时刻 | 动画内时间（秒） | 参数（有则填写） | 画面用途 / 程序同步要求 | 接入状态 |
|---|---|---|---|---|---|
| | | | | | |

## 融合

- SkeletonDataAsset Default Mix Duration：
- Custom Mix Durations：按 From → To → 秒数列本次实际配对，包括 0 秒。
- 需保留的观感或例外：

## 挂点与分层（使用时保留）

- BoneFollower / BoneFollowerGraphic 对象、真实骨骼名、跟随选项与子节点偏移：
- UI Particle 接入路径或程序待接要求（有则填写）：
- 分离 Slot、Parts 对象、外部对象及 Sorting / Canvas 顺序：
- 动作/皮肤/翻转/尺寸变化与遮罩对照；Renderer/批次成本待程序验证：

## 新增 / 重导与修复

- 本次文件组、对象及使用位置；更新前基线来源（无则写明）：
- 动画 / 皮肤 / 事件新增、删除或改名；明确映射（无则写“未取得”）：
- 已修复：实际问题、映射依据和变更文件 / 对象：
- 修复后引用重读、保护的融合 / 曲线 / 材质 / `.meta`：
- 需设计确定：
- 待程序验证：

## 验证

- 资源静态检查：
- 实际动画/皮肤查看，附件、循环接缝与透明边缘：
- 实际正播的融合、循环/结束（未观看写“待验收”）：
- 本次相关 Game/UI 画面、皮肤、材质、遮罩：
- UI Add 光效包体 / AssetBundle / 真机验证（未经实测写“待程序验证”）：
- 设计师表现验收：
- 未验证 / 待程序确认：

交付实际依赖资源及 Unity `.meta`，避免只给录屏或仅给 Timeline。

## 可选：预演（实际使用时填写）

- 场景 / Timeline / 播放入口 / 效果参考：
- 轨道对象与实际 AnimationReferenceAsset：
- 关键时间点、Loop、Speed Multiplier、Clip In：
- 是否沿用资源 Default Mix Duration；片段级覆盖（没有写“无”）：
- Director 时间源 / Spine 轨道 Unscaled Time；游戏时间暂停与 Director 暂停/恢复结果（涉及暂停时）：
- 暂停、片段末尾、Timeline 末尾及隐藏/回待机/保持规则：
- 多轨实际 Track Index / Alpha 动画权重 / Hold Previous / 叠加结束恢复（有则填写）：
- 翻转轨道 Handle / Flip X、Y / 片段范围 / 停止重播恢复（有则填写）：
- 特殊融合要求及实现限制（有则填写；Spine 片段 Ease Out、Blend Curves 不控制动作融合）：
- 预演专用设置与正式播放的区别：
- 编辑态正拖 / 倒拖 / 跳帧 / 回零，以及 Play Mode 正播结果：
