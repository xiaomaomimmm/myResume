"""Version-bound delivery decisions. Does not inspect Unity or invent visual approval."""
import hashlib
import json
from pathlib import Path

LEVELS = {'none': 0, 'static': 1, 'data_load': 2, 'unity_load': 3, 'visual': 4, 'device': 5}
UNITY_FILES = {'.prefab', '.anim', '.asset', '.controller', '.overridecontroller', '.mat'}
LABELS = {'not_requested':'本次未要求正式交付', 'draft':'待补交付清单', 'needs_fix':'有问题需修正',
    'pending_checks':'待完成检查', 'needs_design':'待你确认效果', 'ready_for_programmer':'可以交程序'}


def require(condition, message):
    if not condition:
        raise ValueError('delivery: '+message)


def hash_value(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()


def preview_path(path):
    return Path(path).suffix.lower() in {'.playable', '.unity'}


def validate_plan(task, plan):
    require(isinstance(plan,dict) and type(plan.get('schema_version')) is int and plan['schema_version']==1, 'unsupported plan version')
    targets={t['target_id']:t for t in task['targets']}
    stages={s['id']:s for s in task['stages']}
    require(type(plan.get('visual_required')) is bool and type(plan.get('designer_confirmation')) is bool, 'declare visual and designer requirements')
    require(not plan['designer_confirmation'] or plan['visual_required'], 'designer approval needs a visual review requirement')
    require(isinstance(plan.get('usage'),str) and plan['usage'].strip(), 'play/use instructions missing')
    assets=plan.get('assets')
    require(isinstance(assets,list) and assets, 'explicit formal resources and dependencies required')
    seen=set()
    for asset in assets:
        require(isinstance(asset,dict) and asset.get('target_id') in targets, 'asset must be a tracked target')
        require(asset['target_id'] not in seen, 'duplicate delivery asset')
        seen.add(asset['target_id'])
        require(asset.get('role') in {'formal','dependency'} and type(asset.get('playback')) is bool, 'asset role/playback requirement missing')
        require(isinstance(asset.get('label'),str) and asset['label'].strip(), 'asset needs a readable label')
        path=Path(targets[asset['target_id']]['path'])
        project=Path(task['project_root']).resolve()
        require(project in path.parents, 'delivery resources must belong to this project')
        if asset['role']=='formal':
            require(project/'Assets' in path.parents, 'formal resources must be saved under Assets')
        require(not path.is_dir() and not preview_path(path), 'list individual resources; Timeline and preview scenes cannot be delivered')
        for report in task['reports']:
            for item in report['artifacts']:
                p=Path(item['path'])
                p=(p if p.is_absolute() else Path(task['project_root'])/p).resolve()
                require(p!=path or item['role']!='internal_preview', 'preview drivers cannot be delivered')
    require(any(a['role']=='formal' for a in assets), 'no formal resource selected')
    checks=plan.get('required_checks')
    require(isinstance(checks,list) and checks, 'required checks must be declared before evaluating')
    keys=set()
    for check in checks:
        require(isinstance(check,dict) and check.get('stage_id') in stages and check.get('target_id') in seen, 'requirement stage/target unknown')
        require(check['target_id'] in stages[check['stage_id']]['target_ids'], 'requirement target is outside its stage')
        require(isinstance(check.get('check_id'),str) and check['check_id'].strip(), 'requirement check ID missing')
        require(check.get('purpose') in {'resource','independence','playback','visual','dependencies'}, 'unknown check purpose')
        require(check.get('min_level') in LEVELS and check['min_level']!='none', 'minimum evidence level missing')
        require(isinstance(check.get('label'),str) and check['label'].strip(), 'check needs a readable label')
        key=(check['stage_id'],check['check_id'],check['target_id'])
        require(key not in keys,'duplicate requirement')
        keys.add(key)
        if check['purpose']=='visual':
            require(LEVELS[check['min_level']]>=LEVELS['visual'],'visual review needs visual evidence')
        if check['purpose']=='playback':
            require(LEVELS[check['min_level']]>=LEVELS['unity_load'],'playback needs real player evidence')
    for asset in assets:
        path=Path(targets[asset['target_id']]['path'])
        selected=[c for c in checks if c['target_id']==asset['target_id']]
        resource=[c for c in selected if c['purpose']=='resource']
        minimum='unity_load' if path.suffix.lower() in UNITY_FILES else 'static'
        require(resource and any(LEVELS[c['min_level']]>=LEVELS[minimum] for c in resource),'resource load check missing or too weak')
        if asset['role']=='formal' and path.suffix.lower() in UNITY_FILES:
            require(any(c['purpose']=='independence' for c in selected),'independent-use check missing')
            require(any(c['purpose']=='dependencies' and LEVELS[c['min_level']]>=LEVELS['unity_load'] for c in selected),'saved dependency inventory missing')
        if asset['playback']:
            require(any(c['purpose']=='playback' for c in selected),'actual playback check missing')
        if asset['role']=='formal' and plan['visual_required']:
            require(any(c['purpose']=='visual' for c in selected),'visual check missing')
    require(isinstance(plan.get('previews'),list),'preview entries must be a list')
    for item in plan['previews']:
        require(isinstance(item,dict) and isinstance(item.get('path'),str) and item['path'].strip()
            and isinstance(item.get('label'),str) and item['label'].strip(),'preview path/label missing')


def validate_delivery(task):
    delivery=task.get('delivery')
    if delivery is None:
        return
    require(isinstance(delivery,dict) and isinstance(delivery.get('approvals'),list),'invalid stored delivery')
    validate_plan(task,delivery['plan'])
    for approval in delivery['approvals']:
        require(approval.get('decision') in {'approve','reject'} and isinstance(approval.get('evidence'),str)
            and approval['evidence'].strip() and isinstance(approval.get('version'),str) and isinstance(approval.get('time'),str), 'invalid designer decision record')


def version(task, data):
    plan=task['delivery']['plan']
    selected={a['target_id'] for a in plan['assets']}
    stages={c['stage_id'] for c in plan['required_checks']}
    fields=('stage_id','id','target_ids','effective_status','freshness','scope','required','level','evidence','dependency_paths')
    checks=[{k:c.get(k) for k in fields} for c in data['checks'] if c['stage_id'] in stages
        and c['scope']!='programmer_integration' and c['required'] is not False
        and (not c['target_ids'] or selected.intersection(c['target_ids']))]
    previews=[]
    for item in plan['previews']:
        path=Path(item['path'])
        if '://' not in item['path']:
            path=(path if path.is_absolute() else Path(task['project_root'])/path).resolve()
            previews.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None})
    return hash_value({'plan':plan,'files':{i:data['current_versions'][i]['files'] for i in sorted(selected)},
        'checks':sorted(checks,key=hash_value),'previews':previews})


def evaluate(task, data):
    if not task.get('delivery'):
        return {'status':'draft' if task['formal_delivery'] else 'not_requested','readiness_status':'draft',
            'issues':['还没有本次交付清单。'],'assets':[],'previews':[],'designer_approved':False,'programmer_status':'unknown'}
    validate_delivery(task)
    plan=task['delivery']['plan']
    targets={t['target_id']:t for t in task['targets']}
    selected={a['target_id'] for a in plan['assets']}
    issues=[]
    has_failure=False
    def issue(text,failed=False):
        nonlocal has_failure
        if text not in issues:
            issues.append(text)
        has_failure=has_failure or failed
    assets=[]
    for item in plan['assets']:
        path=Path(targets[item['target_id']]['path'])
        assets.append({**item,'path':str(path)})
        files=data['current_versions'][item['target_id']]['files']
        if not path.is_file() or any(f['sha256'] is None for f in files):
            issue(item['label']+'：文件或资源标识缺失。',True)
    relevant_stages={c['stage_id'] for c in plan['required_checks']}
    for stage in task['stages']:
        stage_checks=[c for c in data['checks'] if c['stage_id']==stage['id']]
        program_only=stage_checks and all(c['scope']=='programmer_integration' for c in stage_checks)
        if selected.intersection(stage['target_ids']) and not program_only and stage['status']!='skipped':
            relevant_stages.add(stage['id'])
    for stage in task['stages']:
        if stage['id'] in relevant_stages and stage['status']!='completed':
            issue('制作步骤尚未完成：'+(stage['next_action'] or stage['detail'] or '继续本次制作。'))
    covered=set()
    for requirement in plan['required_checks']:
        key=(requirement['stage_id'],requirement['check_id'],requirement['target_id'])
        covered.add(key)
        found=[c for c in data['checks'] if c['stage_id']==key[0] and c['id']==key[1] and key[2] in c['target_ids']]
        if not found:
            issue(requirement['label']+'：缺少检查结果。')
            continue
        for check in found:
            if check['scope']!='resource_delivery' or check['required'] is not True:
                issue(requirement['label']+'：检查用途或必要性还未明确。')
            elif check['freshness']!='current':
                issue(requirement['label']+'：资源已变化或检查未关联本版，需要重验。')
            elif check['effective_status']!='passed':
                issue(requirement['label']+'：'+(check['next_action'] or check['detail']),check['effective_status']=='failed')
            elif LEVELS[check['level']]<LEVELS[requirement['min_level']]:
                issue(requirement['label']+'：还缺实际检查，现有证据不足。')
            elif requirement['purpose']=='dependencies':
                paths=check.get('dependency_paths')
                if paths is None:
                    issue(requirement['label']+'：还没有保存实际依赖清单。')
                else:
                    delivered={Path(a['path']).resolve() for a in assets}
                    for value in paths:
                        path=Path(value)
                        path=(path if path.is_absolute() else Path(task['project_root'])/path).resolve()
                        if path not in delivered:
                            issue('必要依赖尚未列入交付清单：'+path.name+'。')
    for check in data['checks']:
        if check['stage_id'] not in relevant_stages or check['scope']=='programmer_integration' or check['required'] is False:
            continue
        if not check['target_ids'] or selected.intersection(check['target_ids']):
            if check['scope'] is None or check['required'] is None:
                issue('还有专项检查未明确用途或必要性。')
            elif check['freshness']!='current' or check['effective_status']!='passed':
                # Required specialist checks remain blockers even if omitted from the plan.
                if not any((check['stage_id'],check['id'],i) in covered for i in check['target_ids']):
                    issue('专项检查待处理：'+(check['next_action'] or check['detail']),check['effective_status']=='failed')
    current_version=version(task,data)
    approvals=task['delivery']['approvals']
    latest=approvals[-1] if approvals else None
    approved=bool(latest and latest['decision']=='approve' and latest['version']==current_version)
    rejected=bool(latest and latest['decision']=='reject')
    status='needs_fix' if has_failure else ('pending_checks' if issues else
        ('needs_design' if rejected or (plan['designer_confirmation'] and not approved) else 'ready_for_programmer'))
    if status=='needs_design':
        issues.append('请查看本版效果并确认；需要调整时直接说明。')
    programmer=[c for c in data['checks'] if c['scope']=='programmer_integration' and c['required'] is not False
        and (not c['target_ids'] or selected.intersection(c['target_ids']))]
    programmer_status='completed' if programmer and all(c['required'] is True and c['freshness']=='current'
        and c['effective_status']=='passed' for c in programmer) else 'pending'
    return {'status':status if task['formal_delivery'] else 'not_requested','readiness_status':status,
        'issues':issues,'assets':assets,'previews':plan['previews'],'usage':plan['usage'],
        'designer_approved':approved,'programmer_status':programmer_status,'version':current_version,
        'resource_checks_passed':not has_failure and status in {'needs_design','ready_for_programmer'}}


def render_card(title,result):
    lines=['# '+title+' · 交付卡','','**'+LABELS[result['status']]+'**','']
    if result['status']=='not_requested' and result['readiness_status']!='draft':
        lines+=['本次试评估：'+LABELS[result['readiness_status']]+'。','']
    for role,label in [('formal','正式资源' if result['status']=='ready_for_programmer' else '本次资源'),('dependency','必要依赖')]:
        entries=[a for a in result['assets'] if a['role']==role]
        if entries:
            lines+=['## '+label,'']
            lines += ['- ['+a['label']+'](<'+a['path']+'>)' for a in entries]
            lines+=['']
    if result.get('usage'):
        lines+=['## 使用说明','',result['usage'],'']
    if result['previews']:
        lines+=['## 内部预演','']
        lines+=['- ['+p['label']+'](<'+p['path']+'>)' for p in result['previews']]
        lines+=['']
    if result['issues']:
        lines+=['## 下一步','']+['- '+x for x in result['issues']]+['']
    lines+=['程序接入：'+('相关检查已通过。' if result['programmer_status']=='completed' else '由程序按播放说明接入，进度单独记录。'), '']
    return '\n'.join(lines)
