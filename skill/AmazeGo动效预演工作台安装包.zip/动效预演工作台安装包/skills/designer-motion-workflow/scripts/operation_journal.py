#!/usr/bin/env python3
"""Guard Unity mutations with durable checkpoints; never rewrites or rolls back assets."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import uuid

from task_record import load, find_stage, canonical, capture, digest, json_bytes, atomic_write, output_guard, require, now, normalize
from execution_receipt import extract


def spec_for(raw, project):
    require(isinstance(raw, dict) and raw.get('mode') in {'create', 'update'}, 'spec needs explicit create/update mode')
    require(isinstance(raw.get('parameters'), dict), 'spec needs the actual operation parameters')
    result = {'mode': raw['mode'], 'parameters': raw['parameters']}
    for key in ('inputs', 'outputs', 'protected'):
        values = raw.get(key, [])
        require(isinstance(values, list) and all(isinstance(v, str) and v for v in values), 'invalid ' + key)
        result[key] = sorted(set(str(canonical(v, project)) for v in values))
    require(result['outputs'], 'spec needs explicit output targets')
    assets = Path(project) / 'Assets'
    require(all(assets in Path(p).parents for p in result['outputs']), 'Unity outputs must be inside project Assets')
    require(not any(Path(a) == Path(b) or Path(a) in Path(b).parents or Path(b) in Path(a).parents
                    for a in result['outputs'] for b in result['protected']), 'protected paths cannot overlap outputs')
    ids = raw.get('verification_ids')
    require(isinstance(ids, list) and ids and all(isinstance(v, str) and v for v in ids), 'spec needs actual verification check IDs')
    result['verification_ids'] = sorted(set(ids))
    return result


def snapshot(project, paths):
    targets = [{'target_id': str(i), 'path': p} for i, p in enumerate(sorted(set(paths)))]
    return capture({'project_root': project, 'targets': targets}, {'id': 'operation', 'target_ids': [t['target_id'] for t in targets]})


def current(record):
    spec = record['spec']
    return snapshot(record['project_root'], spec['inputs'] + spec['outputs'] + spec['protected'])


def protected_ok(record):
    paths = record['spec']['inputs'] + record['spec']['protected']
    return snapshot(record['project_root'], paths)['files'] == record['protected_before']['files']


def decision(record):
    for receipt in record['receipts']:
        path = Path(receipt['path'])
        require(path.is_file() and digest(path.read_bytes()) == receipt['sha256'], 'receipt integrity mismatch; inspect the archive')
    actual = current(record)
    if record['after'] is not None:
        if actual['files'] != record['after']['files'] or not protected_ok(record):
            return 'conflict'
        if record['state'] == 'verified':
            return 'reuse'
        return 'verify_only'
    if record['state'] in {'running', 'failed', 'uncertain'}:
        return 'inspect_interruption'
    if any(not Path(p).exists() for p in record['spec']['inputs']):
        return 'blocked'
    if record['spec']['mode'] == 'create' and any(Path(p).exists() for p in record['spec']['outputs']):
        return 'verify_existing'
    return 'execute'


def payload(response):
    if isinstance(response.get('structuredContent'), dict):
        response = response['structuredContent']
    elif isinstance(response.get('content'), list):
        texts = [c['text'] for c in response['content'] if c.get('type') == 'text']
        require(len(texts) == 1, 'expected structured tool receipt')
        response = json.loads(texts[0])
    require(response.get('success') is True and not response.get('error'), 'tool receipt did not succeed')
    data = response.get('data')
    require(isinstance(data, dict) and data, 'empty success cannot mark applied')
    require(data.get('success') is not False and not data.get('error'), 'nested tool failure')
    return data


def verify_receipt(record, response):
    report = extract(response)
    require(report.get('skill') == record['skill'], 'verification belongs to another specialist')
    require(str(Path(report['project_root']).resolve()) == record['project_root'], 'verification belongs to another project')
    date = datetime.fromisoformat(report['created_at'].replace('Z', '+00:00'))
    require(date >= datetime.fromisoformat(record['started_at']), 'historical report cannot establish this checkpoint')
    checks, _, _ = normalize(report, record['skill'])
    for check_id in record['spec']['verification_ids']:
        found = [c for c in checks if c['id'] == check_id]
        require(found and all(c['status'] == 'passed' for c in found), 'required checkpoint check did not pass: ' + check_id)
    observed = {f['path']: f['sha256'] for f in current(record)['files']}
    hashes = [o for o in report.get('observations', []) if o.get('path') and o.get('sha256')]
    require(hashes, 'verification needs saved output version evidence')
    for item in hashes:
        path = str(canonical(item['path'], record['project_root']))
        require(path in observed and observed[path] == item['sha256'], 'verification hash differs from current output')
    require(all(Path(p).exists() for p in record['spec']['outputs']), 'verified outputs missing')


def idle_verified(path, project):
    receipt = json.loads(Path(path).read_text())
    info = receipt['project_info']
    state = receipt['editor_state']
    require(info.get('success') is True and state.get('success') is True, 'idle/project query failed')
    require(str(Path(info['data']['projectRoot']).resolve()) == project, 'idle evidence is from another project')
    data = state['data']
    age = datetime.now(timezone.utc).timestamp() * 1000 - data['observed_at_unix_ms']
    play = data['editor']['play_mode']
    require(-5000 <= age <= 60000 and data['advice']['ready_for_tools'] is True and data['activity']['phase'] == 'idle'
            and play['is_playing'] is False and play['is_changing'] is False, 'need fresh idle Unity evidence before recovering a write lease')


def render(folder):
    labels = {'execute': '可执行本次写入', 'reuse': '复用，跳过写入', 'verify_only': '只补回读验证',
        'verify_existing': '已有资源，先核验再复用', 'inspect_interruption': '执行结果不明，先查现场',
        'conflict': '版本或参数变化，保留手调并重新判断', 'blocked': '缺输入，先补齐'}
    lines = ['# 重复执行与恢复记录', '', '| 操作 | 阶段 | 检查点 | 当前下一步 | 最近原因 |', '|---|---|---|---|---|']
    for path in sorted((folder / 'operations').glob('*.json')):
        r = json.loads(path.read_text())
        values = [r['operation'], r['stage_id'], r['state'], labels[decision(r)], r.get('reason', '')]
        lines.append('| ' + ' | '.join(str(v).replace('|', '\\|').replace('\n', ' ') for v in values) + ' |')
    lines += ['', '只读取已指定的文件与 .meta。未知部分写入先核验，不盲目重做、不回滚用户资源；具体制作、播放与观感仍按专项验证。', '']
    atomic_write(folder / 'recovery.md', '\n'.join(lines).encode('utf-8'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['begin', 'checkpoint', 'fail', 'recover', 'status'])
    for name in ('task', 'stage', 'operation'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--spec')
    parser.add_argument('--phase', choices=['applied', 'verified'])
    parser.add_argument('--token')
    parser.add_argument('--receipt')
    parser.add_argument('--reason')
    parser.add_argument('--idle-receipt')
    args = parser.parse_args()
    guard = None
    try:
        task_path = Path(args.task).resolve()
        task = load(task_path)
        stage = find_stage(task, args.stage)
        project = task['project_root']
        folder = task_path.parent
        record_path = folder / 'operations' / (digest((args.stage + ':' + args.operation).encode()) + '.json')
        lock_root = Path(project).parent / '.local/reports/designer-motion-workflow'
        output_guard(lock_root, project)
        lock_root.mkdir(parents=True, exist_ok=True)
        project_id = digest(project.encode())[:16]
        lease_path = lock_root / ('unity-write-' + project_id + '.json')
        guard = lock_root / ('journal-guard-' + project_id + '.json')
        if guard.exists():
            owner = json.loads(guard.read_text())
            require(owner.get('project_root') == project and type(owner.get('pid')) is int, 'unknown journal guard; do not remove it')
            try:
                os.kill(owner['pid'], 0)
            except ProcessLookupError:
                guard.unlink()  # Short Python transaction only; never clears the Unity write lease.
            else:
                raise ValueError('another journal transaction is active')
        with guard.open('x', encoding='utf-8') as stream:
            json.dump({'project_root': project, 'pid': os.getpid()}, stream)
        owns_guard = True
        record = json.loads(record_path.read_text()) if record_path.is_file() else None
        lease = json.loads(lease_path.read_text()) if lease_path.is_file() else None
        if args.command == 'begin':
            require(args.spec, 'begin requires an AI-prepared operation spec')
            spec = spec_for(json.loads(Path(args.spec).read_text()), project)
            intent = digest(json_bytes(spec))
            if record and record['intent_id'] != intent:
                return print_result(record, record_path, 'conflict')
            if lease and lease['record_path'] != str(record_path):
                return print_result(record, record_path, 'busy')
            if record is None:
                record = {'schema_version': 1, 'task_id': task['task_id'], 'project_root': project, 'stage_id': args.stage,
                    'skill': stage['skill'], 'operation': args.operation, 'spec': spec, 'intent_id': intent,
                    'state': 'planned', 'started_at': now(), 'after': None, 'token': None, 'reason': '', 'receipts': [], 'events': []}
                record['before'] = current(record)
                record['protected_before'] = snapshot(project, spec['inputs'] + spec['protected'])
            choice = decision(record)
            if choice == 'execute':
                require(not lease, 'write lease already exists')
                require(all(find_stage(task, p)['status'] == 'completed' for p in stage['depends_on']), 'upstream action is not complete')
                # Baseline is captured immediately before the first mutation.
                record['before'] = current(record)
                record['protected_before'] = snapshot(project, spec['inputs'] + spec['protected'])
                record['state'], record['token'], record['started_at'] = 'running', uuid.uuid4().hex, now()
                atomic_write(record_path, json_bytes(record))
                with lease_path.open('x', encoding='utf-8') as stream:
                    json.dump({'record_path': str(record_path), 'token': record['token'], 'task_id': task['task_id']}, stream)
            elif record['state'] == 'planned':
                atomic_write(record_path, json_bytes(record))
        else:
            require(record is not None and record['task_id'] == task['task_id'], 'operation checkpoint not found')
            choice = decision(record)
            if args.command == 'checkpoint':
                require(args.phase and args.receipt, 'checkpoint needs phase and real tool receipt')
                if lease:
                    require(lease['record_path'] == str(record_path), 'another operation owns the Unity write lease')
                content = Path(args.receipt).read_bytes()
                response = json.loads(content)
                require(protected_ok(record), 'input/protected resource changed; preserve it and reassess')
                if args.phase == 'applied':
                    require(record['state'] == 'running' and lease and args.token == record['token'] == lease['token'], 'applied needs the owning write token')
                    payload(response)
                    require(all(Path(p).exists() for p in record['spec']['outputs']), 'saved outputs missing')
                    record['after'], record['state'] = current(record), 'applied'
                else:
                    require(record['state'] in {'planned', 'applied'}, 'uncertain execution must be inspected before a verified checkpoint')
                    baseline = record['after'] or record['before']
                    require(current(record)['files'] == baseline['files'], 'resource changed after checkpoint; do not overwrite manual edits')
                    verify_receipt(record, response)
                    record['after'], record['state'] = current(record), 'verified'
                archive = folder / 'operation-receipts' / (digest(content) + '.json')
                if not archive.exists():
                    atomic_write(archive, content)
                record['receipts'].append({'phase': args.phase, 'path': str(archive), 'sha256': digest(content)})
                record['events'].append({'time': now(), 'event': args.phase})
                atomic_write(record_path, json_bytes(record))
                if lease and lease['record_path'] == str(record_path):
                    lease_path.unlink()
                choice = decision(record)
            elif args.command == 'fail':
                require(args.reason and args.reason.strip(), 'failure needs a concrete reason')
                require(record['state'] != 'verified', 'verified work cannot be failed without a new operation')
                record['state'], record['reason'] = 'failed', args.reason
                record['events'].append({'time': now(), 'event': 'failed', 'reason': args.reason})
                atomic_write(record_path, json_bytes(record))
                choice = decision(record)
            elif args.command == 'recover':
                require(args.idle_receipt, 'recovery requires actual current editor/project queries')
                idle_verified(args.idle_receipt, project)
                if lease:
                    require(lease['record_path'] == str(record_path) and lease['token'] == record['token'], 'never release another operation lease')
                    lease_path.unlink()
                if record['state'] in {'running', 'failed'}:
                    record['state'] = 'applied' if record['after'] is not None else 'uncertain'
                record['events'].append({'time': now(), 'event': 'recovered', 'decision': decision(record)})
                atomic_write(record_path, json_bytes(record))
                choice = decision(record)
        render(folder)
        return print_result(record, record_path, choice)
    except (ValueError, OSError, TypeError, KeyError) as error:
        print('operation_journal: ' + str(error), file=sys.stderr)
        return 2
    finally:
        if guard is not None and locals().get('owns_guard') and guard.exists():
            guard.unlink()


def print_result(record, path, choice):
    print(json.dumps({'decision': choice, 'state': record['state'] if record else 'not_started',
        'token': record['token'] if record else None, 'operation_file': str(path),
        'recovery_file': str(path.parent.parent / 'recovery.md')}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
