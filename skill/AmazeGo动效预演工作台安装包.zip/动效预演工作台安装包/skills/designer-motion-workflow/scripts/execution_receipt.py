#!/usr/bin/env python3
"""Extract a real Unity tool report; empty success and nested failures are rejected."""
import argparse
import json
from pathlib import Path
import sys


def extract(response):
    if not isinstance(response, dict) or response.get('isError'):
        raise ValueError('tool response is not a successful object')
    if isinstance(response.get('structuredContent'), dict):
        response = response['structuredContent']
    elif isinstance(response.get('content'), list):
        texts = [c['text'] for c in response['content'] if c.get('type') == 'text']
        if len(texts) != 1:
            raise ValueError('expected one structured JSON tool response')
        response = json.loads(texts[0])
    success_seen = False
    for _ in range(8):
        if not isinstance(response, dict) or response.get('success') is False or response.get('error'):
            raise ValueError('failed or empty tool payload')
        success_seen = success_seen or response.get('success') is True
        report = response.get('report')
        if success_seen and isinstance(report, dict) and isinstance(report.get('skill'), str) and report.get('checks'):
            return report
        response = response.get('data')
    raise ValueError('successful tool response did not contain a nonempty report')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--response', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    try:
        from task_record import normalize, output_guard, atomic_write, json_bytes
        report = extract(json.loads(Path(args.response).read_text(encoding='utf-8')))
        normalize(report, report['skill'])
        if not report.get('project_root') or not report.get('created_at'):
            raise ValueError('report needs actual project_root and execution time')
        output_guard(args.out, report['project_root'])
        if Path(args.response).resolve() == Path(args.out).resolve():
            raise ValueError('preserve the original response; use a separate report path')
        atomic_write(args.out, json_bytes(report))
        print(json.dumps({'report_file': str(Path(args.out).resolve()), 'skill': report['skill'], 'checks': len(report['checks'])}))
    except (ValueError, OSError, TypeError, KeyError) as error:
        print('execution_receipt: ' + str(error), file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
