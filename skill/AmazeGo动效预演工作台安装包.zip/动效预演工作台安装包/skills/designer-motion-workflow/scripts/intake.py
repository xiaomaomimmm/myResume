#!/usr/bin/env python3
"""Discover explicitly submitted motion jobs; never modifies Unity assets."""
import argparse
from contextlib import contextmanager
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import uuid
import task_record as records

REPO=Path(__file__).resolve().parents[4]

@contextmanager
def transaction(path):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as stream:
        if os.name=='nt':
            import msvcrt
            if path.stat().st_size==0:stream.write(b'0');stream.flush()
            stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:yield
        finally:
            if os.name=='nt':stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(stream,fcntl.LOCK_UN)

def files(folder):
    return sorted(p for p in folder.rglob('*') if p.is_file() and p.name not in {'开始.txt','结果.md'}
        and not any(part.startswith('.') for part in p.relative_to(folder).parts))

def inspect(folder,settle):
    marker=folder/'开始.txt';brief=folder/'需求.md'
    if not marker.is_file():return None,None
    if marker.is_symlink() or not brief.is_file():return None,'请放入需求.md，再提交开始.txt。'
    brief_bytes=brief.read_bytes();content=brief_bytes.decode('utf-8').strip()
    if not content or '请填写' in content or '待填写' in content:return None,'需求还没有填写完整。'
    before=files(folder);rows=[];latest=0
    for path in before:
        if path.is_symlink():return None,'素材链接不能用于自动开工；请复制文件或在需求中注明真实位置。'
        first=path.stat();latest=max(latest,first.st_mtime_ns)
        if first.st_size==0:return None,'还有空文件，请等素材复制完成。'
        sha=hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda:stream.read(1024*1024),b''):sha.update(chunk)
        last=path.stat()
        if (first.st_size,first.st_mtime_ns)!=(last.st_size,last.st_mtime_ns):return None,None
        rows.append({'path':str(path.relative_to(folder)),'sha256':sha.hexdigest()})
    signal=marker.stat().st_mtime_ns
    if files(folder)!=before:return None,None
    if next(r['sha256'] for r in rows if r['path']=='需求.md')!=hashlib.sha256(brief_bytes).hexdigest():return None,None
    if latest>signal:return None,'资料仍在更新；复制完成后请再次保存开始.txt。'
    if time.time_ns()-max(latest,signal)<settle*1000000000:return None,None
    return {'input_version':records.digest(records.json_bytes(rows)),'files':rows,'request':content,'signal':signal},None

def item(entry):
    result={k:entry[k] for k in ('job_id','folder','task_file','token','input_version','reason','retry_when') if k in entry}
    if entry.get('task_file') and entry.get('input_version'):
        result['request_file']=str(Path(entry['task_file']).parent/'intake'/entry['input_version']/'需求.md')
    return result

def safe_inspect(folder,settle):
    try:return inspect(folder,settle)
    except (OSError,ValueError):return None,'需求或素材暂时无法读取，请检查文件。'

def notice(state,entry,reason):
    signature=records.digest(records.json_bytes({'status':entry.get('status'),'version':entry.get('input_version'),'reason':reason}))
    if entry.get('last_notice')==signature:return None
    entry['last_notice']=signature
    return {**item(entry),'title':Path(entry['folder']).name,'reason':reason}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['scan','claim','check','finish'])
    p.add_argument('--inbox',default=str(REPO/'动效任务/待处理'))
    p.add_argument('--project-root',default=str(REPO/'arrowgo-unity'))
    p.add_argument('--store')
    p.add_argument('--settle-seconds',type=int,default=60)
    p.add_argument('--job');p.add_argument('--token');p.add_argument('--resume-reason')
    p.add_argument('--user-message');p.add_argument('--source-reference')
    p.add_argument('--result',choices=['completed','blocked']);p.add_argument('--reason');p.add_argument('--evidence')
    p.add_argument('--retry-when',choices=['manual','tool'],default='manual')
    args=p.parse_args()
    try:
        project=Path(args.project_root).resolve();inbox=Path(args.inbox).resolve()
        store=Path(args.store).resolve() if args.store else project.parent/'.local/reports/designer-motion-workflow/intake'
        records.require((project/'Assets').is_dir(),'project must contain Assets')
        records.output_guard(inbox,project);records.output_guard(store,project)
        records.require(inbox!=store and inbox not in store.parents and store not in inbox.parents,'keep intake state outside submissions')
        records.require(args.settle_seconds>=0,'settling interval cannot be negative')
        state_file=store/'queue.json'
        with transaction(store/'.queue.lock'):
            state=json.loads(state_file.read_text()) if state_file.exists() else {'schema_version':1,'inbox':str(inbox),'project_root':str(project),'jobs':{}}
            records.require(state.get('schema_version')==1 and state['inbox']==str(inbox) and state['project_root']==str(project),'queue belongs to another project/inbox')
            jobs=state['jobs']
            if args.command=='scan':
                result={'ready':[],'resume':[],'recheck':[],'attention':[]}
                for folder in sorted(inbox.iterdir()) if inbox.exists() else []:
                    if not folder.is_dir() or folder.is_symlink() or folder.name.startswith(('.','示例-')):continue
                    key=records.digest(str(folder.resolve()).encode())[:20]
                    entry=jobs.setdefault(key,{'job_id':key,'folder':str(folder.resolve()),'status':'waiting'})
                    snap,reason=safe_inspect(folder,args.settle_seconds)
                    if entry['status']=='running':
                        result['resume'].append(item(entry));continue
                    if reason:
                        msg=notice(state,entry,reason)
                        if msg:result['attention'].append(msg)
                        continue
                    if entry['status'] in {'completed','blocked'}:
                        msg=notice(state,entry,entry.get('reason') or '制作与预演已完成，请查看结果。')
                        if msg:result['attention'].append(msg)
                    if not snap:continue
                    duplicate=next((e for e in jobs.values() if e.get('input_version')==snap['input_version'] and e['status'] in {'completed','running'}),None)
                    if duplicate:continue
                    same=entry.get('input_version')==snap['input_version']
                    if entry['status']=='blocked' and same and snap['signal']<=entry.get('signal',0):
                        if entry.get('retry_when')=='tool':result['recheck'].append(item(entry))
                        continue
                    result['ready'].append({**item(entry),'input_version':snap['input_version']})
                for entry in jobs.values():
                    if entry['status']=='running' and not Path(entry['folder']).is_dir():
                        entry.update(status='blocked',reason='任务目录已移走；保留已有成果，等待你确认。',retry_when='manual')
                        msg=notice(state,entry,entry['reason'])
                        if msg:result['attention'].append(msg)
            else:
                records.require(args.job in jobs,'scan the exact submission before handling it')
                entry=jobs[args.job];folder=Path(entry['folder']);snap,reason=safe_inspect(folder,args.settle_seconds)
                if args.command=='claim':
                    if any(e['status']=='running' and e['job_id']!=args.job for e in jobs.values()):
                        result={'decision':'busy'}
                    elif entry['status']=='running':result={'decision':'resume',**item(entry)}
                    else:
                        records.require(snap is not None,reason or 'submission is not settled')
                        duplicate=next((e for e in jobs.values() if e.get('input_version')==snap['input_version'] and e['status']=='completed'),None)
                        if duplicate:result={'decision':'reuse',**item(duplicate)}
                        else:
                            same=entry.get('input_version')==snap['input_version']
                            if entry['status']=='blocked' and same and snap['signal']<=entry.get('signal',0):
                                tool_ready=entry.get('retry_when')=='tool' and args.resume_reason and args.resume_reason.strip()
                                user_ready=args.user_message and args.user_message.strip() and args.source_reference and args.source_reference.strip()
                                records.require(tool_ready or user_ready,'resume needs actual tool readiness or an explicit user reply with its source')
                            if args.user_message:
                                records.require(args.source_reference and args.source_reference.strip(),'user reply needs its actual message reference')
                                entry.setdefault('user_replies',[]).append({'text':args.user_message,'source':args.source_reference,'time':records.now()})
                            if 'task_file' not in entry:
                                created=records.execute(records.parser().parse_args(['create','--project-root',str(project),'--store',str(store/'tasks'),
                                    '--title',folder.name,'--request',snap['request']]))
                                entry['task_file']=created['task_file']
                            task=records.load(entry['task_file'])
                            entry.setdefault('history',[]).append({k:entry.get(k) for k in ('input_version','status','signal','reason')})
                            entry.update(snap,status='running',token=uuid.uuid4().hex,reason='',retry_when='manual',baseline_revision=task['revision'])
                            archive=Path(entry['task_file']).parent/'intake'/snap['input_version']
                            records.atomic_write(archive/'需求.md',snap['request'].encode('utf-8'))
                            records.atomic_write(archive/'inputs.json',records.json_bytes(snap))
                            result={'decision':'execute',**item(entry),'request_file':str(archive/'需求.md'),'default_output':'制作与预演；效果由设计师确认后再交付'}
                else:
                    records.require(entry['status']=='running' and args.token==entry['token'],'only the owning running job can check or finish')
                    if args.command=='check':
                        records.require(snap and snap['input_version']==entry['input_version'],'input changed or incomplete; preserve current work and reassess')
                        result={'decision':'unchanged',**item(entry)}
                    else:
                        records.require(args.result,'finish needs an actual outcome')
                        if args.result=='completed':
                            records.require(snap and snap['input_version']==entry['input_version'],'input changed; do not declare completion')
                            task_path=Path(entry['task_file']);task=records.load(task_path);records.check_archives(task,task_path)
                            records.require(task['revision']>entry['baseline_revision'] and records.view(task)['run_status']=='completed'
                                and any(s['status']=='completed' for s in task['stages']),'task actions must actually finish before completing intake')
                            evidence=Path(args.evidence).resolve() if args.evidence else None
                            records.require(evidence and evidence.is_file() and task_path.parent in evidence.parents,'provide actual task result evidence')
                            entry['reason']='制作与预演已完成，请查看结果。'
                        else:
                            records.require(args.reason and args.reason.strip(),'blocked needs the actual reason')
                            entry['reason']=args.reason;entry['retry_when']=args.retry_when
                        entry['status']=args.result
                        card=Path(entry['task_file']).with_name('handoff.md')
                        if not card.exists():card=Path(entry['task_file']).with_name('progress.md')
                        records.atomic_write(folder/'结果.md',('# '+folder.name+'\n\n'+entry['reason']+'\n\n[查看结果](<'+str(card)+'>)\n').encode('utf-8'))
                        result={'decision':args.result,**item(entry),'result_file':str(folder/'结果.md')}
            records.atomic_write(state_file,records.json_bytes(state))
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (OSError,ValueError,KeyError,TypeError) as error:
        print('intake: '+str(error),file=sys.stderr);return 2

if __name__=='__main__':sys.exit(main())
