# ⑤ 验收与交付

制作/预演结束，AI 用真实资源与检查填写清单，运行 `harness.py delivery --job JOB --spec 清单.json`；正式交付时才加 --formal-delivery。手动任务用 --task。

```json
{"assets":[{"path":"Assets/实际.anim","label":"入场动画","role":"formal","playback":true}],"checks":[{"step":"已执行的step","id":"报告中的检查ID","path":"Assets/实际.anim","purpose":"resource","label":"资源回读"}],"visual":true,"confirm":true,"usage":"实际播放/使用方法","previews":[{"path":"预演绝对路径","label":"预演"}]}
```

示例只展示格式，checks 必须按真实证据补齐：

| purpose | 必要证据 |
|---|---|
| resource | 每个正式资源和依赖均检查；Unity 资产须实际加载 |
| dependencies | 正式 Unity 资源保存后的真实引用闭包；报告 check 带 dependency_paths 数组，无依赖写 [] |
| independence | 正式资源脱离 Timeline/Director/预演驱动仍可使用 |
| playback | playback=true 的资源实际播放，采样不替代 |
| visual | visual=true 时按 [表现评审](visual-review.md) 查看本版真实画面；交互效果还须正常速度实际触发，核对主次、动作直觉与风格 |

依赖逐个列为 role=dependency 并检查；Timeline、预演场景/驱动另放 previews。用途涉及回零、重播或事件时补必要检查。资源必须先经 before 跟踪；检查明确 scope=resource_delivery、required=true。脚本校验缺项、版本、依赖和等级。

默认 visual/confirm 为 true；仅明确无需效果验收的任务可关闭。待检查/失败先补查或修正。需要用户确认时 finish --result blocked --reason "等待本版效果确认"。

已观察到的层级、表达或动作直觉问题须保留为 failed 并局部修正；缺真实画面、交互证据或关键设计取舍时保留 pending。文件、绑定、播放成功以及逐帧数量都不能作为审美通过依据。AI 对参考和目标的评审，与真实设计师的当前版确认分别记录。

真实用户同意/拒绝后，先按接单规则 resume 原任务，再运行 `harness.py confirm --job JOB --decision approve/reject --user-message <原话> --source-reference <实际消息引用>`。回复必须针对当前版效果。需求、资源或证据变化后重验；达到 ready_for_programmer 才可说“可以交程序”。程序接入待办单列。
