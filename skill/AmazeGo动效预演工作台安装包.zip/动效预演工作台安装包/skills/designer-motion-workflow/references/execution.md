# ③ 执行与回读

Unity 动作前，查询真实实例、project/info、editor/state 和当前工具 schema。写入串行，定向保存本单资产。使用专项的真实入口；未知 action 先查 schema。uGUI 使用 Prefab/FUI 入口，manage_ui 的 UI Toolkit 不适用。

创建游戏内效果的预演场景，或改变相机、Canvas、显示环境时，先读 [场景基准](scene-baseline.md)。把实际来源文件加入操作 spec 的 inputs/protected，来源节点与实测关键参数记入 parameters；verification_ids 必含 preview.environment。保存后新调用回读，对照来源生成同名必要检查，归入原任务；不能仅凭截图相似或场景可播判通过。

## 写入意图

before 的 --spec 是 AI 根据实际目标填写的 JSON：

```json
{"mode":"update","parameters":{"property":"本轮最终值"},"verification_ids":["实际检查ID"],"inputs":[],"protected":[]}
```

mode 为 create/update；--target 指输出，可重复。输入/受保护路径按实际填写，与输出不重叠。参数采用最终值，不能重复叠乘。改变意图先读现状，确认局部修改后使用新的稳定 step；不能换名绕过冲突。

## 原回执与报告

保存成功的原工具 JSON 放到 save_response_file，运行 saved；再发新工具调用加载磁盘正式资源。script-execute 可返回 `success=true,data={report:专项报告}`，保存整个原回执到 read_response_file，再 checked。内存对象、空成功、嵌套失败不算回读通过。

只读文件检查可直接保存真实 JSON 报告：

```json
{"schema_version":"1.0","skill":"unity-animation-delivery","project_root":"实际工程绝对路径","created_at":"本次执行的 ISO 时间","checks":[{"id":"file","target":"实际文件路径","status":"passed","level":"static","scope":"resource_delivery","required":true,"detail":"实际观察","evidence":["具体证据"],"next_action":null}],"changes":[],"artifacts":[]}
```

Animation 版本是字符串 "1.0"，其它专项为整数 1。未实测用 pending/none，实测失败用 failed 并写下一步。changes/artifacts 只列真实结果；预演标 internal_preview。写入后的验证必须使用原成功工具回执。

采样仅证明采样；动画播放名须在保存后重新加载核验，临时 AddClip 别名不能证明持久化。播放与画面按本单必要项实查。
