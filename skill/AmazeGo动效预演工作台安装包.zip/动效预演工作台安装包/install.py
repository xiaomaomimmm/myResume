#!/usr/bin/env python3
"""Install this local workbench into an ArrowsGo checkout. No Unity writes or scheduler setup."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile

PACKAGE = Path(__file__).resolve().parent
PLATFORMS = {'codex': '.agents', 'claude': '.claude', 'opencode': '.opencode'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def inside(path, root):
    actual = path.resolve()
    return actual == root or root in actual.parents


def verify_package():
    manifest = json.loads((PACKAGE / 'manifest.json').read_text(encoding='utf-8'))
    actual = {p.relative_to(PACKAGE).as_posix() for p in PACKAGE.rglob('*') if p.is_file() and p.name != 'manifest.json'}
    require(actual == set(manifest['files']), 'Package has missing or unlisted files')
    for relative, expected in manifest['files'].items():
        name = PurePosixPath(relative)
        require(not name.is_absolute() and '..' not in name.parts, 'Invalid package path')
        path = PACKAGE.joinpath(*name.parts)
        require(path.is_file() and not path.is_symlink(), 'Missing package file: ' + relative)
        require(hashlib.sha256(path.read_bytes()).hexdigest() == expected, 'Package changed: ' + relative)
    return manifest


def atomic_write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.motion-install-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(content)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def remove_alias(path):
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.exists():
        shutil.rmtree(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, help='ArrowsGo checkout root containing arrowgo-unity')
    parser.add_argument('--check', action='store_true', help='Read-only package and installation preflight')
    parser.add_argument('--update', action='store_true', help='Back up and replace conflicting workbench files/entries')
    parser.add_argument('--platforms', nargs='+', choices=sorted(PLATFORMS), default=['codex'])
    args = parser.parse_args()
    try:
        manifest = verify_package()
        workspace = Path(args.workspace).resolve()
        unity = workspace / 'arrowgo-unity'
        require((unity / 'Assets').is_dir() and (unity / 'ProjectSettings').is_dir(),
                'Select the ArrowsGo checkout root, not the package or arrowgo-unity folder')
        require(not inside(workspace, PACKAGE), 'Cannot install into the distribution package')
        names = manifest['skills']
        planned = {}
        for name in names:
            source = PACKAGE / 'skills' / name
            require((source / 'SKILL.md').is_file(), 'Missing skill: ' + name)
            for file in source.rglob('*'):
                if file.is_file():
                    target = workspace / '.ai/skills' / name / file.relative_to(source)
                    require(inside(target, workspace), 'Source destination leaves workspace: ' + str(target))
                    planned[target] = file.read_bytes()
        planned[workspace / '动效任务/待处理/示例-复制后改名/需求.md'] = (PACKAGE / 'templates/需求.md').read_bytes()
        planned[workspace / '动效任务/工作台使用说明.md'] = (PACKAGE / '工作台使用说明.md').read_bytes()
        aliases = {}
        for platform in set(args.platforms):
            base = workspace / PLATFORMS[platform] / 'skills'
            require(inside(base, workspace), 'Skill registration directory leaves workspace')
            for name in names:
                target = base / name
                require(inside(target.parent, workspace), 'Skill registration leaves workspace')
                text = (PACKAGE / 'skills' / name / 'SKILL.md').read_text(encoding='utf-8')
                end = text.index('\n---', 3) + 4
                wrapper = text[:end] + '\n\n# 项目技能源\n\n必须读取 [完整 Skill](../../../.ai/skills/' + name + '/SKILL.md)，按该源及本次必要参考执行。\n'
                exact = target.is_dir() and not target.is_symlink() and sorted(p.name for p in target.iterdir()) == ['SKILL.md']
                if not exact or (target / 'SKILL.md').read_bytes() != wrapper.encode('utf-8'):
                    aliases[target] = wrapper.encode('utf-8')
        changes = {path: content for path, content in planned.items()
                   if not path.is_file() or path.read_bytes() != content}
        for path in changes:
            require(inside(path, workspace), 'File destination leaves workspace')
            require(not path.exists() or path.is_file(), 'File destination is a directory: ' + str(path))
        conflicts = [str(path.relative_to(workspace)) for path in changes if path.exists()]
        conflicts += [str(path.relative_to(workspace)) for path in aliases if path.exists() or path.is_symlink()]
        deps_path = unity / 'Packages/manifest.json'
        deps = json.loads(deps_path.read_text(encoding='utf-8')).get('dependencies', {}) if deps_path.is_file() else {}
        checks = {'unity_mcp_declared': 'com.coplaydev.unity-mcp' in deps,
                  'script_execute_source': (unity / 'Assets/Editor/MCP/ScriptExecuteTool.cs').is_file(),
                  'spine_sources': (unity / 'Assets/Addons/Spine').is_dir(),
                  'ui_particle_declared': 'com.coffee.ui-particle' in deps,
                  'art2prefab_declared': 'com.learnings.unity.art2prefabtool' in deps,
                  'timeline_extension': (unity / 'Assets/Addons/TimelineExtension').is_dir()}
        info = {'status': 'preflight', 'version': manifest['version'], 'skills': names,
                'files_to_write': len(changes), 'entries_to_register': len(aliases), 'conflicts': conflicts,
                'project_file_checks': checks, 'next': 'Installation still needs a live Unity connection check'}
        if args.check:
            print(json.dumps(info, ensure_ascii=False, indent=2))
            return 0
        require(not conflicts or args.update, 'Existing files differ. Inspect --check, then use --update for a backed-up update')
        backup = None
        file_history = []
        alias_history = []
        if changes or aliases:
            base = workspace / '.local/backups/designer-motion-workbench'
            require(inside(base, workspace), 'Backup destination leaves workspace')
            base.mkdir(parents=True, exist_ok=True)
            backup = Path(tempfile.mkdtemp(prefix=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S-'), dir=str(base)))
        try:
            for path, content in changes.items():
                previous = backup / 'files' / path.relative_to(workspace) if path.exists() else None
                if previous:
                    previous.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(path, previous)
                file_history.append((path, previous))
                atomic_write(path, content)
            for path, wrapper in aliases.items():
                previous = backup / 'entries' / path.relative_to(workspace) if path.exists() or path.is_symlink() else None
                path.parent.mkdir(parents=True, exist_ok=True)
                if previous:
                    previous.parent.mkdir(parents=True, exist_ok=True)
                    path.rename(previous)
                alias_history.append((path, previous))
                path.mkdir()
                atomic_write(path / 'SKILL.md', wrapper)
        except Exception:
            for path, previous in reversed(alias_history):
                remove_alias(path)
                if previous:
                    previous.rename(path)
            for path, previous in reversed(file_history):
                if previous:
                    shutil.copy2(previous, path)
                elif path.exists():
                    path.unlink()
            raise
        if backup:
            # Original relative symlinks are retained by rename; restoring to their original entry path restores their meaning.
            record = {'workspace': str(workspace), 'files': [str(p.relative_to(workspace)) for p, _ in file_history],
                      'entries': [str(p.relative_to(workspace)) for p, _ in alias_history]}
            atomic_write(backup / 'backup-map.json', json.dumps(record, ensure_ascii=False, indent=2).encode('utf-8'))
        info.update(status='installed', backup=str(backup) if backup else None,
                    entry_argv=[sys.executable, '-X', 'utf8', str(workspace / '.ai/skills/designer-motion-workflow/scripts/harness.py'), 'next'],
                    inbox=str(workspace / '动效任务/待处理'),
                    automation_prompt='在当前 ArrowsGo 工程中读取 .ai/skills/designer-motion-workflow/SKILL.md，使用本机 Python 3（启用 UTF-8）运行该技能的 scripts/harness.py next。按 action 续到原任务，只读本次必要专项，遵守场景基准和表现评审。默认制作、预演和检查，真实用户确认当前版效果后再交付。没有可行动变化时安静结束；只在完成、失败或需要用户处理时通知结果和下一步。')
        record_path = workspace / '.local/designer-motion-workbench-installation.json'
        require(inside(record_path, workspace), 'Installation record leaves workspace')
        atomic_write(record_path, json.dumps(info, ensure_ascii=False, indent=2).encode('utf-8'))
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({'status': 'blocked', 'reason': str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
